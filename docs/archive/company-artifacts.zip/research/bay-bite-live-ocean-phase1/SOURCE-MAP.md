# Bay Bite Live Ocean Phase 1 — official sensor/source map

**Prepared:** 2026-08-13 (UTC)  
**Scope:** Greater San Francisco Bay / Peninsula shore-fishing command center. Official NOAA/NDBC/CDIP primary sources only. This is a source and truth-labeling recommendation, not an implementation change.

## Executive decision

Phase 1 should model **four different products**, never one generic “station”: (1) CO-OPS **observed water level**, (2) CO-OPS **tide prediction**, (3) CO-OPS **observed current**, and (4) NDBC/CDIP **offshore or nearshore wave observation**. A tide-prediction station is not necessarily a sensor, an offshore buoy is not a beach gauge, and ocean swell must not be displayed as an inner-Bay observation.

Minimum truthful UI label:

> **Observed at {official station name} ({ID}), {distance_nm} nm from selected spot · {environment class} · observation {age}. Not measured at this beach/shoreline.**

For predictions:

> **NOAA tide prediction for {official station name} ({ID}); modeled astronomical tide, not a live observation. Local timing/height may differ.**

For all readings retain `source`, `product_kind`, official `station_id/name/lat/lon`, `observed_at`, `fetched_at`, `age`, units, datum/bin where relevant, distance to spot, environment class, and representativeness warning. Do not use “live” without a valid observation timestamp and per-field freshness.

## Verified official station map

Coordinates and active product classes below came from the CO-OPS Metadata API station collections ([official MDAPI documentation](https://api.tidesandcurrents.noaa.gov/mdapi/prod/)) and NDBC’s current active-station XML ([official live XML](https://www.ndbc.noaa.gov/activestations.xml)). CO-OPS explicitly distinguishes active `waterlevels`, active `currents`, and `tidepredictions`; those sets are not interchangeable.

### Tide/water-level stations

| Coverage | ID — official name | Coordinates | Capability verified 2026-08-13 | Phase-1 use |
|---|---|---:|---|---|
| SF coast / Golden Gate | **9414290 — San Francisco** (prediction listing: “SAN FRANCISCO (Golden Gate)”) | 37.806305, -122.465890 | Active 6-minute water level; harmonic tide prediction; station also exposes physical-ocean/met products. A `date=latest&product=water_level` request returned a timestamped observation. [Station](https://tidesandcurrents.noaa.gov/stationhome.html?id=9414290) · [verified endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?date=latest&station=9414290&product=water_level&datum=MLLW&time_zone=gmt&units=metric&format=json) | Primary observed level for Golden Gate/SF waterfront; prediction anchor for Gate-adjacent spots. Not an Ocean Beach wave/swash gauge. |
| Outer SF beach | **9414275 — Ocean Beach, outer coast** | 37.775000, -122.513000 | Tide **prediction** station; no active water-level observation in the official waterlevels collection. [Prediction endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?begin_date=20260813&end_date=20260814&station=9414275&product=predictions&datum=MLLW&time_zone=gmt&units=metric&interval=hilo&format=json) | Prefer for Ocean Beach tide timing; label `Predicted`, never `Observed`. |
| Half Moon Bay / Pillar Point | **9414131 — Pillar Point Harbor, Half Moon Bay** | 37.502500, -122.482167 | Tide **prediction only** in current product collections. Live-water-level request returned “No data was found.” [Prediction endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?begin_date=20260813&end_date=20260814&station=9414131&product=predictions&datum=MLLW&time_zone=gmt&units=metric&interval=hilo&format=json) · [failed live-product endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?date=latest&station=9414131&product=water_level&datum=MLLW&time_zone=gmt&units=metric&format=json) | Tide timing for HMB/Pacifica when selected as nearest appropriate prediction. Never call it a live tide sensor. |
| Inner/East Bay | **9414750 — Alameda** | 37.771954, -122.300260 | Active water level + prediction; latest endpoint returned data. [Station](https://tidesandcurrents.noaa.gov/stationhome.html?id=9414750) | Alameda/Oakland vicinity observed level, with distance shown. |
| Inner/North Bay | **9414863 — Richmond** | 37.928300, -122.400000 | Active water level + prediction. [Station](https://tidesandcurrents.noaa.gov/stationhome.html?id=9414863) | Richmond/San Pablo vicinity observed level. |
| South Bay | **9414523 — Redwood City** | 37.506813, -122.211906 | Active water level + prediction. [Station](https://tidesandcurrents.noaa.gov/stationhome.html?id=9414523) | Primary South Bay observed level. Local subordinate predictions may be closer for timing. |
| South Bay subordinate predictions | **9414458 — San Mateo Bridge (west end)**; **9414509 — Dumbarton Highway Bridge**; **9414392 — Oyster Point Marina** | 37.580,-122.253; 37.5067,-122.115; 37.665,-122.377 | Tide-prediction stations, not active water-level sensors in MDAPI. [Official prediction list/API type](https://api.tidesandcurrents.noaa.gov/mdapi/prod/webapi/stations.json?type=tidepredictions) | Predicted tide only. Pair with Redwood City observation only if clearly shown as a separate, distant observed source. |
| Carquinez / Delta edge | **9415102 — Martinez-Amorco Pier** | 38.034600, -122.125200 | Active water level + prediction. [Station](https://tidesandcurrents.noaa.gov/stationhome.html?id=9415102) | Primary Martinez/Benicia-area observed level. |
| Carquinez / Suisun | **9415144 — Port Chicago** | 38.056000, -122.039500 | Active water level + prediction. [Station](https://tidesandcurrents.noaa.gov/stationhome.html?id=9415144) | Suisun/Delta-side observed level. |
| Benicia / Vallejo local tide timing | **9415111 — Benicia**; **9415165 — Vallejo, Mare Island Strait** | 38.0433,-122.130; 38.1117,-122.273 | Prediction stations, not active observed-water-level stations in the current collection. [Official prediction collection](https://api.tidesandcurrents.noaa.gov/mdapi/prod/webapi/stations.json?type=tidepredictions) | Prediction only; use Martinez/Port Chicago for clearly separate observations. |
| Bodega Harbor | **9415625 — Bodega Harbor entrance** | 38.308300, -123.055000 | Tide prediction station; no active water-level sensor in MDAPI. [Prediction endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?begin_date=20260813&end_date=20260814&station=9415625&product=predictions&datum=MLLW&time_zone=gmt&units=metric&interval=hilo&format=json) | Correct Bodega tide ID; prediction only. |
| Napa River | **9415623 — Napa, Napa River** | 38.298300, -122.280000 | Tide prediction station; no active water-level sensor in MDAPI. [Prediction endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?begin_date=20260813&end_date=20260814&station=9415623&product=predictions&datum=MLLW&time_zone=gmt&units=metric&interval=hilo&format=json) | Napa prediction only. This ID is **not Bodega Harbor**. |

Other current-code labels such as “Berkeley,” “Corte Madera Creek,” and “Sausalito, Corps of Engineers Dock” can still be used for predictions, but only under their official names and as predictions: 9414816 Berkeley (37.865,-122.307), 9414874 Corte Madera Creek (37.9433,-122.513), and 9414819 Sausalito, Corps of Engineers Dock (37.865,-122.493). The official station-type definitions are in [MDAPI](https://api.tidesandcurrents.noaa.gov/mdapi/prod/).

### Observed current stations (CO-OPS SF Bay PORTS)

The official [San Francisco Bay PORTS page](https://tidesandcurrents.noaa.gov/ports/index.html?port=sf) identifies current meters separately from water levels and waves. The active-current MDAPI query contained four nearby deployed stations:

| ID — official name | Coordinates | Live status at verification | Truthful use |
|---|---:|---|---|
| **s06010 — Martinez-AMORCO Pier** | 38.034630, -122.125252 | Latest `currents` returned speed/direction/bin at 16:21 UTC. [Endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?date=latest&station=s06010&product=currents&time_zone=gmt&units=metric&format=json) | Carquinez only; depth-bin current, not shoreline current. |
| **s08010 — Southampton Shoal Channel LB6** | 37.916250, -122.422330 | Latest observation returned at 16:21 UTC. [Endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?date=latest&station=s08010&product=currents&time_zone=gmt&units=metric&format=json) | Central/north Bay channel context; not Marin beach current. |
| **s09010 — Oakland Outer Harbor LB3** | 37.808200, -122.344340 | Listed active, but `date=latest` returned no data at verification. [Endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?date=latest&station=s09010&product=currents&time_zone=gmt&units=metric&format=json) | `Unavailable` until a fresh row exists; predictions are a separate product. |
| **s10010 — Oakland Inner Harbor LB4** | 37.800970, -122.347750 | Latest observation returned at 16:21 UTC. [Endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?date=latest&station=s10010&product=currents&time_zone=gmt&units=metric&format=json) | Oakland inner-harbor channel context only. |

**SFB1202 — Golden Gate Currents** appears on PORTS as a currents product, but the live `currents` Data API request failed while `currents_predictions` succeeded during verification. Treat SFB1202 as **prediction-only/unavailable for observed current unless a fresh observed endpoint is independently confirmed**. [Prediction endpoint](https://api.tidesandcurrents.noaa.gov/api/prod/datagetter?date=latest&station=SFB1202&product=currents_predictions&time_zone=gmt&units=metric&format=json)

### Offshore and nearshore wave platforms

| Class | ID — official name | Coordinates | Capabilities/current caveats | Representative scope |
|---|---|---:|---|---|
| Offshore/met-ocean | **46026 — SAN FRANCISCO, 18 NM west of San Francisco** | 37.750,-122.838 | NDBC 3-m buoy; stdmet plus spectral wave summary; wind, pressure, water temperature and wave fields vary independently. [Station](https://www.ndbc.noaa.gov/station_page.php?station=46026) · [stdmet](https://www.ndbc.noaa.gov/data/realtime2/46026.txt) · [spectral summary](https://www.ndbc.noaa.gov/data/realtime2/46026.spec) | Regional open-ocean forcing for SF/Peninsula; about **15.5 nm from Ocean Beach** and **17.8 nm from Pacifica** (great-circle calculations). Not beach-local and never for inner Bay. |
| Offshore/met-ocean | **46012 — HALF MOON BAY, 24 NM SSW of San Francisco** | 37.356,-122.881 | Currently an NDBC-hosted **uncrewed surface vehicle**, not a fixed classic moored HMB buoy; stdmet/wave reporting is available but field cadence/completeness varies. [Station](https://www.ndbc.noaa.gov/station_page.php?station=46012) · [stdmet](https://www.ndbc.noaa.gov/data/realtime2/46012.txt) | Regional Peninsula/HMB open ocean; about **20.8 nm from Pillar Point**, **24.9 nm from Pacifica**, **30.0 nm from Ocean Beach**. Not harbor or shore-break data. |
| Offshore/met-ocean | **46013 — BODEGA BAY, 48 NM NW of San Francisco** | 38.235,-123.317 | NDBC 3-m buoy with stdmet and spectral-wave files; on verification WTMP was missing while wave spectra reported separately. [Station](https://www.ndbc.noaa.gov/station_page.php?station=46013) · [stdmet](https://www.ndbc.noaa.gov/data/realtime2/46013.txt) · [spectral summary](https://www.ndbc.noaa.gov/data/realtime2/46013.spec) | Regional Bodega open ocean; about **13.8 nm from Bodega Harbor**, not harbor/jetty conditions. |
| Nearshore wave | **46237 / CDIP 142 — San Francisco Bar** | 37.788,-122.634 | Scripps/CDIP Waverider in 16.76 m water; wave and water-temperature capability, no wind. It had **“No Recent Reports”** on 2026-08-13; newest realtime row was 2026-08-03, so stale/unavailable. [NDBC-hosted CDIP station page](https://www.ndbc.noaa.gov/station_page.php?station=46237) · [realtime](https://www.ndbc.noaa.gov/data/realtime2/46237.txt) | Best spatial wave match for SF Bar/outer SF when fresh (about **6.1 nm from Ocean Beach**), but still not beach-local; do not fall through silently to old data. |
| Former/unsupported | **46247 — San Francisco Offshore, CDIP 180** | historical 37.753,-122.833 | Not in current NDBC active XML and realtime files returned 404 during verification. [Official station table](https://www.ndbc.noaa.gov/data/stations/station_table.txt) | Do not map in Phase 1 unless CDIP/NDBC restores a verified live endpoint. |

NDBC says realtime files contain the last 45 days of automated-real-time-QC data, while `activestations.xml` records whether each product class reported within the last eight hours; the all-station latest-observation file is refreshed about every five minutes and includes only observations under two hours old. See the [official NDBC Web Data Guide](https://www.ndbc.noaa.gov/docs/ndbc_web_data_guide.pdf). An “active station” entry therefore does **not** prove every field is current.

## Current code mappings that are misleading or unsupported

Read-only inspection of `scripts/update-live-data.mjs`, `src/telemetry.ts`, and `src/App.tsx` found:

1. **Bodega and Napa IDs are reversed.** Code maps `Bodega Harbor → 9415623`, but 9415623 is **Napa, Napa River**. It maps `Napa River → 9415625`, but 9415625 is **Bodega Harbor entrance**.
2. **Vallejo is physically wrong.** `9415423` is **Lakeville, Petaluma River** (38.1983,-122.547), not Mare Island/Vallejo. Use 9415165 for Vallejo tide prediction, or a clearly labeled active observed station such as Richmond/Martinez depending on purpose.
3. **Benicia is mislabeled.** `9415118` is the **Union Pacific RR Bridge** PORTS station, not “Benicia Bridge” and not the tide-prediction station named Benicia. Use 9415111 for Benicia prediction and 9415102 Martinez-Amorco for the nearest supported observed water level.
4. **San Rafael and Tiburon labels invent sensor locations.** 9414874 is **Corte Madera Creek**, not “San Rafael Creek”; 9414819 is **Sausalito, Corps of Engineers Dock**, not Tiburon Ferry Terminal.
5. **Berkeley label is wrong.** 9414816 is officially **Berkeley**, not Point Isabel. It is a prediction station, not an active water-level sensor.
6. **Oakland 9414763 is conflated.** PORTS calls 9414763 **Oakland Berth 67**; the tide-prediction collection uses the historic name **Oakland Harbor, Grove Street**. It is not the observed-current station “Oakland Inner Harbor LB4” (that is **s10010**).
7. **Prediction stations are queried as live water sensors.** 9414131, 9414458, 9414509, 9414816, 9414874, 9414819, 9415623 and 9415625 support prediction use but are not in the active observed-water-level collection. HTTP 200 with a JSON `error` body is currently treated as a fulfilled fetch, which can falsely improve source health.
8. **Offshore waves are mapped to inland waters.** 46026/46012 are reused for Richmond, Berkeley, Alameda, Oakland, Redwood City, San Mateo, San Rafael, Tiburon, Dumbarton, Benicia, Vallejo and Napa. A warning string does not make those ocean waves representative. The truthful Phase-1 choice is **no wave observation** for inner Bay/South Bay/Carquinez, not a distant offshore number.
9. **46026 is called “San Francisco Bar.”** Its official name is **SAN FRANCISCO — 18 NM West**. The nearshore San Francisco Bar buoy is 46237/CDIP 142.
10. **Unit corruption in the browser path.** Cached buoy fields are `waveHeightM`, `dominantPeriodSec`, and `waterTempC`, but `App.tsx` reads nonexistent `swellHeightFt`, `swellPeriodSec`, and `waterTempF`, then passes them into functions expecting meters/Celsius. CO-OPS is requested with `units=english`, yet its wind value is passed as `windSpeedMps` and multiplied by 1.94384 again. CO-OPS English wind is already knots. This can misstate wind and suppress buoy data.
11. **Freshness is aggregated from the newest source timestamp.** One recent wind row can make an old wave field look fresh. Freshness and health must be per field/product; predictions should not count toward observation freshness.
12. **`updatedAt` is UI render time, not observation time.** It must be labeled `Fetched` if retained; show source observation time separately.
13. **Silent global fallback is unsafe.** Unknown tide labels default to 9414290/46026, implying SF ocean telemetry for any unmapped spot. Unknown mappings should return `unavailable`, never a default station.

## Truthful minimum mapping for Phase 1

| Spot environment | Tide prediction | Observed level | Observed current | Wave observation |
|---|---|---|---|---|
| Ocean Beach / outer SF | 9414275 Ocean Beach | 9414290 San Francisco only as **distant Golden Gate level context** | None; SFB1202 prediction may be shown separately | 46237 SF Bar only when fresh; otherwise 46026 as **offshore regional** |
| Golden Gate / SF waterfront | 9414290 | 9414290 | No observed Gate current currently verified; SFB1202 prediction only | 46237/46026 only for Gate-approach ocean context, never protected waterfront wave height |
| Pacifica / HMB | 9414131 Pillar Point (or 9414275 where objectively nearer; compute distance) | None | None | 46012 offshore regional; show distance and USV/platform status |
| Bodega | 9415625 Bodega Harbor entrance | None | None | 46013 offshore regional |
| Inner SF Bay / East Bay | nearest supported local prediction; preserve official name | choose among 9414290, 9414750, 9414863 based on geography | s08010/s10010 only for nearby channel context; s09010 only when fresh | **Unavailable** (do not map ocean buoy) |
| South Bay | nearest local subordinate prediction (e.g. 9414392/9414458/9414509) | 9414523 Redwood City, clearly separate from prediction station | None in minimum set | **Unavailable** |
| Carquinez / Delta edge | 9415111 Benicia or local subordinate prediction | 9415102 Martinez-Amorco or 9415144 Port Chicago | s06010 Martinez-AMORCO Pier | **Unavailable** |
| Napa River | 9415623 Napa, Napa River prediction | None in minimum set | None | **Unavailable** |

**Representativeness policy:** always calculate great-circle station-to-spot distance from official coordinates. Use environment compatibility before nearest distance. Display `nearshore`, `offshore`, `harbor/channel`, `inner_bay`, or `tidal_river`. A practical warning rule for Phase 1: always warn on offshore/nearshore waves because none is beach-local; additionally mark `distant` at >10 nm, and `very distant` at >25 nm. Distance thresholds are product policy, not NOAA claims. Never translate buoy significant wave height into expected breaking-wave height.

## Fields, units, cadence, missingness

### CO-OPS

The official [CO-OPS Data API documentation](https://api.tidesandcurrents.noaa.gov/api/prod/) defines products and units:

- `water_level`: timestamp `t`, height `v` relative to required datum (use and display **MLLW**), sigma `s`, flags `f`, quality `q`; 6-minute observations; metric meters or English feet.
- `predictions`: `t`, predicted height `v`, and for high/low requests `type` (`H`/`L`); predictions are modeled and have no observation freshness.
- `wind`: speed `s`, direction degrees `d`, compass direction `dr`, gust `g`; metric m/s or English knots.
- `water_temperature`/`air_temperature`: `v`; °C metric / °F English. `air_pressure`: hPa/mb. `conductivity`: mS/cm. `salinity`: practical salinity value as returned. `visibility`: km metric / nautical miles English.
- `currents`: `t`, speed `s`, direction `d`, bin `b`; metric **cm/s**, English knots. Bin/depth metadata is mandatory context; default observation interval is 6 minutes.
- `currents_predictions`: predicted velocity/direction and bin/depth; keep separate from observed current.

CO-OPS documents `date=latest` as the last point available **within 18 minutes** for eligible observations. A JSON `error` object, empty `data`, invalid timestamp, or flagged/null/non-finite value is unavailable even when HTTP status is 200. Store UTC (`time_zone=gmt`) to avoid timezone ambiguity.

### NDBC/CDIP through NDBC

NDBC standard-meteorological headers and base units are documented by the [Measurement Descriptions and Units page](https://www.ndbc.noaa.gov/faq/measdes.shtml#stdmet) and are visible in each official realtime file:

- `WDIR` degrees true; `WSPD`, `GST` m/s; `WVHT` significant wave height m; `DPD`, `APD` seconds; `MWD` degrees true.
- `PRES` hPa; `ATMP`, `WTMP`, `DEWP` °C; `VIS` nautical miles; `PTDY` hPa; `TIDE` feet.
- Spectral summary (`.spec`): `WVHT`, swell height/period/direction (`SwH`, `SwP`, `SwD`), wind-wave height/period/direction (`WWH`, `WWP`, `WWD`), `STEEPNESS`, `APD`, `MWD`. [Example official file](https://www.ndbc.noaa.gov/data/realtime2/46026.spec)

Use `.spec` when swell/wind-wave partition fields are required; do not rename total significant `WVHT` to “swell height.” `MM` is the standard missing token in stdmet/spectral summaries. Other NDBC datasets use numeric fill sentinels (observed official examples include `-99` and `999`); parse from each product specification and reject documented fills/nonphysical values rather than globally treating every number as data.

NDBC cadence is station/field dependent: verified samples showed 46013/46026 stdmet rows at 10-minute spacing with wave fields on a different cadence, while 46012 was hourly. Determine expected cadence from recent valid timestamps per field; do not hard-code “10 minutes” for all buoys.

### Recommended freshness state machine

Apply independently to every observed field, based on `observed_at`, expected station/field cadence, and current UTC:

- `live`: age ≤ max(2 × expected cadence, 18 min for CO-OPS eligible latest products).
- `delayed`: above live threshold but ≤ 2 hours.
- `stale`: >2 hours; show last value only with age and never in a “current conditions” score.
- `unavailable`: no valid value/time, source error, unsupported product, or stale beyond a product-specific retention cap.
- `partial`: aggregation label only when at least one field is usable and at least one requested field is delayed/stale/unavailable; each field still keeps its own state.

These thresholds are Bay Bite policy. NDBC’s own latest-observation inclusion cutoff is two hours and active product signal is eight hours ([NDBC Web Data Guide](https://www.ndbc.noaa.gov/docs/ndbc_web_data_guide.pdf)); those are useful outer bounds, not permission to call an eight-hour value live.

## Later-source priorities (after Phase 1 truthfulness)

1. **NWS marine forecast and alerts (next):** resolve each selected spot through `https://api.weather.gov/points/{lat},{lon}`, then consume the returned forecast/grid URLs and active alerts. Keep `Forecast` and `Alert` visually separate from observations. Official API examples/documentation: [weather.gov API](https://www.weather.gov/documentation/services-web-api). Also support marine zones returned by NWS rather than assuming one Bay-wide forecast.
2. **NOAA CoastWatch SST/chlorophyll (second):** use West Coast ERDDAP datasets for pixel/composite satellite context. Label sensor/platform, product, acquisition/composite time, cloud/missing mask, pixel distance/resolution, and `Satellite context—not an in-water observation`. Official entry points: [West Coast ERDDAP](https://coastwatch.pfeg.noaa.gov/erddap/index.html), [SST product family](https://coastwatch.noaa.gov/cwn/product-families/sea-surface-temperature.html), [ocean color/chlorophyll](https://coastwatch.noaa.gov/cwn/product-families/ocean-color.html).
3. **HAB/shellfish/crab health (third, safety-critical):** ingest authoritative CDPH advisory state and geographic extent; never infer harvest safety from chlorophyll or red-tide color. [CDPH Shellfish and Seafood Advisories](https://www.cdph.ca.gov/Programs/OPA/Pages/Shellfish-Advisories.aspx) and [Marine Biotoxin Monitoring Program](https://www.cdph.ca.gov/Programs/CEH/DRSEM/Pages/EMB/Shellfish/Marine-Biotoxin-Monitoring-Program.aspx).
4. **Beach closure/bacteria and broader water quality (fourth):** consume state/local agency advisory records with sample date, jurisdiction and explicit status; distinguish swim-contact advisories from fishing/seafood closures. Official California Water Boards portals: [Beach Water Quality](https://www.waterboards.ca.gov/water_issues/programs/beaches/beach_water_quality/) and [Beach Monitoring Data](https://www.waterboards.ca.gov/water_issues/programs/beaches/search_beach_mon.html). Local county health departments may be the issuing authority; only add one after its official endpoint and update behavior are verified.

## Endpoint verification notes and uncertainties

- Requests were made on 2026-08-13 around 16:00–16:25 UTC against CO-OPS MDAPI/Data API, NDBC active XML, and NDBC realtime files. Live conditions can change after this report.
- 46237 was still present in NDBC active XML but had `met="n"`; its station page said “No Recent Reports,” and newest realtime row was 2026-08-03. **Operational status is therefore stale/unavailable, not safely “active.”**
- 46012 is currently represented by an uncrewed surface vehicle with a very large watch-circle value on its official page. Exact platform position behavior/representativeness should be revalidated from current metadata each refresh; do not assume a permanently fixed mooring.
- CO-OPS subordinate prediction station names can differ from nearby modern PORTS observing-station names. Preserve official ID + exact product-specific name and do not normalize names into invented landmarks.
- No currently reporting beach-local wave sensor was verified for Pacifica/Half Moon Bay beaches. Phase 1 must say so rather than implying one.
