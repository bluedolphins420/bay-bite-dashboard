# Bay Bite local-fauna intelligence — source audit 001

- **Date:** 2026-08-13
- **Owner:** Priya Chen (research brief), reconciled by Arthur Blake
- **Evidence status:** verified source and architecture audit; implementation acceptance pending
- **Scope:** San Francisco Bay, Golden Gate, SF Peninsula open coast; shore-accessible recreational fishing
- **Decision:** reuse maintained official/scientific data products before building derived priors

## Outcome

Bay Bite should estimate **relative fishing opportunity**, not current fish presence. It must keep five concepts separate:

1. historical/geographic occurrence evidence;
2. life-stage habitat suitability;
3. current/forecast condition suitability;
4. legal/access/MPA targetability;
5. shore presentation fishability.

Historical occurrence is never evidence that a fish is present now. Survey non-detection is never true absence unless method, effort, season, life stage, and habitat support that inference.

## Current-system audit

- The generated catalog has 24 exact taxa, but all 24 were marked compatible with all nine habitats. This prior is scientifically invalid.
- The richer `regulations-science-data.ts` layer has 22 labels, including aggregates such as Rockfish, Surfperch, and Flatfish; these cannot safely drive exact-taxon biology or regulations.
- The visible UI still uses legacy static `score`, `bestWindow`, and `biteReason` values.
- The normalized recommendation path usually returns no rankable taxa because `livePresenceVerified` and exact MPA resolution fail closed. Live presence is not a realistic prerequisite for a prediction system.
- Generic solunar, barometric-pressure, fixed lure-frequency, and exact temperature-optimum claims are not sufficiently supported for general score multipliers.

## Reuse decision matrix

### 1. Integrated San Francisco Estuary fish surveys (`deltafish` / EDI)

- **Product:** `Delta-Stewardship-Council/deltafish`
- **Data package:** `edi.1075.1`
- **Data DOI:** `10.6073/pasta/0cdf7e5e954be1798ab9bf4f23816e83`
- **Package DOI:** `10.5281/zenodo.6484439`
- **Scale:** about 45 million integrated fish rows from long-term surveys beginning in 1959.
- **Capabilities:** exact taxa, count/length, sample and station joins, time, environmental and effort fields; version-pinned local SQLite workflow.
- **License:** package is MIT; data citation and package metadata must be retained.
- **Adopt for:** Bay/Delta occurrence, age/life-stage, regional/monthly phenology, and environmental association derivatives.
- **Limitations:** heterogeneous gears/programs; effort and zero-catch semantics must be retained; many surveys emphasize channels/open water and young fish; data do not establish shore-level presence.
- **Decision:** **adopt** as core estuarine historical prior, with method-stratified derivatives.

### 2. CDFW/IEP San Francisco Bay Study

- **Official page:** https://wildlife.ca.gov/Conservation/Delta/Bay-Study
- **Current EDI publication:** `10.6073/pasta/57f1c6a838f72a7e4ae4fb860d5c5e26` (1980–2025 publication found during audit)
- **Design:** 52 fixed open-water stations sampled monthly; midwater and otter trawls; counts, lengths, effort, depth, Secchi, salinity/conductivity, temperature, tide/wave/cloud categories.
- **Adopt for:** Central/South/San Pablo/Suisun/West Delta regional seasonality; pelagic versus demersal occurrence; juvenile versus adult context where lengths permit; historical environmental associations.
- **Limitations:** boat/open-water design; trawl selectivity; poor representation of rocks, eelgrass interiors, very shallow shore edges, surf, and inaccessible structure. A station is not a casting point.
- **Decision:** **adopt** with gear, station, effort, age/length, and temporal metadata visible.

### 3. NOAA Marine Cadastre SF Bay Benthic Habitats 2011

- **Download:** https://marinecadastre.gov/downloads/data/benthic/san_francisco_bay_2011.zip
- **Verified artifact:** 35,877,391-byte zip containing a 59,379,712-byte GeoPackage.
- **Verified feature layers:** CMECS biotic (6,103 features), geoform (1,640), substrate (6,409).
- **Examples:** unconsolidated mineral substrate, anthropogenic rock, rock substrate; marsh platform, tidal flat, rip-rap; emergent tidal marsh, macroalgae, vascular vegetation, seagrass.
- **Adopt for:** broad benthic substrate/geoform/biotic intersection with public spot coordinates and map overlays.
- **Limitations:** 2011 survey vintage; broad polygons are not present-day microhabitat or bathymetric truth; some attributes are sparse.
- **Decision:** **adopt** as versioned habitat baseline; show year and regional-resolution caveat.

### 4. BCDC/SFEI SF Bay eelgrass maximum surveyed extent

- **Dataset:** https://data.cnra.ca.gov/dataset/sf-bay-eelgrass-bcdc-2020
- **Feature service:** https://services2.arcgis.com/4Z9x989NrBVrvFwm/arcgis/rest/services/SF_eelgrass_BCDC_2020_simple/FeatureServer/0
- **Verified service:** GeoJSON query works; one multipart public polygon, EPSG:4326, 5,113 acres / 20,692,201 m², with survey lineage 2003, 2009, 2014 and/or Richardson Bay 2019.
- **Rights:** no restrictions on public use per state open-data record.
- **Adopt for:** regional eelgrass association and forage/habitat context.
- **Limitations:** maximum historical surveyed extent, not current bed boundary; dynamic habitat; not a site-specific survey.
- **Decision:** **adopt**, label as historical maximum extent and never infer current eelgrass at a casting point.

### 5. CARI / BAARI / Baylands Habitat Map

- **CARI:** https://www.sfei.org/projects/california-aquatic-resource-inventory-cari
- **Developer/data reference:** https://ecoatlas.org/developers/
- **Capabilities:** standardized aquatic polygons/lines for estuary, wetland, slough, marsh, beach, rocky intertidal, salinity and other landscape features; current release lineage includes BAARI and Baylands Habitat Map.
- **Adopt for:** water-body and shore habitat classification, slough/marsh/baylands context, and map overlays outside the 2011 benthic footprint.
- **Limitations:** multiple source years and regional detail levels; landscape map, not current local conditions.
- **Decision:** **adopt**, pin exact version and source date per feature.

### 6. OBIS and GBIF

- **OBIS API:** https://api.obis.org/
- **GBIF occurrence API:** https://techdocs.gbif.org/en/openapi/v1/occurrence
- **Verified:** all 24 catalog scientific names resolved exactly through GBIF species matching; polygon occurrence query works through OBIS.
- **Adopt for:** supplemental museum/research occurrence, taxonomy reconciliation, coastal observations outside Bay Study coverage.
- **Limitations:** opportunistic and uneven sampling, duplicates, coordinate and identification quality, absence of standardized effort.
- **Decision:** **supplement only**; deduplicate datasets/records and never use raw record density as abundance.

### 7. Acoustic telemetry / OTN / PATH / published studies

- **Examples:** Sabal et al. adult movement; Le Doux-Bloom et al. sub-adult seasonal habitat use; OTN/PATH study records.
- **Adopt for:** life-stage movement corridors, migration phenology, contingent behavior, and uncertainty statements.
- **Limitations:** tagged sample, receiver coverage, study years, age/size and detection bias; not a live fish detector.
- **Decision:** **adopt as movement evidence**, not current presence.

### 8. NOAA/IOOS/USGS live and forecast environment

- **Services:** NOAA CO-OPS, NDBC, ERDDAP/IOOS, USGS/CDEC where licensed and operational.
- **Variables:** water level/tide/current where available, water temperature, salinity/conductivity, waves/swell, wind, SST, chlorophyll, upwelling indices, freshwater outflow.
- **Adopt for:** observed and forecast condition suitability and shore fishability.
- **Limitations:** station/grid distance, depth mismatch, proxy variables, product latency, quality flags, missingness.
- **Decision:** **adopt server-side** with station/product binding, quality/freshness, observed-versus-modeled state, and no favorable missing defaults.

## Evidence pruning

Do not use the following as general model multipliers unless calibrated to local exact-taxon catch/effort data and independently validated:

- commercial solunar table scores or lunar transit windows;
- generic barometric-pressure “feeding frenzy” rules;
- universal lure-vibration frequency bands;
- one-number “optimal temperatures” from secondary angling analyses;
- raw social catch counts without effort, reporting-bias, location-resolution and date controls;
- survey non-detection as absence outside supported gear/habitat/life-stage scope.

Lunar illumination, atmospheric pressure trend, and similar variables may be retained as candidate covariates for future calibration. They must have zero default causal weight.

## Exact-taxon vertical slice

### Morone saxatilis — striped bass

- Anadromous/euryhaline with resident and migratory contingents; geography and salinity use vary by life stage, season, sex and individual.
- Local telemetry supports Bay/Delta/river seasonal movement and life-stage differences.
- USGS 2022 diet work (`10.15447/sfews.2022v20iss3art4`) shows spring/summer estuarine diets can be dominated by amphipods, isopods, and decapods across marsh/shoal/channel contexts; fish prey is important but not universal.
- Engine implication: forage and presentation must reflect habitat and season, not always baitfish imitation; Bay/coast opportunity must be distinct.

### Paralichthys californicus — California halibut

- CDFW ESR: shallow nearshore soft sand/mud, bays and estuaries; estuarine and open-coast nursery use; adult seasonal movement.
- Juveniles consume crustaceans and small fish; larger fish increasingly consume anchovy, sardine, squid and other fishes.
- Engine implication: strong soft-bottom and depth-zone dependence; adjacent rock does not equal suitable bottom; nursery occurrence does not mean legal adult availability. Do not encode a single 61°F optimum.

### Amphistichus argenteus — barred surfperch

- CDFW ESR: open-coast sandy beach is primary; Bay/estuary use is lower and episodic, including life-history movements.
- Diet: Pacific mole crab, amphipods, caprellids, polychaetes, plus occasional small fishes/eggs.
- Engine implication: surf habitat and trough/swash fishability dominate; estuarine historical records should not produce a generic Bay target recommendation.

## Required derivative schema

Each geographic occurrence/habitat derivative must retain:

- exact scientific taxon ID and accepted name;
- life stage or length basis;
- source and version/DOI;
- survey/detection method and gear;
- effort and zero-catch semantics where available;
- public geometry/station/region and spatial resolution;
- start/end time coverage and seasonal sampling;
- observed versus modeled status;
- evidence grade and limitations;
- transformation code/version and generated date.

Each model result must separately report:

- `targetability`: legal/access/MPA fail-closed gate;
- `historicalOccurrence`: evidence-supported geographic prior;
- `habitatFit`: life-stage × salinity × substrate × structure × depth;
- `conditionFit`: observed/forecast variables with quality and freshness;
- `fishability`: ability to present safely/effectively from shore;
- `opportunity`: relative band/score only when support is sufficient;
- `confidence`: evidence coverage, not probability of a catch;
- factor contributions, missing inputs, caveats, and source IDs.

## Calibration roadmap

1. Generate method-stratified monthly-region-life-stage priors from version-pinned Bay Study/deltafish data.
2. Intersect public spot points and shore-reachable buffers with pinned CMECS/CARI/eelgrass layers; retain year and resolution.
3. Build exact-taxon response rules only from CDFW/NOAA/USGS/peer-reviewed claims.
4. Use Bay Bite trip logs as privacy-protected presence/background or catch-per-effort observations, not raw success labels.
5. Backtest by holding out years, regions, and anglers; compare against season-only, spot-only, and static legacy baselines.
6. Calibrate uncertainty and opportunity bands; do not publish point scores that are not demonstrably better than baselines.
7. Expand from three taxa to all locally actionable exact taxa only after source and test coverage pass.

## Acceptance principles

- Unknowns reduce confidence or produce `insufficient-data`.
- Closures/access/MPA uncertainty produce `not-targetable`, not a low ecological score.
- No static legacy score/window may be labeled as model output.
- Map overlays display evidence method, age, resolution and confidence.
- No client-side live calls to third-party science APIs.
- No claim that Bay Bite knows a fish is present now.
