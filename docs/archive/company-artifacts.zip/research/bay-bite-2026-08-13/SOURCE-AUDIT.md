# Bay Bite source and claim audit — private enrichment release

**Analyst:** Priya Chen, research support to Dr. Elias Forge  
**Checked:** 2026-08-13 (America/New_York)  
**Scope:** Bounded audit of the 63 records and shared species profiles in `/root/bay-bite-dashboard/src/data.ts`; not a full re-research of every location. No application code was changed.

## Executive finding

**Release posture: hold the enrichment as private/demo data until P0 items below are corrected.** The dataset has useful habitat-level guidance and every spot has a nonempty `sourceNote`, but it does not yet provide claim-level traceability. More importantly, all 63 records embed current-looking scores, bite windows, tides, swell, wind, and water temperature without observation times or source URLs. The file also labels its report `Today` and publishes momentum percentages without provenance. Those values must not be presented as live/current.

## Verified facts (official sources)

1. CDFW's public-pier list confirms many structures represented in Bay Bite, but CDFW explicitly says it cannot guarantee any structure is open; owners may close them at any time. The no-license exception applies only to a qualifying public pier/jetty/breakwater, while all other regulations still apply and adjacent shore generally requires a license.[1]
2. A California sport-fishing license is generally required for people 16 or older attempting to take fish or invertebrates, subject to exceptions; report cards/validations can still apply even where a license is not required.[2]
3. CDFW's San Francisco ocean-region and SF Bay summaries were updated August 1, 2026. They distinguish ocean-coast rules from SF Bay rules, show dynamic species statuses, and warn that MPAs can further restrict or prohibit fishing.[3][4]
4. CDFW maintains an in-season change page because groundfish, salmon, crab gear, and health-related rules can change outside the annual booklet cycle.[5]
5. Pacifica Municipal Pier is **closed as of June 4, 2026**; the city's status page also links an emergency order concerning the pier and adjacent beach area.[6]
6. Berkeley Municipal Pier has been closed since July 2015 due to structural problems; the replacement/ferry project remains in design/environmental work, with that phase expected through 2027.[7]
7. Point Pinole's official park page reports a Bay Trail closure east of the Atlas Bridge entrance due to a sinkhole, with no reopening timeline, updated August 13, 2026. The park itself and fishing activity are still listed; whether the closure affects a user's chosen pier route depends on entrance/route and was not established in this audit.[8]
8. Candlestick Point SRA currently lists fishing and a public pier, park hours of 7 a.m.–7 p.m., and the license distinction between pier and shoreline. A separate July 29 update says rehabilitation of the **second** fishing pier was in process and expected to take about two months.[9][10]
9. NPS confirms Fort Baker pier/jetty, Fort Mason Piers 2/3, and Torpedo Wharf as license-exempt public fishing structures. NPS also explicitly closes the Crissy Field former Coast Guard pier, breakwater, and seawall to fishing.[11][12]
10. Bean Hollow and Pescadero State Beach official pages say the parks remain open but identify temporary parking/access impacts from ADA work through early August 2026; the notice remained visible when checked. Both list fishing, and Pescadero specifies 8 a.m.–sunset hours and access details.[13][14]
11. The San Mateo County Harbor District currently labels all listed Pillar Point Harbor activities open, including the fishing pier, Johnson Pier, parking, and restrooms.[15]

## Analyst findings and prioritized corrections

### P0 — Must correct before anything is described as current, live, or release-ready

| Finding | Affected records/fields | Why it matters | Recommended wording/data treatment |
|---|---|---|---|
| **Current-looking telemetry is hardcoded.** Every spot has `score`, `bestWindow`, and `conditions`; several values include exact tide times and measured-looking swell/wind/water values. `tideSeries`, `speciesMomentum` percentages, and `dailyReport.date: 'Today'` are also static. | All 63 spots; `tideSeries`; `speciesMomentum`; `dailyReport` | No URL, station ID, observation/prediction timestamp, generated time, or staleness marker ties these values to August 13. A user could mistake mock data for trip-day truth. | Until sourced: label the entire layer **“Demo/sample conditions — not current”** and replace `Today` with **“Sample report.”** For production, store source station/product, `observedAt`/`validTime`, `fetchedAt`, `expiresAt`, status (`live|stale|unavailable|demo`), and last-known-good provenance. Never infer a fresh bite score from stale telemetry. |
| **Pacifica Pier is closed, and the status is owner-confirmed.** Current copy gives it a score 71 and a precise bite window despite warning text. | `pacifica-pier`; potentially `sharp-park-beach` because the city page links an adjacent-beach emergency order | Closed destinations should not rank as actionable fishing picks. The scope/exact duration of the adjacent beach order was not resolved because the linked PDF timed out. | `accessStatus: 'closed'`; `accessStatusCheckedAt: '2026-08-13'`; owner URL [6]. Display: **“CLOSED — Pacifica Municipal Pier has been closed since June 4, 2026. Do not plan pier fishing here; check the City status page for reopening and adjacent-beach restrictions.”** Suppress score/trip-builder eligibility while closed. |
| **Berkeley Pier is not merely “check current access”; it has been closed since 2015.** | `berkeley-pier` | The current combined name “Berkeley Pier / Marina Shore,” score, and species advice can make a closed structure look fishable and blur the license boundary with nearby shoreline. | Split the records or mark the pier closed. Suggested display: **“Berkeley Municipal Pier: CLOSED since July 2015. Nearby marina shoreline is a separate fishing location; verify access and carry a license when fishing off a non-exempt shore.”** Cite [7] for closure and [1] for license boundary. |
| **Crissy Field record omits a specific NPS fishing closure.** | `crissy-field` | NPS closes the former Coast Guard pier, breakwater, and seawall; generic “protected areas” language is inadequate. | Add: **“Fishing is closed from the Crissy Field former Coast Guard pier, breakwater, and seawall. This record refers only to lawful shoreline areas; verify posted boundaries before casting.”** Cite [12]. |
| **Sturgeon language is temporally and legally imprecise.** Current records say “retention currently closed” or “check closure,” while the August 1 regional pages classify sturgeon as a closed fishing season at the audit date. | `dumbarton-pier`, `point-pinole`, `china-camp`, `mcnears-beach`, `martinez-marina`, `benicia-pier`, `eckley-pier`, `vallejo-waterfront`, `cuttings-wharf`; shared `Sturgeon` profile | “Retention closed” can imply targeted catch-and-release is currently permitted. CDFW also requires sturgeon report-card compliance when fishing for/taking sturgeon; current date-specific rules must be checked directly.[2][3][4] | Do not encode a timeless status. Suggested current banner: **“Sturgeon regulations are date- and water-specific. CDFW currently shows sturgeon closed for this region; do not target sturgeon unless the current CDFW page expressly permits it, and follow report-card requirements.”** Store `regulationArea`, `status`, `effectiveFrom`, `effectiveTo`, `checkedAt`, and official URL. |

### P1 — Correct traceability and legal precision in the same private pass

| Finding | Affected records | Recommended correction |
|---|---|---|
| **`sourceNote` is prose, not traceability.** 63/63 records have notes, but none has a structured URL/check date/claim mapping. About 18 use generic formulations such as “SF Bay district species apply,” “species list informs targets,” or “habitat pattern.” | All spots; especially `redwood-city-pier`, `emeryville-marina`, `paradise-beach`, `islais-creek-pier`, `fort-mason-piers`, `crissy-field`, `lands-end`, `bolinas-beach`, `acqua-hotel-pier`, `san-antonio-pier`, `jack-london-pier`, `union-point-park`, `arrowhead-marsh`, `doolittle-pier`, `port-view-park`, `ferry-point`, `vincent-park-pier`, `mussel-rock` | Keep narrative notes only as a summary. Add claim-linked sources with authority level and checked date. A regional regulations page supports legal context, not proof that every listed species is reliably present at each exact spot. Downgrade those local species assertions to `inferred` until supported by an owner page, survey, or clearly dated secondary record. |
| **The confidence algorithm overstates evidence.** Any note containing the string `CDFW` becomes `Officially listed`, even when CDFW only lists a structure or region and the species/tactics are inferred. | Most spots (59/63 notes contain “CDFW”) | Separate confidence by claim class: `accessConfidence`, `speciesConfidence`, `tacticsConfidence`, `regulationConfidence`. “CDFW-listed” should mean only that the exact structure is on CDFW's qualifying-pier list, not that all species, tactics, safety, or access status are officially verified. |
| **Public-pier wording is too broad for mixed or ambiguous locations.** | `pillar-point`, `alameda-rock-wall`, `coyote-point`, `fort-baker`, `bodega-jetty`, `vincent-park-pier`, and any combined “pier / shore / jetty” record | Use: **“The license exemption applies only while angling from the exact qualifying public structure. Adjacent shore, inner rock wall, trail, beach, or nonqualifying jetty section may require a license. Verify the boundary and posted access.”** CDFW notes that only a harbor's most seaward qualifying breakwater/jetty can receive that status.[1] |
| **Candlestick access is incomplete during active works.** | `candlestick` | Add park hours and a construction flag: **“Park hours currently 7 a.m.–7 p.m. Rehabilitation of the second fishing pier was in progress as of July 29, 2026; use only open, posted areas.”** Do not infer both piers are closed.[9][10] |
| **Point Pinole needs a route alert, not a pier-closure claim.** | `point-pinole` | Add: **“Bay Trail east of the Atlas Bridge entrance is closed due to a sinkhole with no reopening timeline (checked Aug. 13). Confirm which entrance reaches your route to the pier.”** The available official page does not establish that the pier itself is closed.[8] |
| **Groundfish, salmon, crab, MPA, and health-advisory text is too generic for a live regulation layer.** | Shared profiles for `Rockfish`, `Cabezon`, `Greenling`, `Lingcod`, `Salmon`, `Dungeness Crab`, `Rock Crab`; spots containing them | Keep editorial habitat guidance, but fetch/display status by regulatory area and date. Current pages explicitly support early closures/in-season changes and MPA overlays.[3][4][5] Use wording: **“Status can change in season; check CDFW current map, in-season notices, MPA boundaries, and applicable health/gear advisories immediately before the trip.”** |
| **Exact striped-bass and halibut limits are hardcoded in reusable profiles.** | Shared `Striped Bass` and `Halibut` profiles | Even with “verify” appended, limits become stale silently. Move exact legal numbers to a dated regulation snapshot keyed by region/species; keep profile wording generic: **“Minimum size and bag rules apply; open the current CDFW rule for this water before retention.”** |
| **Secondary-source species notes lack URLs, dates, and claim scope.** | `torpedo-wharf`, `pier-7`, `pacifica-pier`, `oyster-point`, `berkeley-pier`, `mcnears-beach`, `sharp-park-beach` | Store the exact PierFishing URL, publication/observation date, checked date, and which species claim it supports. Label it `secondary/local-pattern`; never use it for law or current access. |

### P2 — Important follow-up, not a blocker if clearly marked unknown/demo

- Recheck owner pages for all structures whose access notes currently say only “verify access,” “check construction,” or “park rules apply.” CDFW's list establishes legal classification, **not opening status**.[1]
- Add a distinct `locationBoundary`/geometry note for combined records. Examples: `pillar-point`, `fort-baker`, `bodega-jetty`, `berkeley-pier`, and `sharp-park-beach`. A point coordinate plus combined name cannot safely express where pier exemptions or closures begin/end.
- Record consumption-advisory links for SF Bay species, particularly white croaker and long-lived predators. The current regional page points users to OEHHA advisories.[4]

## Practical traceability schema

A minimum maintainable structure should separate editorial claims, live observations, legal status, and access status:

```ts
type EvidenceClass = 'official-primary' | 'official-secondary' | 'secondary-local' | 'analyst-inference';
type ClaimStatus = 'verified' | 'inferred' | 'unknown' | 'superseded';

type ClaimEvidence = {
  claimId: string;                     // e.g. access.pacifica.closed
  claimType: 'access' | 'license' | 'regulation' | 'species' | 'tactic' | 'safety' | 'condition';
  text: string;
  status: ClaimStatus;
  sourceUrl: string;
  sourceTitle: string;
  publisher: string;
  evidenceClass: EvidenceClass;
  checkedAt: string;                   // ISO timestamp
  sourceUpdatedAt?: string;
  effectiveFrom?: string;
  effectiveTo?: string;
  quoteOrLocator?: string;             // heading/section or short exact excerpt
  geography?: string;                  // exact structure / SF Bay / coast area
  reviewer: string;
  nextCheckAt: string;
};

type AccessStatus = {
  state: 'open' | 'partially-open' | 'closed' | 'unknown';
  affectedArea: string;
  checkedAt: string;
  sourceUrl: string;
  suppressRecommendation: boolean;
};

type LiveDatum = {
  value: number | string | null;
  unit?: string;
  source: 'NOAA-COOPS' | 'NDBC' | 'NWS' | 'editorial-demo';
  stationOrProduct?: string;
  observedAt?: string;
  validTime?: string;
  fetchedAt: string;
  expiresAt?: string;
  state: 'live' | 'stale' | 'unavailable' | 'demo';
};
```

**Operational checks:** closed spots cannot enter rankings/trip plans; `live` requires a nonexpired source timestamp; regulatory claims require `geography`, effective dates, and a primary URL; `Officially listed` may describe only the exact claim supported; every claim has `nextCheckAt` (daily for closures/live status, before each season/in-season update for law, annual or evidence-triggered for stable habitat guidance).

## Unknowns / unresolved in this bounded audit

- The exact extent and current enforceability of Pacifica's June emergency order for the **adjacent beach area** could not be confirmed because the linked city PDF timed out. The pier closure itself is confirmed.[6]
- Point Pinole's current trail alert does not say the fishing pier is closed; route impact depends on entrance and chosen trail.[8]
- Candlestick's official pages do not identify which specific pier/walkway segments are open during second-pier rehabilitation; do not infer a full closure.[9][10]
- The official Berkeley page confirms the municipal pier closure but does not validate the current access, fishing suitability, or species at every nearby marina shoreline segment.[7]
- This audit did not independently validate each one of the 63 coordinates, species lists, tactics, or owner-hours pages. Generic/local-pattern claims remain candidates for targeted follow-up rather than accepted official facts.

## Sources

[1] [CDFW — California Beach Fishing](https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing)  
[2] [CDFW — Sport Fishing Licenses and Report Cards](https://wildlife.ca.gov/Licensing/Fishing)  
[3] [CDFW — Current Ocean Recreational Fishing Regulations, San Francisco Region](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/San-Francisco)  
[4] [CDFW — Current Ocean Recreational Fishing Regulations, SF Bay Region](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay)  
[5] [CDFW — In-Season Ocean Fishing Regulation Changes](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Inseason)  
[6] [City of Pacifica — Pacifica Municipal Pier](https://www.cityofpacifica.org/departments/public-works/field-services/pacifica-pier)  
[7] [City of Berkeley — Berkeley Pier with Ferry Access Project](https://berkeleyca.gov/your-government/our-work/capital-projects/berkeley-pier-ferry-access-project)  
[8] [East Bay Regional Park District — Point Pinole Regional Shoreline](https://www.ebparks.org/parks/point-pinole)  
[9] [California State Parks — Candlestick Point SRA](https://www.parks.ca.gov/candlestickpoint/)  
[10] [California State Parks — Candlestick Point SRA FAQs](https://www.parks.ca.gov/?page_id=31480)  
[11] [National Park Service — Fort Baker Fishing](https://www.nps.gov/thingstodo/fort-baker-fishing.htm)  
[12] [National Park Service — Fort Point Fishing](https://www.nps.gov/fopo/planyourvisit/fishing.htm)  
[13] [California State Parks — Bean Hollow State Beach](https://parks.ca.gov/beanhollow)  
[14] [California State Parks — Pescadero State Beach](https://www.parks.ca.gov/?page_id=522)  
[15] [San Mateo County Harbor District — Pillar Point Harbor](https://www.smharbor.com/pillar-point-harbor)
