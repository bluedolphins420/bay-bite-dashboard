import json
from pathlib import Path
p=Path('/root/company/research/bay-bite-fishing-smarts')
d=json.loads((p/'spot-catalog-100.json').read_text())
L=[]
L += ['# Bay Bite — 100+ shore-access spot catalog and official sensor net','',f"**Prepared/check date:** {d['prepared_at']}  ",f"**Candidates:** {d['counts']['candidate_records']} · **agency-backed open/conditional:** {d['counts']['verified_open_or_conditional']} · **site-specific verification pending:** {d['counts']['site_specific_verification_pending']} · **closed alerts:** {d['counts']['closed_alert_records']}  ",f"**Machine-readable canonical detail:** [`spot-catalog-100.json`](./spot-catalog-100.json)",'',
'## Decision summary','',
'- The existing TypeScript inventory contains **63 records**. Eleven are combined records that should not survive normalization because their access/license boundaries differ: `'+ '`, `'.join(d['superseded_combined_records']) +'`.','- The normalized candidate set contains **131 distinct records**. It clears the requested 110-candidate QA buffer and leaves **110 agency-backed open/conditional candidates** after 18 deliberately flagged site-specific checks and 3 closed alert-only structures.','- A CDFW public-pier listing proves the exact qualifying structure/license exemption, not adjacent shore, walking bridge or land-touching rock wall. Every record preserves that boundary.','- Open-coast wave observations and inland Bay/Delta conditions are separated. Inland records explicitly return wave `unavailable`; no ocean buoy is treated as local inland water.','- Seasonal windows are biology guidance, never legality. MPA polygon, current CDFW rules, emergency closures, owner postings and consumption/shellfish advisories remain trip-time dependencies.','',
'## Evidence and confidence model','',
'`open` means the exact pier/jetty is on the current CDFW qualifying-structure list or an owner page explicitly supports access. `open_with_conditions` means an official park/owner supports public shore access or fishing but posted areas/hours/wildlife restrictions still control. `needs_site_specific_verification` is a useful QA candidate whose general park/shore access is official but exact lawful casting parcel/boundary was not established strongly enough. `closed` is alert-only and never actionable. Coordinates are catalog centroids, not instructions to stand at that pixel.','',
'Primary access/legal sources: [CDFW California Beach Fishing](https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing), [CDFW SF Bay regulations](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay), [NPS GGNRA fishing](https://www.nps.gov/goga/planyourvisit/fishing.htm), [California State Parks Sonoma Coast](https://www.parks.ca.gov/?page_id=451), [Half Moon Bay State Beach](https://www.parks.ca.gov/?page_id=531), [EBRPD fishing](https://www.ebparks.org/recreation/fishing). Each JSON record carries checked source URLs.','',
'## Catalog index','',
'Every row below maps to a complete JSON object containing owner/jurisdiction, access state/date/source, exact license-exemption warning, substrate/salinity/exposure, per-species confidence and source class, biology windows, tactics, safety, MPA/advisory dependencies, compatible environmental products with station ID/name/distance/class/warning, and checked source URLs.','']
# tables by region
for region in sorted({s['region'] for s in d['spots']}):
 L += [f'### {region}','', '| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |','|---|---|---|---|---:|---|']
 for s in [x for x in d['spots'] if x['region']==region]:
  env=[]
  for z in s['environmental_sources']:
   env.append(f"{z['product']}:{z.get('id',z.get('state'))}" )
  L.append(f"| `{s['id']}` | {s['name']} | {s['habitat_type']} | {s['access']['state']} | {s['coordinates']['lat']:.4f}, {s['coordinates']['lon']:.4f} | {', '.join(env)} |")
 L.append('')
L += ['## Sensor appendix — selected official net','',
'This appendix expands Phase 1 from a small water-level/buoy set to compatible water-level, current, met, wave, and reserve water-quality context. Inclusion means useful official platform/product, not that every field is fresh. Ingestion must validate timestamps per field.','',
'| ID | Official name | Class | Products / nominal cadence |','|---|---|---|---|']
for s in d['sensor_net']:
 L.append(f"| `{s['id']}` | {s['name']} | {s['environment_class']} | {'; '.join(s['products_and_cadence'])} |")
L += ['', '### Material sensor additions beyond the earlier minimum set','',
'- **46214 / CDIP 029 Point Reyes** adds a real open-coast wave anchor for Point Reyes/Marin; still offshore, never beach-local.','- **9415020 Point Reyes** adds official coastal met context.','- **9414296, 9414311** add SF waterfront visibility/met context; **9414763, 9414769, 9414776, 9414797** add Oakland harbor met platforms.','- **9414847 Point Potrero**, **9415141 Davis Point**, **9415118 Union Pacific Railroad Bridge**, and **9415115 Pittsburg** extend wind/met context through Richmond, Carquinez and Suisun.','- **TIBC1, SCQC1, FFFC1, RYEC1, SFXC1** add official NDBC-hosted/Reserve fixed-platform water-quality or met context for Tiburon, China Camp and Suisun Marsh. Validate individual reported fields and cadence; do not infer missing salinity/temperature.','- Existing core retained: CO-OPS observed levels `9414290`, `9414750`, `9414863`, `9414523`, `9415102`, `9415144`; prediction-only `9414275`, `9414131`, `9415625`; currents `s06010`, `s08010`, `s10010`; waves `46012`, `46013`, `46026`, `46237`.','',
'### Mapping algorithm and maximum distances','']
for i,x in enumerate(d['mapping_policy']['algorithm'],1): L.append(f'{i}. {x}')
L += ['','| Product/environment class | Maximum distance (nm) |','|---|---:|']
for k,v in d['mapping_policy']['maximum_representativeness_distance_nm'].items(): L.append(f'| `{k}` | {v} |')
L += ['',d['mapping_policy']['distance_warning_policy'],'', '**Freshness:** '+d['mapping_policy']['freshness'],'',
'## Exclusions and uncertainties','']
for x in d['exclusions']: L.append(f"- **{x['name']}:** {x['reason']}")
L += ['','Additional unresolved items:','',
'- The 18 `needs_site_specific_verification` records should not enter ranked/actionable production until a parcel/owner page or on-site posting confirms the exact casting boundary.','- MPA/no-take safety requires an authoritative polygon lookup at the casting coordinate; park access alone is not sufficient. Point Reyes and Bodega/outer-coast entries are especially sensitive to boundaries and seasonal wildlife closures.','- `46237` can remain present in metadata while stale; never silently use its old row. `46012` is currently a mobile USV/platform and its current position/status must be re-read.','- CDFW marks Pacifica, Berkeley Municipal and SF Municipal/Muni piers closed in the evidence set; only their adjacent separately verified shores may be actionable.','- Species confidence is deliberately habitat/region-level unless an owner/CDFW source is location-specific. No candidate promises a catch or converts secondary field pattern into legal evidence.','',
'## Source register','',
'- [CDFW — California Beach Fishing / qualifying piers and license boundary](https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing)','- [CDFW — SF Bay ocean regulations map](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay)','- [NPS — GGNRA fishing rules and closures](https://www.nps.gov/goga/planyourvisit/fishing.htm)','- [EBRPD — fishing](https://www.ebparks.org/recreation/fishing)','- [NOAA CO-OPS Metadata API](https://api.tidesandcurrents.noaa.gov/mdapi/prod/)','- [NOAA CO-OPS Data API](https://api.tidesandcurrents.noaa.gov/api/prod/)','- [NOAA San Francisco Bay PORTS](https://tidesandcurrents.noaa.gov/ports/index.html?port=sf)','- [NDBC active stations](https://www.ndbc.noaa.gov/activestations.xml)','- [NDBC Web Data Guide](https://www.ndbc.noaa.gov/docs/ndbc_web_data_guide.pdf)','- [NWS MTR marine page](https://www.weather.gov/mtr/marine)','- [NWS API documentation](https://www.weather.gov/documentation/services-web-api)','',
'## QA use','',
'Filter out `closed` and `needs_site_specific_verification`; then review duplicates by ID and coordinate, owner/access freshness, MPA polygon, exact pier exemption, and station compatibility. The remaining agency-backed set is exactly the 100+ retention pool; QA can reject up to ten and still retain 100. Do not copy this candidate file directly into production without that gate.']
(p/'spot-catalog-100.md').write_text('\n'.join(L)+'\n')
print(len(L), (p/'spot-catalog-100.md').stat().st_size)
