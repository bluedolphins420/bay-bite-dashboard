# Bay Bite dual-gate recovery — 2026-08-13

**Analyst:** Priya Chen, under Arthur Blake  
**Scope:** Eight priority backlog records blocked by both exact access and local species evidence. Internal research artifact only; no application, production, publication, cron, systemd, or Brain changes.

## Outcome

- Recovered with both gates resolved: **5**
- Research-accepted total: **101/131** (from 96)
- Deterministic QA errors: **0**
- No threshold was weakened; the remaining three priority records stay pending.

## Accepted IDs and evidence

| Spot ID | Exact official access evidence | License boundary | Local species edges (OBIS; within 5 km after point distance + uncertainty control) |
|---|---|---|---|
| `spot:doran-beach` | Sonoma County Regional Parks exact Doran page: https://parks.sonomacounty.ca.gov/visit/find-a-park/doran-regional-park | Licensed beach shoreline; no exemption inferred from adjacent jetty | Redtail surfperch (8, medium); jacksmelt (4, medium) |
| `spot:benicia-state-rec-shore` | California State Parks exact Benicia SRA page: https://www.parks.ca.gov/?page_id=476 and official park brochure | Licensed Dillon Point shoreline, age 16+; protected marsh is no-public-access | Striped bass (199, medium; DWR telemetry + other retained provenance); starry flounder (1, low) |
| `spot:martinez-shoreline` | EBRPD exact park map/brochure: https://www.ebparks.org/sites/default/files/radke-martinez-map-brochure.pdf | License/stamps required from shore for age 16+; marina-pier exemption does not extend ashore | Striped bass (200, medium; DWR telemetry); starry flounder (1, low) |
| `spot:coyote-point-shore` | San Mateo County Parks exact recreation-area page: https://www.smcgov.org/parks/coyote-point-recreation-area | Licensed beach-promenade/breakwater shore; no adjacent-pier exemption inferred | Leopard shark (63, medium); bat ray (33, medium) |
| `spot:point-isabel-shore` | EBRPD exact official map/brochure: https://www.ebparks.org/maps/point-isabel | Official brochure expressly requires a State license from shore | Striped bass (17, medium); bat ray (47, medium) |

Every OBIS edge stores its exact parameterized query URL in the generated source collection and retains record-level event date, coordinates, uncertainty, basis, occurrence ID, provider/dataset, QC flags, and independently calculated distance in `.obis-local-targets.json`. Occurrence evidence corroborates local presence, not a catch at the casting pixel or present legality.

All five catalog coordinates remain `clear-at-catalog-point` in the retained CDFW ds582 MPA screen. That screen is not legal authority; same-day Title 14, owner closure, and advisory checks remain required.

## Priority records left unresolved

| Spot ID | Why not accepted |
|---|---|
| `spot:alviso-marina-shore` | OBIS has multiple local species occurrences, but the exact County page located in this pass describes access/boating and did not establish the catalog shoreline as a lawful fishing bank. General County fishing rules cannot cure that exact-unit ambiguity. |
| `spot:oyster-point-shore` | OBIS has multiple local species occurrences, but the exact harbor page establishes public marina/park hours rather than the precise licensed shoreline casting unit at the catalog point. The separately named fishing pier cannot extend its access or exemption to adjacent shore. |
| `spot:albany-bulb-shore` | OBIS has multiple local species occurrences, but official material distinguishes City-operated Bulb parcels from adjacent State/EBRPD park units; no exact official fishing/access record bound the catalog point to a lawful shore casting unit. |

## Verification

Executed successfully:

- `python3 -m py_compile build_catalog_v2.py render_markdown_v2.py qa_catalog_v2.py research_obis_species_edges.py`
- `python3 build_catalog_v2.py`
- `python3 render_markdown_v2.py`
- `python3 qa_catalog_v2.py`

Final QA: 101 accepted; 30 rejected/pending; 101/101 exact access URLs; 101/101 with >=2 local species edges; 101/101 MPA-clear; 101/101 with sensor bindings; no schema, uniqueness, URL, edge-count, OBIS-distance, MPA, inland-wave, or exact-repetition errors.
