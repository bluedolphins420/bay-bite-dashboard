import json, re
from pathlib import Path
from collections import Counter, defaultdict
from urllib.parse import urlparse

ROOT=Path('/root/company/research/bay-bite-fishing-smarts')
P=ROOT/'spot-catalog-100-v2.json'
d=json.loads(P.read_text())
errors=[]
required_top=['schemaVersion','generatedAt','sources','spots','species','habitats','regulatoryAreas','rules','notices','mpas','sensors','spotSpeciesEvidence']
for k in required_top:
 if k not in d: errors.append('missing top-level '+k)
ids=[]
for coll in ['sources','spots','species','habitats','regulatoryAreas','rules','notices','mpas','sensors','spotSpeciesEvidence']:
 ids += [x['id'] for x in d[coll]]
if len(ids)!=len(set(ids)): errors.append('global IDs not unique')
spots=d['spots']; accepted=[s for s in spots if s['researchAcceptance']['acceptedActionable']]
if len({s['id'] for s in spots})!=len(spots): errors.append('duplicate spot IDs')
if len({s['displayName'] for s in spots})!=len(spots): errors.append('duplicate spot names')
coords=[(s['coordinates']['lat'],s['coordinates']['lon']) for s in spots]
if len(set(coords))!=len(coords): errors.append('duplicate exact coordinates')
source_by_id={x['id']:x for x in d['sources']}; evidence=defaultdict(list)
for e in d['spotSpeciesEvidence']: evidence[e['spotId']].append(e)
for s in accepted:
 if s['access']['state'] not in ('open','open_with_conditions'): errors.append(s['id']+' accepted bad access')
 if not s['access']['sourceIds']: errors.append(s['id']+' no access source')
 for x in s['access']['sourceIds']:
  if x not in source_by_id or not source_by_id[x]['url'].startswith('https://'): errors.append(s['id']+' bad access URL')
 if len(evidence[s['id']])<2: errors.append(s['id']+' <2 evidence edges')
 if s['mpaAdjudication']['status']!='clear-at-catalog-point': errors.append(s['id']+' accepted MPA not clear')
 if not s['physicalProfile']['summary'] or not s['tactics'] or not s['safety']['hazardsAndRetreat']: errors.append(s['id']+' missing profile prose')
 if s['environmentClass']!='open_coast':
  for b in s['sensorBindings']:
   if b.get('metric')=='wave' and b.get('sensorId'): errors.append(s['id']+' inland ocean wave assignment')
for e in d['spotSpeciesEvidence']:
 for x in e['sourceIds']:
  if x not in source_by_id or not source_by_id[x]['url'].startswith('https://'): errors.append(e['id']+' bad source')
 if e['evidenceType']=='open-biodiversity-occurrences-within-5km':
  loc=e.get('locality',{})
  if loc.get('radiusKm')!=5 or loc.get('observationCount',0)<1: errors.append(e['id']+' bad OBIS radius/count')
  if loc.get('maximumAcceptedDistancePlusUncertaintyKm',999)>5: errors.append(e['id']+' OBIS distance+uncertainty >5km')
  if not loc.get('dateRange',{}).get('start') or not loc.get('dateRange',{}).get('end'): errors.append(e['id']+' missing OBIS date range')
  if len(loc.get('qualityControls',[]))<5: errors.append(e['id']+' missing OBIS quality controls')

def repetition(field):
 vals=[]
 for s in accepted:
  if field=='tactics': vals.extend(s['tactics'])
  else: vals.extend(s['safety']['hazardsAndRetreat'])
 c=Counter(vals);return {'totalTexts':len(vals),'uniqueTexts':len(c),'exactRepeatedTextGroups':sum(v>1 for v in c.values()),'maximumExactRepeat':max(c.values(),default=0)}
rep_t=repetition('tactics');rep_s=repetition('safety')
if rep_t['exactRepeatedTextGroups']:errors.append('exact repeated tactics')
if rep_s['exactRepeatedTextGroups']:errors.append('exact repeated safety')
domains=Counter(urlparse(x['url']).netloc for x in d['sources'])
edge_types=Counter(e['evidenceType'] for e in d['spotSpeciesEvidence'] if e['spotId'] in {s['id'] for s in accepted})
metrics={'candidateRecords':len(spots),'acceptedActionable':len(accepted),'rejectedOrPending':len(spots)-len(accepted),'closedAlertRecords':sum(s['access']['originalV1State']=='closed' for s in spots),'acceptedWithExactAccessSource':sum(bool(s['access']['sourceIds']) for s in accepted),'acceptedWithTwoPlusSpeciesEdges':sum(len(evidence[s['id']])>=2 for s in accepted),'acceptedMpaClear':sum(s['mpaAdjudication']['status']=='clear-at-catalog-point' for s in accepted),'acceptedWithSensorBindings':sum(bool(s['sensorBindings']) for s in accepted),'actionableAcceptanceRatePct':round(100*len(accepted)/len(spots),1),'tacticsRepetition':rep_t,'safetyRepetition':rep_s,'acceptedEvidenceTypes':dict(edge_types),'sourceDomains':dict(domains),'deterministicErrors':errors}
L=['# Bay Bite spot research v2 — deterministic QA','',f"**Run date:** {d['generatedAt']}  ",f"**Disposition:** {'PASS' if not errors and len(accepted)>=100 else 'REJECT / honest partial'}  ",'', '## Outcome','',f"- Candidates: **{len(spots)}**",f"- Research-accepted actionable: **{len(accepted)}**",f"- Rejected or pending: **{len(spots)-len(accepted)}**",f"- Original closed alerts: **{metrics['closedAlertRecords']}**",f"- Requested >=100 gate: **{'met' if len(accepted)>=100 else 'not met; no padding performed'}**",'', '## Coverage','',f"- Exact access URL coverage among accepted: **{metrics['acceptedWithExactAccessSource']}/{len(accepted)}**",f"- >=2 local evidence edges among accepted: **{metrics['acceptedWithTwoPlusSpeciesEdges']}/{len(accepted)}**",f"- MPA point-screen clear among accepted: **{metrics['acceptedMpaClear']}/{len(accepted)}**",f"- Sensor bindings among accepted: **{metrics['acceptedWithSensorBindings']}/{len(accepted)}**",'', '## Repetition','',f"- Tactics: {rep_t}",f"- Safety: {rep_s}",'', '## Evidence classes','']
for k,v in sorted(edge_types.items()):L.append(f'- `{k}`: {v}')
L+=['','## Source domains','']
for k,v in domains.most_common():L.append(f'- `{k}`: {v}')
L+=['','## Deterministic findings','']
L += ['- '+x for x in errors] if errors else ['- No schema, uniqueness, URL, edge-count, MPA, inland-wave, or exact-repetition errors in the accepted subset.']
L+=['','## Rejected/pending backlog','', '| Spot | Reasons |','|---|---|']
for x in d['rejectedOrPending']:L.append(f"| `{x['spotId']}` {x['name']} | {', '.join(x['reasons'])} |")
L+=['','## Important limits','', '- `researchAcceptedActionable` is an editorial research gate only. `rules` and `notices` are intentionally empty; live legal target-now actionability must remain fail-closed until Elias integrates current official legal snapshots.', '- The CDFW ds582 point screen is not navigational or legal authority. Every record retains the warning to check current Title 14 legal descriptions.', '- iNaturalist and OBIS occurrence records within 5 km are local corroboration, not exact-site catch proof. OBIS edges retain date range, provider class, radius, count, nearest distance, and a point-distance-plus-coordinate-uncertainty <=5 km control; exact-spot reviewed-secondary pages remain lower-confidence catch-pattern evidence and never prove access or legality.', '- Generic owner/regional pages did not qualify as exact parcel proof. Those records remain pending even if the v1 package called them agency-backed.']
(ROOT/'SPOT-RESEARCH-QA.md').write_text('\n'.join(L)+'\n')
print(json.dumps(metrics,indent=2))
raise SystemExit(0 if not errors else 1)
