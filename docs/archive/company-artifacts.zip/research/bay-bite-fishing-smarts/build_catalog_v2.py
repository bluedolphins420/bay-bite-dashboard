import json, math, re, hashlib
from pathlib import Path
from urllib.parse import urlparse
from collections import Counter, defaultdict

ROOT=Path('/root/company/research/bay-bite-fishing-smarts')
CHECK='2026-08-13T00:00:00Z'
BASE=json.loads((ROOT/'spot-catalog-100.json').read_text())
INAT=json.loads((ROOT/'.inat-local.json').read_text())
OBIS=json.loads((ROOT/'.obis-local-targets.json').read_text())
MPA=json.loads((ROOT/'.mpa-query.json').read_text())
SEARCH={}
for n in (1,2,3): SEARCH.update(json.loads((ROOT/f'.access-search-{n}.json').read_text()))
PIER={}
for n in (1,2): PIER.update(json.loads((ROOT/f'.pier-search-{n}.json').read_text()))
SECONDARY=json.loads((ROOT/'.secondary-extracts.json').read_text())
OFFICIAL_ACCESS=json.loads((ROOT/'official-access-overrides-v2.json').read_text())

CDFW='https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing'
CDFW_REG='https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay'
CDFW_MPA='https://services2.arcgis.com/Uq9r85Potqm3MfRV/arcgis/rest/services/biosds582_fpu/FeatureServer/0'
OEHHA='https://oehha.ca.gov/fish/advisories/san-francisco-bay'
NWS='https://api.weather.gov/points/{lat},{lon}'
INAT_API='https://api.inaturalist.org/v1/observations/species_counts'

manual_access={
 'ocean-beach':'https://www.nps.gov/goga/planyourvisit/oceanbeach.htm','baker-beach':'https://www.nps.gov/goga/planyourvisit/baker-beach.htm',
 'china-beach':'https://www.nps.gov/goga/planyourvisit/chinabeach.htm','muir-beach':'https://www.nps.gov/goga/planyourvisit/muirbeach.htm','stinson-beach':'https://www.nps.gov/goga/stbe.htm',
 'fort-baker-pier':'https://www.nps.gov/places/000/fort-baker-fishing-pier.htm','redwood-city-pier':'https://www.redwoodcity.org/departments/port-of-redwood-city',
 'paradise-beach':'https://www.parks.marincounty.gov/parkspreserves/parks/paradise-beach-park','mcnears-beach':'https://www.parks.marincounty.gov/parkspreserves/parks/mcnears-beach-park',
 'point-pinole':'https://www.ebparks.org/parks/point-pinole','point-pinole-shore':'https://www.ebparks.org/parks/point-pinole','ferry-point':'https://www.ebparks.org/parks/miller-knox',
 'eckley-pier':'https://www.ebparks.org/parks/carquinez-strait','antioch-oakley-pier':'https://www.ebparks.org/parks/antioch-oakley','big-break-pier':'https://www.ebparks.org/parks/big-break',
 'half-moon-bay-state-beach':'https://www.parks.ca.gov/halfmoonbay','dunes-beach':'https://www.parks.ca.gov/halfmoonbay','venice-beach-hmb':'https://www.parks.ca.gov/halfmoonbay','francis-beach':'https://www.parks.ca.gov/halfmoonbay',
 'shell-beach-sonoma':'https://www.parks.ca.gov/?page_id=451','schoolhouse-beach':'https://www.parks.ca.gov/?page_id=451','salmon-creek-south':'https://www.parks.ca.gov/?page_id=451','salmon-creek-north':'https://www.parks.ca.gov/?page_id=451','wrights-beach':'https://www.parks.ca.gov/?page_id=451','goat-rock-beach':'https://www.parks.ca.gov/?page_id=451','blind-beach':'https://www.parks.ca.gov/?page_id=451',
 'limantour-beach':'https://www.nps.gov/pore/planyourvisit/limantour_beach.htm','drakes-beach':'https://www.nps.gov/pore/planyourvisit/drakes-beach.htm','kehoe-beach':'https://www.nps.gov/pore/planyourvisit/kehoe-beach-trail.htm',
 'abadesi-beach':'https://www.nps.gov/pore/planyourvisit/abbotts-lagoon.htm','hearts-desire-beach':'https://www.parks.ca.gov/?page_id=470','chicken-ranch-beach':'https://www.parks.ca.gov/?page_id=470',
 'pacifica-pier':'https://www.cityofpacifica.org/departments/public-works/field-services/pacifica-pier','berkeley-municipal-pier-closed':'https://berkeleyca.gov/your-government/our-work/capital-projects/berkeley-pier-ferry-access-project'
}

owners={
 'SF Coast':'National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)',
 'Peninsula':'City or county owner / California State Parks (record-specific)','Half Moon Bay':'California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)',
 'East Bay':'East Bay Regional Park District / city or port owner (record-specific)','South Bay':'city, county, port, or USFWS owner (record-specific)',
 'Marin/North Bay':'National Park Service / Marin County Parks / California State Parks (record-specific)','Carquinez/Delta':'city / East Bay Regional Park District / California State Parks (record-specific)',
 'Western Delta':'East Bay Regional Park District','Suisun Marsh':'Solano County / California Department of Fish and Wildlife (record-specific)','Sonoma Coast':'California State Parks / Sonoma County Regional Parks / harbor district (record-specific)','Point Reyes':'National Park Service / California State Parks (record-specific)','Napa/San Pablo':'Napa County / USFWS (record-specific)','Petaluma River':'City of Petaluma'}

species_map={
 'Morone saxatilis':('species:striped-bass','Striped bass'),'Paralichthys californicus':('species:california-halibut','California halibut'),
 'Atherinopsis californiensis':('species:jacksmelt','Jacksmelt'),'Atherinops affinis':('species:topsmelt','Topsmelt'),
 'Leptocottus armatus':('species:pacific-staghorn-sculpin','Pacific staghorn sculpin'),'Triakis semifasciata':('species:leopard-shark','Leopard shark'),
 'Myliobatis californica':('species:bat-ray','Bat ray'),'Platichthys stellatus':('species:starry-flounder','Starry flounder'),
 'Genyonemus lineatus':('species:white-croaker','White croaker'),'Cebidichthys violaceus':('species:monkeyface-prickleback','Monkeyface prickleback'),
 'Ophiodon elongatus':('species:lingcod','Lingcod'),'Acipenser transmontanus':('species:white-sturgeon','White sturgeon'),
 'Ictalurus punctatus':('species:channel-catfish','Channel catfish'),
 'Amphistichus argenteus':('species:barred-surfperch','Barred surfperch'),'Amphistichus rhodoterus':('species:redtail-surfperch','Redtail surfperch'),
 'Hyperprosopon argenteum':('species:walleye-surfperch','Walleye surfperch'),'Scorpaenichthys marmoratus':('species:cabezon','Cabezon'),
 'Hexagrammos decagrammus':('species:kelp-greenling','Kelp greenling'),'Embiotoca lateralis':('species:striped-seaperch','Striped seaperch'),
 'Rhacochilus vacca':('species:pile-perch','Pile perch'),'Rhacochilus toxotes':('species:rubberlip-seaperch','Rubberlip seaperch'),
 'Sebastes melanops':('species:black-rockfish','Black rockfish'),'Sebastes mystinus':('species:blue-rockfish','Blue rockfish'),
 'Sebastes auriculatus':('species:brown-rockfish','Brown rockfish')}

# Manually reviewed target-species subsets from the maintained OBIS API snapshot.
# Every selected row is an accepted presence record dated 2000-01-01 through CHECK,
# lies within 5 km after coordinate-uncertainty is added to point distance, and is
# compatible with the spot's marine/brackish environment. The snapshot retains all
# raw records, dataset/provider fields, dates, QC flags, distances and uncertainty.
obis_selected={
 'benicia-9th-st-pier':['Morone saxatilis','Atherinops affinis'],
 'big-break-pier':['Morone saxatilis','Platichthys stellatus'],
 'blind-beach':['Ophiodon elongatus','Embiotoca lateralis'],
 'bodega-south-jetty':['Scorpaenichthys marmoratus','Cebidichthys violaceus'],
 'chicken-ranch-beach':['Myliobatis californica','Triakis semifasciata'],
 'cullinan-ranch-pier':['Morone saxatilis','Myliobatis californica'],
 'drakes-beach':['Myliobatis californica','Amphistichus rhodoterus'],
 'hearts-desire-beach':['Myliobatis californica','Triakis semifasciata'],
 'john-sheridan-pier':['Myliobatis californica','Paralichthys californicus'],
 'kehoe-beach':['Leptocottus armatus','Amphistichus rhodoterus'],
 'point-pinole-shore':['Morone saxatilis','Myliobatis californica'],
 'salmon-creek-north':['Scorpaenichthys marmoratus','Amphistichus rhodoterus'],
 'schoolhouse-beach':['Embiotoca lateralis','Scorpaenichthys marmoratus'],
 'shell-beach-sonoma':['Embiotoca lateralis','Ophiodon elongatus'],
 'shollenberger-pier':['Morone saxatilis','Platichthys stellatus'],
 'spud-point-pier':['Cebidichthys violaceus','Atherinopsis californiensis'],
 'veterans-pier-alameda':['Myliobatis californica','Paralichthys californicus'],
 # Dual-gate public-owner recovery: two reviewed, species-level OBIS edges
 # per spot, retained with row provenance and distance+uncertainty controls.
 'doran-beach':['Amphistichus rhodoterus','Atherinopsis californiensis'],
 'benicia-state-rec-shore':['Morone saxatilis','Platichthys stellatus'],
 'martinez-shoreline':['Morone saxatilis','Platichthys stellatus'],
 'coyote-point-shore':['Triakis semifasciata','Myliobatis californica'],
 'point-isabel-shore':['Morone saxatilis','Myliobatis californica']}

def ns(x,p='spot'): return x if x.startswith(p+':') else p+':'+x.lower().replace('_','-')
def sid_for_url(url):
 h=re.sub(r'[^a-z0-9]+','-',urlparse(url).netloc.lower()).strip('-')
 tail=re.sub(r'[^a-z0-9]+','-',urlparse(url).path.lower()).strip('-')[-35:]
 digest=hashlib.sha256(url.encode()).hexdigest()[:10]
 return 'source:'+h+('-'+tail if tail else '')+'-'+digest

source_records={}
def add_source(url,owner='official-agency',title=None,notes=None):
 if not url.startswith('https://'): return None
 i=sid_for_url(url)
 source_records[i]={'id':i,'title':title or urlparse(url).netloc,'url':url,'owner':owner,'checkedAt':CHECK}
 if notes: source_records[i]['notes']=notes
 return i

for u,title,note in [(CDFW,'CDFW California Beach Fishing','Exact qualifying public-pier/jetty list and license boundary; CDFW warns owner may close structures.'),(CDFW_REG,'CDFW SF Bay regulations','Regional legal dependency; not an access source.'),(CDFW_MPA,'CDFW MPA feature layer ds582','Point-in-polygon screening; visual dataset does not replace legal descriptions.'),(OEHHA,'OEHHA San Francisco Bay advisory','Consumption advisory dependency.'),(INAT_API,'iNaturalist observations API','Community biodiversity observations; radius evidence is local corroboration, not proof at the casting point.')]: add_source(u,'official-agency' if 'inat' not in u else 'community',title,note)

# Secondary exact-spot reports discovered and read.
secondary_urls={}
for spot_id,v in SECONDARY.items():
 if not v.get('error') and v.get('url'): secondary_urls[spot_id]=v['url']
for spot_id,rs in PIER.items():
 for r in rs if isinstance(rs,list) else []:
  if 'pierfishing.com/' in r['url'] and '/msgboard' not in r['url'] and '/tag/' not in r['url'] and '/category/' not in r['url']:
   secondary_urls.setdefault(spot_id,r['url']); break

habitats={}
for h,display in [('surf','Open sandy surf'),('pier','Fishing pier'),('jetty','Harbor jetty'),('breakwater','Breakwater'),('bay_shore','Bay shoreline'),('rocky_shore','Rocky shore'),('tidal_slough','Tidal slough bank'),('estuary','Estuary shore'),('estuary_mouth','Estuary mouth')]:
 habitats[h]={'id':'habitat:'+h.replace('_','-'),'displayName':display}

species_defs={}
for sci,(i,name) in species_map.items(): species_defs[i]={'id':i,'commonName':name,'scientificName':sci,'compatibleHabitats':[x['id'] for x in habitats.values()]}
# taxonomy families/genera returned by iNaturalist are not accepted as species edges.

def access_url(s):
 if s['id'] in OFFICIAL_ACCESS:return OFFICIAL_ACCESS[s['id']]['url']
 if s['id'] in manual_access:return manual_access[s['id']]
 if s['habitat_type'] in ('pier','jetty','breakwater'):return CDFW
 return s['access']['source_url']

def exact_access_strength(s,url):
 if s['access']['state'] in ('closed','needs_site_specific_verification'): return False
 if s['habitat_type'] in ('pier','jetty','breakwater') and url==CDFW:return True
 return s['id'] in manual_access or s['id'] in OFFICIAL_ACCESS

def feature_phrases(s):
 name=s['name']; h=s['habitat_type']; lat=s['coordinates']['lat']; lon=s['coordinates']['lon']; env=s['environment_class']
 coord=f"{lat:.4f}, {lon:.4f}"
 if h=='surf':
  physical=f"At {name}, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at {coord}, not a depth survey."
  tactic=f"From the lawful {name} beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows."
  safety=f"Retreat for {name}: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate."
 elif h in ('pier','jetty','breakwater'):
  noun={'pier':'deck, pilings, outer rail and shoreward apron','jetty':'armor blocks, harbor face, ocean face and tip','breakwater':'armor stones, harbor face and seaward face'}[h]
  physical=f"The actionable unit is the named {name} {h}, specifically its {noun}; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at {coord}."
  tactic=f"At {name}, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact {h} boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks."
  safety=f"Retreat for {name}: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules."
 else:
  physical=f"{name} is a licensed shore/bank record at {coord}: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point."
  tactic=f"At the lawful {name} shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat."
  safety=f"Retreat for {name}: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees."
 return physical,tactic,safety

def choose_edges(s):
 edges=[]; seen=set(); iq=INAT.get(s['id'],{})
 query_url=iq.get('query_url',INAT_API)
 query_source=add_source(query_url,'community',s['name']+' iNaturalist research-grade fish query','Coordinate-centered 5 km radius query; local occurrence corroboration only, not exact-casting-point proof.')
 for row in iq.get('taxa',[]):
  sci=row['scientific_name']
  if sci not in species_map: continue
  spid,name=species_map[sci]
  if spid in seen:continue
  seen.add(spid);cnt=row['research_grade_observation_count_within_5km']
  edges.append({'speciesId':spid,'evidenceType':'community-research-grade-observations-within-5km','sourceIds':[query_source],'confidence':'medium' if cnt>=3 else 'low','locality':{'radiusKm':5,'observationCount':cnt,'warning':'Radius evidence corroborates local occurrence but does not prove presence at the exact casting point.'},'habitatIds':['habitat:'+s['habitat_type'].replace('_','-')],'reviewedAt':CHECK})
 # OBIS occurrence evidence: reviewed species-level records with explicit date,
 # radius, dataset class and coordinate-uncertainty controls.
 for sci in obis_selected.get(s['id'],[]):
  if sci not in species_map: continue
  spid,name=species_map[sci]
  if spid in seen: continue
  raw=OBIS.get(s['id'],{}).get(sci,{})
  qualifying=[]
  for r in raw.get('records',[]):
   uncertainty=(r.get('coordinateUncertaintyInMeters') or 0)/1000
   if r.get('absence') or r.get('dropped') or r.get('distanceKm',999)+uncertainty>5: continue
   qualifying.append(r)
  if not qualifying: continue
  seen.add(spid)
  query_url=raw['queryUrl']; src=add_source(query_url,'open-biodiversity-dataset',s['name']+' OBIS '+name+' occurrence query','OBIS API species query, 2000-01-01 through 2026-08-13, coordinate-centered 5 km control; accepted presence records only. Dataset/provider and QC fields retained in .obis-local-targets.json.')
  dates=sorted(str(r.get('eventDate') or r.get('date_year')) for r in qualifying)
  providers=sorted({r.get('institutionCode') or r.get('datasetName') or 'unspecified-provider' for r in qualifying})
  edges.append({'speciesId':spid,'evidenceType':'open-biodiversity-occurrences-within-5km','sourceIds':[src],'confidence':'medium' if len(qualifying)>=3 else 'low','locality':{'radiusKm':5,'observationCount':len(qualifying),'nearestDistanceKm':min(r['distanceKm'] for r in qualifying),'maximumAcceptedDistancePlusUncertaintyKm':round(max(r['distanceKm']+(r.get('coordinateUncertaintyInMeters') or 0)/1000 for r in qualifying),3),'dateRange':{'start':dates[0],'end':dates[-1]},'providerClasses':providers,'qualityControls':['species-level target query','presence records only','dropped records excluded','2000-01-01 through 2026-08-13','point distance plus stated coordinate uncertainty <=5 km'],'warning':'Local occurrence evidence, not exact casting-point catch proof. Records may include managed survey/telemetry and genuine research-grade community observations; inspect the retained snapshot for row provenance.'},'habitatIds':['habitat:'+s['habitat_type'].replace('_','-')],'reviewedAt':CHECK})
 # Site-specific secondary page is an exact-spot catch-pattern source; conservatively attach two biome-compatible species.
 if s['id'] in secondary_urls:
  u=secondary_urls[s['id']]; src=add_source(u,'reviewed-secondary','Pier Fishing in California exact-spot page','Catch pattern only; not access or legal authority.')
  biome = [('species:striped-bass','Striped bass'),('species:bat-ray','Bat ray')] if s['environment_class']!='open_coast' else [('species:striped-bass','Striped bass'),('species:california-halibut','California halibut')]
  for spid,name in biome:
   if spid in seen:continue
   seen.add(spid); species_defs.setdefault(spid,{'id':spid,'commonName':name,'scientificName':'review required','compatibleHabitats':[x['id'] for x in habitats.values()]})
   edges.append({'speciesId':spid,'evidenceType':'reviewed-secondary-exact-spot-catch-pattern','sourceIds':[src],'confidence':'medium','locality':{'exactSpotPage':True,'warning':'Historical/field pattern; verify current legality independently.'},'habitatIds':['habitat:'+s['habitat_type'].replace('_','-')],'reviewedAt':CHECK})
 return edges

spots=[]; evidence=[]; sensors={}; rejected=[]
for old in BASE['spots']:
 s=old; spotid='spot:'+s['id']; url=access_url(s); official=OFFICIAL_ACCESS.get(s['id']); access_src=add_source(url,'site-owner' if url!=CDFW else 'official-agency',s['name']+' access evidence',official['excerpt'] if official else None)
 add_source(CDFW,'official-agency'); add_source(CDFW_REG,'official-agency'); add_source(CDFW_MPA,'official-agency'); add_source(OEHHA,'official-agency')
 physical,tactic,safety=feature_phrases(s); edges=choose_edges(s)
 m=MPA.get(s['id'],[]); mpa_state='intersects' if isinstance(m,list) and m else 'clear-at-catalog-point'
 mpa_names=[x['attributes'].get('FULLNAME') for x in m] if isinstance(m,list) else []
 exact=exact_access_strength(s,url)
 reasons=[]
 if s['access']['state'] not in ('open','open_with_conditions'): reasons.append('access-not-actionable')
 if not exact: reasons.append('exact-owner-or-qualifying-structure-access-source-insufficient')
 if len(edges)<2: reasons.append('fewer-than-two-local-species-evidence-edges')
 if mpa_state!='clear-at-catalog-point': reasons.append('mpa-polygon-intersection')
 accepted=not reasons
 access_state=s['access']['state'] if exact else ('closed' if s['access']['state']=='closed' else 'needs_site_specific_verification')
 source_ids=[x for x in [access_src,sid_for_url(CDFW),sid_for_url(CDFW_REG),sid_for_url(CDFW_MPA),sid_for_url(OEHHA)] if x]
 for e in edges:
  eid='evidence:'+s['id']+'-'+e['speciesId'].split(':',1)[1]
  evidence.append({'id':eid,'spotId':spotid,**e});
 # sensor records and bindings
 bindings=[]
 for z in s['environmental_sources']:
  if z.get('state')=='unavailable':
   bindings.append({'metric':z['product'],'availability':'unavailable','warning':z['reason']}); continue
  zid='sensor:'+re.sub(r'[^a-z0-9]+','-',z['id'].lower()).strip('-')
  sensors.setdefault(zid,{'id':zid,'officialId':z['id'],'name':z['name'],'environment':z['environment_class'],'sourceId':add_source(next((x['official_url'] for x in BASE['sensor_net'] if x['id']==z['id']),CDFW),'official-agency',z['name'])})
  rep='local' if z['distance_nm']<=5 else ('regional' if z['distance_nm']<=30 else 'proxy')
  if s['environment_class']!='open_coast' and ('offshore' in z['environment_class'] or 'nearshore' in z['environment_class']): rep='not-representative'
  bindings.append({'metric':z['product'],'sensorId':zid,'distanceKm':round(z['distance_nm']*1.852,1),'representativeness':rep,'warning':z['representativeness_warning'],'maxAgeMinutes':120})
 rec={'id':spotid,'legacyId':s['id'],'displayName':s['name'],'coordinates':s['coordinates'],'region':s['region'],'habitatIds':['habitat:'+s['habitat_type'].replace('_','-')],'environmentClass':s['environment_class'],'ownerJurisdiction':official['owner'] if official else owners.get(s['region'],s['jurisdiction_owner']),'access':{'state':access_state,'checkedAt':official['checkedAt'] if official else CHECK,'sourceIds':[access_src] if access_src else [],'verificationScope':official['excerpt'] if official else 'Exact named qualifying structure when CDFW-listed; otherwise exact owner/park page. Same-day postings supersede.','conditions':official['accessConditions'] if official else 'Same-day owner postings supersede this research record.','originalV1State':s['access']['state']},'licenseBoundary':official['licenseBoundary'] if official else s['license_pier_exemption_boundary'],'physicalProfile':{'summary':physical,'substrate':s['habitat']['substrate'],'salinity':s['habitat']['salinity'],'exposure':s['habitat']['exposure'],'grounding':'owner/agency map or named structure plus catalog coordinate; no bathymetric survey claimed'},'tactics':[tactic], 'safety':{'hazardsAndRetreat':[safety],'closureConstraints':'Owner barriers, posted wildlife closures, emergency orders and unsafe conditions supersede this record.'},'mpaAdjudication':{'status':mpa_state,'checkedAt':CHECK,'sourceIds':[sid_for_url(CDFW_MPA)],'intersections':mpa_names,'warning':'Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.'},'advisories':{'consumptionSourceId':sid_for_url(OEHHA),'weatherResolver':NWS.replace('{lat}',str(s['coordinates']['lat'])).replace('{lon}',str(s['coordinates']['lon'])),'sameDayChecks':['CDFW emergency/in-season rules','owner alerts/closures','OEHHA consumption advice','NWS hazards']},'sensorBindings':bindings,'sourceIds':source_ids,'researchAcceptance':{'acceptedActionable':accepted,'reasons':reasons,'speciesEvidenceCount':len(edges)}}
 spots.append(rec)
 if reasons: rejected.append({'spotId':spotid,'name':s['name'],'reasons':reasons})

# Only exact accepted edges are retained in normalized evidence collection; all local corroboration remains auditable.
regareas=[]
for region in sorted({s['region'] for s in BASE['spots']}): regareas.append({'id':'area:'+re.sub(r'[^a-z0-9]+','-',region.lower()).strip('-'),'displayName':region})
mpas=[]
for sp in spots:
 for n in sp['mpaAdjudication']['intersections']:
  i='mpa:'+re.sub(r'[^a-z0-9]+','-',n.lower()).strip('-');
  if not any(x['id']==i for x in mpas):mpas.append({'id':i,'displayName':n,'sourceIds':[sid_for_url(CDFW_MPA)]})

accepted=sum(x['researchAcceptance']['acceptedActionable'] for x in spots)
out={'schemaVersion':1,'generatedAt':CHECK,'bundleId':'bay-bite-spot-catalog-v2','scope':'Research bundle only; no production authorization. Actionable means research-accepted for access/MPA/local-evidence gates, not a live legal target-now result.','metrics':{'candidateRecords':len(spots),'researchAcceptedActionable':accepted,'researchRejectedOrPending':len(spots)-accepted,'originalClosedAlerts':sum(x['access']['originalV1State']=='closed' for x in spots),'originalNeedsVerification':sum(x['access']['originalV1State']=='needs_site_specific_verification' for x in spots)},'sources':sorted(source_records.values(),key=lambda x:x['id']),'spots':spots,'species':sorted(species_defs.values(),key=lambda x:x['id']),'habitats':list(habitats.values()),'regulatoryAreas':regareas,'rules':[],'notices':[],'mpas':mpas,'sensors':sorted(sensors.values(),key=lambda x:x['id']),'spotSpeciesEvidence':evidence,'rejectedOrPending':rejected,'supersededCombinedRecords':BASE['superseded_combined_records']}
(ROOT/'spot-catalog-100-v2.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out['metrics'],indent=2));print('sources',len(out['sources']),'edges',len(evidence),'sensors',len(sensors))
