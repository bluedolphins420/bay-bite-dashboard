# Bay Bite access-only backlog recovery — 2026-08-13

## Outcome

- Access-only candidates reviewed (Montara excluded for MPA intersection): **24**
- Recovered with exact first-party access evidence: **19**
- Still unresolved: **5**
- Catalog after regeneration: **96/131 research-accepted actionable**
- Deterministic QA errors: **0**

The catalog total also includes separately added, source-grounded OBIS species-edge recoveries present in the shared build inputs. This access pass itself accounts for exactly the 19 IDs below; it does not claim the full catalog increase as access work.

## Newly access-resolved IDs

- `spot:linda-mar`
- `spot:china-camp`
- `spot:crissy-field`
- `spot:lands-end`
- `spot:rodeo-beach`
- `spot:bolinas-beach`
- `spot:gray-whale-cove`
- `spot:pomponio-state-beach`
- `spot:pescadero-state-beach`
- `spot:san-gregorio-state-beach`
- `spot:bean-hollow`
- `spot:pacifica-rockaway`
- `spot:sharp-park-beach`
- `spot:candlestick-shore`
- `spot:miramar-beach`
- `spot:poplar-beach`
- `spot:cowell-ranch-beach`
- `spot:pigeon-point-beach`
- `spot:palo-alto-baylands`

Exact owner, checked date, excerpt/field, access conditions, URL, and license boundary are maintained in `official-access-overrides-v2.json` and emitted into the normalized catalog.

## Unresolved access-only IDs

| ID | Why it remains unresolved |
|---|---|
| `spot:mussel-rock` | The City of Pacifica page only mentions Mussel Rock as a cleanup meeting location; no exact owner/agency park or lawful shoreline-access record was found. |
| `spot:redondo-beach-hmb` | Official planning material identifies Redondo Beach Road as a coastal access route, but no current exact owner page establishes actionable public beach access at the catalog point. |
| `spot:berkeley-marina-shore` | City material establishes public waterfront recreation and discusses shoreline fishing, but the catalog unit “Berkeley Marina South Shore” remains too imprecise to bind to an exact lawful casting parcel without a map/record naming that unit. |
| `spot:meeker-slough-shore` | City documents establish Bay Trail/Meeker Slough context but not an exact lawful shoreline fishing parcel at the catalog point. |
| `spot:independence-park-shore` | City project documents locate Independence Park on the waterfront, but no current exact public-access/fishing record resolves the catalog shoreline boundary. |

## Excluded

- `spot:montara-state-beach` was not recovered because the authoritative MPA point screen intersects the catalog coordinate; access evidence cannot cure that gate.

## Verification

Executed successfully:

- `python3 build_catalog_v2.py`
- `python3 render_markdown_v2.py`
- `python3 qa_catalog_v2.py`

QA result: 96 accepted, 35 rejected/pending, 96/96 exact access URLs, 96/96 with at least two evidence edges, 96/96 MPA-clear, 96/96 with sensor bindings, and no deterministic errors.
