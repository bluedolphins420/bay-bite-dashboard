# Bay Bite spot research v2 — deterministic QA

**Run date:** 2026-08-13T00:00:00Z  
**Disposition:** PASS  

## Outcome

- Candidates: **131**
- Research-accepted actionable: **101**
- Rejected or pending: **30**
- Original closed alerts: **3**
- Requested >=100 gate: **met**

## Coverage

- Exact access URL coverage among accepted: **101/101**
- >=2 local evidence edges among accepted: **101/101**
- MPA point-screen clear among accepted: **101/101**
- Sensor bindings among accepted: **101/101**

## Repetition

- Tactics: {'totalTexts': 101, 'uniqueTexts': 101, 'exactRepeatedTextGroups': 0, 'maximumExactRepeat': 1}
- Safety: {'totalTexts': 101, 'uniqueTexts': 101, 'exactRepeatedTextGroups': 0, 'maximumExactRepeat': 1}

## Evidence classes

- `community-research-grade-observations-within-5km`: 456
- `open-biodiversity-occurrences-within-5km`: 44
- `reviewed-secondary-exact-spot-catch-pattern`: 20

## Source domains

- `api.inaturalist.org`: 111
- `api.obis.org`: 44
- `www.pierfishing.com`: 18
- `tidesandcurrents.noaa.gov`: 16
- `www.nps.gov`: 13
- `www.parks.ca.gov`: 11
- `www.ebparks.org`: 8
- `www.ndbc.noaa.gov`: 7
- `www.cityofpacifica.org`: 3
- `parks.ca.gov`: 2
- `wildlife.ca.gov`: 2
- `www.parks.marincounty.gov`: 2
- `www.smcgov.org`: 2
- `berkeleyca.gov`: 1
- `oehha.ca.gov`: 1
- `parks.sonomacounty.ca.gov`: 1
- `services2.arcgis.com`: 1
- `www.cityofpaloalto.org`: 1
- `www.half-moon-bay.ca.us`: 1
- `www.marincounty.gov`: 1
- `www.redwoodcity.org`: 1

## Deterministic findings

- No schema, uniqueness, URL, edge-count, MPA, inland-wave, or exact-repetition errors in the accepted subset.

## Rejected/pending backlog

| Spot | Reasons |
|---|---|
| `spot:pacifica-pier` Pacifica Pier | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:mussel-rock` Mussel Rock / Thornton | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:montara-state-beach` Montara State Beach | exact-owner-or-qualifying-structure-access-source-insufficient, mpa-polygon-intersection |
| `spot:redondo-beach-hmb` Redondo Beach / Poplar Edge | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:municipal-pier-closed` San Francisco Municipal (Muni) Pier | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:warm-water-cove` Warm Water Cove Shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:herons-head` Heron’s Head Park Shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:martins-beach-public-tidelands` Martin’s Beach public tidelands candidate | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:berkeley-municipal-pier-closed` Berkeley Municipal Pier | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:berkeley-marina-shore` Berkeley Marina South Shore | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:albany-bulb-shore` Albany Bulb shoreline | exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:meeker-slough-shore` Meeker Slough / Marina Bay shoreline | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:point-san-pablo-shore` Point San Pablo Harbor public shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:garretson-point-shore` Garretson Point shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:tidewater-shore` Tidewater Boating Center shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:oyster-point-shore` Oyster Point licensed shoreline | exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:bayfront-park-millbrae` Bayfront Park Millbrae shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:ryder-park-shore` Ryder Park shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:leo-ryan-park-shore` Leo J. Ryan Park shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:seal-point-shore` Seal Point shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:foster-city-bay-trail` Foster City Bay Trail fishing shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:bair-island-access` Bair Island public access shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:ravenswood-open-space` Ravenswood Open Space shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:alviso-marina-shore` Alviso Marina County Park shoreline | exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:independence-park-shore` Independence Park licensed shoreline | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:port-costa-shore` Port Costa public shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:crockett-shore` Crockett shoreline access | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:point-edith-shore` Point Edith public shoreline candidate | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:grizzly-island-road-bank` Grizzly Island Road designated bank access | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:bodega-head-west` Bodega Head west shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |

## Important limits

- `researchAcceptedActionable` is an editorial research gate only. `rules` and `notices` are intentionally empty; live legal target-now actionability must remain fail-closed until Elias integrates current official legal snapshots.
- The CDFW ds582 point screen is not navigational or legal authority. Every record retains the warning to check current Title 14 legal descriptions.
- iNaturalist and OBIS occurrence records within 5 km are local corroboration, not exact-site catch proof. OBIS edges retain date range, provider class, radius, count, nearest distance, and a point-distance-plus-coordinate-uncertainty <=5 km control; exact-spot reviewed-secondary pages remain lower-confidence catch-pattern evidence and never prove access or legality.
- Generic owner/regional pages did not qualify as exact parcel proof. Those records remain pending even if the v1 package called them agency-backed.
