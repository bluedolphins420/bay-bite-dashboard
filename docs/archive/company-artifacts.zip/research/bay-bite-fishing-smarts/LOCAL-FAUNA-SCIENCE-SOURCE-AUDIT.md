# Bay Bite local-fauna science and reusable-source audit

**Analyst:** Priya Chen, research support to Arthur Blake / Dr. Elias Forge  
**Checked:** 2026-08-13  
**Scope:** Scientific/reuse audit only. No repository, Brain, production, service, timer, or deployment changes.  
**Audited inputs:** the 24-taxon source catalog, its 553 spot–species edges (520 on the 101 accepted spots), `regulations-science-data.ts`, generated habitat/evidence records, prior research artifacts, and the Bay Area shore-fishing reference notes.

## Executive decision

Bay Bite has a useful **historical-occurrence gate**, not yet a scientific species × spot × time suitability engine. The accepted catalog proves that each accepted spot has at least two reviewed local-occurrence edges, but 456 of the 520 accepted edges are iNaturalist research-grade radius queries, 44 are OBIS radius queries, and 20 are reviewed secondary exact-spot patterns. Those sources can establish a historical prior; they do not establish current presence, abundance, shore catchability, or a causal response to today's temperature, tide, pressure, moon, color, or lure vibration.

The next phase should **reuse** CDFW's San Francisco Bay Study for estuarine fish/crustacean abundance and covariates; NOAA's 2011 SF Bay benthic habitat service for substrate/biotic/geoform; OBIS/OTN and GBIF as provenance-preserving occurrence aggregators; NOAA ERDDAP for satellite chlorophyll, C-HARM, upwelling and CalCOFI; CalHABMAP/HABDAC for weekly coastal HAB observations; and exact CDFW MPA geometry as a legal gate. These maintained resources materially beat the current 520-edge catalog by adding sampling effort, species counts, environmental measurements, substrate, time, and/or row-level provenance. They must not be blended into one undifferentiated “evidence count.”

**P0 scientific blockers:** (1) every one of the 24 catalog taxa is currently marked compatible with all nine habitats, which makes habitat compatibility non-informative and biologically wrong; (2) five taxa have no edges at all; (3) occurrence counts are being treated too uniformly despite repeated detections, observer effort, platform duplication and spatial uncertainty; (4) no authoritative abundance/CPUE layer is integrated; (5) the existing science profiles contain unsupported or over-precise causal claims; and (6) authoritative habitat geometry and salinity/substrate matching are absent.

## 1. What the current catalog actually contains

- 131 spot records; 101 pass the editorial access/MPA/local-evidence gates.
- 24 exact species records; none is a taxonomic aggregate in the source catalog.
- 553 total spot–species edges; 520 attach to accepted spots.
- Accepted-edge source classes: 456 iNaturalist research-grade observations within 5 km, 44 OBIS occurrences within 5 km, and 20 reviewed secondary exact-spot catch patterns.
- The 44 OBIS edges are mostly not independent of iNaturalist: 40 identify iNaturalist as provider; four identify California Department of Water Resources. Deduplication by `occurrenceID`, provider dataset and observation URL is therefore mandatory before combining platform evidence.
- Five of 24 source-catalog species have zero edges: kelp greenling, pile perch, rubberlip seaperch, walleye surfperch and white sturgeon.
- The 22-profile `regulations-science-data.ts` is a separate editorial/regulatory library. It still contains dangerous aggregates: surfperch, nearshore rockfish, kelp/rock greenlings, brown/gray smoothhounds, other flatfish and rock crabs. It also omits several exact catalog taxa while adding fishery targets/forage taxa not in the 24-species occurrence catalog.

**Finding:** The 24-taxon source catalog is taxonomically safer than the editorial science library, but its `compatibleHabitats` field is invalid as a discriminator because all 24 species are assigned all nine habitat IDs. A channel catfish should not pass an open-ocean rocky-shore gate; lingcod should not pass a tidal-slough gate; white sturgeon should not pass open surf; monkeyface prickleback should not pass soft-bottom estuary solely because a point is near an observation.

## 2. Species audit matrix — current 24

Confidence refers to taxonomy/local occurrence, not current catchability.

| Catalog taxon | Current accepted-edge coverage | Taxonomic disposition | Habitat/time model required | Confidence and action |
|---|---:|---|---|---|
| Barred surfperch — *Amphistichus argenteus* | 19 | Exact, retain. Do not merge with redtail or family-level “surfperch” for legal or habitat scoring. | Exposed sandy surf and troughs; substrate and beach-state prior; reproductive timing must remain regional/uncertain. | Medium local prior; replace all-habitat flag. |
| Bat ray — *Myliobatis californica* | 28 | Exact, retain. | Soft sand/mud flats and channels; estuarine/coastal salinity; tide/current may alter access to flats but is not proof of feeding. | Medium; many edges are secondary catch-pattern pages. |
| Black rockfish — *Sebastes melanops* | 14 | Exact, retain; never collapse to generic rockfish for recommendation or retention. | Rocky reef/kelp, depth and exposure; distinguish shore-accessible structure from inland/bay soft bottom. | Medium; iNaturalist prior only. |
| Blue rockfish — *Sebastes mystinus* | 1 | Exact, retain, sparse. | Rocky reef/kelp, marine salinity. | Low; one edge is insufficient for broad recommendation. |
| Brown rockfish — *Sebastes auriculatus* | 41 | Exact, retain. | Rocky/structured nearshore and some bay structure; substrate-specific. | Medium historical prior, but high edge count is not abundance. |
| Cabezon — *Scorpaenichthys marmoratus* | 3 | Exact, retain. | Rocky reef, crevices, kelp; marine, not slough/soft estuary. | Low–medium, sparse. |
| California halibut — *Paralichthys californicus* | 52 | Exact, retain. | Sand/mud, bay nursery and sand–structure edge; depth/salinity/season; no magic SST threshold. | Medium local prior; excellent candidate for CDFW Bay Study + benthic integration. |
| Channel catfish — *Ictalurus punctatus* | 8 | Exact, but freshwater/low-salinity edge taxon. | Fresh/low-salinity Delta/slough only; require salinity and management-area gate. | Low; remove from marine/coast habitats. |
| Jacksmelt — *Atherinopsis californiensis* | 64 | Exact, retain; distinguish from topsmelt. | Schooling upper-water-column marine/estuary; local observations are visually bias-prone. | Medium historical prior. |
| Kelp greenling — *Hexagrammos decagrammus* | 0 | Exact, retain but non-recommendable until evidence exists. | Rocky reef/kelp, marine. | Gap; zero local edges. |
| Leopard shark — *Triakis semifasciata* | 3 | Exact, retain. | Shallow bay/estuary sand, mud, eelgrass; slow life history and seasonal aggregation require restraint. | Low–medium, sparse. |
| Lingcod — *Ophiodon elongatus* | 34 | Exact, retain. | Rocky reef/ledges/jetties, marine; exclude tidal slough/soft bay shore unless exact structure evidence. | Medium historical prior. |
| Monkeyface prickleback — *Cebidichthys violaceus* | 44 | Exact, retain. | Rocky intertidal crevice/reef; access/swell and MPA dominate; extremely local home range means 5 km evidence is weak for a particular crevice. | Medium regional prior, low exact-microsite confidence. |
| Pacific staghorn sculpin — *Leptocottus armatus* | 61 | Exact, retain. | Soft-bottom estuary/bay/slough, broad salinity; do not assign reef/open-surf equivalence. | Medium historical prior; strong candidate for CDFW Bay Study. |
| Pile perch — *Rhacochilus vacca* | 0 | Exact, retain but non-recommendable. | Structure, pilings, rocky bay/coast; species-specific surfperch rules. | Gap; zero local edges. |
| Redtail surfperch — *Amphistichus rhodoterus* | 14 | Exact, retain; legally distinct minimum size. | Exposed sandy surf; range and local abundance must be evidenced, not inferred from barred surfperch. | Low–medium. |
| Rubberlip seaperch — *Rhacochilus toxotes* | 0 | Exact, retain but non-recommendable. | Rocky/kelp/piling structure, marine/bay. | Gap; zero local edges. |
| Starry flounder — *Platichthys stellatus* | 30 | Exact, retain; do not fold into “other flatfish.” | Soft sand/mud, estuary, broad salinity; seasonal distribution requires survey data. | Low–medium; half the edges are low confidence. |
| Striped bass — *Morone saxatilis* | 74 | Exact, retain. Introduced anadromous species with multiple movement contingents. | River/Delta/Bay/ocean movement; outflow, season, prey and telemetry are probabilistic covariates. | Medium historical prior; strongest candidate for OTN/DWR telemetry and CDFW surveys. |
| Striped seaperch — *Embiotoca lateralis* | 3 | Exact, retain. | Rocky/kelp/piling habitat, not open sandy surf by default. | Low–medium, sparse. |
| Topsmelt — *Atherinops affinis* | 51 | Exact, retain; distinguish from jacksmelt. | Surface schooling, bays/estuaries and nearshore; observer effort matters. | Medium historical prior. |
| Walleye surfperch — *Hyperprosopon argenteum* | 0 | Exact, retain but non-recommendable. | Surf/bay schooling habitat; exact evidence required. | Gap; zero local edges. |
| White croaker — *Genyonemus lineatus* | 9 | Exact, retain. | Soft-bottom bay/coast; consumption-advisory geometry is independent of suitability. | Low–medium. |
| White sturgeon — *Acipenser transmontanus* | 0 | Exact, retain only as conservation/legal alert until evidence and legal gates pass. | Deep estuary/river channels, episodic recruitment and movement; no open-surf/reef equivalence. | Gap; zero edges; never infer targetability from habitat. |

### Dangerous editorial aggregates to retire from scoring

1. **“Surfperch (barred/redtail and other Embiotocidae)”** — use only as a browse label. Species differ in habitat, distribution and retention rules.
2. **“Rockfish (nearshore *Sebastes* complex)”** — unacceptable as a target/scoring entity. Exact species identification and prohibited-species handling are essential.
3. **“Kelp and rock greenlings”** — split *H. decagrammus* and *H. lagocephalus*.
4. **“Brown/gray smoothhound sharks”** — split *Mustelus henlei* and *M. californicus* before occurrence or retention logic.
5. **“Other flatfish”** — split starry flounder, sanddabs and soles; habitat and rules are not interchangeable.
6. **“Rock crabs”** — fishery aggregate can remain for a regulation display only if species-specific identification/health caveats are explicit; not a biological taxon.

## 3. Reusable sources that beat the current catalog

| Source/integration | Exact claim it can support | Authority / spatial & temporal resolution | Access, cadence, license | Uncertainty and verdict |
|---|---|---|---|---|
| [CDFW San Francisco Bay Study](https://wildlife.ca.gov/Conservation/Delta/Bay-Study) | Species-specific demersal/pelagic fish and mobile-crustacean counts, lengths and effort; salinity, temperature, Secchi depth and station depth; monthly/annual CPUE indices. | Primary agency survey since 1980; 52 open-water stations sampled monthly from South Bay through Bay/Delta transition. Otter and midwater trawls have explicit protocols. | Project page links station map/coordinates and FTP/data resources; confirm machine-download endpoint and data terms with CDFW before automation. | Sampling gears are not shore angling and have selectivity; station CPUE is a regional abundance index, not exact-shore catch probability. **P0 adopt for estuary priors.** |
| [NOAA SF Bay Benthic Habitat 2011](https://www.arcgis.com/home/item.html?id=80e75d135a18428892602fc279dfde5f) / [FeatureServer](https://coast.noaa.gov/arcgis/rest/services/Hosted/san_francisco_bay_2011/FeatureServer) | Biotic cover, substrate and geoform in mapped intertidal/subtidal Bay habitat. | NOAA/OPC/Coastal Conservancy; approximately 930 square miles, mapped to visibility limit near −2 m. | ArcGIS REST and ZIP download; metadata says NOAA data are CC0/public-domain dedicated. Static 2011 layer. | Excellent substrate gate, not current vegetation or depth. Coverage ends where imagery could not classify bottom. **P0 adopt.** |
| [CDFW MPA ds582 FeatureServer](https://services2.arcgis.com/Uq9r85Potqm3MfRV/arcgis/rest/services/biosds582_fpu/FeatureServer) | Point/polygon screening against California MPAs. | CDFW best representation, described as current to Jan. 1, 2019 in service metadata. | Public ArcGIS REST; license field absent. | CDFW explicitly says visual representation is not navigational/legal authority and cannot supersede Title 14. Keep as screen; verify legal descriptions/current replacement. **Legal gate, not biology.** |
| [OBIS v3 occurrence API](https://api.obis.org/v3/) and [OBIS standards/QC](https://manual.obis.org/data_format.html) | Species-level historical occurrence with dataset, institution, basis, event date, coordinates, uncertainty, QC/drop/absence fields, license and occurrence ID. | International marine-biodiversity aggregator; row provenance varies. A test SF-area striped-bass query returned OTN/DWR acoustic detections with 1 km uncertainty and CC BY 4.0. | REST JSON; record-level licenses. Maintained; ingestion cadence varies by provider. | Repeated acoustic pings are not independent animals; OBIS may duplicate iNaturalist/GBIF. Deduplicate by occurrence ID/provider/organism/time bin. **Retain, improve provenance weighting.** |
| [Ocean Tracking Network public discovery](https://members.oceantrack.org/data/discovery) | Public acoustic projects, receiver deployments and detections for tagged fish; movement timing through arrays. | Telemetry network; project-specific study design and tag cohort. | Public projects discoverable; data policy/access varies; many published records flow to OBIS. | Detection ≠ local abundance; receiver uptime/range and repeated pings matter. Use organism-level passage events, not ping counts. **P1 adopt for striped bass/sturgeon movement priors.** |
| [GBIF occurrence API](https://techdocs.gbif.org/en/openapi/v1/occurrence) | Historical occurrence plus dataset key, event date, basis, uncertainty, issues and record license. | Global biodiversity aggregator; mixed authority. | REST/OpenAPI; each record carries a license. | A test query returned a research-grade record with 7.4 km uncertainty and quality issues—demonstrating why radius-only filtering is unsafe. Cross-platform duplicates likely. **P1 gap-fill only.** |
| [iNaturalist API](https://api.inaturalist.org/v1/docs/) | Community observations that reach research grade; useful for conspicuous shore fauna and exact-photo review. | Community source; geographic precision/effort/taxonomic reliability vary. | Public API; observation/media licenses vary by contributor and cannot be assumed from API access. Respect rate limits/terms. | Current `species_counts` aggregates hide row-level dates, coordinates, uncertainty, observer effort and duplicates. Fetch rows, preserve IDs/licenses, and use as low/medium historical prior only. **Retain but downgrade aggregate counts.** |
| [NOAA CoastWatch ERDDAP](https://coastwatch.pfeg.noaa.gov/erddap/index.html) | Consistent gridded/table subset access for SST, chlorophyll, C-HARM, upwelling and CalCOFI datasets. | NOAA server; dataset-specific spatial/temporal coverage. ERDDAP explicitly standardizes download formats and subset queries. | REST-like griddap/tabledap, metadata and common formats; dataset-specific license/attribution. | Match pixel/station footprint and latency to each spot; satellite values are surface/offshore proxies and clouds create gaps. **P0 platform integration.** |
| [CalCOFI datasets on NOAA ERDDAP](https://coastwatch.pfeg.noaa.gov/erddap/search/index.html?page=1&itemsPerPage=100&searchFor=CalCOFI) | Fish egg/larval counts and stages, tow effort, hydrography, zooplankton volume and cruises. | NOAA/SIO long-term oceanographic program; station/cruise data, primarily offshore and much stronger south of Bay Bite. | Public ERDDAP datasets including `erdCalCOFIeggcnt`, `erdCalCOFIlrvcnt`, `erdCalCOFItows`, hydro bottle/cast and zooplankton. | Not a spot-level shore-occurrence source. Use only as regional forage/recruitment/ocean-regime context after geographic coverage checks. **P2 regional prior.** |
| [NOAA upwelling indices on ERDDAP](https://coastwatch.pfeg.noaa.gov/erddap/search/index.html?page=1&itemsPerPage=100&searchFor=upwelling%20index) | 6-hourly/monthly Bakun-style index at fixed coastal latitudes; 36°N/122°W and 39°N/125°W bracket Bay Area. | NOAA environmental index, regional scale. NOAA explains that upwelling is episodic and fuels phytoplankton/zooplankton production, not an always-on seasonal switch.[NOAA NCC overview](https://www.fisheries.noaa.gov/west-coast/science-data/oceanography-northern-california-current-study-area) | Public ERDDAP (`erdUI366hr`, `erdUI396hr`). | Regional forcing proxy, not a local bite trigger. Lag effects must be learned/validated, not asserted. **P1 covariate.** |
| [MODIS chlorophyll anomaly / climatology](https://coastwatch.pfeg.noaa.gov/erddap/search/index.html?page=1&itemsPerPage=100&searchFor=chlorophyll%20California) | Surface chlorophyll and anomalies as a productivity/front proxy. | Satellite product; gridded West Coast surface. | Public ERDDAP; e.g. `osu2ChlaAnom`. | Clouds, coastal adjacency, turbidity and bottom reflectance can contaminate pixels; chlorophyll is not bait abundance. **P1 proxy with QA.** |
| [C-HARM v3.1 ERDDAP](https://coastwatch.pfeg.noaa.gov/erddap/griddap/wvcharmV3_0day.html) | Probability fields for *Pseudo-nitzschia* and particulate/cellular domoic-acid risk, California/Oregon coast, 2022–present. | NOAA model nowcast/forecast. | Public ERDDAP; 0–3 day products found. | Model risk is not a closure, toxin assay or seafood-safety determination. It must never override CDPH/CDFW notices. **P1 safety/context layer.** |
| [CalHABMAP/HABDAC](https://calhabmap.org/) | Weekly phytoplankton and water-quality observations at nine California coastal sites, including Bodega Bay and nearby Central Coast stations. | Statewide monitoring network; point samples, weekly. | Site says data are viewable in HABDAC and provides ERDDAP links per station. | Sparse spatially; does not establish toxin at a fishing spot or in a retained animal. **P1 observed HAB context.** |
| [NOAA Benthic Data Hub](https://coast.noaa.gov/digitalcoast/data/benthiccover.html) | Discovery/download of benthic habitat products beyond SF Bay. | NOAA aggregation, product-specific vintages/resolution. | Public catalog/Data Access Viewer/ArcGIS. | Coastal coverage is uneven; do not extrapolate SF Bay 2011 classes to exposed coast. **P1 discovery source.** |
| [Environmental Data Initiative portal](https://portal.edirepository.org/nis/home.jsp) / IEP repositories | Versioned ecological data packages and metadata for Bay–Delta studies. | Repository authority depends on publishing program; strong provenance/versioning. | Public search/download; package-specific license/cadence. | Requires dataset-by-dataset protocol review. Prefer the original agency survey when available. **P1 discovery and reproducibility.** |

### Important missing/restricted sources

- **SFEI/BAARI:** highly relevant for tidal marsh/aquatic-resource geometry, but automated retrieval was blocked during this audit and ArcGIS items may carry custom terms. Obtain exact authoritative service URLs and reuse terms before integration; do not mirror scraped maps.
- **California Fish Tracking Consortium / UC Davis:** the historical website did not respond. OTN/OBIS exposes some DWR/UC Davis detections, but receiver deployment history, tag cohorts and project data policy must be acquired from the source project before inferring passage probability.
- **Exposed-coast substrate/bathymetry:** NOAA/CDFW/USGS products exist, but one authoritative, current, uniform shore-scale substrate layer covering Sonoma–Pigeon Point was not verified here. This remains a blocker for coast-wide habitat scoring.
- **Current prey abundance:** no single maintained nearshore API was found that directly measures anchovy/herring/sand-crab abundance at Bay Bite spots. Bird/chlorophyll/HAB/front signals are proxies only.

## 4. Evidence hierarchy and scoring rules

### Evidence levels

1. **L0 — Legal/access exclusion:** current official regulations, MPA legal geometry, owner access/closure and health advisories. This is a hard gate, never a suitability feature.
2. **L1 — Standardized local survey abundance:** CDFW/IEP survey counts with gear, effort, station, date and covariates. Supports an abundance/season prior within the sampled stratum.
3. **L2 — Individual telemetry passage:** identified animal, receiver/deployment uptime, detection filtering and study cohort. Supports movement/passage timing for tagged populations, not abundance.
4. **L3 — Voucher/specimen or quality-controlled agency occurrence:** exact taxon, date, coordinates, uncertainty and dataset. Supports historical occurrence.
5. **L4 — Research-grade community observation:** exact row/photo/ID, date, coordinates, uncertainty and license. Supports historical occurrence with observer/detectability bias.
6. **L5 — Reviewed exact-spot angling report:** supports a historical catch pattern/tactic only; never law, access, present abundance or general habitat.
7. **L6 — Habitat compatibility inference:** substrate/salinity/depth overlap without an occurrence. Useful for model extrapolation but must display “habitat-suitable, local occurrence unconfirmed.”

Never sum raw records across levels. Store independent features such as survey CPUE percentile, telemetry passage probability, years-since-last-observation, number of independent datasets, and habitat match. One thousand pings from one tagged fish must not outweigh one well-designed monthly survey.

### Georeferencing rules

- Store source geometry (point/line/polygon), datum, coordinate uncertainty and source scale; never reduce a survey tow or receiver array to an unqualified point.
- For radius occurrence acceptance require `greatCircleDistance + coordinateUncertainty <= policyRadius`; reject missing/large uncertainty according to source class.
- Use environment-aware distance: no crossing land barriers; separate Pacific coast, Central/South/San Pablo/Suisun bays, Carquinez and Delta hydrographic units.
- A 5 km radius is a **historical-nearby** label, not exact-spot proof. For sessile/micro-site-associated taxa such as monkeyface prickleback, require the same rocky shoreline unit or much tighter geometry.
- Survey data should be associated by station/tow footprint and estuary subregion; do not attach a monthly trawl catch to the nearest pier as though caught there.
- Telemetry requires receiver ID/location, deployment interval, uptime and filtered passage events. Collapse repeated detections into organism × receiver-array × passage windows.
- Deduplicate iNaturalist records propagated through OBIS/GBIF using occurrence ID, iNaturalist observation ID, taxon, coordinates/date and provider dataset.
- Record `observedAt`, `publishedAt`, `fetchedAt`, `sourceVersion`, `license`, `basisOfRecord`, `samplingProtocol`, `effort`, `count`, `absence`, `dropped/QC flags`, and a persistent source URL.
- **Occurrence is a historical prior, never current presence or abundance.** No “fish are here now” wording may be generated from OBIS, GBIF or iNaturalist.

## 5. Corrections to unsupported or over-precise existing claims

| Existing claim/pattern | Audit disposition | Replacement rule |
|---|---|---|
| “61°F halibut sweet spot,” 4–5× CPUE, 12,503 fish and 2019–2025 tripling from a fishing blog analysis | **Reject for production science.** It is not a peer-reviewed or CDFW-published analysis; effort, geography, zero catches, buoy matching and confounding are not reproducible. Juvenile ecophysiology research demonstrates temperature/salinity responses but does not validate a Bay Area 61°F catch optimum ([Madon 2002, DOI 10.3354/meps243235 — Crossref metadata](https://api.crossref.org/works/10.3354%2Fmeps243235)). | Use broad seasonal/habitat priors until a reproducible CDFW logbook model is obtained; model temperature with smooth uncertainty and out-of-sample validation, never a single magic threshold. |
| Striped-bass “53–57°F sweet spot,” “>62°F push deep/north,” and exact runoff/outmigration effects | **Unsupported/over-precise.** Historical temperature association and telemetry show flexible contingents, not these deterministic thresholds. | Represent temperature, outflow and season as covariates with population/study provenance; include resident and migratory contingents and wide uncertainty. Cite the actual telemetry paper ([Sabal et al. 2019 — Crossref metadata](https://api.crossref.org/works/10.1007/s12237-018-0467-7)). |
| Spawning migration “begins near 60°F” | **Too deterministic.** Temperature may covary with seasonal migration but is not a spot-level switch. | “Spring spawning migration timing varies with river conditions, temperature and population contingent”; no hard trigger without a population-specific primary model. |
| Barometric pressure makes swim bladders expand, causes discomfort, creates a pre-storm feeding frenzy, then lethargy | **Reject.** Air-pressure changes are tiny relative to hydrostatic pressure changes from modest depth movement, and no primary local evidence supports deterministic bite-state rules. Weather fronts also change wind, waves, turbidity and safety. | Remove barometric pressure from causal bite scoring. If retained for exploration, label as an unvalidated feature and test prospectively; never prescribe lure type from pressure alone. |
| Solunar major/minor windows cause maximum water displacement/current | **Reject causal claim.** Lunar transit is not equivalent to locally maximum current; tide amplitude/current timing are location-specific predictions. No primary local catch study validates solunar tables. | Use NOAA tide height/current predictions directly. Moon phase may enter only through its actual local tide effect or a preregistered experimental feature. |
| “Incoming flood is the prime feeding trigger” for all species/spots | **Overgeneralized.** Tidal access/current can matter, but response varies by species, habitat and station. | Use species × habitat hypotheses; learn effects from local standardized outcomes. Safety/current limits can remain hard gates. |
| Turbidity means striped bass “value vibration/scent,” with exact 20–100 Hz canals and a lure “40–80 Hz sweet spot” | **Mechanistic overreach.** General lateral-line biology does not validate branded lure performance, exact field frequencies or Bay Area catch gains. | Recommend broader presentation families based on physical conditions (visibility, current, snag/weed, casting distance) and label them field-tested hypotheses until controlled catch data exist. |
| Red/yellow penetrate turbid coastal water better; specific Gulp colors map to surfperch cone peaks | **Likely physically wrong and biologically overfit.** Spectral attenuation depends on suspended particles/CDOM; cone sensitivity does not prove a particular commercial color causes strikes. | Use contrast/visibility classes, not wavelength or brand precision. Capture actual water clarity/light and test lure classes prospectively. |
| Orange/red belly improves halibut strike rate; “match the hatch” color precision | **Anecdotal.** No primary corroboration found. | Keep as low-confidence angler heuristic only, never a model coefficient. |
| “Halibut night/low light produces disproportionately large fish,” 1–3 body-length strike window, 2–8 minute crypsis, 5–20 ft/piling-distance prescriptions | **Unsupported precision.** General ambush/crypsis biology does not establish these local numerical rules. | Retain “benthic ambush predator associated with soft substrate and structure edges” as a moderate-confidence mechanism; strip unsupported numbers. |
| Peninsula grunion runs as a reliable halibut trigger | **Geographic error risk.** Grunion are primarily a Southern California phenomenon; a published schedule does not establish Peninsula occurrence or halibut aggregation. | Do not operationalize north of the documented run range without exact local primary observations. Use observed local forage, not a statewide calendar. |
| Upwelling automatically draws massive anchovy/herring/smelt schools and target fish to shore | **Causal chain is too immediate.** NOAA supports upwelling → nutrients → productivity, but events are episodic and lags/spatial transport matter. | Use upwelling, chlorophyll and fronts as regional productivity covariates with lag candidates; validate against survey/catch outcomes. |
| Winter/summer beach morphology and predator positions stated as universal | **Plausible geomorphology, insufficient site specificity.** | Use actual beach profiles, wave history and mapped bars/rips when available; otherwise label field interpretation, not static biology. |
| Every science profile has `confidence: high` | **Reject.** Confidence is not claim-specific and several claims rely on inference/blogs. | Score each claim by source class, geographic transfer, recency, directness and replication. Taxonomy may be high while lure/timing guidance is low. |

## 6. Model design: species × spot × time without false precision

### Separate outputs

1. `legalAndAccessible`: fail-closed official gate.
2. `historicalOccurrencePrior`: probability/rank informed by independent datasets, recency, distance/uncertainty and source bias.
3. `habitatSuitability`: species-specific substrate, salinity, depth, structure, exposure and estuary-zone match.
4. `seasonalAvailability`: survey/telemetry-derived periodic distribution with year and climate uncertainty.
5. `liveEnvironmentalCompatibility`: current tide/current, temperature, waves, turbidity proxy, wind, chlorophyll/HAB; only where representative and fresh.
6. `catchability/presentation`: modest adjustment based on shore geometry and presentation constraints, not unverifiable fish psychology.
7. `finalRecommendation`: gated, calibrated score plus uncertainty interval and top supporting/limiting factors.

### Suggested statistical progression

- Start with interpretable hierarchical generalized additive models or Bayesian partial pooling by species and estuary/coast subregion, not hand-set threshold tables.
- Survey response: count/CPUE with gear effort offset, station random effects, month smooth, salinity/temperature/Secchi/depth and year/ocean-regime terms.
- Occurrence response: presence-only evidence should inform priors, not be naively trained against unobserved pseudo-absences. Correct for platform effort where possible.
- Telemetry response: individual-level passage events with receiver effort; do not fit to raw ping count.
- Presentation recommendations should be rules constrained by habitat/safety/gear legality and later updated from Bay Bite's own structured trip/catch logs. Do not claim causality from uncontrolled user logs.
- Validate by time-blocked and location-blocked cross-validation; report calibration, not only ranking accuracy. A source only “beats 520 edges” if it improves held-out calibration/usefulness without unacceptable coverage/licensing cost.

## 7. Phased priority

### P0 — scientific foundation before new bite scores

1. Replace universal habitat compatibility with exact species × substrate × salinity × depth/exposure rules; make incompatible states fail, unknown remain unknown.
2. Split/remove all scoring aggregates; align the 24 occurrence taxa and 22 editorial profiles to one taxonomic backbone with accepted scientific name, authority ID (WoRMS/ITIS), synonyms and regulatory identity.
3. Integrate NOAA SF Bay benthic polygons and CDFW Bay Study station/tow data; preserve sampling effort and survey protocol.
4. Redesign evidence ingestion to row-level records with deduplication, licenses, uncertainty and source provenance; stop using `species_counts` as if counts were effort-corrected abundance.
5. Remove/relabel unsupported thresholds and causal barometric/solunar/lure claims listed above.
6. Keep occurrence, habitat, live conditions and legality as separate features and user-visible explanations.

### P1 — time-varying ecology and safety

1. OTN/OBIS telemetry passage events for striped bass/sturgeon with receiver deployment effort.
2. NOAA ERDDAP upwelling, SST, chlorophyll anomaly and C-HARM; CalHABMAP/HABDAC observed coastal samples.
3. Verified exposed-coast bathymetry/substrate layer and hydrographic-unit geofencing.
4. Prospective Bay Bite outcome logging: exact taxon/photo confidence, no-catch effort, fishing minutes, method, location precision, release/retention, conditions and source sensor IDs.

### P2 — learned recommendation refinement

1. CalCOFI/forage/regime context where geographic coverage is defensible.
2. Species-specific abundance/availability models with blocked validation and uncertainty.
3. Presentation/lure/rig experiments based on preregistered categories, not brand folklore.
4. Add zero-edge taxa only after qualifying local survey/occurrence evidence; white sturgeon remains legal/conservation alert first.

## 8. Acceptance tests for the next phase

- No taxon is compatible with all habitats unless explicitly justified by a cited source.
- Every recommendation resolves to an exact taxon; aggregates cannot enter legal or suitability scoring.
- Every occurrence row includes persistent ID, source dataset, event date, geometry/uncertainty, basis, QC, license and fetch version.
- Duplicate iNaturalist records arriving through OBIS/GBIF count once.
- Telemetry repeated pings collapse to individual passage events and require receiver deployment coverage.
- Survey abundance includes effort and protocol; shore wording says “survey prior,” not “fish present now.”
- Radius occurrence never generates “here now,” “abundant,” or exact-casting-point language.
- Live data has metric-specific representativeness/freshness; stale or spatially incompatible inputs become unavailable.
- Removing pressure/solunar inputs does not reduce a hidden hand-coded score; any later use requires prospective validation.
- Model evaluation includes held-out locations and future time blocks, calibration and uncertainty.
- Current regulation/access/MPA/health gates remain independent and can veto a biologically high score.

## 9. Confidence and unresolved gaps

**High confidence:** the current universal habitat compatibility is invalid; the 520 edges are overwhelmingly community historical-occurrence evidence; occurrence is not abundance/current presence; CDFW Bay Study and NOAA benthic habitat are materially stronger reusable layers for estuarine abundance and habitat; barometric/solunar and magic-temperature claims are not adequately supported.

**Medium confidence:** OTN/OBIS telemetry can improve striped-bass/sturgeon seasonal passage priors if receiver effort and tag cohort metadata are obtained; ERDDAP products can improve regional environmental context if spatial representativeness and lag are modeled.

**Low/unknown:** coast-wide fine substrate/bathymetry uniformity; current local forage abundance; causal lure color/vibration effects; local grunion relevance; exact licensing/automation terms for some SFEI/ArcGIS/telemetry resources.

## Primary sources and verifiable endpoints

1. [CDFW — San Francisco Bay Study](https://wildlife.ca.gov/Conservation/Delta/Bay-Study) — survey purpose, geography, 52 monthly stations, gears, measurements and CPUE indices.
2. [NOAA — SF Bay Benthic Habitat 2011 ArcGIS item](https://www.arcgis.com/home/item.html?id=80e75d135a18428892602fc279dfde5f) — substrate/biotic/geoform scope, direct service/download and CC0 statement.
3. [NOAA — SF Bay Benthic Habitat FeatureServer](https://coast.noaa.gov/arcgis/rest/services/Hosted/san_francisco_bay_2011/FeatureServer).
4. [CDFW — MPA ds582 FeatureServer](https://services2.arcgis.com/Uq9r85Potqm3MfRV/arcgis/rest/services/biosds582_fpu/FeatureServer) — screening geometry and explicit non-legal/non-navigational limitation.
5. [OBIS API](https://api.obis.org/v3/) and [OBIS data standards](https://manual.obis.org/data_format.html).
6. [OBIS data access manual](https://manual.obis.org/access.html) and [OBIS QC](https://manual.obis.org/data_qc.html).
7. [Ocean Tracking Network public discovery](https://members.oceantrack.org/data/discovery).
8. [GBIF Occurrence API](https://techdocs.gbif.org/en/openapi/v1/occurrence).
9. [iNaturalist API documentation](https://api.inaturalist.org/v1/docs/).
10. [NOAA CoastWatch ERDDAP](https://coastwatch.pfeg.noaa.gov/erddap/index.html).
11. [NOAA ERDDAP CalCOFI search](https://coastwatch.pfeg.noaa.gov/erddap/search/index.html?page=1&itemsPerPage=100&searchFor=CalCOFI).
12. [NOAA ERDDAP upwelling-index search](https://coastwatch.pfeg.noaa.gov/erddap/search/index.html?page=1&itemsPerPage=100&searchFor=upwelling%20index).
13. [NOAA — Northern California Current oceanography](https://www.fisheries.noaa.gov/west-coast/science-data/oceanography-northern-california-current-study-area).
14. [NOAA ERDDAP C-HARM v3.1 nowcast](https://coastwatch.pfeg.noaa.gov/erddap/griddap/wvcharmV3_0day.html).
15. [CalHABMAP](https://calhabmap.org/) — weekly network description and HABDAC/ERDDAP access.
16. [NOAA Benthic Data Hub](https://coast.noaa.gov/digitalcoast/data/benthiccover.html).
17. [Environmental Data Initiative portal](https://portal.edirepository.org/nis/home.jsp).
18. [Sabal et al. 2019 — seasonal movement of striped bass; Crossref metadata](https://api.crossref.org/works/10.1007/s12237-018-0467-7).
19. [Madon 2002 — juvenile California halibut ecophysiology; Crossref metadata](https://api.crossref.org/works/10.3354%2Fmeps243235).
20. [Fodrie & Levin 2008 — juvenile habitat contribution to California halibut](https://levin.ucsd.edu/publications/2008_L&O_Fodrie_&_Levin.pdf).
21. [Peer-reviewed evaluation of three SF Estuary fish surveys; Crossref metadata](https://api.crossref.org/works/10.15447%2Fsfews.2018v16iss4art2).
22. [Variation of fish habitat/low-salinity zone with freshwater flow; Crossref metadata](https://api.crossref.org/works/10.15447%2Fsfews.2013v11iss4art1).

## Retrieval limitations

The configured web-search/web-extract backend had no usable credits, the `agent-reach` CLI was not installed, several Cloudflare-protected pages blocked automated text retrieval, and the historical UC Davis fish-tracking host did not respond. This audit therefore used direct HTTP retrieval of known official pages/APIs, live API test queries, local source artifacts, ArcGIS REST metadata and Crossref DOI metadata. No claim above relies on an unread search-result snippet. Blocked or unverified licensing/data endpoints are explicitly marked as gaps rather than assumed reusable.
