# Bay Bite community-evidence disposition — 2026-08-13

**Owner:** Arthur Blake  
**Input:** `community-evidence-review.json` / `.md`  
**Scope:** Public recommendation graph disposition; community evidence does not establish access, legality, regulation, MPA status, or current presence.

## Decision

### Source-owner firsthand evidence

DRE DAWG reported on 2026-08-13 that he has personally caught striped bass at Point Pinole.

- Spot mapping: `spot:point-pinole-shore`
- Species: striped bass
- Source class: `source-owner-firsthand-catch-report`
- Evidence status: verified as the user's own statement
- Exact date, exact pier-versus-shore casting position, fish size/count, bait or lure, tide, and conditions: not supplied
- Allowed use: historical exact-location catch-pattern corroboration
- Prohibited inference: does not establish present fish presence, abundance, current legality, or conditions today

The firsthand report should supersede the forum thread as the strongest exact-location historical catch-pattern provenance while remaining separate from quality-controlled OBIS locality evidence.

The review examined 110 lead instances across 17 locations and accepted two candidate species edges from one Point Pinole Pier forum thread. Their public-data dispositions differ:

1. **Striped bass at Point Pinole Pier — ACCEPT AS SUPPLEMENTAL HISTORICAL CATCH-PATTERN EVIDENCE**
   - Source: https://www.pierfishing.com/msgboard/index.php?threads/point-pinole-pier.619/
   - Event date: 2019-03-17
   - Exactness: exact pier within Point Pinole Regional Shoreline
   - Confidence: medium secondary evidence
   - Use: may supplement the existing quality-controlled OBIS striped-bass locality edge for `spot:point-pinole-shore`.
   - Required warning: eyewitness historical catch report; not proof for every shoreline casting point, current presence, abundance, or current legality.
   - Must not increase the research-acceptance edge count independently when the OBIS striped-bass edge already exists; retain as corroborating provenance rather than a duplicate species vote.

2. **Reported steelhead at Point Pinole Pier — RETAIN IN AUDIT TRAIL ONLY**
   - Source: same thread
   - Event date: 2019-03-24
   - Confidence: low
   - Reason: one uncorroborated first-person report with no independently verified identification. Steelhead regulatory and handling sensitivity makes promotion into a public target/recommendation graph inappropriate without authoritative corroboration.
   - Must not be ranked, recommended, or used to satisfy a spot evidence threshold.

## Rejected leads

All other reviewed leads remain rejected for the reasons recorded in `community-evidence-review.json`: unrelated or same-name locations, copied CDFW/public-pier lists, questions without catches, generic or regional claims, inaccessible page bodies, ecology material rather than catches, or insufficient exact-location provenance.

## Integration guard

Engineering may import only the striped-bass item under the supplemental/corroborating semantics above. The steelhead report and rejected leads remain non-public audit evidence. Neither item changes the independently verified catalog total of 101 accepted locations.
