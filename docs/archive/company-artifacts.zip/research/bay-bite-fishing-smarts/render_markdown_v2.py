import json
from pathlib import Path
from collections import defaultdict
ROOT=Path('/root/company/research/bay-bite-fishing-smarts')
d=json.loads((ROOT/'spot-catalog-100-v2.json').read_text())
ev=defaultdict(list)
for x in d['spotSpeciesEvidence']:ev[x['spotId']].append(x)
accepted=[s for s in d['spots'] if s['researchAcceptance']['acceptedActionable']]
L=['# Bay Bite spot catalog v2','',f"**Generated:** {d['generatedAt']}  ",f"**Candidates:** {len(d['spots'])} · **research-accepted actionable:** {len(accepted)} · **rejected/pending:** {len(d['spots'])-len(accepted)}  ",'', '> This is a research bundle, not a live legal-open declaration. Current rules/notices remain an independent fail-closed integration gate.','', '## Accepted records','']
for s in accepted:
 L += [f"### {s['displayName']} (`{s['id']}`)",'',f"- **Coordinate:** {s['coordinates']['lat']}, {s['coordinates']['lon']} ({s['coordinates']['precision']})",f"- **Owner/jurisdiction:** {s['ownerJurisdiction']}",f"- **Access:** `{s['access']['state']}` checked {s['access']['checkedAt']}; sources: {', '.join(s['access']['sourceIds'])}",f"- **License boundary:** {s['licenseBoundary']}",f"- **Habitat:** {s['physicalProfile']['summary']} Substrate: {s['physicalProfile']['substrate']}; salinity: {s['physicalProfile']['salinity']}; exposure: {s['physicalProfile']['exposure']}.",f"- **Tactic:** {s['tactics'][0]}",f"- **Safety/retreat:** {s['safety']['hazardsAndRetreat'][0]}",f"- **MPA:** `{s['mpaAdjudication']['status']}`; {s['mpaAdjudication']['warning']}",'- **Species edges:**']
 for e in ev[s['id']]:L.append(f"  - `{e['speciesId']}` — {e['evidenceType']}, confidence `{e['confidence']}`, sources {', '.join(e['sourceIds'])}")
 L.append('- **Sensors:**')
 for b in s['sensorBindings']:
  L.append(f"  - `{b['metric']}`: {b.get('sensorId',b.get('availability'))}; {b.get('distanceKm','—')} km; {b.get('representativeness','—')}; {b['warning']}")
 L.append('')
L += ['## Rejected or pending','', '| Spot | Reasons |','|---|---|']
for x in d['rejectedOrPending']:L.append(f"| `{x['spotId']}` {x['name']} | {', '.join(x['reasons'])} |")
L += ['','## Source register','', '| ID | Owner class | Checked | URL |','|---|---|---|---|']
for x in d['sources']:L.append(f"| `{x['id']}` | {x['owner']} | {x['checkedAt']} | {x['url']} |")
(ROOT/'spot-catalog-100-v2.md').write_text('\n'.join(L)+'\n')
print('rendered',len(L),'lines')
