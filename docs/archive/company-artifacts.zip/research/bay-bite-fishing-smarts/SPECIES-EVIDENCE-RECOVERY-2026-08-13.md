# Bay Bite — species-evidence-only recovery

**Checked:** 2026-08-13  
**Analyst:** Priya Chen, under Arthur Blake  
**Scope:** The 17 candidates whose only v2 blocker was `fewer-than-two-local-species-evidence-edges`. Internal research artifact only; no production/publication authorization.

## Outcome

- **Recovered:** 17/17
- **New research-accepted total:** 77 (from 60)
- **Still unresolved in this 17-spot lane:** 0
- **Catalog-wide remaining rejected/pending:** 54, all for gates outside this species-only assignment
- **Requested catalog-wide >=100:** not met; no thresholds were lowered and no habitat-only edges were admitted

## Method and controls

Used the maintained OBIS API as an open biodiversity occurrence aggregator, with species-level queries centered on each catalog coordinate. Each query was bounded to 2000-01-01 through 2026-08-13 and a 5 km polygon, then records were independently distance-filtered. Accepted records had to be presence records, not dropped by OBIS, biologically compatible with the local marine/brackish environment, and satisfy **point distance + stated coordinate uncertainty <=5 km**. The retained snapshot records dates, basis of record, dataset/provider, occurrence ID, OBIS flags, distance, and coordinate uncertainty.

OBIS documents geometry/date/species filtering and provides QC fields such as `flags` and `dropped`: https://manual.obis.org/access.html and https://api.obis.org/. Community observations aggregated by OBIS remain local occurrence corroboration, not exact casting-point catch proof; managed survey/telemetry records are labeled by their provider. Confidence is `medium` for >=3 qualifying records and `low` for 1–2.

## Newly accepted records

| Spot ID | Accepted species edges | Qualifying records |
|---|---|---:|
| `spot:benicia-9th-st-pier` | Striped bass; topsmelt | 11; 1 |
| `spot:big-break-pier` | Striped bass; starry flounder | 200; 1 |
| `spot:blind-beach` | Lingcod; striped seaperch | 3; 4 |
| `spot:bodega-south-jetty` | Cabezon; monkeyface prickleback | 13; 14 |
| `spot:chicken-ranch-beach` | Bat ray; leopard shark | 30; 9 |
| `spot:cullinan-ranch-pier` | Striped bass; bat ray | 11; 3 |
| `spot:drakes-beach` | Bat ray; redtail surfperch | 9; 2 |
| `spot:hearts-desire-beach` | Bat ray; leopard shark | 34; 11 |
| `spot:john-sheridan-pier` | Bat ray; California halibut | 32; 6 |
| `spot:kehoe-beach` | Pacific staghorn sculpin; redtail surfperch | 5; 1 |
| `spot:point-pinole-shore` | Striped bass; bat ray | 7; 7 |
| `spot:salmon-creek-north` | Cabezon; redtail surfperch | 10; 6 |
| `spot:schoolhouse-beach` | Striped seaperch; cabezon | 5; 2 |
| `spot:shell-beach-sonoma` | Striped seaperch; lingcod | 5; 2 |
| `spot:shollenberger-pier` | Striped bass; starry flounder | 20; 1 |
| `spot:spud-point-pier` | Monkeyface prickleback; jacksmelt | 16; 4 |
| `spot:veterans-pier-alameda` | Bat ray; California halibut | 129; 13 |

Counts above exclude occurrences whose point distance plus coordinate uncertainty exceeded 5 km. Full record-level provenance is retained in `.obis-local-targets.json`; the generated catalog stores the query URL, count, nearest distance, maximum accepted distance-plus-uncertainty, date range, provider classes, controls, confidence, and uncertainty warning on every edge.

## Verification

`python3 build_catalog_v2.py`, `python3 render_markdown_v2.py`, and `python3 qa_catalog_v2.py` completed successfully. Deterministic QA returned zero errors: 77/77 accepted records have exact access sources, >=2 species edges, clear catalog-point MPA screens, sensor bindings, and unique tactic/safety text. The 34 new OBIS edges all pass the new radius/count/date/quality-control/distance-plus-uncertainty assertions.
