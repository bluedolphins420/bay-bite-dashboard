# Bay Bite spot catalog v2

**Generated:** 2026-08-13T00:00:00Z  
**Candidates:** 131 · **research-accepted actionable:** 101 · **rejected/pending:** 30  

> This is a research bundle, not a live legal-open declaration. Current rules/notices remain an independent fail-closed integration gate.

## Accepted records

### Ocean Beach (`spot:ocean-beach`)

- **Coordinate:** 37.7597, -122.5107 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-goga-planyourvisit-oceanbeach-htm-f9be9823b4
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Ocean Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.7597, -122.5107, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Ocean Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Ocean Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c14f4ad0cc
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c14f4ad0cc
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c14f4ad0cc
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c14f4ad0cc
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-c14f4ad0cc
- **Sensors:**
  - `tide`: sensor:9414275; 1.7 km; local; Not measured at this shore.
  - `wave`: sensor:46237; 11.3 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46026; 28.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46237; 11.3 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Baker Beach (`spot:baker-beach`)

- **Coordinate:** 37.7934, -122.483 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-goga-planyourvisit-baker-beach-htm-8bcd648e29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Baker Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.7934, -122.4830, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Baker Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Baker Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f6428ceb67
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f6428ceb67
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f6428ceb67
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f6428ceb67
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f6428ceb67
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f6428ceb67
- **Sensors:**
  - `tide`: sensor:9414275; 3.3 km; local; Not measured at this shore.
  - `wave`: sensor:46237; 13.3 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46026; 31.5 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46237; 13.3 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Torpedo Wharf / Fort Point Pier (`spot:torpedo-wharf`)

- **Coordinate:** 37.8081, -122.4752 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Torpedo Wharf / Fort Point Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8081, -122.4752. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Torpedo Wharf / Fort Point Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Torpedo Wharf / Fort Point Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1e04af6065
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1e04af6065
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1e04af6065
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1e04af6065
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1e04af6065
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1e04af6065
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-fort-point-pier-4f4b754d80
- **Sensors:**
  - `tide_level`: sensor:9414290; 0.9 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 7.2 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Pier 7 — Embarcadero (`spot:pier-7`)

- **Coordinate:** 37.7987, -122.396 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Pier 7 — Embarcadero pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7987, -122.3960. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Pier 7 — Embarcadero, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Pier 7 — Embarcadero: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0253a77284
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0253a77284
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0253a77284
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0253a77284
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0253a77284
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0253a77284
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0253a77284
- **Sensors:**
  - `tide_level`: sensor:9414290; 6.1 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 0.2 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Pier 14 — Embarcadero (`spot:pier-14`)

- **Coordinate:** 37.7934, -122.3891 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Pier 14 — Embarcadero pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7934, -122.3891. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Pier 14 — Embarcadero, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Pier 14 — Embarcadero: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7794115d37
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7794115d37
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7794115d37
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7794115d37
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7794115d37
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7794115d37
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7794115d37
- **Sensors:**
  - `tide_level`: sensor:9414290; 6.9 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 0.6 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Linda Mar / Pacifica State Beach (`spot:linda-mar`)

- **Coordinate:** 37.5946, -122.5036 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** City of Pacifica
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-cityofpacifica-org--safety-guides-pacifica-state-beach-7bb923a2d0
- **License boundary:** Licensed ocean shoreline: California sport-fishing license required for anglers 16+ unless another statutory exception applies.
- **Habitat:** At Linda Mar / Pacifica State Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.5946, -122.5036, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Linda Mar / Pacifica State Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Linda Mar / Pacifica State Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb
- **Sensors:**
  - `tide`: sensor:9414131; 10.4 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 42.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 42.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 42.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Redwood City Pier (`spot:redwood-city-pier`)

- **Coordinate:** 37.508, -122.211 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city, county, port, or USFWS owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-redwoodcity-org-departments-port-of-redwood-city-96efa029dc
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Redwood City Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.5080, -122.2110. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Redwood City Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Redwood City Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-e250f907ba
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-redwood-city-marina-fishing-pier-2-0d9b845ad0
- **Sensors:**
  - `tide_level`: sensor:9414523; 0.2 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Dumbarton Pier (`spot:dumbarton-pier`)

- **Coordinate:** 37.5054, -122.1145 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city, county, port, or USFWS owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Dumbarton Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.5054, -122.1145. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Dumbarton Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Dumbarton Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4b7eaa3397
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4b7eaa3397
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4b7eaa3397
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4b7eaa3397
  - `species:channel-catfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4b7eaa3397
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4b7eaa3397
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-dumbarton-pier-6-18c8883feb
- **Sensors:**
  - `tide_level`: sensor:9414523; 8.5 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Alameda Rock Wall (`spot:alameda-rock-wall`)

- **Coordinate:** 37.7704, -122.3066 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Alameda Rock Wall breakwater, specifically its armor stones, harbor face and seaward face; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7704, -122.3066. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Alameda Rock Wall, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact breakwater boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Alameda Rock Wall: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31
- **Sensors:**
  - `tide_level`: sensor:9414750; 0.6 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 3.9 km; local; Not measured at this shore.
  - `current`: sensor:s10010; 5.0 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Emeryville Marina Pier (`spot:emeryville-marina`)

- **Coordinate:** 37.8429, -122.3101 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Emeryville Marina Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8429, -122.3101. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Emeryville Marina Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Emeryville Marina Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-67f6d8981d
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-67f6d8981d
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-67f6d8981d
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-67f6d8981d
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-67f6d8981d
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-67f6d8981d
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-emeryville-marina-pier-a92be1ecb4
- **Sensors:**
  - `tide_level`: sensor:9414750; 8.0 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 5.0 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### San Leandro Marina Pier (`spot:san-leandro-marina`)

- **Coordinate:** 37.6956, -122.1919 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named San Leandro Marina Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.6956, -122.1919. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At San Leandro Marina Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for San Leandro Marina Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-9b13ac5ee1
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-9b13ac5ee1
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-9b13ac5ee1
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-9b13ac5ee1
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-san-leandro-marina-pier-95aa48e7a6
- **Sensors:**
  - `tide_level`: sensor:9414750; 12.8 km; regional; Not measured at this shore.
  - `wind`: sensor:9414769; 16.9 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Point Pinole Pier (`spot:point-pinole`)

- **Coordinate:** 38.0058, -122.3623 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-parks-point-pinole-b1b4a482f7
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Point Pinole Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.0058, -122.3623. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Point Pinole Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Point Pinole Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-68e174afb1
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-68e174afb1
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-68e174afb1
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-68e174afb1
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-68e174afb1
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-68e174afb1
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-68e174afb1
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-point-pinole-pier-05168e0b68
- **Sensors:**
  - `tide_level`: sensor:9414863; 9.3 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 23.0 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### China Camp Shoreline (`spot:china-camp`)

- **Coordinate:** 38.0017, -122.462 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks (operated with Friends of China Camp)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-chinacamp-47da3bc642
- **License boundary:** Licensed shoreline: California sport-fishing license required for anglers 16+ unless another statutory exception applies.
- **Habitat:** China Camp Shoreline is a licensed shore/bank record at 38.0017, -122.4620: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful China Camp Shoreline shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for China Camp Shoreline: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-229de41fa6
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-229de41fa6
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-229de41fa6
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-229de41fa6
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-229de41fa6
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-229de41fa6
- **Sensors:**
  - `tide_level`: sensor:9414863; 9.8 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 23.5 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Paradise Beach Pier (`spot:paradise-beach`)

- **Coordinate:** 37.9171, -122.4764 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-parks-marincounty-gov-preserves-parks-paradise-beach-park-ff338fafd4
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Paradise Beach Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.9171, -122.4764. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Paradise Beach Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Paradise Beach Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8f77e31c6
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8f77e31c6
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8f77e31c6
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8f77e31c6
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8f77e31c6
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8f77e31c6
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-paradise-beach-pier-tiburon-50aa614fdb
- **Sensors:**
  - `tide_level`: sensor:9414863; 6.9 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 15.2 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### McNears Beach Pier (`spot:mcnears-beach`)

- **Coordinate:** 37.9961, -122.4482 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-parks-marincounty-gov-spreserves-parks-mcnears-beach-park-916d7d9b61
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named McNears Beach Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.9961, -122.4482. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At McNears Beach Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for McNears Beach Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-mcnear-beach-fishing-pier-8b08417b60
- **Sensors:**
  - `tide_level`: sensor:9414863; 8.7 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 22.6 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Martinez Marina Pier (`spot:martinez-marina`)

- **Coordinate:** 38.0194, -122.1371 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city / East Bay Regional Park District / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Martinez Marina Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.0194, -122.1371. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Martinez Marina Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Martinez Marina Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-3b2191efa6
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3b2191efa6
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3b2191efa6
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3b2191efa6
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3b2191efa6
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3b2191efa6
- **Sensors:**
  - `tide_level`: sensor:9415102; 2.0 km; local; Not measured at this shore.
  - `current`: sensor:s06010; 2.0 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 11.9 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Islais Creek Pier (`spot:islais-creek-pier`)

- **Coordinate:** 37.7462, -122.3858 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Islais Creek Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7462, -122.3858. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Islais Creek Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Islais Creek Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-a35434eff1
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-a35434eff1
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-a35434eff1
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-a35434eff1
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-a35434eff1
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-a35434eff1
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-a35434eff1
- **Sensors:**
  - `tide_level`: sensor:9414290; 9.6 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 5.7 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Agua Vista Pier (`spot:agua-vista-pier`)

- **Coordinate:** 37.7673, -122.3868 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Agua Vista Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7673, -122.3868. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Agua Vista Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Agua Vista Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-agua-vista-pier-san-francisco-ed41be4593
- **Sensors:**
  - `tide_level`: sensor:9414290; 8.1 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 3.5 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### South Beach Harbor Pier (`spot:south-beach-harbor-pier`)

- **Coordinate:** 37.7829, -122.3881 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named South Beach Harbor Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7829, -122.3881. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At South Beach Harbor Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for South Beach Harbor Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6
- **Sensors:**
  - `tide_level`: sensor:9414290; 7.2 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 1.7 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Pier 45 / Fisherman’s Wharf (`spot:pier-45`)

- **Coordinate:** 37.8094, -122.415 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Pier 45 / Fisherman’s Wharf pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8094, -122.4150. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Pier 45 / Fisherman’s Wharf, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Pier 45 / Fisherman’s Wharf: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-794ed607b4
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-794ed607b4
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-794ed607b4
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-794ed607b4
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-794ed607b4
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-794ed607b4
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-794ed607b4
- **Sensors:**
  - `tide_level`: sensor:9414290; 4.4 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 2.2 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Saint Francis Jetty / Marina Green (`spot:st-francis-jetty`)

- **Coordinate:** 37.8079, -122.4471 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Saint Francis Jetty / Marina Green jetty, specifically its armor blocks, harbor face, ocean face and tip; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8079, -122.4471. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Saint Francis Jetty / Marina Green, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact jetty boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Saint Francis Jetty / Marina Green: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95
- **Sensors:**
  - `tide_level`: sensor:9414290; 1.7 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 4.8 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Crissy Field Shoreline (`spot:crissy-field`)

- **Coordinate:** 37.8049, -122.465 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service, Golden Gate National Recreation Area
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-ourvisit-crissy-field-promenade-htm-33850b5e91
- **License boundary:** Licensed beach shoreline. The nearby Torpedo Wharf public-pier exemption does not extend to Crissy Field beach, seawall, or breakwater.
- **Habitat:** Crissy Field Shoreline is a licensed shore/bank record at 37.8049, -122.4650: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Crissy Field Shoreline shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Crissy Field Shoreline: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13
- **Sensors:**
  - `tide_level`: sensor:9414290; 0.2 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 6.3 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### China Beach (`spot:china-beach`)

- **Coordinate:** 37.7883, -122.4903 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-goga-planyourvisit-chinabeach-htm-9d8bffa42c
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At China Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.7883, -122.4903, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful China Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for China Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71
- **Sensors:**
  - `tide`: sensor:9414275; 2.4 km; local; Not measured at this shore.
  - `wave`: sensor:46237; 12.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46026; 30.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46237; 12.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Lands End / Sutro Baths Rocks (`spot:lands-end`)

- **Coordinate:** 37.779, -122.5137 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service, Golden Gate National Recreation Area
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-goga-planyourvisit-landsend-htm-3cc0d2d9dd
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** Lands End / Sutro Baths Rocks is a licensed shore/bank record at 37.7790, -122.5137: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At the lawful Lands End / Sutro Baths Rocks shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Lands End / Sutro Baths Rocks: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4fb2019a57
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4fb2019a57
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4fb2019a57
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4fb2019a57
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4fb2019a57
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4fb2019a57
- **Sensors:**
  - `tide`: sensor:9414275; 0.4 km; local; Not measured at this shore.
  - `wave`: sensor:46237; 10.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46026; 28.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46237; 10.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Rodeo Beach (`spot:rodeo-beach`)

- **Coordinate:** 37.8328, -122.5381 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service, Golden Gate National Recreation Area
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-ourvisit-rodeo-beach-and-lagoon-htm-7eeacdf824
- **License boundary:** Licensed ocean beach; no public-pier exemption.
- **Habitat:** At Rodeo Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.8328, -122.5381, not a depth survey. Substrate: sand/reef mix; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** From the lawful Rodeo Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Rodeo Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-08ebe725e0
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-08ebe725e0
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-08ebe725e0
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-08ebe725e0
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-08ebe725e0
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-08ebe725e0
- **Sensors:**
  - `tide_level`: sensor:9414290; 7.0 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 13.3 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Muir Beach (`spot:muir-beach`)

- **Coordinate:** 37.8626, -122.5826 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-goga-planyourvisit-muirbeach-htm-8f1327d452
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Muir Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.8626, -122.5826, not a depth survey. Substrate: sand/reef mix; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** From the lawful Muir Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Muir Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-afe5aa5a93
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-afe5aa5a93
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-afe5aa5a93
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-afe5aa5a93
- **Sensors:**
  - `tide_level`: sensor:9414290; 12.0 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 18.1 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Stinson Beach (`spot:stinson-beach`)

- **Coordinate:** 37.9005, -122.645 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-goga-stbe-htm-5b03bf1db3
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Stinson Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.9005, -122.6450, not a depth survey. Substrate: sand/reef mix; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** From the lawful Stinson Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Stinson Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7a2b2afc8d
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7a2b2afc8d
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7a2b2afc8d
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7a2b2afc8d
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7a2b2afc8d
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-7a2b2afc8d
- **Sensors:**
  - `tide_level`: sensor:9414863; 21.7 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 24.8 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Bolinas Beach / Lagoon Mouth (`spot:bolinas-beach`)

- **Coordinate:** 37.9085, -122.686 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** County of Marin
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-marincounty-gov-h-reopened-under-permanent-advisory-eb7c718e7b
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** Bolinas Beach / Lagoon Mouth is a licensed shore/bank record at 37.9085, -122.6860: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Bolinas Beach / Lagoon Mouth shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Bolinas Beach / Lagoon Mouth: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5964def0b3
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5964def0b3
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5964def0b3
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5964def0b3
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5964def0b3
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5964def0b3
- **Sensors:**
  - `tide_level`: sensor:9414863; 25.2 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 28.5 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Elephant Rock Pier (`spot:elephant-rock`)

- **Coordinate:** 37.8733, -122.4581 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Elephant Rock Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8733, -122.4581. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Elephant Rock Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Elephant Rock Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-elephant-rock-pier-4-f155e2aaac
- **Sensors:**
  - `tide_level`: sensor:9414290; 7.4 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 10.2 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Acqua Hotel Pier (`spot:acqua-hotel-pier`)

- **Coordinate:** 37.8906, -122.5179 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Acqua Hotel Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8906, -122.5179. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Acqua Hotel Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Acqua Hotel Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc8b56e507
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc8b56e507
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc8b56e507
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc8b56e507
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc8b56e507
- **Sensors:**
  - `tide_level`: sensor:9414863; 11.1 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 15.0 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### San Antonio Pier / Oakland Estuary (`spot:san-antonio-pier`)

- **Coordinate:** 37.7892, -122.2509 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named San Antonio Pier / Oakland Estuary pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7892, -122.2509. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At San Antonio Pier / Oakland Estuary, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for San Antonio Pier / Oakland Estuary: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bc73446ad5
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bc73446ad5
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bc73446ad5
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bc73446ad5
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bc73446ad5
  - `species:channel-catfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-bc73446ad5
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-san-antonio-pier-oakland-529edc67be
- **Sensors:**
  - `tide_level`: sensor:9414750; 4.8 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 7.0 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Webster St. / Jack London Pier (`spot:jack-london-pier`)

- **Coordinate:** 37.795, -122.276 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Webster St. / Jack London Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7950, -122.2760. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Webster St. / Jack London Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Webster St. / Jack London Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-95d75913d2
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-95d75913d2
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-95d75913d2
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-95d75913d2
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-95d75913d2
  - `species:channel-catfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-95d75913d2
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-95d75913d2
- **Sensors:**
  - `tide_level`: sensor:9414750; 3.3 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 4.8 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Union Point Park Pier (`spot:union-point-park`)

- **Coordinate:** 37.7829, -122.2439 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Union Point Park Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7829, -122.2439. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Union Point Park Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Union Point Park Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b8721cabb0
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b8721cabb0
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b8721cabb0
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b8721cabb0
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b8721cabb0
  - `species:channel-catfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-b8721cabb0
- **Sensors:**
  - `tide_level`: sensor:9414750; 5.2 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 7.8 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Arrowhead Marsh / MLK Pier (`spot:arrowhead-marsh`)

- **Coordinate:** 37.7363, -122.2088 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Arrowhead Marsh / MLK Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7363, -122.2088. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Arrowhead Marsh / MLK Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Arrowhead Marsh / MLK Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1f4747c0c8
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1f4747c0c8
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1f4747c0c8
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1f4747c0c8
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-1f4747c0c8
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-pier-oakland-arrowhead-marsh-pier-2-590222794d
- **Sensors:**
  - `tide_level`: sensor:9414750; 8.9 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 12.8 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Doolittle Drive Pier (`spot:doolittle-pier`)

- **Coordinate:** 37.7359, -122.2109 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Doolittle Drive Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7359, -122.2109. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Doolittle Drive Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Doolittle Drive Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0e45174235
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0e45174235
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0e45174235
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0e45174235
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-0e45174235
- **Sensors:**
  - `tide_level`: sensor:9414750; 8.9 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 12.8 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Port View Park Pier (`spot:port-view-park`)

- **Coordinate:** 37.7955, -122.3174 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Port View Park Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7955, -122.3174. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Port View Park Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Port View Park Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-port-view-park-pier-898567ef97
- **Sensors:**
  - `tide_level`: sensor:9414750; 3.0 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 1.3 km; local; Not measured at this shore.
  - `current`: sensor:s10010; 2.8 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Estuary Park Pier (`spot:estuary-park-pier`)

- **Coordinate:** 37.7907, -122.2866 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Estuary Park Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7907, -122.2866. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Estuary Park Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Estuary Park Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597
  - `species:channel-catfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-estuary-park-pier-oakland-2-8a204aef2b
- **Sensors:**
  - `tide_level`: sensor:9414750; 2.4 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 3.9 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Ferry Point Pier / Miller Knox (`spot:ferry-point`)

- **Coordinate:** 37.9102, -122.3841 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-parks-miller-knox-23c1780f8d
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Ferry Point Pier / Miller Knox pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.9102, -122.3841. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Ferry Point Pier / Miller Knox, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Ferry Point Pier / Miller Knox: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-ferry-point-pier-richmond-59a84ed44d
- **Sensors:**
  - `tide_level`: sensor:9414863; 2.4 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 12.4 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Eckley Pier (`spot:eckley-pier`)

- **Coordinate:** 38.041, -122.228 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city / East Bay Regional Park District / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-parks-carquinez-strait-971071292a
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Eckley Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.0410, -122.2280. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Eckley Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Eckley Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-27424240dd
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-27424240dd
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-27424240dd
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-27424240dd
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-27424240dd
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-27424240dd
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-eckley-pier-2-aaa5d95eed
- **Sensors:**
  - `tide_level`: sensor:9415102; 9.1 km; local; Not measured at this shore.
  - `current`: sensor:s06010; 9.1 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 3.5 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Cuttings Wharf (`spot:cuttings-wharf`)

- **Coordinate:** 38.1988, -122.3157 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** Napa County / USFWS (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Cuttings Wharf pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.1988, -122.3157. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Cuttings Wharf, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Cuttings Wharf: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b82050a3dc
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-b82050a3dc
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-b82050a3dc
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-eckley-pier-2-aaa5d95eed
- **Sensors:**
  - `tide_level`: sensor:9414863; 30.9 km; regional; Not measured at this shore.
  - `current`: sensor:s08010; 32.8 km; regional; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9414847; 32.8 km; regional; Not measured at this shore.
  - `temperature`: sensor:scqc1; 25.4 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Gray Whale Cove (`spot:gray-whale-cove`)

- **Coordinate:** 37.5633, -122.5141 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-def9028787
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** At Gray Whale Cove, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.5633, -122.5141, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Gray Whale Cove beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Gray Whale Cove: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1b7f757bc2
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1b7f757bc2
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1b7f757bc2
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1b7f757bc2
- **Sensors:**
  - `tide`: sensor:9414131; 7.4 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 39.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 39.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 39.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Half Moon Bay State Beach (`spot:half-moon-bay-state-beach`)

- **Coordinate:** 37.4642, -122.4455 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-halfmoonbay-00c7c5f4b8
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Half Moon Bay State Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.4642, -122.4455, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Half Moon Bay State Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Half Moon Bay State Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4ad8f5576
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4ad8f5576
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4ad8f5576
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4ad8f5576
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4ad8f5576
- **Sensors:**
  - `tide`: sensor:9414131; 5.4 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 40.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 40.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 40.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Pomponio State Beach (`spot:pomponio-state-beach`)

- **Coordinate:** 37.2926, -122.407 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-204f32da9d
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** At Pomponio State Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.2926, -122.4070, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Pomponio State Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Pomponio State Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-32920ea81e
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-32920ea81e
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-32920ea81e
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-32920ea81e
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-32920ea81e
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-32920ea81e
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-32920ea81e
- **Sensors:**
  - `tide`: sensor:9414131; 24.3 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 42.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 42.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 42.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Pescadero State Beach (`spot:pescadero-state-beach`)

- **Coordinate:** 37.2644, -122.4121 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-pescadero-4c92c12d83
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** At Pescadero State Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.2644, -122.4121, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Pescadero State Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Pescadero State Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-58dcb4974d
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-58dcb4974d
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-58dcb4974d
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-58dcb4974d
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-58dcb4974d
- **Sensors:**
  - `tide`: sensor:9414131; 27.2 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 42.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 42.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 42.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### San Gregorio State Beach (`spot:san-gregorio-state-beach`)

- **Coordinate:** 37.3237, -122.4038 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-44a723bdc6
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** At San Gregorio State Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.3237, -122.4038, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful San Gregorio State Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for San Gregorio State Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc16d1269f
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc16d1269f
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-cc16d1269f
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-cc16d1269f
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-cc16d1269f
- **Sensors:**
  - `tide`: sensor:9414131; 21.1 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 42.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 42.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 42.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Bean Hollow / Pebble Beach (`spot:bean-hollow`)

- **Coordinate:** 37.2267, -122.4112 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:parks-ca-gov-beanhollow-b4dd9e55a5
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** Bean Hollow / Pebble Beach is a licensed shore/bank record at 37.2267, -122.4112: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At the lawful Bean Hollow / Pebble Beach shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Bean Hollow / Pebble Beach: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-6d134515bd
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-6d134515bd
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-6d134515bd
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-6d134515bd
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-6d134515bd
- **Sensors:**
  - `tide`: sensor:9414131; 31.3 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 43.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 43.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 43.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Rockaway Beach (`spot:pacifica-rockaway`)

- **Coordinate:** 37.6097, -122.4977 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** City of Pacifica
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-cityofpacifica-org-eaches-locations-maps-safety-guides-1b3ea894b5
- **License boundary:** Licensed ocean shoreline; Pacifica Pier exemption does not extend to Rockaway Beach.
- **Habitat:** At Rockaway Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.6097, -122.4977, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Rockaway Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Rockaway Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d
- **Sensors:**
  - `tide`: sensor:9414131; 12.0 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 44.1 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 44.1 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 44.1 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Sharp Park Beach (`spot:sharp-park-beach`)

- **Coordinate:** 37.6345, -122.4942 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** City of Pacifica
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-cityofpacifica-org-eaches-locations-maps-safety-guides-1b3ea894b5
- **License boundary:** Licensed beach shoreline; the Pacifica Municipal Pier exemption applies only on the qualifying pier.
- **Habitat:** At Sharp Park Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.6345, -122.4942, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Sharp Park Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Sharp Park Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad
- **Sensors:**
  - `tide`: sensor:9414131; 14.6 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 46.1 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 46.1 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 46.1 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Candlestick Eastern Fishing Pier (`spot:candlestick-eastern-pier`)

- **Coordinate:** 37.7089, -122.3827 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Candlestick Eastern Fishing Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7089, -122.3827. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Candlestick Eastern Fishing Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Candlestick Eastern Fishing Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4ce24551a6
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4ce24551a6
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4ce24551a6
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4ce24551a6
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4ce24551a6
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4ce24551a6
- **Sensors:**
  - `tide_level`: sensor:9414290; 13.1 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 10.0 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Candlestick Point Shoreline (`spot:candlestick-shore`)

- **Coordinate:** 37.7115, -122.3838 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:parks-ca-gov-candlestickpoint-46c6a2ed76
- **License boundary:** California license required for anglers 16+ on the shoreline; no license is required only on the park's public fishing pier.
- **Habitat:** Candlestick Point Shoreline is a licensed shore/bank record at 37.7115, -122.3838: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Candlestick Point Shoreline shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Candlestick Point Shoreline: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09
- **Sensors:**
  - `tide_level`: sensor:9414290; 12.8 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 9.6 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Fort Mason Pier 2 (`spot:fort-mason-pier-2`)

- **Coordinate:** 37.8062, -122.432 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Fort Mason Pier 2 pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8062, -122.4320. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Fort Mason Pier 2, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Fort Mason Pier 2: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1
- **Sensors:**
  - `tide_level`: sensor:9414290; 3.0 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 3.5 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Fort Mason Pier 3 (`spot:fort-mason-pier-3`)

- **Coordinate:** 37.8064, -122.4302 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Port of San Francisco / City and County of San Francisco (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Fort Mason Pier 3 pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8064, -122.4302. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Fort Mason Pier 3, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Fort Mason Pier 3: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7
- **Sensors:**
  - `tide_level`: sensor:9414290; 3.1 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 3.3 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Sierra Point Pier (`spot:sierra-point-pier`)

- **Coordinate:** 37.6737, -122.3871 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** City or county owner / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Sierra Point Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.6737, -122.3871. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Sierra Point Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Sierra Point Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-51665a1733
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-51665a1733
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-51665a1733
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-51665a1733
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-51665a1733
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-51665a1733
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-51665a1733
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-brisbane-pier-9778529b2e
- **Sensors:**
  - `tide_level`: sensor:9414290; 16.3 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 13.9 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Fort Baker Fishing Pier (`spot:fort-baker-pier`)

- **Coordinate:** 37.831, -122.4784 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-ces-000-fort-baker-fishing-pier-htm-16cbbd09d3
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Fort Baker Fishing Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8310, -122.4784. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Fort Baker Fishing Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Fort Baker Fishing Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-de84f16bde
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-de84f16bde
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-de84f16bde
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-de84f16bde
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-de84f16bde
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-de84f16bde
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-de84f16bde
- **Sensors:**
  - `tide_level`: sensor:9414290; 3.0 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 8.3 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Fort Baker Jetty (`spot:fort-baker-jetty`)

- **Coordinate:** 37.8304, -122.4758 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / Marin County Parks / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Fort Baker Jetty jetty, specifically its armor blocks, harbor face, ocean face and tip; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.8304, -122.4758. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Fort Baker Jetty, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact jetty boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Fort Baker Jetty: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b3c8945763
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b3c8945763
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b3c8945763
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b3c8945763
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b3c8945763
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b3c8945763
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b3c8945763
- **Sensors:**
  - `tide_level`: sensor:9414290; 2.8 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 8.1 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Half Moon Bay East Jetty (`spot:pillar-point-east-jetty`)

- **Coordinate:** 37.5007, -122.4794 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Half Moon Bay East Jetty jetty, specifically its armor blocks, harbor face, ocean face and tip; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.5007, -122.4794. Substrate: riprap/pilings; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At Half Moon Bay East Jetty, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact jetty boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Half Moon Bay East Jetty: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b9fd0110ee
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b9fd0110ee
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b9fd0110ee
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b9fd0110ee
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b9fd0110ee
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b9fd0110ee
- **Sensors:**
  - `tide`: sensor:9414131; 0.4 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 38.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 38.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 38.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Half Moon Bay West Jetty (`spot:pillar-point-west-jetty`)

- **Coordinate:** 37.5028, -122.491 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Half Moon Bay West Jetty jetty, specifically its armor blocks, harbor face, ocean face and tip; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.5028, -122.4910. Substrate: riprap/pilings; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At Half Moon Bay West Jetty, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact jetty boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Half Moon Bay West Jetty: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-086a1b3a89
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-086a1b3a89
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-086a1b3a89
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-086a1b3a89
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-086a1b3a89
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-086a1b3a89
- **Sensors:**
  - `tide`: sensor:9414131; 0.7 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 38.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 38.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 38.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Pillar Point Harbor Fishing Pier (`spot:pillar-point-pier`)

- **Coordinate:** 37.5031, -122.485 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Pillar Point Harbor Fishing Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.5031, -122.4850. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Pillar Point Harbor Fishing Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Pillar Point Harbor Fishing Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ad1c3b5c5a
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ad1c3b5c5a
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ad1c3b5c5a
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ad1c3b5c5a
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ad1c3b5c5a
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-ad1c3b5c5a
- **Sensors:**
  - `tide_level`: sensor:9414290; 33.7 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 33.7 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Miramar Beach (`spot:miramar-beach`)

- **Coordinate:** 37.493, -122.4607 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** San Mateo County Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-smcgov-org-parks-mirada-surf-9a8d81bba2
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** At Miramar Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.4930, -122.4607, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Miramar Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Miramar Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-79b74c5b6c
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-79b74c5b6c
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-79b74c5b6c
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-79b74c5b6c
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-79b74c5b6c
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-79b74c5b6c
- **Sensors:**
  - `tide`: sensor:9414131; 2.2 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 40.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 40.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 40.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Dunes Beach (`spot:dunes-beach`)

- **Coordinate:** 37.4827, -122.4502 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-halfmoonbay-00c7c5f4b8
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Dunes Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.4827, -122.4502, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Dunes Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Dunes Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c52fafa957
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c52fafa957
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c52fafa957
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c52fafa957
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c52fafa957
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c52fafa957
- **Sensors:**
  - `tide`: sensor:9414131; 3.5 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 40.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 40.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 40.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Venice Beach (Half Moon Bay) (`spot:venice-beach-hmb`)

- **Coordinate:** 37.474, -122.448 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-halfmoonbay-00c7c5f4b8
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Venice Beach (Half Moon Bay), the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.4740, -122.4480, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Venice Beach (Half Moon Bay) beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Venice Beach (Half Moon Bay): remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0c1e25278b
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0c1e25278b
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0c1e25278b
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0c1e25278b
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0c1e25278b
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-0c1e25278b
- **Sensors:**
  - `tide`: sensor:9414131; 4.4 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 40.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 40.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 40.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Francis Beach (`spot:francis-beach`)

- **Coordinate:** 37.468, -122.445 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / San Mateo County Harbor District / City of Half Moon Bay (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-halfmoonbay-00c7c5f4b8
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Francis Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.4680, -122.4450, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Francis Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Francis Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bdf6d4764e
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bdf6d4764e
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bdf6d4764e
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bdf6d4764e
  - `species:white-croaker` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-bdf6d4764e
- **Sensors:**
  - `tide`: sensor:9414131; 5.0 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 40.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 40.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 40.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Poplar Beach (`spot:poplar-beach`)

- **Coordinate:** 37.4483, -122.444 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** City of Half Moon Bay
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-half-moon-bay-ca-us-732-beaches-3414e8ae95
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** At Poplar Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.4483, -122.4440, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Poplar Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Poplar Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-44bc5e276b
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-44bc5e276b
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-44bc5e276b
- **Sensors:**
  - `tide`: sensor:9414131; 6.9 km; local; Not measured at this shore.
  - `wave`: sensor:46012; 40.0 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 40.0 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 40.0 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Cowell Ranch Beach (`spot:cowell-ranch-beach`)

- **Coordinate:** 37.4217, -122.435 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-44a723bdc6
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** At Cowell Ranch Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 37.4217, -122.4350, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Cowell Ranch Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Cowell Ranch Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-eac62c03f5
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-eac62c03f5
- **Sensors:**
  - `tide`: sensor:9414131; 9.8 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 40.0 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 40.0 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 40.0 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Pigeon Point shoreline north cove (`spot:pigeon-point-beach`)

- **Coordinate:** 37.1828, -122.3944 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-pigeonpoint-5fb97b744a
- **License boundary:** Licensed ocean shoreline; no public-pier exemption.
- **Habitat:** Pigeon Point shoreline north cove is a licensed shore/bank record at 37.1828, -122.3944: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At the lawful Pigeon Point shoreline north cove shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Pigeon Point shoreline north cove: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8b48d5fadf
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8b48d5fadf
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8b48d5fadf
  - `species:blue-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-8b48d5fadf
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-8b48d5fadf
- **Sensors:**
  - `tide`: sensor:9414131; 36.3 km; regional; Not measured at this shore.
  - `wave`: sensor:46012; 47.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46012; 47.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46012; 47.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Point Isabel shoreline (`spot:point-isabel-shore`)

- **Coordinate:** 37.9011, -122.3241 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-maps-point-isabel-a6e7fd2398
- **License boundary:** Licensed shoreline: a California State fishing license is required to fish from shore; no public-pier exemption is claimed.
- **Habitat:** Point Isabel shoreline is a licensed shore/bank record at 37.9011, -122.3241: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Point Isabel shoreline shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Point Isabel shoreline: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-4b7bf6bfd3
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-d17dc418e2
- **Sensors:**
  - `tide_level`: sensor:9414863; 7.2 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 11.1 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### John J. Sheridan Pier (`spot:john-sheridan-pier`)

- **Coordinate:** 37.9168, -122.3885 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named John J. Sheridan Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.9168, -122.3885. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At John J. Sheridan Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for John J. Sheridan Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-dea6ad2f0b
  - `species:california-halibut` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-d44ac8aeb9
- **Sensors:**
  - `tide_level`: sensor:9414863; 1.7 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 13.1 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Barbara & Jay Vincent Park Jetty (`spot:vincent-park-jetty`)

- **Coordinate:** 37.9093, -122.3891 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Barbara & Jay Vincent Park Jetty jetty, specifically its armor blocks, harbor face, ocean face and tip; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.9093, -122.3891. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Barbara & Jay Vincent Park Jetty, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact jetty boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Barbara & Jay Vincent Park Jetty: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea
- **Sensors:**
  - `tide_level`: sensor:9414863; 2.4 km; local; Not measured at this shore.
  - `wind`: sensor:9414311; 12.4 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Point Pinole licensed shoreline (`spot:point-pinole-shore`)

- **Coordinate:** 38.004, -122.356 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-parks-point-pinole-b1b4a482f7
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** Point Pinole licensed shoreline is a licensed shore/bank record at 38.0040, -122.3560: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Point Pinole licensed shoreline shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Point Pinole licensed shoreline: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-c5dccd37db
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-d3afd3a427
- **Sensors:**
  - `tide_level`: sensor:9414863; 9.3 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 22.8 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Veterans Pier, Alameda (`spot:veterans-pier-alameda`)

- **Coordinate:** 37.7836, -122.3028 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Veterans Pier, Alameda pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7836, -122.3028. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Veterans Pier, Alameda, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Veterans Pier, Alameda: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-e80f2aba30
  - `species:california-halibut` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-9b2fb044a0
- **Sensors:**
  - `tide_level`: sensor:9414750; 1.3 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 3.1 km; local; Not measured at this shore.
  - `current`: sensor:s10010; 4.4 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### San Antonio North Pier (`spot:san-antonio-north-pier`)

- **Coordinate:** 37.7922, -122.2494 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / city or port owner (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named San Antonio North Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 37.7922, -122.2494. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At San Antonio North Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for San Antonio North Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-34b37a3ec6
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-34b37a3ec6
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-34b37a3ec6
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-34b37a3ec6
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-34b37a3ec6
  - `species:channel-catfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-34b37a3ec6
- **Sensors:**
  - `tide_level`: sensor:9414750; 5.0 km; local; Not measured at this shore.
  - `wind`: sensor:9414769; 7.2 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Coyote Point licensed shoreline (`spot:coyote-point-shore`)

- **Coordinate:** 37.588, -122.32 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** San Mateo County Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-smcgov-org-parks-coyote-point-recreation-area-ce8be5e174
- **License boundary:** Licensed shoreline/breakwater for anglers 16+ unless the angler is standing on a separately qualifying public pier; no adjacent-structure exemption is inferred.
- **Habitat:** Coyote Point licensed shoreline is a licensed shore/bank record at 37.5880, -122.3200: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Coyote Point licensed shoreline shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Coyote Point licensed shoreline: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:leopard-shark` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-0dd3b85e78
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-095165ba2b
- **Sensors:**
  - `tide_level`: sensor:9414523; 13.1 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Palo Alto Baylands designated fishing area (`spot:palo-alto-baylands`)

- **Coordinate:** 37.4592, -122.1082 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** City of Palo Alto Open Space
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-cityofpaloalto-org-maps-baylands-fishing-locations-pdf-0e33feef47
- **License boundary:** Licensed Bay shoreline/designated bank; no public-pier exemption unless standing on a separately qualifying public pier.
- **Habitat:** Palo Alto Baylands designated fishing area is a licensed shore/bank record at 37.4592, -122.1082: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Palo Alto Baylands designated fishing area shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Palo Alto Baylands designated fishing area: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-a394dd4c0b
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-a394dd4c0b
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-a394dd4c0b
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-a394dd4c0b
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-a394dd4c0b
- **Sensors:**
  - `tide_level`: sensor:9414523; 10.6 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Benicia Point Fishing Pier (`spot:benicia-point-pier`)

- **Coordinate:** 38.0458, -122.1588 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city / East Bay Regional Park District / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Benicia Point Fishing Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.0458, -122.1588. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Benicia Point Fishing Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Benicia Point Fishing Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-3811502508
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-3811502508
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3811502508
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3811502508
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3811502508
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-3811502508
- **Sensors:**
  - `tide_level`: sensor:9415102; 3.1 km; local; Not measured at this shore.
  - `current`: sensor:s06010; 3.1 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 9.3 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### 9th Street Pier, Benicia (`spot:benicia-9th-st-pier`)

- **Coordinate:** 38.0584, -122.1683 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city / East Bay Regional Park District / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named 9th Street Pier, Benicia pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.0584, -122.1683. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At 9th Street Pier, Benicia, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for 9th Street Pier, Benicia: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-64cde1263c
  - `species:topsmelt` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-4d80dd7727
- **Sensors:**
  - `tide_level`: sensor:9415102; 4.6 km; local; Not measured at this shore.
  - `current`: sensor:s06010; 4.6 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 8.3 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Benicia State Recreation Area shoreline (`spot:benicia-state-rec-shore`)

- **Coordinate:** 38.0763, -122.1912 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-1ae385d03e
- **License boundary:** Licensed shoreline: the official park brochure requires anglers age 16+ to carry a valid California fishing license.
- **Habitat:** Benicia State Recreation Area shoreline is a licensed shore/bank record at 38.0763, -122.1912: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Benicia State Recreation Area shoreline shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Benicia State Recreation Area shoreline: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-d31334b414
  - `species:starry-flounder` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-785f5e69d9
- **Sensors:**
  - `tide_level`: sensor:9415102; 7.4 km; local; Not measured at this shore.
  - `current`: sensor:s06010; 7.4 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 6.9 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Vallejo Launch Ramp Fishing Pier (`spot:vallejo-launch-pier`)

- **Coordinate:** 38.105, -122.267 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city / East Bay Regional Park District / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Vallejo Launch Ramp Fishing Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.1050, -122.2670. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Vallejo Launch Ramp Fishing Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Vallejo Launch Ramp Fishing Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b4d892a166
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-b4d892a166
  - `species:channel-catfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-b4d892a166
- **Sensors:**
  - `tide_level`: sensor:9415102; 14.6 km; regional; Not measured at this shore.
  - `current`: sensor:s06010; 14.6 km; regional; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 5.4 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Cullinan Ranch Fishing Pier (`spot:cullinan-ranch-pier`)

- **Coordinate:** 38.1717, -122.3705 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** Napa County / USFWS (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Cullinan Ranch Fishing Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.1717, -122.3705. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Cullinan Ranch Fishing Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Cullinan Ranch Fishing Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-e927028702
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-700eef932d
- **Sensors:**
  - `tide_level`: sensor:9414863; 27.2 km; regional; Not measured at this shore.
  - `current`: sensor:s08010; 28.7 km; regional; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9414847; 29.6 km; regional; Not measured at this shore.
  - `temperature`: sensor:scqc1; 20.6 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Martinez Regional Shoreline bank (`spot:martinez-shoreline`)

- **Coordinate:** 38.0198, -122.136 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District / City of Martinez
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-les-radke-martinez-map-brochure-pdf-d50576a8a7
- **License boundary:** California fishing license and stamps are required from shore for anglers 16+; the no-license exception is limited to the marina fishing pier.
- **Habitat:** Martinez Regional Shoreline bank is a licensed shore/bank record at 38.0198, -122.1360: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Martinez Regional Shoreline bank shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Martinez Regional Shoreline bank: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-9c8277ee3d
  - `species:starry-flounder` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-461e9ad960
- **Sensors:**
  - `tide_level`: sensor:9415102; 1.9 km; local; Not measured at this shore.
  - `current`: sensor:s06010; 1.9 km; local; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 11.9 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Pittsburg Marina fishing pier (`spot:pittsburg-marina-pier`)

- **Coordinate:** 38.0395, -121.884 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** city / East Bay Regional Park District / California State Parks (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Pittsburg Marina fishing pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.0395, -121.8840. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Pittsburg Marina fishing pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Pittsburg Marina fishing pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-11f8e9893f
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-11f8e9893f
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-11f8e9893f
- **Sensors:**
  - `tide_level`: sensor:9415102; 21.1 km; regional; Not measured at this shore.
  - `current`: sensor:s06010; 21.1 km; regional; Not measured at this shore. Channel/depth-bin current is not shoreline current.
  - `wind`: sensor:9415141; 33.3 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Antioch/Oakley Regional Shoreline Pier (`spot:antioch-oakley-pier`)

- **Coordinate:** 38.0177, -121.7518 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-parks-antioch-oakley-84238648be
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Antioch/Oakley Regional Shoreline Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.0177, -121.7518. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Antioch/Oakley Regional Shoreline Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Antioch/Oakley Regional Shoreline Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-ioch-oakley-regional-shoreline-pier-3d6379ee54
  - `species:bat-ray` — reviewed-secondary-exact-spot-catch-pattern, confidence `medium`, sources source:www-pierfishing-com-ioch-oakley-regional-shoreline-pier-3d6379ee54
- **Sensors:**
  - `tide_level`: sensor:9415144; 25.6 km; regional; Not measured at this shore.
  - `wind`: sensor:9415115; 12.0 km; regional; Not measured at this shore.
  - `temperature`: sensor:fffc1; 31.5 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Big Break Regional Shoreline Pier (`spot:big-break-pier`)

- **Coordinate:** 38.104, -121.7307 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** East Bay Regional Park District
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:www-ebparks-org-parks-big-break-6d75a074f0
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Big Break Regional Shoreline Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.1040, -121.7307. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Big Break Regional Shoreline Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Big Break Regional Shoreline Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-ac81470c12
  - `species:starry-flounder` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-26d453f7d0
- **Sensors:**
  - `tide_level`: sensor:9415144; 27.6 km; regional; Not measured at this shore.
  - `wind`: sensor:9415115; 15.4 km; regional; Not measured at this shore.
  - `temperature`: sensor:fffc1; 28.3 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Belden’s Landing fishing pier (`spot:belden-landing-pier`)

- **Coordinate:** 38.19, -121.9942 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** Solano County / California Department of Fish and Wildlife (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Belden’s Landing fishing pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.1900, -121.9942. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Belden’s Landing fishing pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Belden’s Landing fishing pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-1191b0ccad
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-1191b0ccad
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-1191b0ccad
- **Sensors:**
  - `tide_level`: sensor:9415144; 15.4 km; regional; Not measured at this shore.
  - `wind`: sensor:9415115; 19.1 km; regional; Not measured at this shore.
  - `temperature`: sensor:fffc1; 3.5 km; local; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Spud Point Public Pier (`spot:spud-point-pier`)

- **Coordinate:** 38.3305, -123.0552 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Spud Point Public Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.3305, -123.0552. Substrate: riprap/pilings; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Spud Point Public Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Spud Point Public Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-a9235f9551
  - `species:jacksmelt` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-f65c3cfd2f
- **Sensors:**
  - `tide_level`: sensor:9414863; 72.8 km; proxy; Not measured at this shore.
  - `wind`: sensor:9414311; 82.8 km; proxy; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Bodega Bay South Jetty (`spot:bodega-south-jetty`)

- **Coordinate:** 38.303, -123.06 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Bodega Bay South Jetty jetty, specifically its armor blocks, harbor face, ocean face and tip; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.3030, -123.0600. Substrate: riprap/pilings; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At Bodega Bay South Jetty, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact jetty boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Bodega Bay South Jetty: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:cabezon` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-7a63c25c83
  - `species:monkeyface-prickleback` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-1a4e4671bb
- **Sensors:**
  - `tide`: sensor:9415625; 0.7 km; local; Not measured at this shore.
  - `wave`: sensor:46013; 23.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 23.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 23.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Bodega Bay North Jetty (`spot:bodega-north-jetty`)

- **Coordinate:** 38.3068, -123.0608 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Bodega Bay North Jetty jetty, specifically its armor blocks, harbor face, ocean face and tip; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.3068, -123.0608. Substrate: riprap/pilings; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At Bodega Bay North Jetty, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact jetty boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Bodega Bay North Jetty: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5b9d46c79b
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5b9d46c79b
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5b9d46c79b
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5b9d46c79b
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-5b9d46c79b
- **Sensors:**
  - `tide`: sensor:9415625; 0.6 km; local; Not measured at this shore.
  - `wave`: sensor:46013; 23.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 23.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 23.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Doran Regional Park Beach (`spot:doran-beach`)

- **Coordinate:** 38.313, -123.043 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** Sonoma County Regional Parks
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:parks-sonomacounty-ca-gov-sit-find-a-park-doran-regional-park-14794741b1
- **License boundary:** Licensed beach shoreline for anglers 16+ unless another statutory exception applies; no pier exemption extends to the beach or land-touching rock jetty.
- **Habitat:** At Doran Regional Park Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.3130, -123.0430, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Doran Regional Park Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Doran Regional Park Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:redtail-surfperch` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-ac4f2dfa75
  - `species:jacksmelt` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-03521dd523
- **Sensors:**
  - `tide`: sensor:9415625; 1.1 km; local; Not measured at this shore.
  - `wave`: sensor:46013; 25.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 25.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 25.4 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Salmon Creek Beach South (`spot:salmon-creek-south`)

- **Coordinate:** 38.3505, -123.069 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-d7c98fdf29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Salmon Creek Beach South, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.3505, -123.0690, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Salmon Creek Beach South beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Salmon Creek Beach South: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-06d9eb6766
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-06d9eb6766
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-06d9eb6766
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-06d9eb6766
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-06d9eb6766
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-06d9eb6766
- **Sensors:**
  - `tide`: sensor:9415625; 4.8 km; local; Not measured at this shore.
  - `wave`: sensor:46013; 25.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 25.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 25.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Salmon Creek Beach North (`spot:salmon-creek-north`)

- **Coordinate:** 38.365, -123.074 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-d7c98fdf29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Salmon Creek Beach North, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.3650, -123.0740, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Salmon Creek Beach North beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Salmon Creek Beach North: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:cabezon` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-1339bf4d52
  - `species:redtail-surfperch` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-1d381f0cc0
- **Sensors:**
  - `tide`: sensor:9415625; 6.5 km; local; Not measured at this shore.
  - `wave`: sensor:46013; 25.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 25.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 25.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Wright’s Beach (`spot:wrights-beach`)

- **Coordinate:** 38.4004, -123.096 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-d7c98fdf29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Wright’s Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.4004, -123.0960, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Wright’s Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Wright’s Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8916ea59a
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8916ea59a
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-d8916ea59a
- **Sensors:**
  - `tide`: sensor:9415625; 10.9 km; regional; Not measured at this shore.
  - `wave`: sensor:46013; 26.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 26.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 26.7 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Shell Beach, Sonoma Coast (`spot:shell-beach-sonoma`)

- **Coordinate:** 38.4185, -123.105 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-d7c98fdf29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** Shell Beach, Sonoma Coast is a licensed shore/bank record at 38.4185, -123.1050: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At the lawful Shell Beach, Sonoma Coast shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Shell Beach, Sonoma Coast: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-seaperch` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-30704cde5a
  - `species:lingcod` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-66b897d62a
- **Sensors:**
  - `tide`: sensor:9415625; 13.0 km; regional; Not measured at this shore.
  - `wave`: sensor:46013; 27.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 27.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 27.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Schoolhouse Beach (`spot:schoolhouse-beach`)

- **Coordinate:** 38.4243, -123.1103 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-d7c98fdf29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** Schoolhouse Beach is a licensed shore/bank record at 38.4243, -123.1103: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** At the lawful Schoolhouse Beach shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Schoolhouse Beach: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-seaperch` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-ceeafcf8c8
  - `species:cabezon` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-e73131f1a6
- **Sensors:**
  - `tide`: sensor:9415625; 13.7 km; regional; Not measured at this shore.
  - `wave`: sensor:46013; 27.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 27.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 27.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Goat Rock Beach (`spot:goat-rock-beach`)

- **Coordinate:** 38.4477, -123.126 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-d7c98fdf29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Goat Rock Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.4477, -123.1260, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Goat Rock Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Goat Rock Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4937f15072
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-4937f15072
  - `species:monkeyface-prickleback` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4937f15072
  - `species:black-rockfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-4937f15072
- **Sensors:**
  - `tide`: sensor:9415625; 16.7 km; regional; Not measured at this shore.
  - `wave`: sensor:46013; 28.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 28.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 28.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Blind Beach (`spot:blind-beach`)

- **Coordinate:** 38.461, -123.133 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** California State Parks / Sonoma County Regional Parks / harbor district (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-d7c98fdf29
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Blind Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.4610, -123.1330, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Blind Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Blind Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:lingcod` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-7ddf7eeb23
  - `species:striped-seaperch` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-fc894ab5a1
- **Sensors:**
  - `tide`: sensor:9415625; 18.3 km; regional; Not measured at this shore.
  - `wave`: sensor:46013; 29.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46013; 29.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46013; 29.8 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Shollenberger Pier (`spot:shollenberger-pier`)

- **Coordinate:** 38.228, -122.596 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** City of Petaluma
- **Access:** `open` checked 2026-08-13T00:00:00Z; sources: source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8
- **License boundary:** No California sport-fishing license required only while fishing from this exact qualifying public pier/most-seaward harbor jetty; all other rules apply. Adjacent shore/rock wall is not exempt.
- **Habitat:** The actionable unit is the named Shollenberger Pier pier, specifically its deck, pilings, outer rail and shoreward apron; surrounding shore, walking bridges and land-touching rock walls are different legal and hydrodynamic units. Substrate is structure over local sand/mud or riprap at 38.2280, -122.5960. Substrate: riprap/pilings; salinity: brackish-variable; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At Shollenberger Pier, first fish the current shadow of the named structure, then its outer edge; keep bottom gear inside the exact pier boundary and use a landing net from the rail. If current will not hold, shift to the protected face instead of adding unsafe weight or stepping onto adjacent rocks.
- **Safety/retreat:** Retreat for Shollenberger Pier: leave by the public deck/crest to the signed landward entrance; wet armor, rail closures, vessel wakes, overhead casting conflicts, or an owner barrier end the session. Never descend to adjacent shore to land a fish without satisfying that shore's separate license/access rules.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:striped-bass` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-a3a6214458
  - `species:starry-flounder` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-e2b818455e
- **Sensors:**
  - `tide_level`: sensor:9415144; 52.2 km; regional; Not measured at this shore.
  - `wind`: sensor:9415115; 65.4 km; proxy; Not measured at this shore.
  - `temperature`: sensor:fffc1; 49.3 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Limantour Beach outside posted closures (`spot:limantour-beach`)

- **Coordinate:** 38.027, -122.899 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-e-planyourvisit-limantour-beach-htm-f9b4901f89
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Limantour Beach outside posted closures, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.0270, -122.8990, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Limantour Beach outside posted closures beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Limantour Beach outside posted closures: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:barred-surfperch` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2da5cc1fe2
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2da5cc1fe2
  - `species:lingcod` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-2da5cc1fe2
  - `species:striped-bass` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-2da5cc1fe2
  - `species:starry-flounder` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-2da5cc1fe2
- **Sensors:**
  - `tide`: sensor:9415020; 7.6 km; local; Not measured at this shore.
  - `wave`: sensor:46214; 50.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46214; 50.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46214; 50.6 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Drakes Beach lawful shoreline (`spot:drakes-beach`)

- **Coordinate:** 38.0277, -122.961 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-pore-planyourvisit-drakes-beach-htm-4be2a374d1
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Drakes Beach lawful shoreline, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.0277, -122.9610, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Drakes Beach lawful shoreline beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Drakes Beach lawful shoreline: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-2ccf2f6c7f
  - `species:redtail-surfperch` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-8e83dcc32a
- **Sensors:**
  - `tide`: sensor:9415020; 3.7 km; local; Not measured at this shore.
  - `wave`: sensor:46214; 45.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46214; 45.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46214; 45.2 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Kehoe Beach (`spot:kehoe-beach`)

- **Coordinate:** 38.1605, -122.949 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-planyourvisit-kehoe-beach-trail-htm-cf3e23f451
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Kehoe Beach, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.1605, -122.9490, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Kehoe Beach beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Kehoe Beach: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:pacific-staghorn-sculpin` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-e1e12b88ee
  - `species:redtail-surfperch` — open-biodiversity-occurrences-within-5km, confidence `low`, sources source:api-obis-org-v3-occurrence-5875be2557
- **Sensors:**
  - `tide`: sensor:9415020; 18.5 km; regional; Not measured at this shore.
  - `wave`: sensor:46214; 51.3 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46214; 51.3 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46214; 51.3 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Abbotts Lagoon / Abadesi Beach lawful ocean shore (`spot:abadesi-beach`)

- **Coordinate:** 38.123, -122.956 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-nps-gov-re-planyourvisit-abbotts-lagoon-htm-162e1eca1a
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** At Abbotts Lagoon / Abadesi Beach lawful ocean shore, the mapped access meets a mobile sand beach; treat bars, the first trough, creek/lagoon influence when named, and any rocky bookend as separate micro-features. This is a map/owner-grounded coastal landform interpretation at 38.1230, -122.9560, not a depth survey. Substrate: sand/reef mix; salinity: marine; exposure: open swell/sneaker-wave exposure.
- **Tactic:** From the lawful Abbotts Lagoon / Abadesi Beach lawful ocean shore beach boundary, scan the first trough and bar cuts before rigging; start beside the most visible foam seam, then move along the named beach rather than repeatedly casting one feature. Match sinker hold to side-sweep and stop if the dry-sand retreat narrows.
- **Safety/retreat:** Retreat for Abbotts Lagoon / Abadesi Beach lawful ocean shore: remain seaward only while an uninterrupted dry-sand route back to the signed access is visible; rising run-up, creek-mouth scour, bluff fall, or closure signs are immediate turn-around triggers at this coordinate.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:topsmelt` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-31137c285a
  - `species:california-halibut` — community-research-grade-observations-within-5km, confidence `medium`, sources source:api-inaturalist-org-v1-observations-species-counts-31137c285a
  - `species:pacific-staghorn-sculpin` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-31137c285a
  - `species:jacksmelt` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-31137c285a
  - `species:brown-rockfish` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-31137c285a
  - `species:redtail-surfperch` — community-research-grade-observations-within-5km, confidence `low`, sources source:api-inaturalist-org-v1-observations-species-counts-31137c285a
- **Sensors:**
  - `tide`: sensor:9415020; 14.3 km; regional; Not measured at this shore.
  - `wave`: sensor:46214; 48.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `wind`: sensor:46214; 48.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.
  - `temperature`: sensor:46214; 48.9 km; regional; Not measured at this shore. Regional sea state only; never convert significant wave height to shore break.

### Heart’s Desire Beach lawful fishing area (`spot:hearts-desire-beach`)

- **Coordinate:** 38.141, -122.889 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-af8e425ee6
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** Heart’s Desire Beach lawful fishing area is a licensed shore/bank record at 38.1410, -122.8890: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Heart’s Desire Beach lawful fishing area shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Heart’s Desire Beach lawful fishing area: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-c4833f6b65
  - `species:leopard-shark` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-ed26c3d213
- **Sensors:**
  - `tide_level`: sensor:9414863; 48.9 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 57.8 km; proxy; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

### Chicken Ranch Beach lawful fishing area (`spot:chicken-ranch-beach`)

- **Coordinate:** 38.1185, -122.867 (catalog centroid; verify legal casting position on site)
- **Owner/jurisdiction:** National Park Service / California State Parks (record-specific)
- **Access:** `open_with_conditions` checked 2026-08-13T00:00:00Z; sources: source:www-parks-ca-gov-af8e425ee6
- **License boundary:** California sport-fishing license required for anglers 16+ unless a specific statutory exception applies.
- **Habitat:** Chicken Ranch Beach lawful fishing area is a licensed shore/bank record at 38.1185, -122.8670: a shallow intertidal margin of mud/sand with marsh edge, riprap, point, slough or channel margin as named. Water level can expose soft mud and move the fishable edge far from the catalog point. Substrate: mud/sand channel margin; salinity: estuarine; exposure: wind, tide and vessel-wake exposure.
- **Tactic:** At the lawful Chicken Ranch Beach lawful fishing area shoreline, cast from firm signed ground toward the nearest named point/slough/channel edge, not across marsh vegetation; fish the seam on moderate movement and shorten casts as the flat floods. Use a rig that can be retrieved without walking onto mud or wildlife habitat.
- **Safety/retreat:** Retreat for Chicken Ranch Beach lawful fishing area: preserve the signed trail or paved-bank route behind you; flooding tide, soft mud, riprap gaps, rail restrictions, wildlife buffers, or vessel wakes are stop conditions. Do not improvise access through marsh, private lots, or closed levees.
- **MPA:** `clear-at-catalog-point`; Point screen is not navigational/legal authority; confirm current Title 14 boundary before fishing near an MPA.
- **Species edges:**
  - `species:bat-ray` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-8bec0ea810
  - `species:leopard-shark` — open-biodiversity-occurrences-within-5km, confidence `medium`, sources source:api-obis-org-v3-occurrence-a016aea8b3
- **Sensors:**
  - `tide_level`: sensor:9414863; 46.1 km; regional; Not measured at this shore.
  - `wind`: sensor:9414311; 54.8 km; regional; Not measured at this shore.
  - `wave`: unavailable; — km; —; No environment-compatible observed wave station; ocean buoys intentionally not assigned inland.

## Rejected or pending

| Spot | Reasons |
|---|---|
| `spot:pacifica-pier` Pacifica Pier | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:mussel-rock` Mussel Rock / Thornton | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:montara-state-beach` Montara State Beach | exact-owner-or-qualifying-structure-access-source-insufficient, mpa-polygon-intersection |
| `spot:redondo-beach-hmb` Redondo Beach / Poplar Edge | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:municipal-pier-closed` San Francisco Municipal (Muni) Pier | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:warm-water-cove` Warm Water Cove Shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:herons-head` Heron’s Head Park Shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:martins-beach-public-tidelands` Martin’s Beach public tidelands candidate | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:berkeley-municipal-pier-closed` Berkeley Municipal Pier | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:berkeley-marina-shore` Berkeley Marina South Shore | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:albany-bulb-shore` Albany Bulb shoreline | exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:meeker-slough-shore` Meeker Slough / Marina Bay shoreline | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:point-san-pablo-shore` Point San Pablo Harbor public shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:garretson-point-shore` Garretson Point shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:tidewater-shore` Tidewater Boating Center shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:oyster-point-shore` Oyster Point licensed shoreline | exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:bayfront-park-millbrae` Bayfront Park Millbrae shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:ryder-park-shore` Ryder Park shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:leo-ryan-park-shore` Leo J. Ryan Park shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:seal-point-shore` Seal Point shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:foster-city-bay-trail` Foster City Bay Trail fishing shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:bair-island-access` Bair Island public access shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:ravenswood-open-space` Ravenswood Open Space shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:alviso-marina-shore` Alviso Marina County Park shoreline | exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:independence-park-shore` Independence Park licensed shoreline | exact-owner-or-qualifying-structure-access-source-insufficient |
| `spot:port-costa-shore` Port Costa public shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:crockett-shore` Crockett shoreline access | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:point-edith-shore` Point Edith public shoreline candidate | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:grizzly-island-road-bank` Grizzly Island Road designated bank access | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |
| `spot:bodega-head-west` Bodega Head west shoreline | access-not-actionable, exact-owner-or-qualifying-structure-access-source-insufficient, fewer-than-two-local-species-evidence-edges |

## Source register

| ID | Owner class | Checked | URL |
|---|---|---|---|
| `source:api-inaturalist-org-v1-observations-species-counts-0253a77284` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7987&lng=-122.396&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-0259ae7a86` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0584&lng=-122.1683&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-06d9eb6766` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.3505&lng=-123.069&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-086a1b3a89` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.5028&lng=-122.491&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-08ebe725e0` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8328&lng=-122.5381&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-0c1e25278b` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.474&lng=-122.448&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-0e45174235` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7359&lng=-122.2109&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-0fa37577e3` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0198&lng=-122.136&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-1191b0ccad` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.19&lng=-121.9942&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-11f8e9893f` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0395&lng=-121.884&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-1403f3a5d6` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7829&lng=-122.3881&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-1b7f757bc2` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.5633&lng=-122.5141&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-1d89f5b0a1` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.3305&lng=-123.0552&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-1dacc3bde2` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8733&lng=-122.4581&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-1e04af6065` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8081&lng=-122.4752&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-1f4747c0c8` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7363&lng=-122.2088&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-20be7a5a31` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7704&lng=-122.3066&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-229de41fa6` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0017&lng=-122.462&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-27424240dd` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.041&lng=-122.228&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-2803b34a99` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0763&lng=-122.1912&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-2c7c3abb13` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8049&lng=-122.465&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-2da5cc1fe2` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.027&lng=-122.899&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-31137c285a` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.123&lng=-122.956&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-32920ea81e` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.2926&lng=-122.407&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-34b37a3ec6` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7922&lng=-122.2494&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-3811502508` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0458&lng=-122.1588&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-3b2191efa6` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0194&lng=-122.1371&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-3cae1b2d69` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.004&lng=-122.356&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-44bc5e276b` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.4483&lng=-122.444&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-44bde7ff15` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8897&lng=-122.3193&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-4937f15072` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.4477&lng=-123.126&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-4b7eaa3397` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.5054&lng=-122.1145&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-4ce24551a6` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7089&lng=-122.3827&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-4d5b369b71` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7883&lng=-122.4903&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-4fb2019a57` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.779&lng=-122.5137&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-4fccd73f2f` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.104&lng=-121.7307&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-50115b29ea` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.4243&lng=-123.1103&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-51665a1733` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.6737&lng=-122.3871&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-51981fa494` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.141&lng=-122.889&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-533069265f` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7836&lng=-122.3028&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-58dcb4974d` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.2644&lng=-122.4121&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-5964def0b3` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9085&lng=-122.686&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-5b9d46c79b` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.3068&lng=-123.0608&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-5c3fcfc2c1` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8062&lng=-122.432&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-5cf3e6449c` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9961&lng=-122.4482&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-6042103f61` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.461&lng=-123.133&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-61a50231d8` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.303&lng=-123.06&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-625e3e9c8a` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9102&lng=-122.3841&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-627bc09f9c` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.86&lng=-122.312&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-67f6d8981d` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8429&lng=-122.3101&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-68e174afb1` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0058&lng=-122.3623&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-6d134515bd` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.2267&lng=-122.4112&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-6d5e563391` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.1605&lng=-122.949&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-6dd7d0bfc9` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0277&lng=-122.961&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-6e3a12f7f4` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.4276&lng=-121.9805&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-7794115d37` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7934&lng=-122.3891&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-791f7f03ed` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7955&lng=-122.3174&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-794ed607b4` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8094&lng=-122.415&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-79b74c5b6c` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.493&lng=-122.4607&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-7a2b2afc8d` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9005&lng=-122.645&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-81c285da6b` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9168&lng=-122.3885&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-8b48d5fadf` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.1828&lng=-122.3944&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-8ef8dc1ff3` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7673&lng=-122.3868&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-8fdda5fbad` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.6345&lng=-122.4942&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-954d46aa76` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.1717&lng=-122.3705&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-95d75913d2` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.795&lng=-122.276&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-9b13ac5ee1` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.6956&lng=-122.1919&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-9ed26cec88` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.1185&lng=-122.867&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-a35434eff1` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7462&lng=-122.3858&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-a394dd4c0b` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.4592&lng=-122.1082&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-ac1a1c66fc` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.228&lng=-122.596&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-ad1c3b5c5a` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.5031&lng=-122.485&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-afe5aa5a93` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8626&lng=-122.5826&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-b3c8945763` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8304&lng=-122.4758&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-b4d892a166` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.105&lng=-122.267&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-b5e15c2b1f` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9132&lng=-122.347&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-b7c41b036d` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.313&lng=-123.043&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-b82050a3dc` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.1988&lng=-122.3157&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-b8721cabb0` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7829&lng=-122.2439&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-b9fd0110ee` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.5007&lng=-122.4794&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-bc4d7fe959` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.6655&lng=-122.375&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-bc73446ad5` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7892&lng=-122.2509&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-bdf6d4764e` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.468&lng=-122.445&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-bedb2d3f95` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8079&lng=-122.4471&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-c14f4ad0cc` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7597&lng=-122.5107&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-c52fafa957` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.4827&lng=-122.4502&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-c79ee352ea` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9093&lng=-122.3891&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-cb54efcf23` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.5447&lng=-122.5165&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-cb92e98240` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.588&lng=-122.32&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-cc16d1269f` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.3237&lng=-122.4038&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-cc8b56e507` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8906&lng=-122.5179&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-cf79a5074e` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.365&lng=-123.074&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-d03bece698` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.4185&lng=-123.105&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-d0a2de669d` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.6697&lng=-122.4949&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-d8916ea59a` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.4004&lng=-123.096&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-d8f77e31c6` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9171&lng=-122.4764&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-dd175a0727` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.4384&lng=-122.4436&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-de84f16bde` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.831&lng=-122.4784&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-e250f907ba` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.508&lng=-122.211&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-e280bd4c09` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7115&lng=-122.3838&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-e4ad8f5576` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.4642&lng=-122.4455&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-e4d45ea1a7` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.8064&lng=-122.4302&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-e5eb2b162e` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.0177&lng=-121.7518&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-ea6631cd7f` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=38.104&lng=-122.264&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-eac62c03f5` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.4217&lng=-122.435&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-ed68ae2597` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7907&lng=-122.2866&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-f0ec85b140` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.9011&lng=-122.3241&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-f39790a4bb` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.5946&lng=-122.5036&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-f6428ceb67` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.7934&lng=-122.483&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-fbefa1e10d` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts?lat=37.6097&lng=-122.4977&radius=5&iconic_taxa=Actinopterygii%2CElasmobranchii&quality_grade=research&per_page=100 |
| `source:api-inaturalist-org-v1-observations-species-counts-ff266d6b62` | community | 2026-08-13T00:00:00Z | https://api.inaturalist.org/v1/observations/species_counts |
| `source:api-obis-org-v3-occurrence-03521dd523` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Atherinopsis+californiensis&geometry=POLYGON%28%28-123.10040886311812+38.26795495495496%2C-122.9855911368819+38.26795495495496%2C-122.9855911368819+38.358045045045046%2C-123.10040886311812+38.358045045045046%2C-123.10040886311812+38.26795495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-095165ba2b` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.37684509732097+37.54295495495496%2C-122.26315490267902+37.54295495495496%2C-122.26315490267902+37.633045045045044%2C-122.37684509732097+37.633045045045044%2C-122.37684509732097+37.54295495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-0dd3b85e78` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Triakis+semifasciata&geometry=POLYGON%28%28-122.37684509732097+37.54295495495496%2C-122.26315490267902+37.54295495495496%2C-122.26315490267902+37.633045045045044%2C-122.37684509732097+37.633045045045044%2C-122.37684509732097+37.54295495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-1339bf4d52` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Scorpaenichthys+marmoratus&geometry=POLYGON%28%28-123.13145008370908+38.31995495495496%2C-123.01654991629091+38.31995495495496%2C-123.01654991629091+38.410045045045045%2C-123.13145008370908+38.410045045045045%2C-123.13145008370908+38.31995495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-1a4e4671bb` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Cebidichthys+violaceus&geometry=POLYGON%28%28-123.11740094828056+38.257954954954954%2C-123.00259905171944+38.257954954954954%2C-123.00259905171944+38.34804504504504%2C-123.11740094828056+38.34804504504504%2C-123.11740094828056+38.257954954954954%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-1d381f0cc0` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Amphistichus+rhodoterus&geometry=POLYGON%28%28-123.13145008370908+38.31995495495496%2C-123.01654991629091+38.31995495495496%2C-123.01654991629091+38.410045045045045%2C-123.13145008370908+38.410045045045045%2C-123.13145008370908+38.31995495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-26d453f7d0` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Platichthys+stellatus&geometry=POLYGON%28%28-121.78794425755842+38.058954954954956%2C-121.67345574244158+38.058954954954956%2C-121.67345574244158+38.14904504504504%2C-121.78794425755842+38.14904504504504%2C-121.78794425755842+38.058954954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-2ccf2f6c7f` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-123.0181845889562+37.98265495495496%2C-122.9038154110438+37.98265495495496%2C-122.9038154110438+38.072745045045046%2C-123.0181845889562+38.072745045045046%2C-123.0181845889562+37.98265495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-30704cde5a` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Embiotoca+lateralis&geometry=POLYGON%28%28-123.16249260464218+38.37345495495496%2C-123.04750739535783+38.37345495495496%2C-123.04750739535783+38.463545045045045%2C-123.16249260464218+38.463545045045045%2C-123.16249260464218+38.37345495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-461e9ad960` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Platichthys+stellatus&geometry=POLYGON%28%28-122.19317842384501+37.97475495495495%2C-122.07882157615498+37.97475495495495%2C-122.07882157615498+38.06484504504504%2C-122.19317842384501+38.06484504504504%2C-122.19317842384501+37.97475495495495%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-4b7bf6bfd3` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-122.38118608139453+37.856054954954956%2C-122.26701391860547+37.856054954954956%2C-122.26701391860547+37.94614504504504%2C-122.38118608139453+37.94614504504504%2C-122.38118608139453+37.856054954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-4d80dd7727` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Atherinops+affinis&geometry=POLYGON%28%28-122.2255085700024+38.013354954954956%2C-122.1110914299976+38.013354954954956%2C-122.1110914299976+38.10344504504504%2C-122.2255085700024+38.10344504504504%2C-122.2255085700024+38.013354954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-5875be2557` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Amphistichus+rhodoterus&geometry=POLYGON%28%28-123.00628858787276+38.115454954954956%2C-122.89171141212724+38.115454954954956%2C-122.89171141212724+38.20554504504504%2C-123.00628858787276+38.20554504504504%2C-123.00628858787276+38.115454954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-64cde1263c` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-122.2255085700024+38.013354954954956%2C-122.1110914299976+38.013354954954956%2C-122.1110914299976+38.10344504504504%2C-122.2255085700024+38.10344504504504%2C-122.2255085700024+38.013354954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-66b897d62a` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Ophiodon+elongatus&geometry=POLYGON%28%28-123.16249260464218+38.37345495495496%2C-123.04750739535783+38.37345495495496%2C-123.04750739535783+38.463545045045045%2C-123.16249260464218+38.463545045045045%2C-123.16249260464218+38.37345495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-700eef932d` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.42779739024978+38.12665495495496%2C-122.31320260975023+38.12665495495496%2C-122.31320260975023+38.216745045045045%2C-122.42779739024978+38.216745045045045%2C-122.42779739024978+38.12665495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-785f5e69d9` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Platichthys+stellatus&geometry=POLYGON%28%28-122.24842256930563+38.03125495495496%2C-122.13397743069436+38.03125495495496%2C-122.13397743069436+38.12134504504505%2C-122.24842256930563+38.12134504504505%2C-122.24842256930563+38.03125495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-7a63c25c83` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Scorpaenichthys+marmoratus&geometry=POLYGON%28%28-123.11740094828056+38.257954954954954%2C-123.00259905171944+38.257954954954954%2C-123.00259905171944+38.34804504504504%2C-123.11740094828056+38.34804504504504%2C-123.11740094828056+38.257954954954954%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-7ddf7eeb23` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Ophiodon+elongatus&geometry=POLYGON%28%28-123.19052646361166+38.415954954954955%2C-123.07547353638833+38.415954954954955%2C-123.07547353638833+38.50604504504504%2C-123.19052646361166+38.50604504504504%2C-123.19052646361166+38.415954954954955%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-8bec0ea810` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.92425562250916+38.073454954954954%2C-122.80974437749084+38.073454954954954%2C-122.80974437749084+38.16354504504504%2C-122.92425562250916+38.16354504504504%2C-122.92425562250916+38.073454954954954%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-8e83dcc32a` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Amphistichus+rhodoterus&geometry=POLYGON%28%28-123.0181845889562+37.98265495495496%2C-122.9038154110438+37.98265495495496%2C-122.9038154110438+38.072745045045046%2C-123.0181845889562+38.072745045045046%2C-123.0181845889562+37.98265495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-9b2fb044a0` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Paralichthys+californicus&geometry=POLYGON%28%28-122.35979520630765+37.73855495495496%2C-122.24580479369236+37.73855495495496%2C-122.24580479369236+37.82864504504504%2C-122.35979520630765+37.82864504504504%2C-122.35979520630765+37.73855495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-9c8277ee3d` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-122.19317842384501+37.97475495495495%2C-122.07882157615498+37.97475495495495%2C-122.07882157615498+38.06484504504504%2C-122.19317842384501+38.06484504504504%2C-122.19317842384501+37.97475495495495%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-a016aea8b3` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Triakis+semifasciata&geometry=POLYGON%28%28-122.92425562250916+38.073454954954954%2C-122.80974437749084+38.073454954954954%2C-122.80974437749084+38.16354504504504%2C-122.92425562250916+38.16354504504504%2C-122.92425562250916+38.073454954954954%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-a3a6214458` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-122.65334171212726+38.18295495495496%2C-122.53865828787275+38.18295495495496%2C-122.53865828787275+38.273045045045045%2C-122.65334171212726+38.273045045045045%2C-122.65334171212726+38.18295495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-a9235f9551` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Cebidichthys+violaceus&geometry=POLYGON%28%28-123.1126227235471+38.28545495495496%2C-122.9977772764529+38.28545495495496%2C-122.9977772764529+38.375545045045044%2C-123.1126227235471+38.375545045045044%2C-123.1126227235471+38.28545495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-ac4f2dfa75` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Amphistichus+rhodoterus&geometry=POLYGON%28%28-123.10040886311812+38.26795495495496%2C-122.9855911368819+38.26795495495496%2C-122.9855911368819+38.358045045045046%2C-123.10040886311812+38.358045045045046%2C-123.10040886311812+38.26795495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-ac81470c12` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-121.78794425755842+38.058954954954956%2C-121.67345574244158+38.058954954954956%2C-121.67345574244158+38.14904504504504%2C-121.78794425755842+38.14904504504504%2C-121.78794425755842+38.058954954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-c4833f6b65` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.94627327397846+38.095954954954955%2C-122.83172672602153+38.095954954954955%2C-122.83172672602153+38.18604504504504%2C-122.94627327397846+38.18604504504504%2C-122.94627327397846+38.095954954954955%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-c5dccd37db` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-122.41316610086955+37.958954954954955%2C-122.29883389913044+37.958954954954955%2C-122.29883389913044+38.04904504504504%2C-122.41316610086955+38.04904504504504%2C-122.41316610086955+37.958954954954955%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-ceeafcf8c8` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Embiotoca+lateralis&geometry=POLYGON%28%28-123.16779722118312+38.37925495495496%2C-123.05280277881687+38.37925495495496%2C-123.05280277881687+38.469345045045046%2C-123.16779722118312+38.469345045045046%2C-123.16779722118312+38.37925495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-d17dc418e2` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.38118608139453+37.856054954954956%2C-122.26701391860547+37.856054954954956%2C-122.26701391860547+37.94614504504504%2C-122.38118608139453+37.94614504504504%2C-122.38118608139453+37.856054954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-d31334b414` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-122.24842256930563+38.03125495495496%2C-122.13397743069436+38.03125495495496%2C-122.13397743069436+38.12134504504505%2C-122.24842256930563+38.12134504504505%2C-122.24842256930563+38.03125495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-d3afd3a427` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.41316610086955+37.958954954954955%2C-122.29883389913044+37.958954954954955%2C-122.29883389913044+38.04904504504504%2C-122.41316610086955+38.04904504504504%2C-122.41316610086955+37.958954954954955%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-d44ac8aeb9` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Paralichthys+californicus&geometry=POLYGON%28%28-122.4455982640037+37.87175495495496%2C-122.33140173599628+37.87175495495496%2C-122.33140173599628+37.961845045045045%2C-122.4455982640037+37.961845045045045%2C-122.4455982640037+37.87175495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-dea6ad2f0b` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.4455982640037+37.87175495495496%2C-122.33140173599628+37.87175495495496%2C-122.33140173599628+37.961845045045045%2C-122.4455982640037+37.961845045045045%2C-122.4455982640037+37.87175495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-e1e12b88ee` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Leptocottus+armatus&geometry=POLYGON%28%28-123.00628858787276+38.115454954954956%2C-122.89171141212724+38.115454954954956%2C-122.89171141212724+38.20554504504504%2C-123.00628858787276+38.20554504504504%2C-123.00628858787276+38.115454954954956%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-e2b818455e` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Platichthys+stellatus&geometry=POLYGON%28%28-122.65334171212726+38.18295495495496%2C-122.53865828787275+38.18295495495496%2C-122.53865828787275+38.273045045045045%2C-122.65334171212726+38.273045045045045%2C-122.65334171212726+38.18295495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-e73131f1a6` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Scorpaenichthys+marmoratus&geometry=POLYGON%28%28-123.16779722118312+38.37925495495496%2C-123.05280277881687+38.37925495495496%2C-123.05280277881687+38.469345045045046%2C-123.16779722118312+38.469345045045046%2C-123.16779722118312+38.37925495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-e80f2aba30` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Myliobatis+californica&geometry=POLYGON%28%28-122.35979520630765+37.73855495495496%2C-122.24580479369236+37.73855495495496%2C-122.24580479369236+37.82864504504504%2C-122.35979520630765+37.82864504504504%2C-122.35979520630765+37.73855495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-e927028702` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Morone+saxatilis&geometry=POLYGON%28%28-122.42779739024978+38.12665495495496%2C-122.31320260975023+38.12665495495496%2C-122.31320260975023+38.216745045045045%2C-122.42779739024978+38.216745045045045%2C-122.42779739024978+38.12665495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-ed26c3d213` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Triakis+semifasciata&geometry=POLYGON%28%28-122.94627327397846+38.095954954954955%2C-122.83172672602153+38.095954954954955%2C-122.83172672602153+38.18604504504504%2C-122.94627327397846+38.18604504504504%2C-122.94627327397846+38.095954954954955%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-f65c3cfd2f` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Atherinopsis+californiensis&geometry=POLYGON%28%28-123.1126227235471+38.28545495495496%2C-122.9977772764529+38.28545495495496%2C-122.9977772764529+38.375545045045044%2C-123.1126227235471+38.375545045045044%2C-123.1126227235471+38.28545495495496%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:api-obis-org-v3-occurrence-fc894ab5a1` | open-biodiversity-dataset | 2026-08-13T00:00:00Z | https://api.obis.org/v3/occurrence?scientificname=Embiotoca+lateralis&geometry=POLYGON%28%28-123.19052646361166+38.415954954954955%2C-123.07547353638833+38.415954954954955%2C-123.07547353638833+38.50604504504504%2C-123.19052646361166+38.50604504504504%2C-123.19052646361166+38.415954954954955%29%29&startdate=2000-01-01&enddate=2026-08-13&size=200&fields=id%2CscientificName%2CdecimalLatitude%2CdecimalLongitude%2CcoordinateUncertaintyInMeters%2CeventDate%2Cdate_year%2CbasisOfRecord%2Cdataset_id%2CdatasetName%2CinstitutionCode%2CcollectionCode%2CoccurrenceID%2CoccurrenceStatus%2Cflags%2Cdropped%2Cabsence |
| `source:berkeleyca-gov--berkeley-pier-ferry-access-project-cb66f901fd` | site-owner | 2026-08-13T00:00:00Z | https://berkeleyca.gov/your-government/our-work/capital-projects/berkeley-pier-ferry-access-project |
| `source:oehha-ca-gov-fish-advisories-san-francisco-bay-e7b670ed80` | official-agency | 2026-08-13T00:00:00Z | https://oehha.ca.gov/fish/advisories/san-francisco-bay |
| `source:parks-ca-gov-beanhollow-b4dd9e55a5` | site-owner | 2026-08-13T00:00:00Z | https://parks.ca.gov/beanhollow |
| `source:parks-ca-gov-candlestickpoint-46c6a2ed76` | site-owner | 2026-08-13T00:00:00Z | https://parks.ca.gov/candlestickpoint |
| `source:parks-sonomacounty-ca-gov-sit-find-a-park-doran-regional-park-14794741b1` | site-owner | 2026-08-13T00:00:00Z | https://parks.sonomacounty.ca.gov/visit/find-a-park/doran-regional-park |
| `source:services2-arcgis-com-vices-biosds582-fpu-featureserver-0-9048f0a177` | official-agency | 2026-08-13T00:00:00Z | https://services2.arcgis.com/Uq9r85Potqm3MfRV/arcgis/rest/services/biosds582_fpu/FeatureServer/0 |
| `source:tidesandcurrents-noaa-gov-ports-index-html-af66eed5fe` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/ports/index.html?port=sf |
| `source:tidesandcurrents-noaa-gov-stationhome-html-09c7f9c4ae` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414769 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-0a34228a04` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414131 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-16034965c2` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9415144 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-20a83bac18` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414311 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-6eef7b355d` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9415020 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-9d4eae39fe` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9415115 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-a4c61ba862` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414750 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-a64f6c8c42` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9415141 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-a7b27cf495` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414847 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-afd610ba26` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414275 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-bcd7b02233` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9415102 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-c871448ef8` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414523 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-d70bd8284b` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414863 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-dde3ea9062` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9415625 |
| `source:tidesandcurrents-noaa-gov-stationhome-html-ef8b24421f` | official-agency | 2026-08-13T00:00:00Z | https://tidesandcurrents.noaa.gov/stationhome.html?id=9414290 |
| `source:wildlife-ca-gov-cean-regulations-fishing-map-sf-bay-aaa0620459` | official-agency | 2026-08-13T00:00:00Z | https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay |
| `source:wildlife-ca-gov-fishing-ocean-beach-fishing-ed1d54b2a8` | official-agency | 2026-08-13T00:00:00Z | https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing |
| `source:www-cityofpacifica-org--safety-guides-pacifica-state-beach-7bb923a2d0` | site-owner | 2026-08-13T00:00:00Z | https://www.cityofpacifica.org/departments/parks-beaches-recreation/parks-and-beaches-locations-maps-safety-guides/pacifica-state-beach |
| `source:www-cityofpacifica-org--works-field-services-pacifica-pier-06cc41e53a` | site-owner | 2026-08-13T00:00:00Z | https://www.cityofpacifica.org/departments/public-works/field-services/pacifica-pier |
| `source:www-cityofpacifica-org-eaches-locations-maps-safety-guides-1b3ea894b5` | site-owner | 2026-08-13T00:00:00Z | https://www.cityofpacifica.org/departments/parks-beaches-recreation/parks-and-beaches-locations-maps-safety-guides |
| `source:www-cityofpaloalto-org-maps-baylands-fishing-locations-pdf-0e33feef47` | site-owner | 2026-08-13T00:00:00Z | https://www.cityofpaloalto.org/files/assets/public/community-services/parks-and-open-space/open-space-maps/baylands-fishing-locations.pdf |
| `source:www-ebparks-org-les-radke-martinez-map-brochure-pdf-d50576a8a7` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/sites/default/files/radke-martinez-map-brochure.pdf |
| `source:www-ebparks-org-maps-point-isabel-a6e7fd2398` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/maps/point-isabel |
| `source:www-ebparks-org-parks-antioch-oakley-84238648be` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/parks/antioch-oakley |
| `source:www-ebparks-org-parks-big-break-6d75a074f0` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/parks/big-break |
| `source:www-ebparks-org-parks-carquinez-strait-971071292a` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/parks/carquinez-strait |
| `source:www-ebparks-org-parks-miller-knox-23c1780f8d` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/parks/miller-knox |
| `source:www-ebparks-org-parks-point-pinole-b1b4a482f7` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/parks/point-pinole |
| `source:www-ebparks-org-recreation-fishing-551b117012` | site-owner | 2026-08-13T00:00:00Z | https://www.ebparks.org/recreation/fishing |
| `source:www-half-moon-bay-ca-us-732-beaches-3414e8ae95` | site-owner | 2026-08-13T00:00:00Z | https://www.half-moon-bay.ca.us/732/Beaches |
| `source:www-marincounty-gov-h-reopened-under-permanent-advisory-eb7c718e7b` | site-owner | 2026-08-13T00:00:00Z | https://www.marincounty.gov/news-releases/bolinas-beach-reopened-under-permanent-advisory |
| `source:www-ndbc-noaa-gov-station-page-php-0457548819` | official-agency | 2026-08-13T00:00:00Z | https://www.ndbc.noaa.gov/station_page.php?station=scqc1 |
| `source:www-ndbc-noaa-gov-station-page-php-352e63000f` | official-agency | 2026-08-13T00:00:00Z | https://www.ndbc.noaa.gov/station_page.php?station=46026 |
| `source:www-ndbc-noaa-gov-station-page-php-36b91766f2` | official-agency | 2026-08-13T00:00:00Z | https://www.ndbc.noaa.gov/station_page.php?station=fffc1 |
| `source:www-ndbc-noaa-gov-station-page-php-38ba33ff03` | official-agency | 2026-08-13T00:00:00Z | https://www.ndbc.noaa.gov/station_page.php?station=46013 |
| `source:www-ndbc-noaa-gov-station-page-php-aaa085b2e8` | official-agency | 2026-08-13T00:00:00Z | https://www.ndbc.noaa.gov/station_page.php?station=46214 |
| `source:www-ndbc-noaa-gov-station-page-php-d03a5be9df` | official-agency | 2026-08-13T00:00:00Z | https://www.ndbc.noaa.gov/station_page.php?station=46012 |
| `source:www-ndbc-noaa-gov-station-page-php-d7cb793674` | official-agency | 2026-08-13T00:00:00Z | https://www.ndbc.noaa.gov/station_page.php?station=46237 |
| `source:www-nps-gov-ces-000-fort-baker-fishing-pier-htm-16cbbd09d3` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/places/000/fort-baker-fishing-pier.htm |
| `source:www-nps-gov-e-planyourvisit-limantour-beach-htm-f9b4901f89` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/pore/planyourvisit/limantour_beach.htm |
| `source:www-nps-gov-goga-planyourvisit-baker-beach-htm-8bcd648e29` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/planyourvisit/baker-beach.htm |
| `source:www-nps-gov-goga-planyourvisit-chinabeach-htm-9d8bffa42c` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/planyourvisit/chinabeach.htm |
| `source:www-nps-gov-goga-planyourvisit-landsend-htm-3cc0d2d9dd` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/planyourvisit/landsend.htm |
| `source:www-nps-gov-goga-planyourvisit-muirbeach-htm-8f1327d452` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/planyourvisit/muirbeach.htm |
| `source:www-nps-gov-goga-planyourvisit-oceanbeach-htm-f9be9823b4` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/planyourvisit/oceanbeach.htm |
| `source:www-nps-gov-goga-stbe-htm-5b03bf1db3` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/stbe.htm |
| `source:www-nps-gov-ourvisit-crissy-field-promenade-htm-33850b5e91` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/planyourvisit/crissy-field-promenade.htm |
| `source:www-nps-gov-ourvisit-rodeo-beach-and-lagoon-htm-7eeacdf824` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/goga/planyourvisit/rodeo-beach-and-lagoon.htm |
| `source:www-nps-gov-planyourvisit-kehoe-beach-trail-htm-cf3e23f451` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/pore/planyourvisit/kehoe-beach-trail.htm |
| `source:www-nps-gov-pore-planyourvisit-drakes-beach-htm-4be2a374d1` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/pore/planyourvisit/drakes-beach.htm |
| `source:www-nps-gov-re-planyourvisit-abbotts-lagoon-htm-162e1eca1a` | site-owner | 2026-08-13T00:00:00Z | https://www.nps.gov/pore/planyourvisit/abbotts-lagoon.htm |
| `source:www-parks-ca-gov-1ae385d03e` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/?page_id=476 |
| `source:www-parks-ca-gov-204f32da9d` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/?page_id=521 |
| `source:www-parks-ca-gov-44a723bdc6` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/?page_id=529 |
| `source:www-parks-ca-gov-af8e425ee6` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/?page_id=470 |
| `source:www-parks-ca-gov-chinacamp-47da3bc642` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/chinacamp |
| `source:www-parks-ca-gov-d7c98fdf29` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/?page_id=451 |
| `source:www-parks-ca-gov-def9028787` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/?page_id=528 |
| `source:www-parks-ca-gov-f1676b1133` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/?page_id=531 |
| `source:www-parks-ca-gov-halfmoonbay-00c7c5f4b8` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/halfmoonbay |
| `source:www-parks-ca-gov-pescadero-4c92c12d83` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/Pescadero/ |
| `source:www-parks-ca-gov-pigeonpoint-5fb97b744a` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.ca.gov/PigeonPoint |
| `source:www-parks-marincounty-gov-preserves-parks-paradise-beach-park-ff338fafd4` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.marincounty.gov/parkspreserves/parks/paradise-beach-park |
| `source:www-parks-marincounty-gov-spreserves-parks-mcnears-beach-park-916d7d9b61` | site-owner | 2026-08-13T00:00:00Z | https://www.parks.marincounty.gov/parkspreserves/parks/mcnears-beach-park |
| `source:www-pierfishing-com-agua-vista-pier-san-francisco-ed41be4593` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/agua-vista-pier-san-francisco/ |
| `source:www-pierfishing-com-brisbane-pier-9778529b2e` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/brisbane-pier/ |
| `source:www-pierfishing-com-dumbarton-pier-6-18c8883feb` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/dumbarton-pier/6/ |
| `source:www-pierfishing-com-eckley-pier-2-aaa5d95eed` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/eckley-pier/2/ |
| `source:www-pierfishing-com-elephant-rock-pier-4-f155e2aaac` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/elephant-rock-pier/4/ |
| `source:www-pierfishing-com-emeryville-marina-pier-a92be1ecb4` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/emeryville-marina-pier/ |
| `source:www-pierfishing-com-estuary-park-pier-oakland-2-8a204aef2b` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/estuary-park-pier-oakland/2/ |
| `source:www-pierfishing-com-ferry-point-pier-richmond-59a84ed44d` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/ferry-point-pier-richmond/ |
| `source:www-pierfishing-com-fort-point-pier-4f4b754d80` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/fort-point-pier/ |
| `source:www-pierfishing-com-ioch-oakley-regional-shoreline-pier-3d6379ee54` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/antioch-bridge-pier-aka-antioch-oakley-regional-shoreline-pier/ |
| `source:www-pierfishing-com-mcnear-beach-fishing-pier-8b08417b60` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/mcnear-beach-fishing-pier/ |
| `source:www-pierfishing-com-paradise-beach-pier-tiburon-50aa614fdb` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/paradise-beach-pier-tiburon/ |
| `source:www-pierfishing-com-pier-oakland-arrowhead-marsh-pier-2-590222794d` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/arrowhead-marsh-pier-oakland/arrowhead-marsh-pier-2/ |
| `source:www-pierfishing-com-point-pinole-pier-05168e0b68` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/point-pinole-pier/ |
| `source:www-pierfishing-com-port-view-park-pier-898567ef97` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/port-view-park-pier/ |
| `source:www-pierfishing-com-redwood-city-marina-fishing-pier-2-0d9b845ad0` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/redwood-city-marina-fishing-pier-2/ |
| `source:www-pierfishing-com-san-antonio-pier-oakland-529edc67be` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/san-antonio-pier-oakland/ |
| `source:www-pierfishing-com-san-leandro-marina-pier-95aa48e7a6` | reviewed-secondary | 2026-08-13T00:00:00Z | https://www.pierfishing.com/san-leandro-marina-pier/ |
| `source:www-redwoodcity-org-departments-port-of-redwood-city-96efa029dc` | site-owner | 2026-08-13T00:00:00Z | https://www.redwoodcity.org/departments/port-of-redwood-city |
| `source:www-smcgov-org-parks-coyote-point-recreation-area-ce8be5e174` | site-owner | 2026-08-13T00:00:00Z | https://www.smcgov.org/parks/coyote-point-recreation-area |
| `source:www-smcgov-org-parks-mirada-surf-9a8d81bba2` | site-owner | 2026-08-13T00:00:00Z | https://www.smcgov.org/parks/mirada-surf |
