# Bay Bite — 100+ shore-access spot catalog and official sensor net

**Prepared/check date:** 2026-08-13  
**Candidates:** 131 · **agency-backed open/conditional:** 110 · **site-specific verification pending:** 18 · **closed alerts:** 3  
**Machine-readable canonical detail:** [`spot-catalog-100.json`](./spot-catalog-100.json)

## Decision summary

- The existing TypeScript inventory contains **63 records**. Eleven are combined records that should not survive normalization because their access/license boundaries differ: `benicia-pier`, `berkeley-pier`, `bodega-jetty`, `candlestick`, `coyote-point`, `fort-baker`, `fort-mason-piers`, `oyster-point`, `pillar-point`, `vallejo-waterfront`, `vincent-park-pier`.
- The normalized candidate set contains **131 distinct records**. It clears the requested 110-candidate QA buffer and leaves **110 agency-backed open/conditional candidates** after 18 deliberately flagged site-specific checks and 3 closed alert-only structures.
- A CDFW public-pier listing proves the exact qualifying structure/license exemption, not adjacent shore, walking bridge or land-touching rock wall. Every record preserves that boundary.
- Open-coast wave observations and inland Bay/Delta conditions are separated. Inland records explicitly return wave `unavailable`; no ocean buoy is treated as local inland water.
- Seasonal windows are biology guidance, never legality. MPA polygon, current CDFW rules, emergency closures, owner postings and consumption/shellfish advisories remain trip-time dependencies.

## Evidence and confidence model

`open` means the exact pier/jetty is on the current CDFW qualifying-structure list or an owner page explicitly supports access. `open_with_conditions` means an official park/owner supports public shore access or fishing but posted areas/hours/wildlife restrictions still control. `needs_site_specific_verification` is a useful QA candidate whose general park/shore access is official but exact lawful casting parcel/boundary was not established strongly enough. `closed` is alert-only and never actionable. Coordinates are catalog centroids, not instructions to stand at that pixel.

Primary access/legal sources: [CDFW California Beach Fishing](https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing), [CDFW SF Bay regulations](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay), [NPS GGNRA fishing](https://www.nps.gov/goga/planyourvisit/fishing.htm), [California State Parks Sonoma Coast](https://www.parks.ca.gov/?page_id=451), [Half Moon Bay State Beach](https://www.parks.ca.gov/?page_id=531), [EBRPD fishing](https://www.ebparks.org/recreation/fishing). Each JSON record carries checked source URLs.

## Catalog index

Every row below maps to a complete JSON object containing owner/jurisdiction, access state/date/source, exact license-exemption warning, substrate/salinity/exposure, per-species confidence and source class, biology windows, tactics, safety, MPA/advisory dependencies, compatible environmental products with station ID/name/distance/class/warning, and checked source URLs.

### Carquinez/Delta

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `martinez-marina` | Martinez Marina Pier | pier | open | 38.0194, -122.1371 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `eckley-pier` | Eckley Pier | pier | open | 38.0410, -122.2280 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `benicia-point-pier` | Benicia Point Fishing Pier | pier | open | 38.0458, -122.1588 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `benicia-9th-st-pier` | 9th Street Pier, Benicia | pier | open | 38.0584, -122.1683 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `benicia-state-rec-shore` | Benicia State Recreation Area shoreline | bay_shore | open_with_conditions | 38.0763, -122.1912 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `vallejo-launch-pier` | Vallejo Launch Ramp Fishing Pier | pier | open | 38.1050, -122.2670 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `independence-park-shore` | Independence Park licensed shoreline | bay_shore | open_with_conditions | 38.1040, -122.2640 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `martinez-shoreline` | Martinez Regional Shoreline bank | bay_shore | open_with_conditions | 38.0198, -122.1360 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `port-costa-shore` | Port Costa public shoreline | bay_shore | needs_site_specific_verification | 38.0455, -122.1830 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `crockett-shore` | Crockett shoreline access | bay_shore | needs_site_specific_verification | 38.0520, -122.2175 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `point-edith-shore` | Point Edith public shoreline candidate | bay_shore | needs_site_specific_verification | 38.0490, -122.0760 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |
| `pittsburg-marina-pier` | Pittsburg Marina fishing pier | pier | open | 38.0395, -121.8840 | tide_level:9415102, current:s06010, wind:9415141, wave:unavailable |

### East Bay

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `alameda-rock-wall` | Alameda Rock Wall | breakwater | open_with_conditions | 37.7704, -122.3066 | tide_level:9414750, wind:9414769, current:s10010, wave:unavailable |
| `emeryville-marina` | Emeryville Marina Pier | pier | open | 37.8429, -122.3101 | tide_level:9414750, wind:9414769, wave:unavailable |
| `san-leandro-marina` | San Leandro Marina Pier | pier | open | 37.6956, -122.1919 | tide_level:9414750, wind:9414769, wave:unavailable |
| `point-pinole` | Point Pinole Pier | pier | open | 38.0058, -122.3623 | tide_level:9414863, wind:9414769, wave:unavailable |
| `san-antonio-pier` | San Antonio Pier / Oakland Estuary | pier | open | 37.7892, -122.2509 | tide_level:9414750, wind:9414769, wave:unavailable |
| `jack-london-pier` | Webster St. / Jack London Pier | pier | open | 37.7950, -122.2760 | tide_level:9414750, wind:9414769, wave:unavailable |
| `union-point-park` | Union Point Park Pier | pier | open | 37.7829, -122.2439 | tide_level:9414750, wind:9414769, wave:unavailable |
| `arrowhead-marsh` | Arrowhead Marsh / MLK Pier | pier | open | 37.7363, -122.2088 | tide_level:9414750, wind:9414769, wave:unavailable |
| `doolittle-pier` | Doolittle Drive Pier | pier | open | 37.7359, -122.2109 | tide_level:9414750, wind:9414769, wave:unavailable |
| `port-view-park` | Port View Park Pier | pier | open | 37.7955, -122.3174 | tide_level:9414750, wind:9414769, current:s10010, wave:unavailable |
| `estuary-park-pier` | Estuary Park Pier | pier | open | 37.7907, -122.2866 | tide_level:9414750, wind:9414769, wave:unavailable |
| `ferry-point` | Ferry Point Pier / Miller Knox | pier | open | 37.9102, -122.3841 | tide_level:9414863, wind:9414311, wave:unavailable |
| `berkeley-municipal-pier-closed` | Berkeley Municipal Pier | pier | closed | 37.8648, -122.3188 | tide_level:9414750, wind:9414769, wave:unavailable |
| `berkeley-marina-shore` | Berkeley Marina South Shore | bay_shore | open_with_conditions | 37.8600, -122.3120 | tide_level:9414750, wind:9414769, wave:unavailable |
| `albany-bulb-shore` | Albany Bulb shoreline | bay_shore | open_with_conditions | 37.8897, -122.3193 | tide_level:9414863, wind:9414769, wave:unavailable |
| `point-isabel-shore` | Point Isabel shoreline | bay_shore | open_with_conditions | 37.9011, -122.3241 | tide_level:9414863, wind:9414769, wave:unavailable |
| `meeker-slough-shore` | Meeker Slough / Marina Bay shoreline | bay_shore | open_with_conditions | 37.9132, -122.3470 | tide_level:9414863, wind:9414769, wave:unavailable |
| `john-sheridan-pier` | John J. Sheridan Pier | pier | open | 37.9168, -122.3885 | tide_level:9414863, wind:9414311, wave:unavailable |
| `vincent-park-jetty` | Barbara & Jay Vincent Park Jetty | jetty | open_with_conditions | 37.9093, -122.3891 | tide_level:9414863, wind:9414311, wave:unavailable |
| `point-pinole-shore` | Point Pinole licensed shoreline | bay_shore | open_with_conditions | 38.0040, -122.3560 | tide_level:9414863, wind:9414769, wave:unavailable |
| `point-san-pablo-shore` | Point San Pablo Harbor public shoreline | bay_shore | needs_site_specific_verification | 37.9637, -122.4192 | tide_level:9414863, wind:9414311, wave:unavailable |
| `veterans-pier-alameda` | Veterans Pier, Alameda | pier | open | 37.7836, -122.3028 | tide_level:9414750, wind:9414769, current:s10010, wave:unavailable |
| `san-antonio-north-pier` | San Antonio North Pier | pier | open | 37.7922, -122.2494 | tide_level:9414750, wind:9414769, wave:unavailable |
| `garretson-point-shore` | Garretson Point shoreline | bay_shore | needs_site_specific_verification | 37.7467, -122.2108 | tide_level:9414750, wind:9414769, wave:unavailable |
| `tidewater-shore` | Tidewater Boating Center shoreline | bay_shore | needs_site_specific_verification | 37.7594, -122.2200 | tide_level:9414750, wind:9414769, wave:unavailable |

### Half Moon Bay

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `montara-state-beach` | Montara State Beach | surf | open_with_conditions | 37.5447, -122.5165 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `gray-whale-cove` | Gray Whale Cove | surf | open_with_conditions | 37.5633, -122.5141 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `half-moon-bay-state-beach` | Half Moon Bay State Beach | surf | open_with_conditions | 37.4642, -122.4455 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `redondo-beach-hmb` | Redondo Beach / Poplar Edge | surf | open_with_conditions | 37.4384, -122.4436 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `pomponio-state-beach` | Pomponio State Beach | surf | open_with_conditions | 37.2926, -122.4070 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `pescadero-state-beach` | Pescadero State Beach | surf | open_with_conditions | 37.2644, -122.4121 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `san-gregorio-state-beach` | San Gregorio State Beach | surf | open_with_conditions | 37.3237, -122.4038 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `bean-hollow` | Bean Hollow / Pebble Beach | rocky_shore | open_with_conditions | 37.2267, -122.4112 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `pillar-point-east-jetty` | Half Moon Bay East Jetty | jetty | open | 37.5007, -122.4794 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `pillar-point-west-jetty` | Half Moon Bay West Jetty | jetty | open | 37.5028, -122.4910 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `pillar-point-pier` | Pillar Point Harbor Fishing Pier | pier | open | 37.5031, -122.4850 | tide_level:9414290, wind:9414311, wave:unavailable |
| `miramar-beach` | Miramar Beach | surf | open_with_conditions | 37.4930, -122.4607 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `dunes-beach` | Dunes Beach | surf | open_with_conditions | 37.4827, -122.4502 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `venice-beach-hmb` | Venice Beach (Half Moon Bay) | surf | open_with_conditions | 37.4740, -122.4480 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `francis-beach` | Francis Beach | surf | open_with_conditions | 37.4680, -122.4450 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `poplar-beach` | Poplar Beach | surf | open_with_conditions | 37.4483, -122.4440 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `cowell-ranch-beach` | Cowell Ranch Beach | surf | open_with_conditions | 37.4217, -122.4350 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `martins-beach-public-tidelands` | Martin’s Beach public tidelands candidate | surf | needs_site_specific_verification | 37.3748, -122.4107 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `pigeon-point-beach` | Pigeon Point shoreline north cove | rocky_shore | open_with_conditions | 37.1828, -122.3944 | tide:9414131, wave:46012, wind:46012, temperature:46012 |

### Marin/North Bay

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `china-camp` | China Camp Shoreline | bay_shore | open_with_conditions | 38.0017, -122.4620 | tide_level:9414863, wind:9414311, wave:unavailable |
| `paradise-beach` | Paradise Beach Pier | pier | open | 37.9171, -122.4764 | tide_level:9414863, wind:9414311, wave:unavailable |
| `mcnears-beach` | McNears Beach Pier | pier | open | 37.9961, -122.4482 | tide_level:9414863, wind:9414311, wave:unavailable |
| `rodeo-beach` | Rodeo Beach | surf | open_with_conditions | 37.8328, -122.5381 | tide_level:9414290, wind:9414311, wave:unavailable |
| `muir-beach` | Muir Beach | surf | open_with_conditions | 37.8626, -122.5826 | tide_level:9414290, wind:9414311, wave:unavailable |
| `stinson-beach` | Stinson Beach | surf | open_with_conditions | 37.9005, -122.6450 | tide_level:9414863, wind:9414311, wave:unavailable |
| `bolinas-beach` | Bolinas Beach / Lagoon Mouth | estuary_mouth | open_with_conditions | 37.9085, -122.6860 | tide_level:9414863, wind:9414311, wave:unavailable |
| `elephant-rock` | Elephant Rock Pier | pier | open | 37.8733, -122.4581 | tide_level:9414290, wind:9414311, wave:unavailable |
| `acqua-hotel-pier` | Acqua Hotel Pier | pier | open | 37.8906, -122.5179 | tide_level:9414863, wind:9414311, wave:unavailable |
| `fort-baker-pier` | Fort Baker Fishing Pier | pier | open | 37.8310, -122.4784 | tide_level:9414290, wind:9414311, wave:unavailable |
| `fort-baker-jetty` | Fort Baker Jetty | jetty | open | 37.8304, -122.4758 | tide_level:9414290, wind:9414311, wave:unavailable |

### Napa/San Pablo

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `cuttings-wharf` | Cuttings Wharf | pier | open | 38.1988, -122.3157 | tide_level:9414863, current:s08010, wind:9414847, temperature:SCQC1, wave:unavailable |
| `cullinan-ranch-pier` | Cullinan Ranch Fishing Pier | pier | open | 38.1717, -122.3705 | tide_level:9414863, current:s08010, wind:9414847, temperature:SCQC1, wave:unavailable |

### Peninsula

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `linda-mar` | Linda Mar / Pacifica State Beach | surf | open_with_conditions | 37.5946, -122.5036 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `pacifica-pier` | Pacifica Pier | pier | closed | 37.6334, -122.4938 | tide_level:9414290, wind:9414311, wave:unavailable |
| `mussel-rock` | Mussel Rock / Thornton | surf | open_with_conditions | 37.6697, -122.4949 | tide:9414275, wave:46237, wind:46026, temperature:46237 |
| `pacifica-rockaway` | Rockaway Beach | surf | open_with_conditions | 37.6097, -122.4977 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `sharp-park-beach` | Sharp Park Beach | surf | open_with_conditions | 37.6345, -122.4942 | tide:9414131, wave:46012, wind:46012, temperature:46012 |
| `sierra-point-pier` | Sierra Point Pier | pier | open | 37.6737, -122.3871 | tide_level:9414290, wind:9414311, wave:unavailable |

### Petaluma River

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `shollenberger-pier` | Shollenberger Pier | pier | open | 38.2280, -122.5960 | tide_level:9415144, wind:9415115, temperature:FFFC1, wave:unavailable |

### Point Reyes

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `limantour-beach` | Limantour Beach outside posted closures | surf | open_with_conditions | 38.0270, -122.8990 | tide:9415020, wave:46214, wind:46214, temperature:46214 |
| `drakes-beach` | Drakes Beach lawful shoreline | surf | open_with_conditions | 38.0277, -122.9610 | tide:9415020, wave:46214, wind:46214, temperature:46214 |
| `kehoe-beach` | Kehoe Beach | surf | open_with_conditions | 38.1605, -122.9490 | tide:9415020, wave:46214, wind:46214, temperature:46214 |
| `abadesi-beach` | Abbotts Lagoon / Abadesi Beach lawful ocean shore | surf | open_with_conditions | 38.1230, -122.9560 | tide:9415020, wave:46214, wind:46214, temperature:46214 |
| `hearts-desire-beach` | Heart’s Desire Beach lawful fishing area | estuary | open_with_conditions | 38.1410, -122.8890 | tide_level:9414863, wind:9414311, wave:unavailable |
| `chicken-ranch-beach` | Chicken Ranch Beach lawful fishing area | estuary | open_with_conditions | 38.1185, -122.8670 | tide_level:9414863, wind:9414311, wave:unavailable |

### SF Coast

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `ocean-beach` | Ocean Beach | surf | open_with_conditions | 37.7597, -122.5107 | tide:9414275, wave:46237, wind:46026, temperature:46237 |
| `baker-beach` | Baker Beach | surf | open_with_conditions | 37.7934, -122.4830 | tide:9414275, wave:46237, wind:46026, temperature:46237 |
| `torpedo-wharf` | Torpedo Wharf / Fort Point Pier | pier | open | 37.8081, -122.4752 | tide_level:9414290, wind:9414311, wave:unavailable |
| `pier-7` | Pier 7 — Embarcadero | pier | open | 37.7987, -122.3960 | tide_level:9414290, wind:9414311, wave:unavailable |
| `pier-14` | Pier 14 — Embarcadero | pier | open | 37.7934, -122.3891 | tide_level:9414290, wind:9414311, wave:unavailable |
| `islais-creek-pier` | Islais Creek Pier | pier | open | 37.7462, -122.3858 | tide_level:9414290, wind:9414311, wave:unavailable |
| `agua-vista-pier` | Agua Vista Pier | pier | open | 37.7673, -122.3868 | tide_level:9414290, wind:9414311, wave:unavailable |
| `south-beach-harbor-pier` | South Beach Harbor Pier | pier | open | 37.7829, -122.3881 | tide_level:9414290, wind:9414311, wave:unavailable |
| `pier-45` | Pier 45 / Fisherman’s Wharf | pier | open | 37.8094, -122.4150 | tide_level:9414290, wind:9414311, wave:unavailable |
| `st-francis-jetty` | Saint Francis Jetty / Marina Green | jetty | open | 37.8079, -122.4471 | tide_level:9414290, wind:9414311, wave:unavailable |
| `crissy-field` | Crissy Field Shoreline | bay_shore | open_with_conditions | 37.8049, -122.4650 | tide_level:9414290, wind:9414311, wave:unavailable |
| `china-beach` | China Beach | surf | open_with_conditions | 37.7883, -122.4903 | tide:9414275, wave:46237, wind:46026, temperature:46237 |
| `lands-end` | Lands End / Sutro Baths Rocks | rocky_shore | open_with_conditions | 37.7790, -122.5137 | tide:9414275, wave:46237, wind:46026, temperature:46237 |
| `candlestick-eastern-pier` | Candlestick Eastern Fishing Pier | pier | open | 37.7089, -122.3827 | tide_level:9414290, wind:9414311, wave:unavailable |
| `candlestick-shore` | Candlestick Point Shoreline | bay_shore | open_with_conditions | 37.7115, -122.3838 | tide_level:9414290, wind:9414311, wave:unavailable |
| `fort-mason-pier-2` | Fort Mason Pier 2 | pier | open | 37.8062, -122.4320 | tide_level:9414290, wind:9414311, wave:unavailable |
| `fort-mason-pier-3` | Fort Mason Pier 3 | pier | open | 37.8064, -122.4302 | tide_level:9414290, wind:9414311, wave:unavailable |
| `municipal-pier-closed` | San Francisco Municipal (Muni) Pier | pier | closed | 37.8098, -122.4267 | tide_level:9414290, wind:9414311, wave:unavailable |
| `warm-water-cove` | Warm Water Cove Shoreline | bay_shore | needs_site_specific_verification | 37.7490, -122.3820 | tide_level:9414290, wind:9414311, wave:unavailable |
| `herons-head` | Heron’s Head Park Shoreline | bay_shore | needs_site_specific_verification | 37.7390, -122.3765 | tide_level:9414290, wind:9414769, wave:unavailable |

### Sonoma Coast

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `spud-point-pier` | Spud Point Public Pier | pier | open | 38.3305, -123.0552 | tide_level:9414863, wind:9414311, wave:unavailable |
| `bodega-south-jetty` | Bodega Bay South Jetty | jetty | open | 38.3030, -123.0600 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `bodega-north-jetty` | Bodega Bay North Jetty | jetty | open | 38.3068, -123.0608 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `doran-beach` | Doran Regional Park Beach | surf | open_with_conditions | 38.3130, -123.0430 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `bodega-head-west` | Bodega Head west shoreline | rocky_shore | needs_site_specific_verification | 38.3095, -123.0660 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `salmon-creek-south` | Salmon Creek Beach South | surf | open_with_conditions | 38.3505, -123.0690 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `salmon-creek-north` | Salmon Creek Beach North | surf | open_with_conditions | 38.3650, -123.0740 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `wrights-beach` | Wright’s Beach | surf | open_with_conditions | 38.4004, -123.0960 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `shell-beach-sonoma` | Shell Beach, Sonoma Coast | rocky_shore | open_with_conditions | 38.4185, -123.1050 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `schoolhouse-beach` | Schoolhouse Beach | rocky_shore | open_with_conditions | 38.4243, -123.1103 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `goat-rock-beach` | Goat Rock Beach | surf | open_with_conditions | 38.4477, -123.1260 | tide:9415625, wave:46013, wind:46013, temperature:46013 |
| `blind-beach` | Blind Beach | surf | open_with_conditions | 38.4610, -123.1330 | tide:9415625, wave:46013, wind:46013, temperature:46013 |

### South Bay

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `redwood-city-pier` | Redwood City Pier | pier | open | 37.5080, -122.2110 | tide_level:9414523, wave:unavailable |
| `dumbarton-pier` | Dumbarton Pier | pier | open | 37.5054, -122.1145 | tide_level:9414523, wave:unavailable |
| `oyster-point-shore` | Oyster Point licensed shoreline | bay_shore | open_with_conditions | 37.6655, -122.3750 | tide_level:9414523, wave:unavailable |
| `coyote-point-shore` | Coyote Point licensed shoreline | bay_shore | open_with_conditions | 37.5880, -122.3200 | tide_level:9414523, wave:unavailable |
| `bayfront-park-millbrae` | Bayfront Park Millbrae shoreline | bay_shore | needs_site_specific_verification | 37.6023, -122.3705 | tide_level:9414523, wave:unavailable |
| `ryder-park-shore` | Ryder Park shoreline | bay_shore | needs_site_specific_verification | 37.5772, -122.3112 | tide_level:9414523, wave:unavailable |
| `leo-ryan-park-shore` | Leo J. Ryan Park shoreline | bay_shore | needs_site_specific_verification | 37.5554, -122.2710 | tide_level:9414523, wave:unavailable |
| `seal-point-shore` | Seal Point shoreline | bay_shore | needs_site_specific_verification | 37.5700, -122.2980 | tide_level:9414523, wave:unavailable |
| `foster-city-bay-trail` | Foster City Bay Trail fishing shoreline | bay_shore | needs_site_specific_verification | 37.5593, -122.2506 | tide_level:9414523, wave:unavailable |
| `bair-island-access` | Bair Island public access shoreline | bay_shore | needs_site_specific_verification | 37.5136, -122.2050 | tide_level:9414523, wave:unavailable |
| `ravenswood-open-space` | Ravenswood Open Space shoreline | bay_shore | needs_site_specific_verification | 37.4910, -122.1262 | tide_level:9414523, wave:unavailable |
| `palo-alto-baylands` | Palo Alto Baylands designated fishing area | bay_shore | open_with_conditions | 37.4592, -122.1082 | tide_level:9414523, wave:unavailable |
| `alviso-marina-shore` | Alviso Marina County Park shoreline | tidal_slough | open_with_conditions | 37.4276, -121.9805 | tide_level:9415144, wind:9415115, temperature:FFFC1, wave:unavailable |

### Suisun Marsh

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `belden-landing-pier` | Belden’s Landing fishing pier | pier | open | 38.1900, -121.9942 | tide_level:9415144, wind:9415115, temperature:FFFC1, wave:unavailable |
| `grizzly-island-road-bank` | Grizzly Island Road designated bank access | tidal_slough | needs_site_specific_verification | 38.1640, -121.9800 | tide_level:9415144, wind:9415115, temperature:FFFC1, wave:unavailable |

### Western Delta

| ID | Spot | Habitat | Access | Lat, Lon | Local environment products |
|---|---|---|---|---:|---|
| `antioch-oakley-pier` | Antioch/Oakley Regional Shoreline Pier | pier | open | 38.0177, -121.7518 | tide_level:9415144, wind:9415115, temperature:FFFC1, wave:unavailable |
| `big-break-pier` | Big Break Regional Shoreline Pier | pier | open | 38.1040, -121.7307 | tide_level:9415144, wind:9415115, temperature:FFFC1, wave:unavailable |

## Sensor appendix — selected official net

This appendix expands Phase 1 from a small water-level/buoy set to compatible water-level, current, met, wave, and reserve water-quality context. Inclusion means useful official platform/product, not that every field is fresh. Ingestion must validate timestamps per field.

| ID | Official name | Class | Products / nominal cadence |
|---|---|---|---|
| `9414290` | San Francisco | coops_water_level | water_level (6-minute); predictions (modeled) |
| `9414275` | Ocean Beach, outer coast | coops_tide_prediction | predictions (modeled; not observation) |
| `9414131` | Pillar Point Harbor, Half Moon Bay | coops_tide_prediction | predictions (modeled; not observation) |
| `9414750` | Alameda | coops_water_level | water_level (6-minute); predictions (modeled) |
| `9414863` | Richmond | coops_water_level | water_level (6-minute); predictions (modeled) |
| `9414523` | Redwood City | coops_water_level | water_level (6-minute); predictions (modeled) |
| `9415102` | Martinez-Amorco Pier | coops_water_level | water_level (6-minute); predictions (modeled) |
| `9415144` | Port Chicago | coops_water_level | water_level (6-minute); predictions (modeled) |
| `9415625` | Bodega Harbor entrance | coops_tide_prediction | predictions (modeled; not observation) |
| `9415020` | Point Reyes | coops_met | station-dependent met; validate each product timestamp |
| `s06010` | Martinez-AMORCO Pier currents | coops_channel_current | currents (typically 6-minute; bin/depth required) |
| `s08010` | Southampton Shoal Channel LB6 | coops_channel_current | currents (typically 6-minute; bin/depth required) |
| `s10010` | Oakland Inner Harbor LB4 | coops_channel_current | currents (typically 6-minute; bin/depth required) |
| `46013` | BODEGA BAY — 48NM NW of San Francisco | ndbc_offshore | stdmet station-dependent (often 10–60 minute); spectral wave station-dependent |
| `46026` | SAN FRANCISCO — 18NM West | ndbc_offshore | stdmet station-dependent (often 10–60 minute); spectral wave station-dependent |
| `46012` | HALF MOON BAY — 24NM SSW / USV | ndbc_offshore | stdmet station-dependent (often 10–60 minute); spectral wave station-dependent |
| `46214` | Point Reyes CDIP 029 | cdip_offshore | directional wave, station-dependent; water temperature when reported |
| `46237` | San Francisco Bar CDIP 142 | cdip_nearshore | directional wave, station-dependent; water temperature when reported |
| `9414311` | San Francisco Pier 1 | coops_met | station-dependent met; validate each product timestamp |
| `9414296` | Pier 17 visibility | coops_met | station-dependent met; validate each product timestamp |
| `9414763` | Oakland Berth 67 | coops_met | station-dependent met; validate each product timestamp |
| `9414769` | Oakland Middle Harbor Met | coops_met | station-dependent met; validate each product timestamp |
| `9414776` | Oakland Berth 34 | coops_met | station-dependent met; validate each product timestamp |
| `9414797` | Oakland Berth 38 | coops_met | station-dependent met; validate each product timestamp |
| `9414847` | Point Potrero, Richmond | coops_met | station-dependent met; validate each product timestamp |
| `9415115` | Pittsburg (Suisun Bay) | coops_met | station-dependent met; validate each product timestamp |
| `9415118` | Union Pacific Railroad Bridge | coops_met | station-dependent met; validate each product timestamp |
| `9415141` | Davis Point | coops_met | station-dependent met; validate each product timestamp |
| `TIBC1` | Tiburon Pier | ndbc_fixed_waterquality | station-dependent fixed-platform met/water quality |
| `SCQC1` | China Camp Reserve | ndbc_fixed_waterquality | station-dependent fixed-platform met/water quality |
| `FFFC1` | First Mallard Reserve | ndbc_fixed_waterquality | station-dependent fixed-platform met/water quality |
| `RYEC1` | Second Mallard Reserve | ndbc_fixed_waterquality | station-dependent fixed-platform met/water quality |
| `SFXC1` | Rush Ranch Reserve | ndbc_fixed_met | station-dependent fixed-platform met/water quality |

### Material sensor additions beyond the earlier minimum set

- **46214 / CDIP 029 Point Reyes** adds a real open-coast wave anchor for Point Reyes/Marin; still offshore, never beach-local.
- **9415020 Point Reyes** adds official coastal met context.
- **9414296, 9414311** add SF waterfront visibility/met context; **9414763, 9414769, 9414776, 9414797** add Oakland harbor met platforms.
- **9414847 Point Potrero**, **9415141 Davis Point**, **9415118 Union Pacific Railroad Bridge**, and **9415115 Pittsburg** extend wind/met context through Richmond, Carquinez and Suisun.
- **TIBC1, SCQC1, FFFC1, RYEC1, SFXC1** add official NDBC-hosted/Reserve fixed-platform water-quality or met context for Tiburon, China Camp and Suisun Marsh. Validate individual reported fields and cadence; do not infer missing salinity/temperature.
- Existing core retained: CO-OPS observed levels `9414290`, `9414750`, `9414863`, `9414523`, `9415102`, `9415144`; prediction-only `9414275`, `9414131`, `9415625`; currents `s06010`, `s08010`, `s10010`; waves `46012`, `46013`, `46026`, `46237`.

### Mapping algorithm and maximum distances

1. Classify spot environment before distance calculation.
2. Filter sources by compatible product and environment; never assign an open-ocean wave buoy to inland water.
3. Within compatible class choose nearest fresh source by great-circle distance; retain official ID/name/coordinates, observation time, fetch time, units and per-field health.
4. Predictions and observations remain separate. Current meters are channel/depth-bin context, not shoreline current.
5. If no compatible source exists, return unavailable rather than global fallback.
6. Resolve every point with api.weather.gov/points/{lat},{lon}; use returned forecast/grid/forecastZone/fireWeatherZone/county links and active alerts, rather than hard-coded Bay-wide zones.

| Product/environment class | Maximum distance (nm) |
|---|---:|
| `coops_tide_prediction_same_waterbody` | 20 |
| `coops_water_level_inner_bay` | 15 |
| `coops_channel_current` | 8 |
| `coops_met_wind_same_basin` | 15 |
| `nearshore_wave_open_coast` | 12 |
| `offshore_wave_open_coast` | 30 |
| `fixed_water_quality_same_subembayment` | 10 |

Warn whenever distance exceeds half the class maximum; reject beyond maximum unless explicitly marked regional context. All wave readings receive a not-at-shore warning.

**Freshness:** Per field: live <= max(2x learned cadence,18 min for eligible CO-OPS latest); delayed <=2h; stale >2h; unavailable on invalid/error/unsupported. NDBC active metadata does not prove every field fresh.

## Exclusions and uncertainties

- **MPA no-take water and posted ecological closures:** Exact casting-point polygon dependency; not cataloged as fishable.
- **Private marina docks and boat-only reefs:** No verified unrestricted land access.
- **Pacifica Pier:** Retained only as closed alert; closed since 2026-06-04 per owner.
- **Berkeley Municipal Pier:** Retained only as closed alert; adjacent marina shoreline split.
- **San Francisco Municipal/Muni Pier:** CDFW current list marks closed; retained only as alert.
- **Lands End/Sutro dangerous ledges:** Existing broad record retained only as shore-zone candidate; inaccessible/wet ledges are excluded.

Additional unresolved items:

- The 18 `needs_site_specific_verification` records should not enter ranked/actionable production until a parcel/owner page or on-site posting confirms the exact casting boundary.
- MPA/no-take safety requires an authoritative polygon lookup at the casting coordinate; park access alone is not sufficient. Point Reyes and Bodega/outer-coast entries are especially sensitive to boundaries and seasonal wildlife closures.
- `46237` can remain present in metadata while stale; never silently use its old row. `46012` is currently a mobile USV/platform and its current position/status must be re-read.
- CDFW marks Pacifica, Berkeley Municipal and SF Municipal/Muni piers closed in the evidence set; only their adjacent separately verified shores may be actionable.
- Species confidence is deliberately habitat/region-level unless an owner/CDFW source is location-specific. No candidate promises a catch or converts secondary field pattern into legal evidence.

## Source register

- [CDFW — California Beach Fishing / qualifying piers and license boundary](https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing)
- [CDFW — SF Bay ocean regulations map](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay)
- [NPS — GGNRA fishing rules and closures](https://www.nps.gov/goga/planyourvisit/fishing.htm)
- [EBRPD — fishing](https://www.ebparks.org/recreation/fishing)
- [NOAA CO-OPS Metadata API](https://api.tidesandcurrents.noaa.gov/mdapi/prod/)
- [NOAA CO-OPS Data API](https://api.tidesandcurrents.noaa.gov/api/prod/)
- [NOAA San Francisco Bay PORTS](https://tidesandcurrents.noaa.gov/ports/index.html?port=sf)
- [NDBC active stations](https://www.ndbc.noaa.gov/activestations.xml)
- [NDBC Web Data Guide](https://www.ndbc.noaa.gov/docs/ndbc_web_data_guide.pdf)
- [NWS MTR marine page](https://www.weather.gov/mtr/marine)
- [NWS API documentation](https://www.weather.gov/documentation/services-web-api)

## QA use

Filter out `closed` and `needs_site_specific_verification`; then review duplicates by ID and coordinate, owner/access freshness, MPA polygon, exact pier exemption, and station compatibility. The remaining agency-backed set is exactly the 100+ retention pool; QA can reject up to ten and still retain 100. Do not copy this candidate file directly into production without that gate.
