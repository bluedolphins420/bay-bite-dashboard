import concurrent.futures, json, math, time, urllib.parse, urllib.request
from pathlib import Path

ROOT=Path('/root/company/research/bay-bite-fishing-smarts')
BASE=json.loads((ROOT/'spot-catalog-100.json').read_text())
V2=json.loads((ROOT/'spot-catalog-100-v2.json').read_text())
# Keep the original species-only lane and the separately adjudicated dual-gate
# public-owner recovery lane reproducible.  Merge into the retained snapshot so
# rerunning a focused pass never erases another worker's accepted raw evidence.
DUAL_GATE_IDS={
 'doran-beach','alviso-marina-shore','benicia-state-rec-shore',
 'martinez-shoreline','oyster-point-shore','coyote-point-shore',
 'albany-bulb-shore','point-isabel-shore'
}
IDS={x['spotId'].split(':',1)[1] for x in V2['rejectedOrPending'] if x['reasons']==['fewer-than-two-local-species-evidence-edges']} | DUAL_GATE_IDS
SPOTS={x['id']:x for x in BASE['spots'] if x['id'] in IDS}
SPECIES=['Morone saxatilis','Paralichthys californicus','Atherinopsis californiensis','Atherinops affinis','Leptocottus armatus','Triakis semifasciata','Myliobatis californica','Platichthys stellatus','Genyonemus lineatus','Cebidichthys violaceus','Ophiodon elongatus','Ictalurus punctatus','Amphistichus argenteus','Amphistichus rhodoterus','Hyperprosopon argenteum','Scorpaenichthys marmoratus','Hexagrammos decagrammus','Embiotoca lateralis','Rhacochilus vacca','Rhacochilus toxotes','Sebastes melanops','Sebastes mystinus','Sebastes auriculatus']

def hav(lat1,lon1,lat2,lon2):
 p1,p2=math.radians(lat1),math.radians(lat2); dp=p2-p1; dl=math.radians(lon2-lon1)
 a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
 return 6371*2*math.asin(math.sqrt(a))

def task(item):
 sid,sci=item; s=SPOTS[sid]; lat=s['coordinates']['lat']; lon=s['coordinates']['lon']; dlat=5/111; dlon=5/(111*math.cos(math.radians(lat)))
 poly=f'POLYGON(({lon-dlon} {lat-dlat},{lon+dlon} {lat-dlat},{lon+dlon} {lat+dlat},{lon-dlon} {lat+dlat},{lon-dlon} {lat-dlat}))'
 q={'scientificname':sci,'geometry':poly,'startdate':'2000-01-01','enddate':'2026-08-13','size':200,'fields':'id,scientificName,decimalLatitude,decimalLongitude,coordinateUncertaintyInMeters,eventDate,date_year,basisOfRecord,dataset_id,datasetName,institutionCode,collectionCode,occurrenceID,occurrenceStatus,flags,dropped,absence'}
 url='https://api.obis.org/v3/occurrence?'+urllib.parse.urlencode(q)
 for attempt in range(3):
  try:
   with urllib.request.urlopen(url,timeout=45) as r: data=json.load(r)
   rows=[]
   for x in data.get('results',[]):
    if x.get('dropped') or x.get('absence') or x.get('decimalLatitude') is None: continue
    dist=hav(lat,lon,x['decimalLatitude'],x['decimalLongitude'])
    uncertainty=(x.get('coordinateUncertaintyInMeters') or 0)/1000
    if dist+uncertainty<=5.0: rows.append({**x,'distanceKm':round(dist,3)})
   rows.sort(key=lambda x:(x['distanceKm'],str(x.get('eventDate',''))))
   return sid,sci,url,data.get('total',0),rows
  except Exception as e:
   if attempt==2:return sid,sci,url,None,[{'error':str(e)}]
   time.sleep(1+attempt)

snapshot_path=ROOT/'.obis-local-targets.json'
out=json.loads(snapshot_path.read_text()) if snapshot_path.exists() else {}
for sid in IDS: out[sid]={}
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:
 for sid,sci,url,total,rows in ex.map(task,[(sid,sci) for sid in sorted(IDS) for sci in SPECIES]):
  if rows and 'error' not in rows[0]: out[sid][sci]={'queryUrl':url,'bboxTotal':total,'within5kmCount':len(rows),'records':rows}
  elif rows: out[sid][sci]={'queryUrl':url,'error':rows[0]['error']}
snapshot_path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
for sid in sorted(out):
 print('\n'+sid)
 for sci,v in out[sid].items():
  if v.get('within5kmCount'): print(sci,v['within5kmCount'],v['records'][0].get('eventDate'),v['records'][0]['distanceKm'],v['records'][0].get('basisOfRecord'),v['records'][0].get('datasetName'))
