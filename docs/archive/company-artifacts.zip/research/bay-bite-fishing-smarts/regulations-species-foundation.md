# Bay Bite regulations and species-science foundation

**As of:** 2026-08-13 (checked 2026-08-13T10:34:50-07:00)  
**Analyst:** Priya Chen  
**Scope:** Greater San Francisco Bay shore waters, Sonoma coast through Pigeon Point, and shore-accessible Delta/Carquinez.  
**Machine-readable authority:** [`regulations-species-foundation.json`](./regulations-species-foundation.json)

## Safety contract

This is a fail-closed recommendation layer, not a substitute for the regulation text. A species/area record is targetable only when its status and freshness gates pass. `closed`, `catch-release`, `no-take`, and `unknown` are never targetable; `restricted` and `special-notice` require every warning/gear/quota/MPA gate to pass. An expired or failed source check becomes `unknown`—the engine must never preserve a stale `open` value.

## Critical status today

- **White sturgeon:** CLOSED through Sep. 30; no targeting today; Oct–Jun is catch-release only with report card.
- **Dungeness crab:** CLOSED on Sonoma–Pigeon Point coast today; NO-TAKE at all times in SF/San Pablo bays.
- **Ocean Chinook salmon:** SPECIAL NOTICE: Point Arena–Pigeon Point open Aug. 1–31 only while 34,900 guideline remains; same-day verification mandatory.
- **Surfperch:** OPEN today: coast 20 combined/max 10 one species; SF Bay Aug. 1–Mar. 31 only, 5 combined; redtail 10½-inch minimum.
- **Groundfish:** RESTRICTED: shore-based anglers are exempt from seasons/depths, not MPAs, prohibited species, RCG sublimits, hook/size rules; boat season Apr. 1–Dec. 31.

## Regulatory geography

- **SF coast:** Point Arena (38°57.5′ N) to Pigeon Point (37°11′ N), outside the Golden Gate. CDFW current summary updated Aug. 1, 2026.[CDFW SF coast](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/San-Francisco)
- **SF Bay District:** Golden Gate to west Carquinez Bridge, including defined tidal tributaries. CDFW current summary updated Aug. 1, 2026.[CDFW SF Bay](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay)
- **Carquinez/Delta:** mixed boundary. West of the west Carquinez Bridge uses SF Bay District rules; east uses inland/Delta rules. Any unresolved coordinate is `unknown`, never inferred.
- **MPAs:** geometry is an independent gate. SMRs generally prohibit all extraction; SMCAs/SMPs have area-specific exceptions. A regional season never overrides an MPA.[CDFW MPA network](https://wildlife.ca.gov/Conservation/Marine/MPAs/Network)

## Species and area record inventory

The JSON contains **22 species profiles** and **66 species×area regulatory records** across 3 areas. Status counts: `closed` 4, `no-take` 1, `open` 29, `restricted` 8, `special-notice` 4, `unknown` 20.

| Species | SF coast | SF Bay | Carquinez/Delta |
|---|---|---|---|
| Surfperch (barred/redtail and other Embiotocidae) (*Amphistichus spp.; family Embiotocidae*) | open | open | unknown |
| Striped Bass (*Morone saxatilis*) | open | open | open |
| California Halibut (*Paralichthys californicus*) | open | open | unknown |
| Rockfish (nearshore Sebastes complex) (*Sebastes spp.*) | restricted | restricted | unknown |
| Cabezon (*Scorpaenichthys marmoratus*) | restricted | restricted | unknown |
| Lingcod (*Ophiodon elongatus*) | restricted | restricted | unknown |
| Kelp and Rock Greenlings (*Hexagrammos decagrammus; H. lagocephalus*) | restricted | restricted | unknown |
| Jacksmelt (*Atherinopsis californiensis*) | open | open | unknown |
| White Croaker (*Genyonemus lineatus*) | open | open | unknown |
| Leopard Shark (*Triakis semifasciata*) | open | open | unknown |
| Bat Ray (*Myliobatis californica*) | open | open | unknown |
| Brown/Gray Smoothhound Sharks (*Mustelus henlei; M. californicus*) | open | open | unknown |
| White Sturgeon (*Acipenser transmontanus*) | closed | closed | closed |
| Other Flatfish (sanddabs, soles, starry flounder) (*multiple Pleuronectiformes species*) | open | open | unknown |
| Chinook Salmon (ocean fishery) (*Oncorhynchus tshawytscha*) | special-notice | special-notice | unknown |
| Dungeness Crab (*Metacarcinus magister*) | closed | no-take | unknown |
| Rock Crabs (*Cancer productus; Romaleon antennarium; R. branneri*) | special-notice | special-notice | unknown |
| Monkeyface Prickleback (*Cebidichthys violaceus*) | open | open | unknown |
| White Seabass (*Atractoscion nobilis*) | open | open | unknown |
| Pacific Herring (*Clupea pallasii*) | open | open | unknown |
| Northern Anchovy (*Engraulis mordax*) | open | open | unknown |
| Pacific Sardine (*Sardinops sagax*) | open | open | unknown |

## Resolved high-risk rules

### White sturgeon

CDFW states the season is closed after June 30 and reopens Oct. 1. The open season is catch-and-release only, no harvest, and targeting requires a report card. Gear is one single-point, single-shank barbless hook; east of I-680 the hook gap may not exceed one inch. White sturgeon over 60 inches fork length and every green sturgeon must remain in the water. Bay Bite status is therefore **closed today**, not “retention closed.”[CDFW report card](https://wildlife.ca.gov/Conservation/Fishes/Sturgeon/Report-Card)

### Dungeness crab

CDFW prohibits taking Dungeness crab from San Francisco and San Pablo bays at any time. The central coast season is over on Aug. 13, so the Sonoma–Pigeon Point record is **closed**. In-season RAMP orders can independently prohibit traps while allowing other methods, and CDPH health notices are a second independent gate.[CDFW SF Bay](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay) [CDFW in-season notices](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Inseason) [CDPH advisories](https://www.cdph.ca.gov/Programs/OPA/Pages/Shellfish-Advisories.aspx)

### Ocean salmon

Point Arena–Pigeon Point is scheduled open Aug. 1–31 with a 34,900-Chinook guideline and may close early. Daily bag is two salmon except coho; 20-inch minimum after May 15. Coho and steelhead retention is prohibited. Same-day status/harvest verification is mandatory.[CDFW salmon](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Salmon)

### Surfperch

Ocean coast is open under the 20-finfish aggregate, no more than 10 of one species. Inside SF Bay the special season is Aug. 1–Mar. 31 and the combined bag is five except shiner perch; redtail surfperch minimum is 10½ inches. The two areas must never share one limit.[CDFW coast](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/San-Francisco) [CDFW Bay](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay)

### Groundfish shore exemption

CDFW explicitly defines shore-based anglers as fishing beaches, banks, piers, jetties, breakwaters, docks and other shore-connected structures. They are exempt from groundfish **season and depth** restrictions when no vessel/watercraft assists. They are not exempt from MPAs, prohibited species (bronzespotted, cowcod, quillback, yelloweye), RCG sublimits, lingcod 22-inch minimum, or one-line/two-hook rules. Boat anglers in the SF management area are open Apr. 1–Dec. 31 and need a descending device.[CDFW groundfish summary](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Groundfish-Summary)

## Health-advisory layer

OEHHA's SF Bay advisory is mandatory at point of retention: Lauritzen Channel is do-not-eat for all fish/shellfish; advice is species- and consumer-group-specific for halibut, jacksmelt, surfperch, white croaker, sharks, striped bass and others. It must not be reduced to one generic warning.[OEHHA SF Bay](https://oehha.ca.gov/fish/advisories/san-francisco-bay) CDPH lifted the 2026 central-coast anchovy/sardine warning by Aug. 3, but the engine still checks current seafood/biotoxin notices. Rock crab remains `special-notice` pending explicit confirmation that the Dec. 2025 viscera warning has been lifted.[CDPH advisories](https://www.cdph.ca.gov/Programs/OPA/Pages/Shellfish-Advisories.aspx)

## Biological model

Each JSON profile includes canonical/scientific names, habitat guild, substrate, depth/salinity, temperature, forage, seasonal movements, tide/current/light/turbidity triggers, spawning/nursery sensitivity, tackle implications, citations and confidence. The profiles are ecological priors—not proof of current local presence. Bay Bite should combine them with verified access, lawful geometry and live environmental data, never use them to override a legal gate.

Important model corrections:

- “Rockfish” is not one interchangeable target; species identification and prohibited-species handling are mandatory.
- California halibut are sand-edge ambush predators and bays/estuaries are nursery habitat; no unsupported single-temperature “magic number” is encoded.
- White sturgeon are late-maturing with episodic wet-year recruitment and recent HAB mortality; legal status dominates bite potential.
- Herring spawning aggregations are seasonal and substrate-sensitive; an annual calendar alone is not live evidence.
- Monkeyface prickleback are localized rocky-intertidal residents; repeat harvest from one crevice can deplete a micro-site, and MPA/no-take geometry is decisive.
- Anchovy and sardine have no numerical bag limit, but ecological restraint and HAB notices still apply.

## Deterministic refresh/check strategy

1. **Daily 06:00 PT:** fetch both CDFW regional maps, in-season notices, salmon, sturgeon and CDPH. Validate HTTP success, nonempty content and expected current markers.
2. **Same day before recommendation:** recheck salmon quota/status, Dungeness RAMP/health status, sturgeon season and every `special-notice` record.
3. **Weekly:** groundfish table, general ocean regulations, MPA regulation/geometry feeds, OEHHA advisory index.
4. **Coordinate gate:** resolve each spot against Golden Gate/Carquinez management boundaries and authoritative MPA polygons. Unknown geometry suppresses affected species.
5. **Diff gate:** parse to a candidate snapshot; any legal-status/season/limit/gear/boundary change blocks affected species pending reviewed approval. Atomic publish only after validation.
6. **Failure policy:** source/parser/geometry failure changes affected status to `unknown`; preserve last-known data only as audit history, never as targetable state.
7. **Required tests:** stale open suppressed; closed/no-take/unknown excluded; salmon missing quota status excluded; groundfish prohibited species excluded; Dungeness SF Bay always excluded; unresolved Carquinez side excluded.

## Known uncertainties

- The exact current inland rule for every shore-accessible Delta coordinate is intentionally unresolved in this marine-first packet. Only striped bass and today's sturgeon closure are represented confidently; other Delta records fail closed as `unknown`.
- `Flounder/Sole`, `Rockfish`, `Surfperch`, and `Smoothhound Shark` are UI aggregates spanning species with different identification/limit implications. Production should select the exact species before retention guidance.
- Rock crab is conservatively `special-notice` because the CDPH page shows a Dec. 2025 northern-coast viscera warning but no clearly matched lift in the fetched current notices.
- Salmon is a dynamic harvest-guideline fishery. A static Aug. 1 page check is insufficient for an Aug. 13 trip.
- MPA rules are geometry-specific; this packet provides the dependency and official map sources, not a spot-level polygon adjudication.

## Primary sources

- [CDFW current San Francisco ocean-region map](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/San-Francisco) — checked 2026-08-13T10:34:50-07:00
- [CDFW current SF Bay region map](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/SF-Bay) — checked 2026-08-13T10:34:50-07:00
- [2026 Ocean Sport Fishing Regulations](https://nrm.dfg.ca.gov/FileHandler.ashx?DocumentID=239985&inline) — checked 2026-08-13T10:34:50-07:00
- [CDFW in-season ocean changes](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Inseason) — checked 2026-08-13T10:34:50-07:00
- [CDFW recreational groundfish summary](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Groundfish-Summary) — checked 2026-08-13T10:34:50-07:00
- [CDFW ocean salmon fishery information](https://wildlife.ca.gov/Fishing/Ocean/Regulations/Salmon) — checked 2026-08-13T10:34:50-07:00
- [CDFW sturgeon report card and current season](https://wildlife.ca.gov/Conservation/Fishes/Sturgeon/Report-Card) — checked 2026-08-13T10:34:50-07:00
- [CDFW MPA network/map](https://wildlife.ca.gov/Conservation/Marine/MPAs/Network) — checked 2026-08-13T10:34:50-07:00
- [OEHHA SF Bay fish consumption advisory](https://oehha.ca.gov/fish/advisories/san-francisco-bay) — checked 2026-08-13T10:34:50-07:00
- [CDPH shellfish and seafood advisories](https://www.cdph.ca.gov/Programs/OPA/Pages/Shellfish-Advisories.aspx) — checked 2026-08-13T10:34:50-07:00
- [NOAA West Coast Groundfish](https://www.fisheries.noaa.gov/species/west-coast-groundfish) — checked 2026-08-13T10:34:50-07:00
