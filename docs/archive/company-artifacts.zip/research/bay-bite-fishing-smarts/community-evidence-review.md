# Bay Bite community evidence lead review

**Reviewer:** Priya Chen  
**Reviewed:** 2026-08-13  
**Scope:** Species/catch evidence only; **not** access, legality, regulations, or MPA status.

## Outcome

- Spots reviewed: **17**
- Lead instances reviewed: **110** across **65** unique URLs
- Accepted lead pages: **1**
- Accepted species edges: **2**
- Spots with no supplied leads: **8**

Search snippets were treated as discovery only. Actual pages were fetched directly where possible. Inaccessible bodies, questions, copied public-pier lists, vague regional claims, habitat possibility, and generic “anglers fish for” statements were rejected.

## Accepted species edges

| Spot | Species | Date/season | Exactness | Source class | Confidence | Evidence | Source |
|---|---|---|---|---|---|---|---|
| `point-pinole-shore` Point Pinole shoreline | striped bass | 2019-03-17 | exact-pier-within-named-shoreline | reviewed-community-forum-report | medium | Author saw a couple of striped bass, about 5–8 lb, caught on pile worms and grass shrimp. Uncertainty: Single eyewitness forum report; exact Point Pinole Pier, not proof for every shoreline casting pixel. | https://www.pierfishing.com/msgboard/index.php?threads/point-pinole-pier.619/ |
| `point-pinole-shore` Point Pinole shoreline | steelhead | 2019-03-24 | exact-pier-within-named-shoreline | reviewed-community-forum-report | low | A participant reported catching a small steelhead off the pier on Sunday. Uncertainty: Uncorroborated first-person anecdote; species identification not independently verified. | https://www.pierfishing.com/msgboard/index.php?threads/point-pinole-pier.619/ |

## Spot-by-spot review

### `john-sheridan-pier` — John J. Sheridan Pier

1. **REJECTED** — https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing
   - Actual page: California Beach Fishing (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

2. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163534055989839/
   - Actual page: Redondo Beach Pier | Dec 20th | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

3. **REJECTED** — https://www.facebook.com/official.die.hard.fishing/posts/beach-closures-dont-stop-fishing-learn-how-to-catch-surf-perch-and-more-from-a-p/1440848778083395/
   - Actual page: 80K views · 825 reactions | Beach closures don't stop fishing! Learn how to catch surf perch and more from a pier, right next to the breaking waves. Relaxing, productive, and surprisingly effective. #PierFishing #SurfFishing #FishingTips #CaliforniaFishing #CatchAndRelease | Die Hard Fishing (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

4. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164516902314839/
   - Actual page: Pier Fishing In California | Q&A with the DFG | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

5. **REJECTED** — https://www.facebook.com/redwoodcityport/posts/reel-in-the-next-big-catch-at-our-public-fishing-pier-open-to-the-community-come/1346997197464090/
   - Actual page: Port of Redwood City (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

6. **REJECTED** — https://www.facebook.com/newportnewsparks/posts/a-fisherman-shows-off-the-speckled-trout-he-caught-at-the-wavescreen-fishing-pie/10158210142675336/
   - Actual page: Newport News Parks Division (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

7. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163660353234839/
   - Actual page: Pier Fishing In California | **To: Pier Fishing In California Message Board** | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

8. **REJECTED** — https://www.facebook.com/CaliforniaDFW/posts/where-can-you-fish-without-a-fishing-license-in-california-did-you-know-that-a-f/243946117914006/
   - Actual page: California Department of Fish and Wildlife (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

9. **REJECTED** — https://www.facebook.com/groups/754770128572431/posts/1619066675476101/
   - Actual page: Puerto Rico things to do & daily itinerary | Besides crashboat what are some spots for pier fishing on the west coast | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

10. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164093677304839/
   - Actual page: San Clemente Pier — 63 Fish Species | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

11. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164429602829839/
   - Actual page: Pier Fishing In California | Fish & game caught a bunch of people at the end of Santa Monica pier jigging and hooking like 30 lobsters | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

12. **REJECTED** — https://www.pierfishing.com/msgboard/index.php?threads/the-official-california-fish-wildlife-dept-list-of-public-piers-and-jetties-%E2%80%94-no-fishing-license-required.2508/
   - Actual page: The official California Fish & Wildlife Dept. list of public piers and jetties — NO FISHING LICENSE REQUIRED (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

13. **REJECTED** — https://www.facebook.com/mackfishreports/posts/wow-this-is-huge-what-we-call-simple-green-spot-is-now-open-on-the-navy-side-at-/1250077330457942/
   - Actual page: Macks Fish Reports (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

14. **REJECTED** — https://www.facebook.com/groups/SFbayareastreetphotograpy/posts/10163427814845746/
   - Actual page: San Francisco Bay Area Street Photography | **Sunrise Point Fishing Pier** is a public pier in Candlestick Point State Recreation Area | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

15. **REJECTED** — https://www.facebook.com/cayucoschamberofcommerce/posts/fishing-in-cayucos-is-always-a-good-daycast-a-line-off-the-pier-with-salty-air-i/1344585861046890/
   - Actual page: Cayucos Chamber of Commerce (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

### `point-pinole-shore` — Point Pinole shoreline

1. **REJECTED** — https://www.tiktok.com/@rippedlips209/video/7656287852719820063
   - Actual page: Point Pinole fishing tips: Best spots & bait for Bay Area saltwater (fetch: fetched, HTTP 200)
   - Exactness: `name-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual TikTok page/search aggregation does not state a verifiable species catch at the exact spot; fishing tips/hashtags and generic “fish report” labels are insufficient.

2. **REJECTED** — https://www.facebook.com/groups/724158551629608/posts/1445423672836422/
   - Actual page: Northern California Striped Bass Report | I live in Rodeo,ca and the fishing in the bay here is good but want to venture around where are some good spots close by if anyone knows and wants to ... | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

3. **REJECTED** — https://richmondconfidential.org/2012/10/15/oysters-in-for-a-comeback-at-point-pinole/
   - Actual page: Oysters in for a comeback at Point Pinole (fetch: fetched, HTTP 200)
   - Exactness: `exact-shoreline`; source class: `local-news/ecology-report`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: exact Point Pinole ecology article concerns Olympia oyster restoration/presence, not an angler catch or target-fish catch report.

4. **REJECTED** — https://www.instagram.com/p/Dan9Ci1AbPZ/
   - Actual page: The Loon Foundation on Instagram: "It’s #FieldWorkFriday
 
This week has been filled with exciting species. We had mentioned last week that sometimes we get adult squid in our juvenile salmon sets and on Friday, they were there! One was very active and tried to camouflage in the bucket. Check out the cool video where you can see one of them ink. In addition to Shiner perch, we had pile perch, which we only see occasionally.
 
In our larval crab survey, we had a western brook lamprey. These fish are elusive parasites that can have big impacts on fish. You can tell when a lamprey has been attached by the round wound left in the flesh of its hosts. Check out the mouth and all of those teeth!
 
We had an amazing group of youth come to help clean up the Iris and Billy Griffith Center to get ready for the Kids Nature & Art camp that we are offering in August. They cleared the trails and driveway, mowed the lawns, dismantled the rotting bird blind, and removed deadfall from the forest. A huge thank you to the Glenwood Group! We will be working on cleaning up the inside of the building on July 23 with our amazing volunteers.
 
Want to get involved? We have many opportunities to participate in monitoring and events. Please visit our events calendar at www.loonfoundation.org or contact Jenn at jenn@loonfoundation.org for details." (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

5. **REJECTED** — https://www.tiktok.com/@yollygee/video/7667810851776154894
   - Actual page: ✅CHECK ON FROG POND 📍POINT PINOLE ⚠️HE SAID ITS ... (fetch: fetched, HTTP 200)
   - Exactness: `name-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual TikTok page/search aggregation does not state a verifiable species catch at the exact spot; fishing tips/hashtags and generic “fish report” labels are insufficient.

6. **REJECTED** — https://www.reddit.com/r/SurfFishing/comments/1ohynpy/striper_confusion/
   - Actual page: Striper confusion : r/SurfFishing (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

7. **REJECTED** — https://www.instagram.com/p/DRIrWF_EggC/
   - Actual page: UVic ERC on Instagram: "Join us for our Forage-fish Survey at Willows Beach on November 21st at 7pm!

Forage fish are small schooling fish, such as Pacific sand lance, smelts, and anchovies. These species are key stone species! 

Spawning surveys are important for increasing our knowledge of Forage fish spawning behaviour, species, and their favourite spots for spawning. (BEACH Program, Pennisula Streams)

If you want to join us, sign up via the link tree in our bio!" (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

8. **REJECTED** — https://www.tiktok.com/@yollygee/video/7656215414568946957
   - Actual page: Fishing by Oracle Park: SF Giants Waterfront Fishing Guide (fetch: fetched, HTTP 200)
   - Exactness: `name-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual TikTok page/search aggregation does not state a verifiable species catch at the exact spot; fishing tips/hashtags and generic “fish report” labels are insufficient.

9. **REJECTED** — https://www.sfgate.com/green/article/S-F-Bay-s-slide-in-mud-worries-scientists-3215319.php
   - Actual page: S.F. Bay's slide in mud worries scientists (fetch: fetched, HTTP 200)
   - Exactness: `exact-shoreline`; source class: `news/environmental-report`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: exact shoreline appears as environmental context; no species catch is reported.

10. **REJECTED** — https://www.tiktok.com/content/point-pinole-regional-shoreline-fishing?lang
   - Actual page: Point Pinole Regional Shoreline Fishing (fetch: fetched, HTTP 200)
   - Exactness: `name-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual TikTok page/search aggregation does not state a verifiable species catch at the exact spot; fishing tips/hashtags and generic “fish report” labels are insufficient.

11. **ACCEPTED** — https://www.pierfishing.com/msgboard/index.php?threads/point-pinole-pier.619/
   - Actual page: Point Pinole Pier (fetch: fetched, HTTP 200)
   - Exactness: `exact-pier-within-named-shoreline`; source class: `reviewed-community-forum-report`; confidence: `medium`
   - Date/season: 2019-03-17 (reported Mar. 20, 2019)
   - Reason: Thread body names the Point Pinole shoreline and pier and reports seeing two striped bass caught; a later same-thread post reports a small steelhead caught from the pier the following Sunday.
   - Uncertainty: Single eyewitness forum report; exact Point Pinole Pier, not proof for every shoreline casting pixel.
   - Accepted edge: **striped bass** — Author saw a couple of striped bass, about 5–8 lb, caught on pile worms and grass shrimp. Confidence: medium.
   - Accepted edge: **steelhead** — A participant reported catching a small steelhead off the pier on Sunday. Confidence: low.

12. **REJECTED** — https://www.instagram.com/p/DUKFLaWCBEP/
   - Actual page: Project Watershed on Instagram: "🐟 Our forage fish team is launching a new program: herring spawn monitoring! 🐟

They are looking for volunteers to walk Kye Bay, Little 
River, and Point Holmes from February 15 until March 31st to document Pacific herring eggs. 

📆 Training sessions will be held Saturday, February 7th from 1-3 pm at Kye Bay and Tuesday, February 10th from 2-4 pm at Point Holmes.

👉 If you are interested in helping out, please sign up for a training session via our Volunteer Calendar: projectwatershed.ca/volunteer (link in bio - and then choose either the Feb 7th or Feb 10th training session from the calendar view)." (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

13. **REJECTED** — https://www.tiktok.com/@yollygee/video/7659257558292499725
   - Actual page: came for the churros Got to meet a parrot lol #oaklandfleamarket #p... (fetch: fetched, HTTP 200)
   - Exactness: `name-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual TikTok page/search aggregation does not state a verifiable species catch at the exact spot; fishing tips/hashtags and generic “fish report” labels are insufficient.

14. **REJECTED** — https://www.mercurynews.com/2022/04/14/bay-area-hikes-the-history-of-explosives-at-point-pinole-regional-shoreline/
   - Actual page: Bay Area hikes: The history of explosives at Point Pinole Regional Shoreline (fetch: fetched, HTTP 200)
   - Exactness: `exact-pier-within-named-shoreline`; source class: `local-news-feature`; confidence: `none`
   - Date/season: 2022-04-14
   - Reason: Rejected under the current-presence/general angling-claim rule: page says anglers fish for halibut, rockfish, and white sturgeon, but does not report an exact-site catch event.
   - Uncertainty: Names species anglers fish for, but gives no dated catch observation or report provenance.

15. **REJECTED** — https://www.instagram.com/reel/C6wbv62xAoA/
   - Actual page: The Watershed Project on Instagram: "“THANK YOU so much for coming to our school and planting amazing trees, grasses, and shrubs.  My soul is light and happy seeing the new additions to our yard.  Additionally, I enjoyed seeing the high schoolers partner with our nine year olds!  It was an amazing day and such a memorable opportunity for everyone.  Thank you for selecting our school and I do hope you come back again for another project!” 
- D. Lau-Yee, Principal, Robert Louie Stevenson Elementary School 

Closing remarks from RL Stevenson’s Principal on The Watershed Project (in partnership with @lotusengineers and @mysfpuc) and the work from the Rainwater Action Day on their campus! 🌄🤝🏽" (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

16. **REJECTED** — https://www.instagram.com/p/DZIbJ9mGyJH/
   - Actual page: Necanicum Watershed Council on Instagram: "Join us at the Necanicum Estuary for a fun day of clamming during ODFW’s Free Fishing Day! No fishing licenses are required. Just bring clothes you don’t mind getting a little dirty, appropriate shoes, a container, and a smile! If you have a shovel or clam gun, bring it along. We look forward to seeing you there. Link in bio 🪏

Únanse con nosotros en el estuario Necanicum para un día divertido de pesca de almejas durante el Día de Pesca Gratuita del ODFW. ¡No se necesita licencia de pesca! Solo traigan ropa que se pueda ensuciar, zapatos adecuados, un recipiente y una sonrisa. Si tienen una pala o una pistola de almejas, tráiganla. Esperamos verlos allí. Enlace en la bio 🪏

#freefishingday #clamming #pnwisbest #clams" (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

17. **REJECTED** — https://www.spn.usace.army.mil/Portals/68/docs/regulatory/RGP/Enclosures%20all_permit.pdf?ver=OzQ9wzy1FqJbpyTVCorEgQ%3D%3D
   - Actual page: [PDF] Description of Covered Maintenance Activities Culvert Repair ... (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `secondary-web`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

### `veterans-pier-alameda` — Veterans Pier Alameda

**No leads were supplied.** No community species edge could be reviewed or accepted.

### `benicia-9th-st-pier` — 9th Street Pier Benicia

1. **REJECTED** — https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing
   - Actual page: California Beach Fishing (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

2. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164455570594839/
   - Actual page: Pier Fishing In California | 🌞🌞As Kenneth Jones says, be careful as to not jump to conclusions | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

3. **REJECTED** — https://www.facebook.com/groups/754770128572431/posts/1619066675476101/
   - Actual page: Puerto Rico things to do & daily itinerary | Besides crashboat what are some spots for pier fishing on the west coast | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

4. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163660353234839/
   - Actual page: Pier Fishing In California | **To: Pier Fishing In California Message Board** | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

5. **REJECTED** — https://www.facebook.com/redwoodcityport/posts/reel-in-the-next-big-catch-at-our-public-fishing-pier-open-to-the-community-come/1346997197464090/
   - Actual page: Port of Redwood City (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

6. **REJECTED** — https://www.facebook.com/cayucoschamberofcommerce/posts/fishing-in-cayucos-is-always-a-good-daycast-a-line-off-the-pier-with-salty-air-i/1344585861046890/
   - Actual page: Cayucos Chamber of Commerce (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

7. **REJECTED** — https://www.facebook.com/FriendsOfSantaCruzStateParks/posts/its-too-cold-for-swimming-instead-go-fishing-at-palm-state-beachanglers-at-palm-/587995443365857/
   - Actual page: Friends of Santa Cruz State Parks (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

8. **REJECTED** — https://www.facebook.com/mackfishreports/posts/wow-this-is-huge-what-we-call-simple-green-spot-is-now-open-on-the-navy-side-at-/1250077330457942/
   - Actual page: Macks Fish Reports (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

9. **REJECTED** — https://www.facebook.com/groups/1142408325798566/posts/6678368685535808/
   - Actual page: Trinis who fish | Let's go fishing 347-6413 | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

10. **REJECTED** — https://www.facebook.com/groups/SFbayareastreetphotograpy/posts/10163414727035746/
   - Actual page: San Francisco Bay Area Street Photography | There are two public fishing piers along the southern shoreline of Candlestick Point Park (no license required) | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

11. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163534055989839/
   - Actual page: Redondo Beach Pier | Dec 20th | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

12. **REJECTED** — https://www.facebook.com/official.die.hard.fishing/posts/beach-closures-dont-stop-fishing-learn-how-to-catch-surf-perch-and-more-from-a-p/1440848778083395/
   - Actual page: 80K views · 825 reactions | Beach closures don't stop fishing! Learn how to catch surf perch and more from a pier, right next to the breaking waves. Relaxing, productive, and surprisingly effective. #PierFishing #SurfFishing #FishingTips #CaliforniaFishing #CatchAndRelease | Die Hard Fishing (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

13. **REJECTED** — https://www.pierfishing.com/msgboard/index.php?threads/the-official-california-fish-wildlife-dept-list-of-public-piers-and-jetties-%E2%80%94-no-fishing-license-required.2508/
   - Actual page: The official California Fish & Wildlife Dept. list of public piers and jetties — NO FISHING LICENSE REQUIRED (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

14. **REJECTED** — https://www.facebook.com/groups/SFbayareastreetphotograpy/posts/10163427814845746/
   - Actual page: San Francisco Bay Area Street Photography | **Sunrise Point Fishing Pier** is a public pier in Candlestick Point State Recreation Area | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

15. **REJECTED** — https://www.facebook.com/100093010238370/posts/no-fishing-license-needed-on-pismo-beach-pier/821754114268256/
   - Actual page: Luci Rogers (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

### `cullinan-ranch-pier` — Cullinan Ranch Fishing Pier

1. **REJECTED** — https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing
   - Actual page: California Beach Fishing (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

2. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163534055989839/
   - Actual page: Redondo Beach Pier | Dec 20th | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

3. **REJECTED** — https://www.facebook.com/official.die.hard.fishing/posts/beach-closures-dont-stop-fishing-learn-how-to-catch-surf-perch-and-more-from-a-p/1440848778083395/
   - Actual page: 80K views · 825 reactions | Beach closures don't stop fishing! Learn how to catch surf perch and more from a pier, right next to the breaking waves. Relaxing, productive, and surprisingly effective. #PierFishing #SurfFishing #FishingTips #CaliforniaFishing #CatchAndRelease | Die Hard Fishing (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

4. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164516902314839/
   - Actual page: Pier Fishing In California | Q&A with the DFG | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

5. **REJECTED** — https://www.facebook.com/newportnewsparks/posts/a-fisherman-shows-off-the-speckled-trout-he-caught-at-the-wavescreen-fishing-pie/10158210142675336/
   - Actual page: Newport News Parks Division (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

6. **REJECTED** — https://www.facebook.com/redwoodcityport/posts/reel-in-the-next-big-catch-at-our-public-fishing-pier-open-to-the-community-come/1346997197464090/
   - Actual page: Port of Redwood City (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

7. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164093677304839/
   - Actual page: San Clemente Pier — 63 Fish Species | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

8. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163660353234839/
   - Actual page: Pier Fishing In California | **To: Pier Fishing In California Message Board** | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

9. **REJECTED** — https://www.facebook.com/cayucoschamberofcommerce/posts/fishing-in-cayucos-is-always-a-good-daycast-a-line-off-the-pier-with-salty-air-i/1344585861046890/
   - Actual page: Cayucos Chamber of Commerce (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

10. **REJECTED** — https://www.facebook.com/groups/754770128572431/posts/1619066675476101/
   - Actual page: Puerto Rico things to do & daily itinerary | Besides crashboat what are some spots for pier fishing on the west coast | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

11. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164429602829839/
   - Actual page: Pier Fishing In California | Fish & game caught a bunch of people at the end of Santa Monica pier jigging and hooking like 30 lobsters | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

12. **REJECTED** — https://www.pierfishing.com/msgboard/index.php?threads/the-official-california-fish-wildlife-dept-list-of-public-piers-and-jetties-%E2%80%94-no-fishing-license-required.2508/
   - Actual page: The official California Fish & Wildlife Dept. list of public piers and jetties — NO FISHING LICENSE REQUIRED (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

13. **REJECTED** — https://www.facebook.com/mackfishreports/posts/wow-this-is-huge-what-we-call-simple-green-spot-is-now-open-on-the-navy-side-at-/1250077330457942/
   - Actual page: Macks Fish Reports (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

14. **REJECTED** — https://www.facebook.com/CaliforniaDFW/posts/where-can-you-fish-without-a-fishing-license-in-california-did-you-know-that-a-f/243946117914006/
   - Actual page: California Department of Fish and Wildlife (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

### `big-break-pier` — Big Break Regional Shoreline fishing pier

1. **REJECTED** — https://www.waterboards.ca.gov/drought/tucp/docs/2022/2022-06-01-habs-weeds-report.pdf
   - Actual page: [PDF] Temporary Urgency Change Petition of 2021 and Emergency Drought ... (fetch: fetched, HTTP 200)
   - Exactness: `exact-site-monitoring-name`; source class: `government-environmental-report`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: report uses Big Break fishing pier as a HAB/aquatic-weed monitoring location and discusses Delta fish generally; it does not report a species caught at the pier.

2. **REJECTED** — https://www.yelp.com/search?find_desc=Fishing+Pier&find_loc=Dublin%2C+CA
   - Actual page: TOP 10 BEST Fishing Pier near Dublin, CA - Updated 2026 - Yelp (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `secondary-web`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

3. **REJECTED** — https://waterboards.ca.gov/drought/tucp/docs/2022/2022-10-14-habs-weeds-report.pdf
   - Actual page: [PDF] Temporary Urgency Change Petition of 2021 and Emergency Drought ... (fetch: fetched, HTTP 200)
   - Exactness: `exact-site-monitoring-name`; source class: `government-environmental-report`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: report uses Big Break fishing pier as a HAB/aquatic-weed monitoring location and discusses Delta fish generally; it does not report a species caught at the pier.

4. **REJECTED** — https://m.yelp.com/search?find_desc=Fishing+Pier&find_loc=Murphys%2C+CA
   - Actual page: TOP 10 BEST Fishing Pier near Murphys, CA - Updated 2026 - Yelp (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `secondary-web`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

### `spud-point-pier` — Spud Point Public Pier

1. **REJECTED** — https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing
   - Actual page: California Beach Fishing (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

2. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164546895654839/
   - Actual page: Pier Fishing In California | Yesterday's catch | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `none`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook post lists a “yesterday’s catch” with species but does not name the Bay Bite spot; search association came from unrelated copied pier-list text/snippet, so location is unproven.

3. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164516902314839/
   - Actual page: Pier Fishing In California | Q&A with the DFG | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

4. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163660353234839/
   - Actual page: Pier Fishing In California | **To: Pier Fishing In California Message Board** | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

5. **REJECTED** — https://www.facebook.com/redwoodcityport/posts/reel-in-the-next-big-catch-at-our-public-fishing-pier-open-to-the-community-come/1346997197464090/
   - Actual page: Port of Redwood City (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

6. **REJECTED** — https://www.facebook.com/cayucoschamberofcommerce/posts/fishing-in-cayucos-is-always-a-good-daycast-a-line-off-the-pier-with-salty-air-i/1344585861046890/
   - Actual page: Cayucos Chamber of Commerce (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

7. **REJECTED** — https://www.facebook.com/groups/754770128572431/posts/1619066675476101/
   - Actual page: Puerto Rico things to do & daily itinerary | Besides crashboat what are some spots for pier fishing on the west coast | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

8. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164093677304839/
   - Actual page: San Clemente Pier — 63 Fish Species | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

9. **REJECTED** — https://www.facebook.com/mackfishreports/posts/wow-this-is-huge-what-we-call-simple-green-spot-is-now-open-on-the-navy-side-at-/1250077330457942/
   - Actual page: Macks Fish Reports (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

10. **REJECTED** — https://www.facebook.com/CaliforniaDFW/posts/where-can-you-fish-without-a-fishing-license-in-california-did-you-know-that-a-f/243946117914006/
   - Actual page: California Department of Fish and Wildlife (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

11. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164033637464839/
   - Actual page: Pier Fishing In California | Anyone catching at any piers tonight | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

12. **REJECTED** — https://www.facebook.com/official.die.hard.fishing/posts/beach-closures-dont-stop-fishing-learn-how-to-catch-surf-perch-and-more-from-a-p/1440848778083395/
   - Actual page: 80K views · 825 reactions | Beach closures don't stop fishing! Learn how to catch surf perch and more from a pier, right next to the breaking waves. Relaxing, productive, and surprisingly effective. #PierFishing #SurfFishing #FishingTips #CaliforniaFishing #CatchAndRelease | Die Hard Fishing (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

13. **REJECTED** — https://www.reddit.com/r/crabbing/comments/emvspy/crabbing_in_sf_for_the_first_time_tonight/
   - Actual page: Crabbing in SF for the first time tonight. (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

14. **REJECTED** — https://www.facebook.com/groups/SFbayareastreetphotograpy/posts/10163427814845746/
   - Actual page: San Francisco Bay Area Street Photography | **Sunrise Point Fishing Pier** is a public pier in Candlestick Point State Recreation Area | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

### `bodega-south-jetty` — Bodega Bay South Jetty

1. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164546895654839/
   - Actual page: Pier Fishing In California | Yesterday's catch | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `none`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook post lists a “yesterday’s catch” with species but does not name the Bay Bite spot; search association came from unrelated copied pier-list text/snippet, so location is unproven.

2. **REJECTED** — https://wildlife.ca.gov/Fishing/Ocean/Beach-Fishing
   - Actual page: California Beach Fishing - California Department of Fish and Wildlife (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

3. **REJECTED** — https://www.facebook.com/groups/754770128572431/posts/1619066675476101/
   - Actual page: Puerto Rico things to do & daily itinerary | Besides crashboat what are some spots for pier fishing on the west coast | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

4. **REJECTED** — https://www.facebook.com/mackfishreports/posts/wow-this-is-huge-what-we-call-simple-green-spot-is-now-open-on-the-navy-side-at-/1250077330457942/
   - Actual page: Macks Fish Reports (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

5. **REJECTED** — https://www.facebook.com/cristopher.carpila/posts/the-santa-monica-pier-is-a-historic-landmark-known-for-its-amusement-park-pacifi/10233841745210336/
   - Actual page: Cristopher Retokelly Carpila (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

6. **REJECTED** — https://www.iatp.org/files/Estimated_Annual_Economic_Impacts_from_Harmful.htm
   - Actual page: Estimated Annual Economic Impacts from Harmful Algal Blooms in the ... (fetch: fetched, HTTP 200)
   - Exactness: `regional-list-including-exact-name`; source class: `historical-economic/HAB-summary`; confidence: `none`
   - Date/season: historical table (1980s–1990s)
   - Reason: Reject: exact jetty appears only in a grouped harmful-algal-bloom affected-area list; mackerel/rockfish sample lines cannot be tied unambiguously to that location and are not community catch reports.
   - Uncertainty: The table groups multiple Sonoma County affected areas; fish measurements are not unambiguously assigned to South Jetty.

7. **REJECTED** — https://www.facebook.com/newportnewsparks/posts/a-fisherman-shows-off-the-speckled-trout-he-caught-at-the-wavescreen-fishing-pie/10158210142675336/
   - Actual page: Newport News Parks Division (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

8. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10163660353234839/
   - Actual page: Pier Fishing In California | **To: Pier Fishing In California Message Board** | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

9. **REJECTED** — https://www.facebook.com/FriendsOfSantaCruzStateParks/posts/its-too-cold-for-swimming-instead-go-fishing-at-palm-state-beachanglers-at-palm-/587995443365857/
   - Actual page: Friends of Santa Cruz State Parks (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

10. **REJECTED** — https://www.facebook.com/groups/73007114838/posts/10164516905849839/
   - Actual page: Pier Fishing In California | Q&A with the DFG | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

11. **REJECTED** — https://www.reddit.com/r/crabbing/comments/6bkn35/crab_snares_on_the_bodega_bay_south_jetty/
   - Actual page: Crab Snares on the Bodega Bay South Jetty (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

12. **REJECTED** — https://www.facebook.com/groups/881540849020721/posts/1185921911915945/
   - Actual page: Rudee Inlet Fishing | Is it legal to walk to the end of this rock inlet jetty thing | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

13. **REJECTED** — https://www.facebook.com/official.die.hard.fishing/posts/beach-closures-dont-stop-fishing-learn-how-to-catch-surf-perch-and-more-from-a-p/1440848778083395/
   - Actual page: 80K views · 825 reactions | Beach closures don't stop fishing! Learn how to catch surf perch and more from a pier, right next to the breaking waves. Relaxing, productive, and surprisingly effective. #PierFishing #SurfFishing #FishingTips #CaliforniaFishing #CatchAndRelease | Die Hard Fishing (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

14. **REJECTED** — https://www.pierfishing.com/msgboard/index.php?threads/the-official-california-fish-wildlife-dept-list-of-public-piers-and-jetties-%E2%80%94-no-fishing-license-required.2508/
   - Actual page: The official California Fish & Wildlife Dept. list of public piers and jetties — NO FISHING LICENSE REQUIRED (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

15. **REJECTED** — https://www.facebook.com/cayucoschamberofcommerce/posts/fishing-in-cayucos-is-always-a-good-daycast-a-line-off-the-pier-with-salty-air-i/1344585861046890/
   - Actual page: Cayucos Chamber of Commerce (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

16. **REJECTED** — https://www.facebook.com/CaliforniaDFW/posts/interested-in-learning-the-basics-of-fishing-and-crabbing-from-piers-and-jetties/4400701713342595/
   - Actual page: California Department of Fish and Wildlife (fetch: fetched, HTTP 200)
   - Exactness: `name-only-in-list`; source class: `official-or-copied-public-pier/generic-fishing-list`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page is a statewide public-pier/generic fishing resource or copied CDFW list, not an exact-spot catch report; generic species material is not locally attributable.

17. **REJECTED** — https://www.facebook.com/PortofNewport/posts/while-fishing-from-marina-docks-is-prohibited-by-port-of-newport-facilities-code/572291031593545/
   - Actual page: Port of Newport (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

### `salmon-creek-north` — Salmon Creek Beach North Sonoma

**No leads were supplied.** No community species edge could be reviewed or accepted.

### `shell-beach-sonoma` — Shell Beach Sonoma Coast

1. **REJECTED** — https://www.facebook.com/groups/BayAreaHike/posts/3179189648916788/
   - Actual page: Bay Area Hikers | The Kortum trail from Goat Rock to Shell Beach, Sonoma coast yesterday and ending with an Aperol Spritz at Gillies restaurant with my daughter, Fiona. | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

2. **REJECTED** — https://www.instagram.com/p/DbOTR-qjaSl/
   - Actual page: Stewards of Coast & Redwoods on Instagram: "TOMORROW Sunday, July 26th from 10am to 12:30pm, learn NATURE JOURNALING  at Shell Beach in Sonoma County! https://stewardscr.org/events/2026-playing-with-watercolor-in-nature-journals-at-the-coast-july/
Sarah Reid is an instructor of Nature Journaling. Her journey began in a 2017 California Naturalist certification course where a nature journal was required. She taught herself how to draw and journal using the John Muir Laws’ Guide to Drawing and Nature Journaling. After taking many online live and recorded workshops from John Muir Laws’, attending week-long retreats with him and other nature journal instructors, and participating in the annual Wild Wonder Nature Journaling Conference, Sarah began teaching Nature Journaling in 2023." (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

3. **REJECTED** — https://www.kqed.org/science/1991709/the-best-places-to-go-tide-pooling-in-the-bay-area
   - Actual page: Top Tide Pooling Spots in the Bay Area | KQED (fetch: fetched, HTTP 200)
   - Exactness: `exact-name-but-non-catch-context`; source class: `secondary-guide-or-program-document`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page identifies the location only for tidepooling, tides, education, or a regional guide; any species claims are ecological/regional and not an exact-site catch report.

4. **REJECTED** — https://www.instagram.com/reel/DFvWy_0xPfh/
   - Actual page: environerd 🐚 Katie Shore on Instagram: "Beach Spotlight: 📍 Leo Carrillo State Beach, Malibu, CA

Features: 1.5 miles of sandy beach surrounded by rocky tide pools and coastal cliffs, with a campground and backcountry hiking trails close by 

Wildlife: Intertidal species can be found in this beach’s plentiful tide pools, like sea anemones, sea urchins, mussels, barnacles, crabs, and more

Amenities:  Paved parking lot, public restrooms, campground with restrooms and showers, drinking fountains, RV access, and boating facilities. Dog-friendly in day-use areas, North Beach, and the campground. Park rangers offer free educational programs, including the Junior Ranger program

Accessibility: Accessible parking and restrooms are available at the beach and campground. Beach wheelchairs are available for checkout upon entry 

Best Time of Year: This beach is great year-round, however tide pooling is best during winter months when we experience king tides

Cost: Parking is $12/car each day, with hourly rates available for 3 hours and under. Campsites start at $45/night. This beach participates in the California State Parks Library Pass, where you can borrow a day-use pass for free from your local library!

#leocarrillo #castateparks #castateparkslibrarypass #beaches #stateparks #travelcalifornia #familyfriendly #travelwithkids #marinebiology #tidepools #socal #losangeles #malibu" (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

5. **REJECTED** — https://www.yelp.com/search?find_desc=Scenic+Overlook&find_loc=Dillon+Beach%2C+CA
   - Actual page: TOP 10 BEST Scenic Overlook in Dillon Beach, CA (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `secondary-web`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

6. **REJECTED** — https://www.facebook.com/groups/449587999147524/posts/1593358521437127/
   - Actual page: Bay Area Eats (dine-in / take-out) | Bay Oyster Crawl: Bodega and Tomales | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

7. **REJECTED** — https://www.stewardscr.org/pdf/2019%20OTS%20Single.pdf
   - Actual page: Community Education Programs & Volunteer Trainings (fetch: fetched, HTTP 200)
   - Exactness: `exact-name-but-non-catch-context`; source class: `secondary-guide-or-program-document`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page identifies the location only for tidepooling, tides, education, or a regional guide; any species claims are ecological/regional and not an exact-site catch report.

8. **REJECTED** — https://www.instagram.com/p/Da5PRmsFFsZ/
   - Actual page: Nature Nexus Institute on Instagram: "Beach Sketching Friday!

Big thanks to everyone who showed up to our in-person Beach Ecology Sketching Crew meet-up last Saturday! We participated in the Open Wetlands event at Ballona Wetlands Ecological Reserve, then strolled over to Dockweiler Beach to check out the intertidal zone.

What does this have to do with Snowy Plover and Least Tern conservation?
Our favorite federally-listed beach nesting birds rely on sandy beach habitat to survive. Learning about sandy beach habitat helps us see how plovers and terns are connected to the bigger ecological picture. Spending time nature sketching and journaling is a great way to boost your observation skills and connect with nature.

Are you fired up about nature sketching? Do you want to connect with others to talk about favorite paint brushes and the best snacks to take on an outdoor drawing adventure?
Then consider joining our Beach Ecology Sketching Crew this summer! We have free online and in-person opportunities. Check out the QR code on the flyer in the last slide of this post for more information, or visit the link in our bio.

There are lots of sketching groups to connect to for outings and knowledge exchange. Here are a few:
@wildwonderfoundation
@ci_nature_journalers
@naturejournal_smm
@usklosangeles

This summer we are sharing ways to enjoy, learn about, and be good stewards of our wonderful sandy beach habitat. This work is funded by a USFWS Section 6 grant in collaboration with CDFW, California State Parks, and Los Angeles Audubon Society.

#sharetheshore #sandybeachhabitat #coastalstewardship #losangelesnature #naturesketching

@la_audubon 
@LosAngelesAudubon" (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

9. **REJECTED** — https://www.instagram.com/p/B71CsX_FwoB/
   - Actual page: Stewards of Coast & Redwoods on Instagram: "Where the Russian River meets the ocean. 1.25.20 - A great place to volunteer! 707-869-9711 www.stewardscr.org.  #jennercalifornia #californiapacific #californiastateparks #californiapacific #stateparks #castateparks #sunset #stewardsofcr photo @lcar_photo" (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

10. **REJECTED** — https://www.instagram.com/p/DVZRrx_AeLk/
   - Actual page: Visit Lost Coast on Instagram: "Art meets ecology.
Story meets stewardship.
Community meets creativity.

Join SCARF (Shelter Cove Arts & Recreation Foundation) for an immersive field and studio series exploring the wildlife, landscapes, and living history of the Lost Coast.
From native birds and land mammals to salmon, redwoods, conservation history, and cultural storytelling — each class pairs hands-on art with expert guest speakers who bring deep local knowledge to the table.
This is more than an art class.
It’s a way to see this place differently.

Limited spots are available for each session. Pre-registration is encouraged.
To reserve your space:
colorsdv@gmail.com
(707) 223-4272

Stay tuned for more classes in this series!

For more information local events  go to VisitLostCoast.com

#ShelterCove #SCARF #LostCoast #CommunityArt #NatureAndArt #HumboldtCounty #FieldStudy #WatercolorWorkshop ##ShelterCove #SCARF #LostCoast #CommunityArt #NatureAndArt #HumboldtCounty #FieldStudy #WatercolorWorkshop ##conservationthroughartConservationThroughArt" (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-event-only`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Instagram post concerns another location, a survey/event, nature art, or general ecology; no exact Bay Bite spot catch with species is stated.

11. **REJECTED** — https://www.facebook.com/groups/sonomafoodies/posts/1922299758372835/
   - Actual page: Sonoma County Foodies | I am new to the area, and everyone keeps raving about the clam chowder at Spud Point, so my husband and I done some taste testing at Spud Point and Fi... | Facebook (fetch: fetched, HTTP 200)
   - Exactness: `different-location-or-name-only-in-copied-list`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Actual Facebook page is unrelated to the named Bay Bite spot or mentions it only inside copied public-pier/search boilerplate; it does not provide an attributable exact-site species catch.

12. **REJECTED** — https://tides.net/california/283/
   - Actual page: Bodega Bay Tides | Tide Charts & Tables | California Coast ... (fetch: fetched, HTTP 200)
   - Exactness: `exact-name-but-non-catch-context`; source class: `secondary-guide-or-program-document`; confidence: `none`
   - Date/season: not stated
   - Reason: Reject: page identifies the location only for tidepooling, tides, education, or a regional guide; any species claims are ecological/regional and not an exact-site catch report.

13. **REJECTED** — https://www.yelp.com/search?find_desc=Hiking&find_near=five-brooks-bodega-bay-3
   - Actual page: Best Hiking near Five Brooks in Bodega Bay, CA (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `secondary-web`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

### `schoolhouse-beach` — Schoolhouse Beach Sonoma Coast

**No leads were supplied.** No community species edge could be reviewed or accepted.

### `blind-beach` — Blind Beach Goat Rock fishing

1. **REJECTED** — https://www.reddit.com/r/sonomacounty/comments/hxspl8/blind_beach_goat_rock_fishing_sucked_today_but_no/
   - Actual page: Blind Beach (Goat Rock) fishing sucked today but no one ... - Reddit (fetch: inaccessible, HTTP 403)
   - Exactness: `none`; source class: `community-social`; confidence: `none`
   - Date/season: not stated
   - Reason: Page was inaccessible (HTTP 403); the discovery snippet is not admissible evidence and no page-body provenance could be verified.
   - Uncertainty: Could not verify body content or exact-location context.

### `shollenberger-pier` — Shollenberger Pier fishing

**No leads were supplied.** No community species edge could be reviewed or accepted.

### `drakes-beach` — Drakes Beach Point Reyes fishing

**No leads were supplied.** No community species edge could be reviewed or accepted.

### `kehoe-beach` — Kehoe Beach Point Reyes fishing

**No leads were supplied.** No community species edge could be reviewed or accepted.

### `hearts-desire-beach` — Heart's Desire Beach Tomales fishing

**No leads were supplied.** No community species edge could be reviewed or accepted.

### `chicken-ranch-beach` — Chicken Ranch Beach Tomales fishing

**No leads were supplied.** No community species edge could be reviewed or accepted.

## Boundary note

Community evidence in this review is not used to establish access, pier-license exemptions, legality, current regulations, closures, or MPA status. The accepted Point Pinole evidence is exact to the **pier within the regional shoreline** and should not be generalized to every shoreline casting location.
