# Bay Bite — remaining 21 exact-taxon science package (corrected after independent rejection)

**Analyst:** Priya Chen  
**Accountable owner / receiver:** Dr. Elias Forge  
**Checked:** 2026-08-13  
**Review deadline:** Owner review on receipt; legal sources re-fetched at evaluation  
**Machine artifact:** `/root/company/research/bay-bite-fishing-smarts/remaining-21-taxa-science.v1.json`  
**Status:** Research correction only; implementation acceptance is not claimed.

## Assignment and boundaries

- Exact question: Complete conservative exact-taxon science profiles for the remaining 21 catalog taxa.
- Scope: 21 exact taxa; per-field provenance, source-role correction, rubberlip re-verification, validation.
- Exclusions: repository changes; production/systemd/deployment; Brain writes; current-presence claims; portfolio/pricing/outreach decisions.
- Evidence standard: Official/primary first; fetched content only; per-field role-appropriate provenance; unknown when unsupported; presentation excluded from scientific coverage.
- Deliverables: this Markdown and the machine artifact above. Elias accepts/rejects.

## Exact changed counts

- `profilesWithClaimProvenanceAdded`: **21**
- `perProfileClaimFields`: **17**
- `claimObjectsAdded`: **357**
- `knownClaims`: **325**
- `unknownClaims`: **32**
- `sourceRegistryRecordsBefore`: **38**
- `sourceRegistryRecordsAfter`: **41**
- `sourceRegistryRecordsAdded`: **3**
- `sourceRecordsAssignedDistinctRoleAndFoundationStatus`: **41**
- `sourceUrlsCorrected`: **1**
- `nestedPresentationProvenanceNormalized`: **28**
- `evidenceSupportDescriptionsRoleBounded`: **48**
- `rubberlipEcologyFieldsRebasedToExactCDFWSource`: **11**
- `retainedFieldsDowngradedToUnknown`: **32**

Inaccessible/rejected: former `source:usfws-rubberlip` DTIC URL (independent direct 403; Jina maintenance/mismatch). It was removed. Direct and Jina fetches of the replacement USFWS exact-species page both returned HTTP 200 and matched Rubberlip Seaperch / Rhacochilus toxotes; it supports taxonomy only. Rubberlip ecology uses the fetched exact-species CDFW account, not family transfer.

## Fields downgraded to unknown (32)

- `species:bat-ray.legalIdentityRuleStatus`
- `species:bat-ray.localHistoricalEvidence`
- `species:black-rockfish.localHistoricalEvidence`
- `species:blue-rockfish.localHistoricalEvidence`
- `species:brown-rockfish.localHistoricalEvidence`
- `species:cabezon.localHistoricalEvidence`
- `species:channel-catfish.legalIdentityRuleStatus`
- `species:channel-catfish.localHistoricalEvidence`
- `species:jacksmelt.legalIdentityRuleStatus`
- `species:jacksmelt.localHistoricalEvidence`
- `species:kelp-greenling.localHistoricalEvidence`
- `species:kelp-greenling.season`
- `species:leopard-shark.localHistoricalEvidence`
- `species:lingcod.localHistoricalEvidence`
- `species:monkeyface-prickleback.legalIdentityRuleStatus`
- `species:monkeyface-prickleback.localHistoricalEvidence`
- `species:pacific-staghorn-sculpin.localHistoricalEvidence`
- `species:pile-perch.authorityIdentifiers`
- `species:pile-perch.localHistoricalEvidence`
- `species:pile-perch.season`
- `species:redtail-surfperch.localHistoricalEvidence`
- `species:rubberlip-seaperch.localHistoricalEvidence`
- `species:rubberlip-seaperch.season`
- `species:starry-flounder.localHistoricalEvidence`
- `species:striped-seaperch.localHistoricalEvidence`
- `species:striped-seaperch.season`
- `species:topsmelt.localHistoricalEvidence`
- `species:walleye-surfperch.localHistoricalEvidence`
- `species:white-croaker.legalIdentityRuleStatus`
- `species:white-croaker.localHistoricalEvidence`
- `species:white-sturgeon.localHistoricalEvidence`
- `species:white-sturgeon.presentation`

## Provenance contract

Every profile contains exactly 17 `claimProvenance` objects: `taxonomy`, `authorityIdentifiers`, `domain`, `environment`, `substrate`, `structure`, `salinity`, `depth`, `lifeStages`, `season`, `forage`, `feedingMode`, `vulnerabilities`, `shoreAccessibility`, `legalIdentityRuleStatus`, `localHistoricalEvidence`, `presentation`. Known = `{state:"known",value,sourceIds:[...],limitations:[...]}`; unknown = `{state:"unknown",reason,sourceIds:[]}`. Legal notices are legal-only; advisories are vulnerability/legal-caution-only; occurrence is historical-only; taxonomy metadata is identity-only. Presentation is a field heuristic outside scientific coverage.

## Exact-taxon review

### 1. Bat ray — *Myliobatis californica* (`species:bat-ray`)

- Authority identifiers: `{"NCBI": "319543"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Shallow sand/mud flats, bays, sloughs and estuary channels; recorded from surface to about 46 m."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["venomous tail spine", "population-history uncertainty"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 28, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "CDFW exact-species page reports general year-round take; live general bag, gear, MPA and place rules still gate actionability.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-bat-ray | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-bat-ray | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | unknown | — | No separately classified legal source directly supports retained text; live rule resolution remains mandatory. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-bat-ray | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 2. Black rockfish — *Sebastes melanops* (`species:black-rockfish`)

- Authority identifiers: `{"NCBI": "72085", "WoRMS": "274817"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Schools over high-relief rock, kelp, boulders and artificial reef; typically shallower than 73 m though records are deeper."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["long lived", "schooling can concentrate pressure", "barotrauma where captured deep"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 13, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Exact-species RCG identity required; current area, season/depth, bag, prohibited-species and MPA rules must be fetched at evaluation time.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-black-rockfish | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-black-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-groundfish-2026 | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-black-rockfish | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 3. Blue rockfish — *Sebastes mystinus* (`species:blue-rockfish`)

- Authority identifiers: `{"NCBI": "72088"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Schools above shallow rock and kelp; surface to about 156 m in agency profile."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["long lived", "black/blue identification confusion", "barotrauma at depth"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 1, "status": "sparse", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Exact-species RCG and current-regulation gate required; one catalog edge means narrow evidence coverage.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-blue-rockfish | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-blue-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-groundfish-2026 | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-blue-rockfish | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 4. Brown rockfish — *Sebastes auriculatus* (`species:brown-rockfish`)

- Authority identifiers: `{"WoRMS": "274773"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Nearshore rock, kelp and artificial structure; generally shallower than 53 m despite deeper records."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["long lived", "localized structure association", "barotrauma at depth"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 39, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Exact-species RCG and current area/bag/MPA gate required; pier/bay compatibility requires mapped structure.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-brown-rockfish | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-brown-rockfish | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-groundfish-2026 | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-brown-rockfish | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 5. Cabezon — *Scorpaenichthys marmoratus* (`species:cabezon`)

- Authority identifiers: `{"NCBI": "52273"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Crevices, reefs, kelp, tidepools and jetties from intertidal into deeper water."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["guarding-male removal can expose eggs", "eggs poisonous to humans", "barotrauma at depth"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 3, "status": "sparse", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Exact cabezon RCG identity; current bag/area/MPA and method rules gate use.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-cabezon | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-cabezon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-groundfish-2026 | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-cabezon | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 6. Channel catfish — *Ictalurus punctatus* (`species:channel-catfish`)

- Authority identifiers: `{"NCBI": "7998"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Deep pools, runs, backwaters and cover over sand/gravel/rock; salinity tolerance is not preference."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["fin spines", "introduced SF Estuary population context", "early stages may be salt-sensitive"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 7, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Exact waterbody and inland/ocean jurisdiction required; no current statewide species-specific rule was safely resolved.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | unknown | — | No separately classified legal source directly supports retained text; live rule resolution remains mandatory. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:smithsonian-channel-catfish, source:cdfw-catfish-monitoring | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 7. Jacksmelt — *Atherinopsis californiensis* (`species:jacksmelt`)

- Authority identifiers: `{"NCBI": "1311532", "WoRMS": "279813"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Shallow schools in bays, estuaries, sandy beaches and kelp canopy; usually about 1.5–15 m."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["schooling concentrates local harvest", "adhesive eggs use vegetation"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 59, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Jacksmelt is not topsmelt or surf smelt; exact identity, general finfish, gear, place and MPA rules require live resolution.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-jacksmelt | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-jacksmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | unknown | — | No separately classified legal source directly supports retained text; live rule resolution remains mandatory. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-jacksmelt | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 8. Kelp greenling — *Hexagrammos decagrammus* (`species:kelp-greenling`)

- Authority identifiers: `{"WoRMS": "240732"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Rocky coasts, kelp and jetties; intertidal to 149 m, more common shallower than 100 m."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["attached egg masses on rock", "identification with other greenlings"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 0, "status": "zero-edge-blocked", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Zero-edge non-recommendable. Exact greenling/RCG identity and current bag, place and MPA rules still required.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`blocked-zero-edge`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed + zero-edge blocked`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | unknown | — | Retained profile explicitly reports season/movement as unknown or unresolved. |
| `forage` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-groundfish-2026 | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-kelp-greenling, source:noaa-kelp-greenling | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 9. Leopard shark — *Triakis semifasciata* (`species:leopard-shark`)

- Authority identifiers: `{"NCBI": "30493", "WoRMS": "279060"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Shallow bay/estuary sand and nearshore sandy/kelp environments, usually near bottom."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["live-bearing life history", "aggregations concentrate pressure", "handling stress"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 3, "status": "sparse", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "CDFW SF Bay page showed 3 fish and 36-inch total-length minimum when checked; current exact place/MPA/gear rules remain mandatory.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-leopard-shark | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-leopard-shark | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-sf-bay-regs | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-leopard-shark | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 10. Lingcod — *Ophiodon elongatus* (`species:lingcod`)

- Authority identifiers: `{"NCBI": "225387"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Adults use rocky bottom and kelp; juveniles can use sand near eelgrass/kelp. Adult compatibility is structure-specific."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["nest-guarding male removal", "protected-rockfish bycatch", "barotrauma"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 32, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Separate exact lingcod groundfish rule; checked summary showed 2 fish and 22-inch minimum, subject to current area/season/MPA changes.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:noaa-lingcod, source:cdfw-lingcod | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:noaa-lingcod, source:cdfw-lingcod | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-groundfish-2026 | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:noaa-lingcod, source:cdfw-lingcod | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 11. Monkeyface prickleback — *Cebidichthys violaceus* (`species:monkeyface-prickleback`)

- Authority identifiers: `{"NCBI": "271503", "WoRMS": "280053"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Rocky crevices, boulders, algae, jetties and breakwaters; highly local residential use."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["specialized intertidal habitat", "eel-like species can be conflated"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 42, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "No special exact-species rule verified; current general finfish, intertidal collection, MPA and place rules gate use.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-monkeyface | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-monkeyface | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | unknown | — | No separately classified legal source directly supports retained text; live rule resolution remains mandatory. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-monkeyface | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 12. Pacific staghorn sculpin — *Leptocottus armatus* (`species:pacific-staghorn-sculpin`)

- Authority identifiers: `{"NCBI": "214925", "WoRMS": "254345"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Soft sandy/muddy estuaries, bays and tidal water; bottom-associated."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["early-life estuarine habitat", "common bycatch potential"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 58, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "CDFW general ocean rules list exact species among no-limit taxa when checked; special gear permissions are geographically bounded.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:ca-waterboards-staghorn | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:ca-waterboards-staghorn | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-general-ocean | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:ca-waterboards-staghorn | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 13. Pile perch — *Rhacochilus vacca* (`species:pile-perch`)

- Authority identifiers: `{"WoRMS accepted": "1577347", "accepted name": "Phanerodon vacca"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Adults around rocky shores, kelp, pilings and artificial reef; juveniles can use eelgrass/bays."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["viviparity", "low reproductive potential", "aggregation susceptibility", "taxonomy combination changed in WoRMS"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 0, "status": "zero-edge-blocked", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Zero-edge non-recommendable. Surfperch aggregate closure/bag and current place/MPA rules still apply; catalog name retained as exact identity alias.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`blocked-zero-edge`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed + zero-edge blocked`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:gbif-species-match | GBIF species-match returned EXACT and matched the canonical binomial; taxonomy only, not ecology. |
| `authorityIdentifiers` | unknown | — | No retained/re-fetched authority identifier. |
| `domain` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | unknown | — | Retained profile explicitly reports season/movement as unknown or unresolved. |
| `forage` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-pile, source:cdfw-surfperch-account | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-pile, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-sf-bay-regs | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-pile, source:cdfw-surfperch-account | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 14. Redtail surfperch — *Amphistichus rhodoterus* (`species:redtail-surfperch`)

- Authority identifiers: `{"NCBI": "72546", "WoRMS": "279596"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["High-energy open-coast sandy beaches, sandy pocket beaches and swash/trough habitat."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["viviparity", "low fecundity", "nearshore aggregations", "localized depletion risk"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 12, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Exact redtail identity: checked CDFW rule shows 10.5-inch minimum; SF/San Pablo surfperch closure and aggregate bag remain area/date gated.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-redtail | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-redtail | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-sf-bay-regs | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-redtail | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 15. Rubberlip seaperch — *Rhacochilus toxotes* (`species:rubberlip-seaperch`)

- Authority identifiers: `{"NCBI": "100202", "WoRMS": "282575"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Rocky reef/kelp, wharves, pilings and jetties; inshore waters to about 150 feet in the exact-species CDFW account."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["viviparity", "low reproductive output", "pile-perch identification confusion"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 0, "status": "zero-edge-blocked", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Zero-edge non-recommendable. Surfperch aggregate rules and current place/MPA checks required.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`blocked-zero-edge`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed + zero-edge blocked`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy, source:usfws-rubberlip | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy, source:usfws-rubberlip | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | unknown | — | Retained profile explicitly reports season/movement as unknown or unresolved. |
| `forage` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-surfperch-account | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-sf-bay-regs | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-surfperch-account | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 16. Starry flounder — *Platichthys stellatus* (`species:starry-flounder`)

- Authority identifiers: `{"NCBI": "195632", "WoRMS": "154781"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Demersal over gravel, sand and mud in ocean, bays, estuaries, river mouths and sloughs."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["estuarine habitat alteration", "bottom-trawl bycatch"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 28, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "CDFW general ocean rule listed exact starry flounder as no-limit when checked; jurisdiction, gear, place and MPA rules remain live gates.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-starry | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-starry | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-general-ocean | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-starry | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 17. Striped seaperch — *Embiotoca lateralis* (`species:striped-seaperch`)

- Authority identifiers: `{"NCBI": "229144", "WoRMS": "240740"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Shallow rocky reef, kelp and nearshore artificial structure; surface/intertidal to deeper water."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["viviparity", "low reproductive potential", "aggregation susceptibility"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 3, "status": "sparse", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Surfperch aggregate closure/bag plus current place/MPA rules; no exact minimum verified.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | unknown | — | Retained profile explicitly reports season/movement as unknown or unresolved. |
| `forage` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-striped-seaperch | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-striped-seaperch | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-sf-bay-regs | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-striped-seaperch | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 18. Topsmelt — *Atherinops affinis* (`species:topsmelt`)

- Authority identifiers: `{"NCBI": "238741", "WoRMS": "279812"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Upper-water-column schools along estuaries, shorelines, beaches, kelp and pilings; most often surface to about 9 m."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["spawning eggs attach to vegetation", "forage role", "no formal stock assessment", "SF Bay consumption concern"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 49, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "CDFW general ocean rule listed exact topsmelt as no-limit; OEHHA health advice is separate and must display for SF Bay.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-topsmelt, source:oehha-sf-bay | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-topsmelt | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-general-ocean | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-topsmelt | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 19. Walleye surfperch — *Hyperprosopon argenteum* (`species:walleye-surfperch`)

- Authority identifiers: `{"NCBI": "100192", "WoRMS": "281098"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Sandy beach, bays and shallow water near rocks/pier structure; schooling."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["viviparity", "schooling aggregation", "short life", "contaminant advisory"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 0, "status": "zero-edge-blocked", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "Zero-edge non-recommendable. Surfperch aggregate closure/bag, health advice, place and MPA rules require live resolution.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`blocked-zero-edge`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed + zero-edge blocked`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-walleye, source:cdfw-surfperch-account, source:oehha-sf-bay | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-sf-bay-regs | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-walleye, source:cdfw-surfperch-account | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 20. White croaker — *Genyonemus lineatus* (`species:white-croaker`)

- Authority identifiers: `{"NCBI": "320395", "WoRMS": "280830"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Demersal soft sand–mud habitat, sometimes sand-bottom kelp; surf zone to deeper water."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["contaminant bioaccumulation", "nearshore fishing pressure", "shallow juvenile habitat"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 8, "status": "historical-corroboration-only", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "current-rule-gated", "statement": "No dedicated special limit verified; general finfish, place and MPA rules apply. OEHHA consumption alert is independent and mandatory where applicable.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`profile-available-gates-required`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:cdfw-white-croaker, source:oehha-white-croaker | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:cdfw-white-croaker | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | unknown | — | No separately classified legal source directly supports retained text; live rule resolution remains mandatory. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | known | source:cdfw-white-croaker | Field heuristic outside scientific coverage; no causal lure-effectiveness claim. |

### 21. White sturgeon — *Acipenser transmontanus* (`species:white-sturgeon`)

- Authority identifiers: `{"NCBI": "7904", "WoRMS": "238345"}`
- Retained review fields: substrate/structure/salinity/depth/exposure=`["Large rivers, Delta and estuary channels; spawning eggs adhere to hard river substrate; feeding/residence is demersal."]`; shoreAccessibility=`Conditional on safely reachable mapped habitat; historical occurrence is not current presence.`; vulnerabilities=`["long lived", "late maturity", "infrequent female spawning", "habitat loss", "entrainment", "contaminants", "poaching", "vessel strikes", "HAB mortality"]`; localHistoricalEvidence=`{"catalogAcceptedEdgeCount": 0, "status": "zero-edge-blocked", "limitations": ["Accepted-client catalog count; not independent observations, abundance, absence, seasonality, or current presence."]}`; legalIdentityRuleStatus=`{"status": "conservation-legal-alert-first", "statement": "CONSERVATION/LEGAL ALERT FIRST. CESA candidate protections; zero-edge non-recommendable. The cited 2025–26 catch-and-release season ended June 30, 2026, so status is unresolved on checked date; no recommendation. Report card and special barbless-hook/handling rules apply when a lawful season exists.", "checkedAt": "2026-08-13", "actionable": false, "limitations": ["Must resolve exact taxon, date, area, mode, MPA, access, gear, size/retention intent and current official rule."]}`; recommendability=`blocked-zero-edge`; profileVersion=`exact-taxon-science:v1`; reviewedAt=`2026-08-13`; targetingPolicy=`fail-closed + zero-edge blocked`.
| Claim | State | Source IDs | Limitation/reason |
|---|---|---|---|
| `taxonomy` | known | source:ncbi-taxonomy, source:worms-taxonomy | Authority records verify identity only. |
| `authorityIdentifiers` | known | source:ncbi-taxonomy, source:worms-taxonomy | Identifiers re-fetched and matched to canonical name. |
| `domain` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `environment` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `substrate` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `structure` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `salinity` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `depth` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Combined reviewed text is not an atomized quantitative measurement. |
| `lifeStages` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `season` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy.; Life-history timing is not a bite window or regulation season. |
| `forage` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `feedingMode` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `vulnerabilities` | known | source:frontiers-sturgeon, source:cdfw-white-sturgeon | Biology, conservation, and advisory caution remain distinct. |
| `shoreAccessibility` | known | source:frontiers-sturgeon | Regional/species biology does not establish current local presence, abundance, catch probability, or lure efficacy. |
| `legalIdentityRuleStatus` | known | source:cdfw-white-sturgeon, source:cdfw-sturgeon-card, source:cdfw-sturgeon-opener | Time-sensitive; re-fetch at evaluation; does not support ecology. |
| `localHistoricalEvidence` | unknown | — | Accepted-edge count is retained reviewed metadata, but no independently fetched occurrence artifact directly supports the per-profile count. |
| `presentation` | unknown | — | No supported field-heuristic presentation is available. |

## Source registry

| ID | Role | Foundation status | Fetch | URL |
|---|---|---|---|---|
| `source:cdfw-bat-ray` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/bat-ray/ |
| `source:cdfw-black-rockfish` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/black-rockfish/false |
| `source:cdfw-blue-rockfish` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/blue-rockfish/false/ |
| `source:cdfw-brown-rockfish` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/brown-rockfish/false/ |
| `source:cdfw-cabezon` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/cabezon/ |
| `source:cdfw-groundfish-2026` | `legal-regulation` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://wildlife.ca.gov/Fishing/Ocean/Regulations/Groundfish-Summary |
| `source:cdfw-catfish-monitoring` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://journal.wildlife.ca.gov/2024/12/27/experimental-gillnet-study-to-inform-future-large-fish-monitoring-in-the-san-francisco-estuary/ |
| `source:smithsonian-channel-catfish` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://invasions.si.edu/nemesis/species_summary/163998 |
| `source:cdfw-jacksmelt` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/jacksmelt/true/ |
| `source:cdfw-kelp-greenling` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/kelp-greenling/ |
| `source:noaa-kelp-greenling` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://apps-afsc.fisheries.noaa.gov/ichthyo/LHDataLH.php?GSID=Hexagrammos%21decagrammus |
| `source:cdfw-leopard-shark` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/leopard-shark/false/ |
| `source:cdfw-sf-bay-regs` | `legal-regulation` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/sf-bay |
| `source:noaa-lingcod` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://www.fisheries.noaa.gov/species/lingcod |
| `source:cdfw-lingcod` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/lingcod/false/ |
| `source:cdfw-monkeyface` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://nrm.dfg.ca.gov/FileHandler.ashx?DocumentID=34299 |
| `source:ca-waterboards-staghorn` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://www.waterboards.ca.gov/centralcoast/water_issues/programs/duke_energy/docs/sampling/staghornsculpin.pdf |
| `source:cdfw-general-ocean` | `legal-regulation` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://wildlife.ca.gov/Fishing/Ocean/Regulations/Sport-Fishing/General-Ocean-Fishing-Regs |
| `source:cdfw-pile` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/pile-perch/false/ |
| `source:cdfw-surfperch-account` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://nrm.dfg.ca.gov/FileHandler.ashx?DocumentID=34362 |
| `source:cdfw-redtail` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/barred-surfperch-and-redtail-surfperch/the-species/ |
| `source:usfws-rubberlip` | `taxonomy-metadata` | `foundation` | 2026-08-13; direct+jina; HTTP 200; verified=true | https://www.fws.gov/species/rubberlip-seaperch-rhacochilus-toxotes |
| `source:cdfw-starry` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/starry-flounder/ |
| `source:cdfw-striped-seaperch` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/striped-seaperch/false/ |
| `source:cdfw-topsmelt` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/topsmelt/ |
| `source:cdfw-walleye` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/walleye-surfperch/false/ |
| `source:cdfw-white-croaker` | `biology` | `foundation` | 2026-08-13; jina; HTTP 200; verified=true | https://marinespecies.wildlife.ca.gov/white-croaker/true/ |
| `source:oehha-white-croaker` | `consumption-advisory` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://oehha.ca.gov/fish/species/white-croaker |
| `source:oehha-sf-bay` | `consumption-advisory` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://oehha.ca.gov/fish/advisories/san-francisco-bay |
| `source:cdfw-white-sturgeon` | `conservation-status` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://wildlife.ca.gov/Conservation/Fishes/Sturgeon/White-Sturgeon |
| `source:cdfw-sturgeon-card` | `legal-regulation` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://wildlife.ca.gov/Conservation/Fishes/Sturgeon/report-card |
| `source:cdfw-sturgeon-opener` | `legal-regulation` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://wildlife.ca.gov/News/Archive/white-sturgeon-opener-kicks-off-with-a-no-fee-report-card-for-this-season |
| `source:frontiers-sturgeon` | `biology` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://www.frontiersin.org/journals/marine-science/articles/10.3389/fmars.2022.859038/full |
| `source:cdfw-bay-study` | `historical-occurrence` | `supplemental-not-foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://wildlife.ca.gov/Conservation/Delta/Bay-Study |
| `source:noaa-benthic` | `biology` | `supplemental-not-foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://coast.noaa.gov/arcgis/rest/services/Hosted/san_francisco_bay_2011/FeatureServer |
| `source:obis-api` | `historical-occurrence` | `supplemental-not-foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://api.obis.org/v3/ |
| `source:gbif-api` | `historical-occurrence` | `supplemental-not-foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://techdocs.gbif.org/en/openapi/v1/occurrence |
| `source:inat-api` | `historical-occurrence` | `supplemental-not-foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://api.inaturalist.org/v1/docs/ |
| `source:gbif-species-match` | `taxonomy-metadata` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://api.gbif.org/v1/species/match?name={SCIENTIFIC_NAME} |
| `source:ncbi-taxonomy` | `taxonomy-metadata` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=taxonomy&id={NCBI_ID} |
| `source:worms-taxonomy` | `taxonomy-metadata` | `foundation` | 2026-08-13; direct; HTTP 200; verified=true | https://www.marinespecies.org/rest/AphiaRecordByAphiaID/{APHIA_ID} |

Foundation means fetched content supports an allowed retained profile claim. Bay Study, benthic map, and occurrence APIs are supplemental here because no profile-specific records were queried in this correction. Reachability alone is not claim support.

## Validation pseudocode/results

```text
assert 21 profiles and each has REQUIRED_17_FIELDS
known => nonempty resolving sourceIds and field in source.allowedClaimFields
unknown => reason and sourceIds == []
assert no legal/advisory ID in ecology
assert occurrence IDs only in localHistoricalEvidence
assert five zero-edge taxa blocked
assert white sturgeon blocked, conservation/legal-first, no presentations
assert no all-nine compatible habitat profile or prohibited positive claims
```

- `checkedAt`: `"2026-08-13"`
- `passed`: `true`
- `errors`: `[]`
- `profileCount`: `21`
- `canonicalIdNameChecks`: `21`
- `canonicalNameGbifExactMatches`: `21`
- `authorityIdentifierQueries`: `34`
- `authorityIdentifierNameMatches`: `34`
- `sourceIdResolution`: `"passed"`
- `knownClaimSourceRoleChecks`: `"passed"`
- `legalAdvisoryEcologyExclusion`: `"passed"`
- `zeroEdgeFiveBlocked`: `"passed"`
- `whiteSturgeonConservationLegalFirstNoPresentations`: `"passed"`
- `allNineHabitats`: `"none"`
- `prohibitedPositiveClaims`: `"none"`

## Verification commands

```bash
python3 -m json.tool /root/company/research/bay-bite-fishing-smarts/remaining-21-taxa-science.v1.json >/dev/null
python3 - <<'PY'
import json
p="/root/company/research/bay-bite-fishing-smarts/remaining-21-taxa-science.v1.json"; d=json.load(open(p)); r={s["id"]:s for s in d["sourceRegistryAdditions"]}; q=set(d["claimProvenanceSchema"]["requiredFields"]); assert len(d["profiles"])==21
for x in d["profiles"]:
 assert set(x["claimProvenance"])==q and len(x["habitat"]["compatible"])<9
 for f,c in x["claimProvenance"].items():
  assert (c["state"]=="unknown" and c["sourceIds"]==[] and c["reason"]) or (c["state"]=="known" and c["sourceIds"] and all(s in r and f in r[s]["allowedClaimFields"] for s in c["sourceIds"]))
z=set(d["globalGuards"]["zeroEdgeTaxa"]); assert len(z)==5 and all(x["recommendability"]=="blocked-zero-edge" and x["localHistoricalEvidence"]["catalogAcceptedEdgeCount"]==0 for x in d["profiles"] if x["id"] in z)
w=next(x for x in d["profiles"] if x["id"]=="species:white-sturgeon"); assert not w["shorePresentations"] and w["recommendability"]=="blocked-zero-edge"
print(d["validationResults"])
PY
curl -L -A 'Mozilla/5.0' -o /tmp/usfws-rubberlip.direct.html -w '%{http_code} %{size_download}\n' 'https://www.fws.gov/species/rubberlip-seaperch-rhacochilus-toxotes'
curl -L -o /tmp/usfws-rubberlip.jina.txt -w '%{http_code} %{size_download}\n' 'https://r.jina.ai/https://www.fws.gov/species/rubberlip-seaperch-rhacochilus-toxotes'
```

## Correction changelog

- Added 17 claim-specific provenance objects to all 21 profiles; unsupported claims are unknown.
- Split six source roles and added allowed-field/foundation policy.
- Removed rejected DTIC rubberlip URL; verified replacement direct and Jina; restricted it to taxonomy; exact CDFW Rubberlip section supports ecology.
- Re-fetched NCBI/WoRMS authority services: 34/34 identifier-name matches; GBIF species match: 21/21 EXACT canonical-name matches.
- Removed legal/advisory/season notices from ecology provenance; presentation remains outside scientific coverage.
- Retained all required reviewed fields and fail-closed policy.
- No repo, Brain, deploy, or systemd changes; no implementation acceptance claim.
