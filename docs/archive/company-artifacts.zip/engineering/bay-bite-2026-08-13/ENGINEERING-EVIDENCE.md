# Bay Bite Command engineering evidence — 2026-08-13

Owner: Dr. Elias Forge (CTO / Principal Engineer)  
Scope: private enrichment hardening only; no commit, push, deployment, restart, spend, contact, or publication.

## Outcome

- Preserved the pre-existing unpublished enrichment on `main` (already three commits ahead of `origin/main`).
- Added Vitest infrastructure and 8 focused tests covering spot/data invariants, species-profile coverage, `getSpotIntel`, dynamic spot count, official source URLs, and truthful telemetry states.
- Replaced the hardcoded hero count with `spotCountLabel(spots)`.
- Removed live-looking telemetry substitutions. Missing fields now render as `Unavailable`; partial feeds are `partial`, total absence is `fallback`, and the Promise chain has an explicit catch/failure transition.
- Labeled static spot conditions as a researched planning baseline, not live telemetry.
- Added directly recheckable official CDFW/NOAA source links without inventing spot-level provenance.
- Browser-checked the built private preview at desktop and 390×844 mobile sizes; no browser console or JavaScript errors were observed. Primary controls and map were visible and usable; mobile header wrapped without horizontal overflow.

## Strict TDD evidence

### Cycle 1 — data invariants and dynamic count

RED command:

```bash
cd /root/bay-bite-dashboard
npm test -- --run src/data.test.ts
```

Expected RED observed:

```text
src/data.test.ts (4 tests | 1 failed)
TypeError: spotCountLabel is not a function
Tests 1 failed | 3 passed
exit code 1
```

GREEN command/result:

```bash
npm test -- --run src/data.test.ts
```

```text
src/data.test.ts (4 tests)
Test Files 1 passed (1)
Tests 4 passed (4)
exit code 0
```

### Cycle 2 — telemetry truth states

RED command:

```bash
npm test -- --run src/telemetry.test.ts
```

Expected RED observed:

```text
src/telemetry.test.ts (3 tests | 3 failed)
TypeError: buildTelemetrySnapshot is not a function
Tests 3 failed (3)
exit code 1
```

GREEN command/result:

```bash
npm test -- --run src/telemetry.test.ts
```

```text
src/telemetry.test.ts (3 tests)
Test Files 1 passed (1)
Tests 3 passed (3)
exit code 0
```

### Cycle 3 — recheckable source URLs

RED command:

```bash
npm test -- --run src/data.test.ts
```

Expected RED observed:

```text
src/data.test.ts (5 tests | 1 failed)
TypeError: Cannot read properties of undefined (reading 'trim')
Tests 1 failed | 4 passed
exit code 1
```

GREEN command/result:

```bash
npm test -- --run src/data.test.ts
```

```text
src/data.test.ts (5 tests)
Test Files 1 passed (1)
Tests 5 passed (5)
exit code 0
```

### Cycle 4 — distinguish partial from fully live telemetry

RED command:

```bash
npm test -- --run src/telemetry.test.ts
```

Expected RED observed:

```text
AssertionError: expected 'live' to be 'partial'
Tests 1 failed | 2 passed
exit code 1
```

GREEN command/result:

```bash
npm test -- --run src/telemetry.test.ts
```

```text
src/telemetry.test.ts (3 tests)
Test Files 1 passed (1)
Tests 3 passed (3)
exit code 0
```

## Final verification

Commands:

```bash
cd /root/bay-bite-dashboard
npm test
npm run lint
npm run build
git diff --check
```

Results:

```text
npm test: 2 test files passed; 8 tests passed; exit code 0
npm run lint: Found 0 warnings and 0 errors; exit code 0
npm run build: TypeScript + Vite build passed; 2412 modules transformed; exit code 0
git diff --check: no output; exit code 0
```

Build sizes:

```text
dist/index.html                   0.57 kB │ gzip:   0.33 kB
dist/assets/index-DSu5WEAQ.css   29.69 kB │ gzip:   9.97 kB
dist/assets/index-DUu3Jpli.js   850.42 kB │ gzip: 247.00 kB
```

Known build warning: the main minified JavaScript chunk remains above Vite's 500 kB advisory threshold. This was pre-existing architectural debt and was not expanded into an unrelated code-splitting redesign.

Browser verification:

```bash
npm run preview -- --host 127.0.0.1
# Vite selected http://127.0.0.1:4174 because 4173 was already occupied.
google-chrome --headless --no-sandbox --disable-gpu --hide-scrollbars \
  --window-size=390,844 --screenshot=/tmp/bay-bite-mobile.png \
  http://127.0.0.1:4174/
```

Browser result: title `Bay Bite Command`; desktop and mobile rendered; console messages `0`; JavaScript errors `0`. The temporary preview process was terminated after verification. No existing service was restarted or stopped.

## Files changed in this hardening pass

- `/root/bay-bite-dashboard/package.json` — test command and Vitest dev dependency.
- `/root/bay-bite-dashboard/package-lock.json` — lockfile for test infrastructure.
- `/root/bay-bite-dashboard/src/data.test.ts` — data/intelligence/count/source invariants.
- `/root/bay-bite-dashboard/src/telemetry.test.ts` — unavailable/partial/invalid telemetry behavior.
- `/root/bay-bite-dashboard/src/data.ts` — dynamic count helper and official source records.
- `/root/bay-bite-dashboard/src/telemetry.ts` — pure truthful telemetry snapshot builder and partial state.
- `/root/bay-bite-dashboard/src/App.tsx` — dynamic count, explicit fetch failure path, no fabricated telemetry, truthful labels, linked sources.

Pre-existing unpublished modifications preserved and still present include `/root/bay-bite-dashboard/PRODUCT_BACKLOG.md`, `/root/bay-bite-dashboard/src/App.css`, `/root/bay-bite-dashboard/vite.config.ts`, `/root/bay-bite-dashboard/public/data/`, and `/root/bay-bite-dashboard/scripts/`, plus the earlier enrichment portions of `src/App.tsx`, `src/data.ts`, and `package.json`.

## Git evidence

Exact captured status: `/root/company/engineering/bay-bite-2026-08-13/git-status.txt`  
Tracked diff snapshot: `/root/company/engineering/bay-bite-2026-08-13/git-diff.patch`

Captured status:

```text
## main...origin/main [ahead 3]
 M PRODUCT_BACKLOG.md
 M package-lock.json
 M package.json
 M src/App.css
 M src/App.tsx
 M src/data.ts
 M src/telemetry.ts
 M vite.config.ts
?? public/data/
?? scripts/
?? src/data.test.ts
?? src/telemetry.test.ts
```

Snapshot checksums at capture time:

```text
ee76d12fdefdf08bb9ac147ac691e17b6d6a9b5daabb2cedb4734be8e1bb6497  git-diff.patch
4b12fb96a76205773fd429f5523e1b0829d45944157a843d95e43887daf59945  git-status.txt
```

Note: `git-diff.patch` is the exact tracked-file diff. Untracked artifacts are represented by the exact status and remain in place; nothing was staged or committed.

## Residual risks / handoff gates

1. Nora's independent reconciliation remains required before Arthur claims readiness.
2. Spot-level `sourceNote` values are still descriptive legacy provenance. The source panel now links official recheck targets, but a full per-claim citation matrix would require a separate evidence audit and was intentionally not fabricated.
3. `public/data/live-status.json` is a generated cache from the earlier pass. Its age/status must be interpreted as cache metadata; the UI's selected-spot telemetry still fetches direct upstream feeds and labels missing readings honestly.
4. Static bite scores, daily report, tide chart, species momentum, and spot condition baselines remain researched/mock-scored prototype guidance, not live observations; the footer and conditions label disclose this.
5. The 850.42 kB JS chunk warning remains.
6. No commit was created because the repository already contains valuable mixed unpublished work and no practice required committing this private pass. No push or deployment occurred.

## Local corroboration wording correction — 2026-08-13T17:09:40-04:00

- Scope: presentation wording/test only; no deploy, reset, clean, systemd, commit, or push action.
- TDD RED: `npm test -- --run src/presentation.test.mjs` failed as expected, 1 failed / 12 passed, because the bounded paragraph was absent.
- Correction: `src/App.tsx` now says the reviewed query returned nearby records but does **not** establish a spot-level historical pattern, occurrence prior, current presence, absence, abundance, seasonality, or legality; every displayed legacy evidence edge is labeled `reviewed local corroboration only`.
- Regression: `src/presentation.test.mjs` asserts the exact bounded wording/label and rejects the former historical-pattern and confidence/evidence-type presentation.
- Focused GREEN: 13/13 passed.
- Full gates: `npm test` 11 files / 100 tests passed; `npm run lint` 0 warnings / 0 errors; `npm run build` passed with 2,421 modules; `git diff --check` passed.
- Build retained the existing nonblocking chunk-size advisory: main JS 1,679.41 kB minified / 300.27 kB gzip.
- Independent narrow review: PASS; no findings and no reviewer edits.
- Files changed by this correction: `/root/bay-bite-dashboard/src/App.tsx`, `/root/bay-bite-dashboard/src/presentation.test.mjs`, and this report.
