# Bay Bite remediation evidence — 2026-08-13

## Canonical original disposition

Nora's restored original report is `/root/company/operations/bay-bite-2026-08-13/INDEPENDENT-QA.md` with disposition **REJECT** and blockers BBC-QA-01/02/03.

## BBC-QA-01 — trusted click

Root cause was QA automation targeting an offscreen ref, not application behavior. At `scrollY=0`, the Ocean Beach button was at y=4511–4610 while viewport height was 577; hit-testing at the attempted viewport point returned `.hero-overlay`. After `scrollIntoView`, fresh snapshot/ref, and ordinary `browser_click` (no DOM `.click()`), selected heading and `.spot-card.selected` both changed to Ocean Beach.

Evidence: `/root/company/operations/bay-bite-2026-08-13/TRUSTED-CLICK-EXCEPTION-ANALYSIS.md`.

## BBC-QA-02 — Pacifica effective date

Structured owner warning now states `Pacifica Municipal Pier — closed since June 4, 2026`, checked 2026-08-13, with the City of Pacifica URL. Regression test asserts the date wording.

## BBC-QA-03 — static/model truth hierarchy

Point-of-display labels now include:

- `Sample fishing outlook · not a live forecast` in the hero;
- `Sample captain outlook`;
- `Sample peak window` and `model score`;
- `Model-ranked region`;
- `Sample species momentum` plus `Model percentages for planning only — not current observations`;
- map popup `Model score` and `Sample window`;
- ranked cards `Model N`;
- chart titles/series labeled sample/model.

A presentation source-regression test covers these labels.

## BBC-QA-04 — confidence overclaim

`Officially listed` inferred from any CDFW mention was removed. The model now distinguishes `Owner-listed access`, `Multi-source guidance`, and `Field pattern`. Linda Mar cannot receive blanket official confidence from a broad regional CDFW mention.

## Deck White hardening

Although the restored canonical report says Deck White remained legible, the theme was strengthened with opaque white hero/card surfaces, explicit dark foreground colors, high-contrast pills/ghost controls/search placeholders, and bounded warning colors. The presentation test protects core high-glare selectors.

## Final gate

```text
npm test: 3 files, 12 tests passed
npm run lint: 0 warnings, 0 errors
npm run build: passed, 2412 modules
Vite advisory: 852.37 kB main JS chunk (>500 kB)
git diff --check: passed
```

## Sealed candidate

- Diff: `/root/company/engineering/bay-bite-2026-08-13/final/git-diff-remediated.patch`
- Diff SHA-256: `94e4edc5a96d3652c003c2e71d23a1c813771b1f540fc6d54b900e7c81c4315a`
- Status: `/root/company/engineering/bay-bite-2026-08-13/final/git-status-remediated.txt`
- Status SHA-256: `af08e7ed4224326af8735bea9c14d754270e1dd6f4bb661df42258546ba3387c`

## Boundaries

No commit, push, deployment, production restart, publication, contact, spending, or Shared Brain update occurred during remediation.
