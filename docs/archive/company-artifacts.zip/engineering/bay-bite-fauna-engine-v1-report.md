# Bay Bite fauna engine v1 remediation report

Date: 2026-08-13
Owner: Dr. Elias Forge, CTO / Principal Engineer
Repository: `/root/bay-bite-dashboard`
Status: local implementation verified; no deployment performed or authorized

## Objective

Remediate owner-review defects in the exact-taxon fauna vertical slice without resetting or altering accepted unrelated work. Keep historical occurrence, ecological compatibility, condition completeness, legal/access/MPA targetability, shore presentation, and confidence distinct.

## Decisions and behavior

- Renamed the client overlay contract and active UI from habitat/occurrence wording to `OccurrenceEvidenceOverlay` / `occurrenceEvidenceOverlays` and the exact button label `Show occurrence evidence overlays`. Circles are labeled as historical occurrence areas and explicitly are not habitat polygons or live fish locations.
- Legacy aggregate `Surfperch` remains unsupported as `species:surfperch` unless the selected spot has an exact `species:barred-surfperch` evidence edge. Exact evidence displays `Barred surfperch`; family-level legality is not reused.
- Added multidimensional confidence coverage for occurrence evidence, habitat evidence geometry, condition evidence, and legal/access/MPA certainty. Client habitat geometry is absent, so confidence remains low even with grade-A occurrence.
- Added `missingInputs` and `confidenceReasons`. Missing or stale current/wave/wind/clarity/light, absent habitat geometry, and unresolved access/legal/MPA inputs are explicit.
- Ecological factors, exact-taxon biology, forage, habitat nuance, and factor contributions remain visible when targeting fails closed. `not-targetable` results always have empty presentations.
- Scientific JSON export now uses a narrow allow-listed selected-water object and scientific opportunity results; it does not export legacy `score`, `bestWindow`, `biteReason`, or `tactics` fields.
- Removed active selected-water legacy tactics, mock-score footer language, and static field-playbook presentation from the active UI.
- Fixed the pre-existing future-dated dynamic-rule gate exposed by the required full suite: a dynamic legal snapshot from the future now fails closed.
- Added requested `catalog:check` and `client:check` npm script aliases.

## Focused changed files

- `/root/bay-bite-dashboard/src/fishing-smarts/fauna-opportunity.ts`
- `/root/bay-bite-dashboard/src/fishing-smarts/fauna-opportunity.test.ts`
- `/root/bay-bite-dashboard/src/fishing-smarts/selected-water-opportunity.ts`
- `/root/bay-bite-dashboard/src/fishing-smarts/selected-water-opportunity.test.ts`
- `/root/bay-bite-dashboard/src/fishing-smarts/index.ts`
- `/root/bay-bite-dashboard/src/App.tsx`
- `/root/bay-bite-dashboard/src/presentation.test.mjs`
- `/root/bay-bite-dashboard/package.json`

The worktree already contained broad accepted changes before this remediation; they were not reset, cleaned, checked out, or attributed to this focused pass.

## TDD evidence

### Primary remediation RED

Command:

`npm test -- --run src/fishing-smarts/fauna-opportunity.test.ts src/fishing-smarts/selected-water-opportunity.test.ts src/presentation.test.mjs`

Observed RED: 9 failed, 18 passed. Expected failures covered missing confidence coverage/reasons/inputs, aggregate Surfperch incorrectly mapped as barred, old habitat-overlay exports/UI wording, unsafe full-spot export, and absent export helper.

### Primary remediation GREEN

Same focused command after implementation:

- 3 test files passed
- 27 tests passed
- exit 0

### Independent review finding RED/GREEN

Independent review found omitted optional `clarity` and `light` could be treated as complete coverage. Added a focused regression test.

RED command:

`npm test -- --run src/fishing-smarts/fauna-opportunity.test.ts -t "reports omitted optional clarity and light"`

Observed: 1 failed, 9 skipped; condition coverage was incorrectly `complete`.

GREEN command after the minimal fix:

`npm test -- --run src/fishing-smarts/fauna-opportunity.test.ts -t "reports omitted optional clarity and light"`

Observed: 1 passed, 9 skipped; exit 0.

### Full-suite defect

The first required full-suite run found one pre-existing failing acceptance test: future-dated dynamic legal snapshots returned open. The test already served as RED. After the narrow `isStale` fix:

`npm test -- --run src/fishing-smarts/eligibility.test.ts`

Observed: 10 passed; exit 0.

## Final verification

- `npm test -- --run` — PASS: 11 files, 98 tests passed.
- `npm run catalog:check` — PASS: 101 accepted, 30 excluded, 25 sensors, 520 accepted edges.
- `npm run client:check` — PASS: built client has 101 accepted spots; all 30 excluded IDs and names absent.
- `npm run lint` — PASS: 0 warnings, 0 errors across 30 files / 104 rules.
- `npm run build` — PASS: TypeScript and Vite build completed; 2,421 modules transformed. Output JS 1,676.24 kB (299.90 kB gzip). Vite emitted a non-blocking >500 kB chunk warning.
- `git diff --check` — PASS: no whitespace errors.
- Independent review — acceptance checks passed except one omitted-optional-input finding; that finding was reproduced RED, fixed, and verified GREEN as documented above.

## Remaining gaps and risk

- Science coverage is limited to three exact taxa: striped bass, California halibut, and barred surfperch.
- Real NOAA CMECS benthic habitat polygons and CARI geometry are not client-integrated. Catalog habitat labels are ecological context, not mapped habitat evidence.
- Bay Study / deltafish derivatives are not yet client-integrated.
- Exact MPA geometry remains unresolved, so targeting fails closed and presentations remain empty in the active UI.
- Real telemetry lacks current, clarity, and light inputs; no opportunity band/score or presentation is fabricated.
- The production bundle is large (approximately 1.68 MB minified JS); this is a performance follow-up, not a correctness gate failure.

## Deployment statement

No deployment, publication, service restart, systemd change, `/srv` change, timer change, gateway change, immutable-seal change, repository push, or production-system action was performed.

## Focused Deck White accessibility follow-up — 2026-08-13

### Objective and scope

Correct the Deck White favorite-star foreground reported by live QA at `rgb(208, 214, 224)` on white (1.46:1), and give Leaflet attribution links explicit readable Deck White colors. This pass changed only `src/App.css`, `src/presentation.test.mjs`, and this report. It did not reset/clean the worktree, deploy, touch systemd, or alter unrelated files.

### TDD RED evidence

1. Command: `npm test -- --run src/presentation.test.mjs -t "gives the Deck White favorite control explicit dark foregrounds in every state"`
   Result: expected RED; 1 failed, 11 skipped, exit 1. The missing `.deck-white .favorite-button` explicit dark foreground assertion failed.
2. Command: `npm test -- --run src/presentation.test.mjs -t "gives Deck White Leaflet attribution links an explicit dark foreground"`
   Result: expected RED; 1 failed, 12 skipped, exit 1. The missing `.deck-white .leaflet-control-attribution a` explicit foreground assertion failed.

### Minimal implementation

- Deck White favorite default: `#334155` on `#f8fafc`.
- Favorite hover: `#0f172a` on `#e2e8f0`.
- Favorite focus-visible: explicit `#0f172a`.
- Favorite active/selected: `#713f12` on `#fef3c7` with `#a16207` border.
- Deck White Leaflet attribution links: `#075985`; hover/focus-visible: `#0c4a6e`.

### GREEN and quality-gate evidence

- Command: `npm test -- --run src/presentation.test.mjs -t "Deck White favorite control|Deck White Leaflet attribution"`
  Result: PASS; 2 passed, 11 skipped, exit 0.
- Command: `npm test -- --run`
  Result: PASS; 11 test files and 100 tests passed, exit 0.
- Command: `npm run lint`
  Result: PASS; 0 warnings and 0 errors across 30 files / 104 rules, exit 0.
- Command: `npm run build`
  Result: PASS; TypeScript and Vite completed, 2,421 modules transformed, exit 0. Output: CSS 34.83 kB (11.08 kB gzip), JS 1,676.24 kB (299.90 kB gzip). Existing non-blocking Vite warning remains for a chunk over 500 kB.
- Command: `git diff --check`
  Result: PASS; no output, exit 0.
- Command:
  `python3 - <<'PY'` with the WCAG relative-luminance formula for the five declared foreground/background pairs.
  Result: `#334155` on `#f8fafc` 9.90:1; `#0f172a` on `#e2e8f0` 14.48:1; `#713f12` on `#fef3c7` 7.79:1; `#075985` on white 7.56:1; `#0c4a6e` on white 9.46:1. All exceed 4.5:1.

### Independent review

Independent review recommendation: PASS, no blocking or substantive accessibility findings. Review verified the requested default/hover/focus/active favorite states, default/hover/focus Leaflet attribution states, contrast pairs, and focused CSS scope. Non-blocking observation: the static tests assert explicit known-good declarations rather than calculating contrast dynamically; the separate reproducible luminance command above verifies the declared pairs.

### Status

Focused local accessibility fix verified. No deployment, reset, clean, systemd action, publication, or repository push was performed.

## Final provenance-boundary remediation — 2026-08-13

### Certification defects addressed

- Generic `telemetryFromBindings` normalization no longer issues trusted telemetry identity.
- `ingestLiveStatusCache(raw: unknown)` validates the schema-v4 envelope, dates, product kinds, station/product identity, numeric fields, and source structure, then freezes and registers only the exact ingested cache object. This is a closed-module structural boundary, not cryptographic authentication of upstream NOAA bytes.
- Reviewed condition production obtains spot sensor bindings internally from the research catalog. Direct caches, copied issued caches, arbitrary telemetry, generic-normalizer output, copied snapshots, station-ID mismatch, and stale/invalid products fail closed.
- Exact-taxon science, nested presentation templates and claim provenance, and the scientific source registry are recursively frozen.
- Legal and safety modules export no scenario-specific issuers and no generic safe-footing or condition-signing helpers.
- The fixed `scenario:crissy-striped-validation-v1` calibration path now invokes the same private `evaluateOpportunityCore` as production through a non-exported symbol capability and exact object identity. The public scenario API accepts only that fixed ID and no caller fields.
- The scenario is explicitly NON-LIVE and proves evaluator reachability only. It is not evidence of real Crissy Field occurrence, current conditions, current legality, safety, or a fishing opportunity.
- Production selected-water behavior remains fail-closed because there is no production safe-footing issuer and unresolved MPA/current/clarity/light inputs suppress presentations.
- README now states that legacy static score/window/reason/tactics fields are inactive compatibility data, not active model output.

### TDD and adversarial evidence

- RED: forged bound-station telemetry could previously mint trusted favorable wave/wind conditions; mutable taxon science accepted nested runtime mutation; no closed positive evaluator path existed.
- Intermediate review rejected a public generic normalizer that issued trust and exported scenario safety/legal issuers. Those APIs were removed before sealing.
- Intermediate review also rejected a hand-assembled positive `OpportunityResult`; the fixture was moved into `fauna-opportunity.ts` and now traverses the same non-exported evaluator core as production.
- Focused final command: `npm test -- --run src/fishing-smarts/trust-boundary.test.ts src/fishing-smarts/reviewed-scenario.test.ts src/fishing-smarts/fauna-opportunity.test.ts src/fishing-smarts/selected-water-opportunity.test.ts src/telemetry.test.ts` — PASS: 5 files, 47 tests.
- Full suite: `npm test -- --run` — PASS: 13 files, 117 tests.
- `npm run catalog:check` — PASS: 101 accepted, 30 excluded, 25 sensors, 520 accepted edges.
- `npm run client:check` — PASS: 101 accepted spots; all 30 excluded IDs and names absent.
- `npm run lint` — PASS: 0 warnings and 0 errors across 35 files / 104 rules.
- `npm run build` — PASS: 2,423 modules transformed; existing non-blocking large-chunk warning remains (1,690.35 kB JS, 303.13 kB gzip).
- `git diff --check` — PASS.

### Remaining scope limits

- Only striped bass, California halibut, and barred surfperch have exact-taxon executable profiles; unsupported taxa fail closed without family fallback.
- The positive calibration fixture is synthetic/reviewed test evidence, not production fish-distribution or safety evidence.
- Real effort-aware survey derivatives, mapped habitat intersections, exact MPA geometry, trusted shore inspections, local current/clarity/light products, and full taxon expansion remain future data-engineering work.
- No deployment, publication, production restart, systemd/timer change, `/srv` write, commit, or push was performed.

## Prototype-safe cache and immutable binding policy — 2026-08-13

A subsequent immutable review rejected the prior seal because frozen cache objects could still resolve mutable inherited product data and because exported research spot/sensor policy remained mutable. The rejected seal was preserved and not deployed.

### Remediation

- Live-status ingestion now reads own property descriptors, rejects accessors without executing getters, rejects inherited required fields, symbol keys, prototype-pollution keys, sparse arrays, and custom array prototypes, and applies strict field allowlists.
- Ingestion constructs a new null-prototype canonical graph containing only validated own primitive data, recursively freezes it, and issues identity only to that detached graph. Caller records and prototypes are never issued.
- Research catalog data is canonicalized into a recursively frozen graph at module initialization. Spot records, sensor bindings, sensor definitions, evidence, sources, and nested arrays are immutable at runtime.
- Mutable exported `Map` indexes were replaced with read-only lookup functions backed by private maps.
- Reviewed telemetry still obtains spot bindings internally; public mutation attempts cannot redirect sensor policy or source attribution.

### Adversarial and quality evidence

- Regression tests reproduce inherited-field, accessor/getter, symbol, pollution-key, sparse-array, custom-array-prototype, nested-product-prototype, binding-redirection, and sensor-source mutation attacks.
- Focused attack suite — PASS: 4 files, 34 tests.
- Full suite: `npm test -- --run` — PASS: 13 files, 124 tests.
- `npm run catalog:check` — PASS: 101 accepted, 30 excluded, 25 sensors, 520 accepted edges.
- `npm run client:check` — PASS: 101 accepted spots; all 30 excluded IDs and names absent.
- `npm run lint` — PASS: 0 warnings and 0 errors across 35 files / 104 rules.
- `npm run build` — PASS: 2,423 modules transformed; existing non-blocking large-chunk warning remains (1,694.79 kB JS, 304.63 kB gzip).
- `git diff --check` — PASS.

The boundary remains structural/module identity rather than cryptographic upstream authentication. Production delivery must continue protecting the same-origin cache producer and transport.
