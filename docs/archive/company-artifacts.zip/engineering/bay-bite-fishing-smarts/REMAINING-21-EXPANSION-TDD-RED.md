# Remaining 21 exact-taxon expansion — strict TDD RED contract

**Owner:** Dr. Elias Forge, CTO / Principal Engineer  
**Prepared:** 2026-08-13  
**Repository:** `/root/bay-bite-dashboard`  
**Disposition:** RED CONTRACT PREPARED — implementation and biological/source content intentionally not added  
**Scope boundary:** tests and a minimal test helper only. No production biology, source registry records, deployment, reset, clean, commit, push, Brain, systemd, `/srv`, or seal action.

## Objective

Lock the implementation acceptance contract for expanding `exactTaxonScience` from the existing three exact taxa to the 24 exact canonical taxa in `researchCatalog.species`, while keeping unsupported science unknown and all legal, occurrence, safety, source, immutability, and production-boundary controls fail closed.

The RED prerequisite is centralized so every expansion behavior test stops on the same factual deficit: `exactTaxonScience` currently has 3 canonical records and is missing exactly the remaining 21. This prevents downstream assertions from producing misleading secondary failures before profile existence is implemented.

## Test artifacts

- `/root/bay-bite-dashboard/src/fishing-smarts/exact-taxon-expansion.contract-helper.ts`
  - derives canonical IDs/names and the nine habitat IDs from the immutable generated research catalog;
  - fixes the five zero-edge taxon IDs from the accepted research audit;
  - exposes one prerequisite assertion with actual count, missing IDs, and extra IDs;
  - provides only recursive-freeze and fail-closed input helpers.
- `/root/bay-bite-dashboard/src/fishing-smarts/exact-taxon-science-expansion.test.ts`
  - exact 24 IDs and canonical common/scientific names;
  - no aggregate taxonomy;
  - recursive immutability;
  - evidence and known-claim citations resolve to the immutable scientific source registry;
  - explicit nonempty compatible and incompatible habitat sets, no overlap, only canonical habitat IDs, and never all nine compatible;
  - explicit `known` or `unknown` state for domain, environment, substrate, structure, salinity, depth, forage, season, and presentation;
  - no magic 61F, barometric, solunar, 40–80 Hz, aggregate, or guaranteed-bite language.
- `/root/bay-bite-dashboard/src/fishing-smarts/exact-taxon-evaluator-expansion.test.ts`
  - all 24 profiles are recognized without unsupported condition inference;
  - five zero-edge taxa remain occurrence-blocked and non-presentable despite profile existence;
  - white sturgeon is conservation/legal-alert-first;
  - exact legal decisions do not inherit aggregate family rule IDs;
  - deep mutation cannot alter evaluator results.
- `/root/bay-bite-dashboard/src/fishing-smarts/exact-taxon-ui-boundary-expansion.test.ts`
  - selected-water projection retains each exact catalog evidence taxon and its canonical label rather than collapsing it to an aggregate UI label.
- `/root/bay-bite-dashboard/src/fishing-smarts/exact-taxon-production-boundary-expansion.test.mjs`
  - production `App.tsx` and selected-water adapter do not import or invoke `reviewed-scenario`/`evaluateReviewedScenario`;
  - the certification-only module remains the explicit reviewed-scenario export boundary.

## Observed focused RED

Command:

```text
npx vitest run src/fishing-smarts/exact-taxon-science-expansion.test.ts src/fishing-smarts/exact-taxon-evaluator-expansion.test.ts src/fishing-smarts/exact-taxon-ui-boundary-expansion.test.ts src/fishing-smarts/exact-taxon-production-boundary-expansion.test.mjs --reporter=verbose
```

Observed result:

```text
Test Files  3 failed | 1 passed (4)
Tests       12 failed | 1 passed (13)
Exit code   1
```

The independent production dependency-boundary test passed. Every one of the 12 expansion failures stopped at the same prerequisite assertion:

```text
exactTaxonScience expansion prerequisite: RED must be caused only by the 21 canonical profiles not implemented yet
actualCount: 3
extra: []
```

Exact missing IDs reported by Vitest:

1. `species:bat-ray`
2. `species:black-rockfish`
3. `species:blue-rockfish`
4. `species:brown-rockfish`
5. `species:cabezon`
6. `species:channel-catfish`
7. `species:jacksmelt`
8. `species:kelp-greenling`
9. `species:leopard-shark`
10. `species:lingcod`
11. `species:monkeyface-prickleback`
12. `species:pacific-staghorn-sculpin`
13. `species:pile-perch`
14. `species:redtail-surfperch`
15. `species:rubberlip-seaperch`
16. `species:starry-flounder`
17. `species:striped-seaperch`
18. `species:topsmelt`
19. `species:walleye-surfperch`
20. `species:white-croaker`
21. `species:white-sturgeon`

No extra profile ID, test setup error, import error, syntax error, or unrelated behavioral failure was observed in the focused RED run.

## Existing-suite preservation evidence

Baseline before adding the RED contract:

```text
npm test -- --run --reporter=dot
Test Files  13 passed (13)
Tests       124 passed (124)
Exit code   0
```

Explicit unaffected-suite run after adding the RED files (excluding only the four new contract test files):

```text
npx vitest run src/data.test.ts src/popup-content.test.ts src/presentation.test.mjs src/telemetry.test.ts src/fishing-smarts/fauna-opportunity.test.ts src/fishing-smarts/selected-water-opportunity.test.ts src/fishing-smarts/research-catalog.test.ts src/fishing-smarts/schema.test.ts src/fishing-smarts/reviewed-scenario.test.ts src/fishing-smarts/eligibility.test.ts src/fishing-smarts/trust-boundary.test.ts scripts/update-live-data.test.mjs scripts/generate-research-catalog.test.mjs --reporter=dot
Test Files  13 passed (13)
Tests       124 passed (124)
Exit code   0
```

Additional static gates:

```text
npm run lint
Found 0 warnings and 0 errors.
Exit code 0

git diff --check
(no output)
Exit code 0
```

The ordinary unfiltered `npm test` is now expected to be RED until the 21 profiles and their reviewed evidence contracts are implemented. The original 124 tests were not edited or weakened.

## Implementation acceptance contract

GREEN is not achieved merely by adding 21 object keys. An implementation is accepted only when all new and existing tests pass and the following are true:

1. `exactTaxonScience` contains exactly the 24 IDs in `researchCatalog.species`; no missing or extra IDs.
2. Every common and scientific name exactly matches the canonical research catalog; no `spp.`, family, complex, or aggregate identity enters science, evaluator, legality, or presentation logic.
3. Every profile and every nested array/object is recursively immutable.
4. Every evidence citation resolves to a record in the recursively immutable `scientificSourceRegistry`.
5. Every known claim has one or more claim-appropriate source IDs; unsupported claims are explicit `unknown` with a reason and no invented value.
6. Each profile declares at least one compatible and one incompatible canonical habitat, with no overlap and no all-nine compatibility claim.
7. Domain, environment, substrate, structure, salinity, depth, forage, season, and presentation are each explicit known/unknown claims rather than implicit prose assumptions.
8. No profile or generated recommendation contains magic 61F, causal barometric/solunar language, 40–80 Hz claims, aggregate taxonomy, guaranteed-bite language, or equivalent spelling variants covered by the tests.
9. Kelp greenling, pile perch, rubberlip seaperch, walleye surfperch, and white sturgeon remain occurrence-missing, non-scored, and non-presentable until qualifying exact evidence exists.
10. White sturgeon explicitly uses `targetingPolicy: 'conservation-legal-alert-first'`; its fail-closed output communicates conservation/legal-alert status and never becomes a target presentation from profile existence alone.
11. Legal evaluation for an exact taxon cannot match or inherit an aggregate family/complex rule. Missing exact legal mapping remains unknown/non-actionable.
12. Selected-water projection derives exact taxa from canonical catalog evidence and displays canonical exact common names; aggregate `Spot.species` labels cannot erase exact identity.
13. Missing, stale, unmodeled, or unsupported condition factors remain `unknown`; they cannot generate an opportunity band or presentation.
14. Production `App.tsx` and selected-water code remain independent of the reviewed synthetic certification scenario.
15. Attempted deep mutation of every profile throws and cannot alter repeated evaluator output.
16. The existing 124 tests, all new expansion tests, lint, build/typecheck, catalog/client-boundary checks, and `git diff --check` must pass before implementation can be called complete.
17. Production biology and source records must be supplied from reviewed, claim-appropriate evidence; passing by invented placeholder biology or fabricated source records violates this contract even if structurally green.
18. Because eventual implementation will be multi-file scientific/data-handling work, independent code/science review is required before acceptance. No deployment or publication is implied.

## Current status

Verified RED contract only. Biological profiles and source records for the remaining 21 taxa are deliberately **not implemented** and therefore **not verified**. No deployment or publication action occurred.
