# Bay Bite Local-Fauna Behavior Engine — Audit and Build Specification

**Architecture/audit role:** Dr. Elias Forge  
**Audit date:** 2026-08-13  
**Application inspected (read-only):** `/root/bay-bite-dashboard`  
**Accepted immutable baseline:** `/root/bay-bite-dashboard-sealed-20260813-1537`  
**Scope:** scientific behavior, data contracts, evaluation, migration, and UI integration. This document does **not** authorize changes to application, production, Brain, or systemd.

## 0. Executive decision

Bay Bite has a strong provenance and fail-closed legal/access foundation, but it does **not** yet have a behavior engine. Its visible `score`, `bestWindow`, bite curve, region comparison, `biteReason`, species filters, “what to throw first,” and much of the species playbook are static, index-derived, aggregate-label-driven, or generic. Live observations are displayed beside the model rather than consumed by it. The normalized 101-spot/24-taxon/9-habitat/520-edge catalog is used for spot identity, access, telemetry bindings, tactics, and evidence disclosure, but a second 22-profile/66-rule science/legal dataset uses different taxon IDs and is not joined to those exact 24 taxa.

**Build decision:** introduce a pure, versioned, uncertainty-aware engine behind a new `evaluateCellTaxonWindow()` contract. It must return intervals/classes and explanation traces—not an unexplained 0–100 “bite score.” Legal, access, exact-geometry, safety, and local-evidence gates remain independent hard gates. Ecological suitability and lure ranking may never override them.

**Recommended first vertical slice:** `species:striped-bass` at one exact inner-Bay spot/cell, using tide/current, light, temperature availability, local evidence, access, and exact legal geometry. It exercises migratory behavior, forage, moving-water response, live-data uncertainty, lure/presentation ranking, and every hard gate without the aggregate-identification hazards of “Rockfish,” “Surfperch,” or “Flounder/Sole.” Ship it in shadow mode with no replacement of current UI ranking until backtesting and calibration gates pass.

---

## 1. Audited inventory

### 1.1 Canonical research catalog

`src/fishing-smarts/generated/research-catalog.v2.json`, generated from `scripts/data/spot-catalog-100-v2.source.json`:

| Collection | Client artifact | Canonical source |
|---|---:|---:|
| Accepted/client spots | 101 | 131 candidates; 101 accepted, 30 rejected/pending |
| Sources | 210 | 247 |
| Exact taxa | 24 | 24 |
| Habitats | 9 | 9 |
| Regulatory areas | 13 | 13 |
| MPA records | 1 | 1 |
| Sensors | 25 | 25 |
| Spot–taxon evidence edges | 520 | 553 total; 520 accepted-client |

Generator enforcement is valuable: global stable-ID uniqueness, referential integrity, exact accepted/excluded counts, ≥2 evidence edges per accepted spot, MPA point-screen state, sensor references, and no ocean-wave sensor on inland environments. The built-client boundary also excludes all 30 rejected IDs/names.

### 1.2 Exact taxon IDs that the engine must preserve

These IDs—not UI aggregates—are the behavior-engine identity set:

1. `species:barred-surfperch` — *Amphistichus argenteus*
2. `species:bat-ray` — *Myliobatis californica*
3. `species:black-rockfish` — *Sebastes melanops*
4. `species:blue-rockfish` — *Sebastes mystinus*
5. `species:brown-rockfish` — *Sebastes auriculatus*
6. `species:cabezon` — *Scorpaenichthys marmoratus*
7. `species:california-halibut` — *Paralichthys californicus*
8. `species:channel-catfish` — *Ictalurus punctatus*
9. `species:jacksmelt` — *Atherinopsis californiensis*
10. `species:kelp-greenling` — *Hexagrammos decagrammus*
11. `species:leopard-shark` — *Triakis semifasciata*
12. `species:lingcod` — *Ophiodon elongatus*
13. `species:monkeyface-prickleback` — *Cebidichthys violaceus*
14. `species:pacific-staghorn-sculpin` — *Leptocottus armatus*
15. `species:pile-perch` — *Rhacochilus vacca*
16. `species:redtail-surfperch` — *Amphistichus rhodoterus*
17. `species:rubberlip-seaperch` — *Rhacochilus toxotes*
18. `species:starry-flounder` — *Platichthys stellatus*
19. `species:striped-bass` — *Morone saxatilis*
20. `species:striped-seaperch` — *Embiotoca lateralis*
21. `species:topsmelt` — *Atherinops affinis*
22. `species:walleye-surfperch` — *Hyperprosopon argenteum*
23. `species:white-croaker` — *Genyonemus lineatus*
24. `species:white-sturgeon` — *Acipenser transmontanus*

Current UI projection collapses these into 17 labels. Several mappings are biologically or legally unsafe: `species:channel-catfish` and `species:pacific-staghorn-sculpin` become `Flounder/Sole`; `species:monkeyface-prickleback` becomes `Greenling`; six exact surfperches and three exact rockfish become family/genus labels. Filters, profiles, legality, and lure advice therefore lose exact identity.

### 1.3 Habitat IDs

Current exact IDs are:

- `habitat:surf`
- `habitat:pier`
- `habitat:jetty`
- `habitat:breakwater`
- `habitat:bay-shore`
- `habitat:rocky-shore`
- `habitat:tidal-slough`
- `habitat:estuary`
- `habitat:estuary-mouth`

These are access/form categories, not sufficient ecological habitat. Every one of the 24 taxa currently lists all nine as compatible—only **one compatibility signature exists**—so habitat compatibility cannot discriminate suitability. Substrate, depth, salinity, cover, exposure, bathymetric edge, vegetation, structure, and hydrodynamic zone must be normalized separately.

### 1.4 Evidence inventory

Accepted 520 edges:

- 456 `community-research-grade-observations-within-5km`
- 44 `open-biodiversity-occurrences-within-5km`
- 20 `reviewed-secondary-exact-spot-catch-pattern`
- confidence: 434 medium, 86 low, **0 high**
- 500 edges have 5 km radius and observation count; 20 have neither
- 2–9 edges per spot
- no edge exposes event date, sampling protocol, effort, coordinate uncertainty, basis of record, occurrence status, or raw record IDs

The UI correctly labels these as historical local corroboration, not current presence. However, a species-count endpoint aggregated inside 5 km is not a historical density surface and cannot support abundance, phenology, catch rate, or absence. Taxon-specific effort and detectability are unknown.

### 1.5 Separate regulations/science dataset

`regulations-science-data.ts` contains 22 biological profiles, 66 species×area rules, and 3 areas. It has useful official-source ownership checks, freshness, MPA dependency, statuses, identification caveats, and fail-closed evaluation. But:

- its 22 IDs are a different taxonomy (`species:surfperch`, `species:rockfish`, `species:flatfish`, etc.);
- it has no spot records or evidence edges;
- only a hand-written mapping joins 17 UI labels to those IDs;
- its biology is prose, not parameterized response data;
- area assignment is region/set heuristics rather than polygon resolution;
- `currentSpotLegality()` forces `fishingMode: 'shore'` even for piers/jetties;
- MPA geometry is deliberately unresolved, making all displayed targets non-actionable;
- `rankableSpeciesForSpot()` is hardwired to return none because `actionable` and `livePresenceVerified` are always false.

The fail-closed outcome is correct. The contracts need convergence, not weakening.

---

## 2. Quantified algorithm/UI audit

### 2.1 Static or generic behavior

| Output | Current derivation | Quantified result | Scientific status |
|---|---|---:|---|
| Spot `score` | `50 + (index % 21)` because `legacyById` is empty | all 101 spots; only 21 values (50–70), repeated 4–5× | arbitrary ordering, not a model |
| `bestWindow` | fixed fallback string | 101/101: “Verify same-day tide…” | no computed window |
| `biteReason` | physical-profile summary | 101/101 | place description, not condition response |
| `conditions` | fixed “Use locality binding…” placeholders | 101/101 projected records | telemetry not consumed by suitability |
| tide/bite graph | `tideSeries` literal 9 points | same curve for every spot/species/day | sample fiction |
| daily report | literal prose/top pick | global static object | not generated from observations |
| species momentum | six literal scores/trends | static | no historical comparison |
| region score graph | mean of arbitrary spot indices | all regions | pseudo-comparison |
| “What to throw first” | first matching aggregate label | six branches | ignores conditions/tackle and exact taxon |
| species profiles | 17 aggregate prose records | shared globally | generic; disconnected from exact 24 taxa |
| spot intel | union first five rigs / first six baits | deterministic prose aggregation | no ranking or constraints |
| map | markers + clustering only | 101 points | no habitat/suitability/uncertainty overlay |
| filters | region, aggregate species, mode, text | exact taxa absent | biology, legal state, conditions not filterable |

`App.tsx` reads legacy/projection fields directly: eight score references, three best-window references, one bite-reason reference, one tactics reference, twelve species references, and four condition references. The normalized catalog is therefore bypassed for the product’s central claims even though it supplies the spot list.

### 2.2 Existing strengths to retain

- deterministic accepted-only generator and source/client separation;
- stable namespaced IDs and referential-integrity checks;
- access/license boundaries and owner jurisdiction;
- exact catalog-point MPA warning;
- per-metric telemetry bindings, distance, representativeness, and TTL;
- explicit inland wave unavailability;
- observed-vs-forecast labels and cache freshness semantics;
- fail-closed legal resolver and evidence/habitat gate tests;
- truthful evidence disclosure;
- DOM-safe popup construction.

### 2.3 Current verification status

Read-only test run: **75 passed, 2 failed (77 total)**. Both failures are in `src/telemetry.test.ts`: fixtures omit an explicit `currentNow`, so their 2026 observations are rejected by the implementation’s invocation-clock/TTL policy in the 2026-08-13 audit environment. This is not an engine failure introduced by this audit; no application files were changed. Because `npm test` failed, the chained catalog/client checks did not execute in that command, although catalog structure was independently inspected.

---

## 3. Scientific product contract

### 3.1 Product semantics

The engine predicts **relative ecological opportunity conditional on available evidence**, not fish presence, catch probability, or legal permission. Public labels:

- `unsupported` — missing essential taxon/cell model or incompatible domain;
- `low`, `typical`, `elevated` — calibrated ordinal opportunity classes;
- optional interval `suitabilityRange: [lo, hi]` on 0–1 internal scale;
- never display a percentage as “chance of bite” without a catch/effort dataset and validated probabilistic calibration.

A “window” is a contiguous interval where conservative suitability exceeds a calibrated class threshold and all hard gates remain passable. If uncertainty is too large, return “insufficient evidence,” not a narrow clock time.

### 3.2 Versioned entities and TypeScript contracts

```ts
type TaxonId = `species:${string}`;
type CellId = `cell:h3:${number}:${string}`;
type SourceId = `source:${string}`;
type ObservationId = `observation:${string}`;
type FeatureId = `feature:${string}`;
type EvidenceId = `evidence:${string}`;
type ModelVersion = `behavior-model:${string}`;

type Knowledge<T> =
  | { state: 'known'; value: T; uncertainty?: Uncertainty; provenance: ProvenanceRef[] }
  | { state: 'unknown'; reason: UnknownReason; required?: boolean }
  | { state: 'not-applicable'; reason: string };

type Uncertainty =
  | { kind: 'interval'; lower: number; upper: number; unit: string; coverage?: number }
  | { kind: 'sd'; value: number; unit: string }
  | { kind: 'class'; value: 'low'|'medium'|'high'; method: string };

type UnknownReason =
  | 'not-observed'|'stale'|'unsupported-product'|'outside-domain'
  | 'geometry-unresolved'|'source-failed'|'insufficient-evidence'
  | 'taxon-unresolved'|'unit-unresolved';

interface ProvenanceRef {
  sourceId: SourceId;
  recordId?: string;
  retrievedAt: string;
  observedAt?: string;
  method?: string;
  license?: string;
  transformationIds: string[];
}
```

#### Exact species behavior profile

```ts
interface TaxonBehaviorProfileV1 {
  id: TaxonId; scientificName: string; acceptedTaxonKey?: string;
  lifeStages: Array<{
    id: 'juvenile'|'subadult'|'adult'|'spawning-adult'|'unknown';
    activeMonths: Knowledge<MonthWeight[]>;
    movement: Knowledge<Array<{
      season: MonthRange; fromZoneIds: string[]; toZoneIds: string[];
      cueIds: string[]; directionConfidence: 'low'|'medium'|'high';
    }>>;
    depthM: ResponseCurve;
    temperatureC: ResponseCurve;
    salinityPsu: ResponseCurve;
    flowMs: ResponseCurve;
    turbidityNtu: ResponseCurve;
    lightLux: ResponseCurve;
    substrateWeights: Record<SubstrateClass, WeightWithEvidence>;
    structureWeights: Record<StructureClass, WeightWithEvidence>;
    forage: Array<{ preyTaxonId?: TaxonId; preyGuildId?: string; sizeMm?: Range; weight: number; evidence: ProvenanceRef[] }>;
    sensory: {
      vision: SensoryResponse; olfaction: SensoryResponse;
      vibration: SensoryResponse; benthicContact: SensoryResponse;
    };
    diel: Knowledge<Array<{ solarPhase: SolarPhase; weight: number }>>;
    tidalPhase: Knowledge<Array<{ phase: TidalPhase; weight: number }>>;
    vulnerabilities: string[];
  }>;
  responseInteractions: Array<{
    featureIds: string[]; function: 'min'|'product'|'lookup2d'|'monotone-spline';
    parameters: number[]; evidence: ProvenanceRef[];
  }>;
  domain: { regionIds: string[]; environmentClasses: string[] };
  reviewedAt: string; profileVersion: string;
}

interface ResponseCurve {
  kind: 'piecewise-linear'|'monotone-spline'|'categorical'|'unknown';
  points?: Array<{ x: number; suitability: number }>;
  unit: string; extrapolation: 'clamp'|'unknown';
  uncertainty: Uncertainty; evidence: ProvenanceRef[];
}
```

Profiles must use explicit unknowns. A prose statement such as “cool temperate” cannot become a numeric optimum without cited data. Life-stage inference defaults to `unknown`; the engine marginalizes over plausible stages rather than pretending age is observed.

#### Spot cells and features

Use the spot point only for access/UI selection. Model water as cells and features:

```ts
interface SpotCellV1 {
  id: CellId; h3Resolution: number; h3Index: string;
  geometry: GeoJSON.Polygon;
  waterFraction: number;
  reachableFromSpotIds: `spot:${string}`[];
  castingAccess: Knowledge<{
    minDistanceM: number; maxDistanceM: number;
    bearingRangesDeg: Array<[number, number]>;
  }>;
  geography: {
    environmentClass: string; managementAreaIds: string[]; mpaIds: string[];
    shorelineSegmentIds: string[]; hydrologicZoneId?: string;
  };
  staticFeatures: {
    depthM: Knowledge<DistributionSummary>;
    depthGradient: Knowledge<DistributionSummary>;
    substrate: Knowledge<Array<{ class: SubstrateClass; fraction: number }>>;
    structure: Knowledge<Array<{ class: StructureClass; fraction: number }>>;
    vegetation: Knowledge<Array<{ class: string; fraction: number }>>;
    exposure: Knowledge<'sheltered'|'moderate'|'exposed'>;
    distanceToChannelM: Knowledge<number>;
    distanceToFreshwaterM: Knowledge<number>;
  };
  featureVersion: string; validFrom: string; validTo?: string;
}
```

Recommended starting H3 resolution must be selected empirically against shoreline complexity and casting footprint; do not claim the hexagon itself is ecological truth. Preserve exact access polygons/lines separately from H3. H3 is an indexing/aggregation aid, while authoritative legal and shoreline geometry stays GeoJSON.

#### Condition observations

```ts
interface ConditionObservationV1 {
  id: ObservationId;
  phenomenon: 'water-level'|'tide-phase'|'current-speed'|'current-direction'
    |'wave-height'|'wave-period'|'wind-speed'|'wind-direction'
    |'water-temperature'|'salinity'|'turbidity'|'light'|'precipitation';
  result: Knowledge<{ value: number; unit: UCUMUnit }>;
  phenomenonTime: string; resultTime: string;
  validTime?: [string, string];
  sourceFeatureId: string;
  targetCellIds: CellId[];
  representativeness: 'exact-site'|'local'|'regional'|'proxy'|'not-representative';
  distanceKm?: number;
  interpolation?: { method: string; parameters: Record<string, number>; crossValidationError?: number };
  quality: { flags: string[]; detectionLimit?: number; uncertainty: Uncertainty };
  provenance: ProvenanceRef[];
  expiresAt: string;
}
```

Use UCUM-compatible units internally; convert only at presentation. Forecasts, observations, climatology, and editorial priors are distinct `sourceFeatureId`/provenance classes and never silently substitute for one another.

### 3.3 Hard gates

Evaluate before ranking and preserve each result independently:

```ts
interface GateResult {
  gate: 'access'|'legal'|'geometry'|'safety'|'local-evidence'|'model-domain';
  status: 'pass'|'fail'|'unknown'|'not-applicable';
  reasons: string[]; provenance: ProvenanceRef[];
}
```

1. **Access:** exact fishing unit open at evaluation time; mode-specific boundary known.
2. **Legal:** exact taxon, mode, method, gear, date, area, MPA, notice, size/retention intent all resolved. Only verified fresh `open` passes target ranking.
3. **Geometry:** cell-to-area/MPA and angler access-to-cell relation resolved.
4. **Safety:** explicit hard-stop rules (closed facility, hazardous swell/period/exposure combination, severe weather, no retreat route). Unknown safety-critical observations produce unknown/non-actionable.
5. **Local evidence:** exact taxon edge with accepted provenance and compatible ecological features. Regional possibility alone fails.
6. **Model domain:** profile and calibration domain cover taxon, environment, season, and feature range.

`actionable = every(requiredGate.status === 'pass')`. No weighted score can compensate for a failed or unknown hard gate.

### 3.4 Suitability components and formula

For taxon `s`, life stage `l`, cell `c`, and time window `t`, calculate component responses in `[0,1]`:

- `H`: static habitat/substrate/structure/depth suitability
- `M`: seasonal/life-stage movement prior
- `F`: forage support
- `Y`: hydrodynamics (tide/current/wave relative to habitat)
- `T`: temperature/salinity physiology
- `V`: sensory opportunity (light/turbidity/scent/vibration)
- `O`: historical occurrence support, effort-qualified

Never sum missing components as zero. For each Monte Carlo draw `k` from observation/profile uncertainty:

```text
logit(S_k) = β0[s,l,region]
           + βH·logit(clamp(H_k))
           + βM·logit(clamp(M_k))
           + βF·logit(clamp(F_k))
           + βY·logit(clamp(Y_k))
           + βT·logit(clamp(T_k))
           + βV·logit(clamp(V_k))
           + βO·logit(clamp(O_k))
           + approved interaction terms
```

Where `clamp(x) = min(0.99, max(0.01, x))`. Coefficients are fitted only after outcome data exists. **Bootstrap mode** before fitting uses a transparent weighted geometric mean over known components:

```text
S_k = exp( Σ(i in known) w_i log(max(ε, C_i,k)) / Σ(i in known) w_i )
coverage = Σ(i in known) w_i / Σ(i in required)
```

Rules:

- return `unsupported` if any taxon-required component is unknown or `coverage < 0.70`;
- otherwise return median and 10th–90th percentile from draws;
- class is based on the conservative 10th percentile and calibration thresholds;
- never show more than two significant digits internally in traces or more resolution than source uncertainty supports;
- rank across candidates only when model version, domain, gate policy, and coverage are comparable.

**No product-facing “83% bite chance.”** Until calibrated catch/non-catch effort data exists, expose only ordinal class, interval, coverage, and evidence quality.

### 3.5 Unknown propagation

- Unknown is not neutral and not zero.
- Required stale/missing telemetry makes the dependent component unknown.
- Proxy observations widen uncertainty according to validated interpolation error; absent validation, proxy use cannot improve the conservative class.
- Conflicting sources form a mixture/interval and add a conflict flag.
- Taxon aggregate selection returns `taxon-unresolved`; it never averages species with different rules/behavior.
- Life stage unknown is marginalized using documented seasonal priors; if priors are absent, stage-sensitive outputs are unsupported.
- Historical non-detection never becomes absence unless sampling effort/detectability supports it.

### 3.6 Window generation

1. Evaluate fixed 15-minute bins over a maximum 48-hour forecast horizon.
2. Apply gates per bin; split on any gate transition or data-validity boundary.
3. Smooth only with a documented 3-bin median for display; preserve raw bins in trace.
4. A candidate window requires ≥4 contiguous bins (one hour), conservative class `elevated`, coverage ≥0.70, and no required unknown gate.
5. Merge windows separated by one bin only if causes and gate states match.
6. Report rounded local times and a range (e.g., “about 06:30–08:00”), plus the dominant drivers and caveat. Do not report minute-level precision unsupported by forecast cadence.

### 3.7 Lure and presentation ranking

Separate **ecological fit** from **angler feasibility** and **legal gear compliance**.

```ts
interface TackleConstraints {
  fishingMode: 'shore'|'pier'|'jetty'|'boat';
  rodPower?: 'ultralight'|'light'|'medium'|'medium-heavy'|'heavy';
  lineLb?: Range; maxCastingWeightOz?: number; maxLureWeightOz?: number;
  availableLureIds: `lure:${string}`[];
  baitAllowed: boolean; liveBaitAvailable: boolean;
  skill?: 'novice'|'intermediate'|'advanced';
  mobility?: 'fixed'|'limited'|'mobile';
}

interface PresentationCandidate {
  lureId: `lure:${string}`; presentationId: `presentation:${string}`;
  targetTaxonId: TaxonId; preyMimicIds: string[];
  depthEnvelopeM: Range; substrateRisk: SubstrateClass[];
  sensorySignature: { visual: number; vibration: number; scent: number; silhouette: number };
  flowEnvelopeMs: Range; turbidityEnvelopeNtu?: Range; lightEnvelopeLux?: Range;
  temperatureNotes?: string; tackleRequirements: TackleConstraints;
  legalMethodIds: string[];
}
```

Score candidate `p` only after legal/method and tackle feasibility pass:

```text
R(p) = GM(
  prey_match,
  depth_access,
  substrate_snag_fit,
  turbidity_sensory_fit,
  light_sensory_fit,
  flow_control,
  temperature_presentation_fit,
  tackle_feasibility
)
```

Each term is `[0,1]`, uncertainty-aware, and normalized over known terms with the same ≥0.70 coverage rule. Hard reject if lure weight exceeds tackle, depth cannot be reached, bait/method is illegal, substrate snag risk exceeds configured safety threshold, or presentation requires unavailable live bait. Return top 3 with “why,” “how,” and “switch trigger”; ties within uncertainty are displayed as co-equal, not artificially ordered.

Examples of trace logic—not fixed advice:

- turbid/low-light + olfactory/vibration-oriented taxon → scent or stronger vibration gains relative fit;
- clear/bright + visually hunting taxon → natural profile/color and subtler action;
- strong flow → presentation requiring bottom contact must have controllable sink rate/weight within rod constraints;
- rocky substrate → snag-resistant single-hook presentation outranks multi-hook bottom drag;
- prey size/identity controls silhouette and retrieve, not brand names.

### 3.8 Explanation trace

Every response is reproducible:

```ts
interface BehaviorEvaluationV1 {
  evaluationId: string; modelVersion: ModelVersion; schemaVersion: 1;
  requestedAt: string; taxonId: TaxonId; cellId: CellId; interval: [string,string];
  gates: GateResult[];
  suitability: {
    status: 'supported'|'unsupported'; class?: 'low'|'typical'|'elevated';
    range?: [number,number]; coverage: number;
    components: Array<{
      id: 'habitat'|'movement'|'forage'|'hydrodynamics'|'physiology'|'sensory'|'occurrence';
      state: Knowledge<number>; weight: number; contributionRange?: [number,number];
    }>;
  };
  presentationRanking: Array<{
    lureId: string; presentationId: string; rankClass: 'top'|'alternative'|'not-feasible';
    range?: [number,number]; reasons: string[]; switchTriggers: string[];
  }>;
  trace: Array<{
    step: string; inputs: Array<{ id: string; value: unknown; provenance: ProvenanceRef[] }>;
    operation: string; output: unknown; warnings: string[];
  }>;
  caveats: string[];
}
```

Persist evaluation input hashes, model/profile/data versions, and source snapshot IDs. Explanations are generated from trace codes/templates, never free-form claims detached from calculations.

---

## 4. Geospatial overlays and occurrence history

### 4.1 Overlay API

```http
GET /api/v1/behavior/tiles/{modelVersion}/{taxonId}/{z}/{x}/{y}.mvt?at=...&scenario=...
GET /api/v1/behavior/cells/{cellId}?taxonId=...&at=...
POST /api/v1/behavior/evaluations
GET /api/v1/occurrence/tiles/{taxonId}/{z}/{x}/{y}.mvt?from=...&to=...
```

Layers:

1. reachable water cells;
2. static habitat features;
3. taxon suitability class and coverage hatch;
4. uncertainty (separate alpha/hatch, never hidden in color);
5. access/legal/safety masks;
6. telemetry footprint and representativeness;
7. historical occurrence density;
8. source/evidence inspection points where license permits.

Use vector tiles for display, GeoJSON for exchange/debug, and authoritative polygons for gate decisions. Never infer legal status from rendered tile pixels.

### 4.2 Historical occurrence density

Store Darwin Core-compatible event/occurrence fields: `scientificName`, accepted taxon ID/key, `basisOfRecord`, `eventDate`, `decimalLatitude`, `decimalLongitude`, `coordinateUncertaintyInMeters`, `occurrenceStatus`, `individualCount`, `samplingProtocol`, `samplingEffort`, `datasetKey`, `institutionCode`, and record ID.[3]

Two products only:

- **effort-standardized occurrence index** where positive and sampling-effort data permit it;
- **presence-only observation intensity** otherwise, explicitly labeled as observer/reporting intensity—not abundance or probability of presence.

For effort-qualified cell/time stratum:

```text
encounter_rate = detections / valid_effort_units
smoothed_rate = (detections + α_region,taxon) / (effort + β_region,taxon)
```

Publish posterior/bootstrapped interval, event count, effort, observer/source diversity, date range, coordinate-uncertainty exclusions, and spatial bandwidth. Presence-only density uses adaptive KDE or cell counts with spatial thinning; it must show record count and sampling-bias caveat and must not be called catch rate. Never interpret zero records as absence.

---

## 5. Reuse standards/libraries before custom code

| Need | Adopt | Decision |
|---|---|---|
| Geometry interchange | GeoJSON RFC 7946[1] | canonical API/debug geometry; WGS84 longitude/latitude order |
| Spatial indexing | H3 / `h3-js`[5] | candidate water-cell index and aggregation; not legal geometry |
| Browser geoprocessing | Turf.js modular functions[6] | point-in-polygon, distance, intersection QA; avoid custom spherical math |
| Feature service | OGC API Features[7] | collection/query shape for cells/features where a service is introduced |
| Observation model | OGC SensorThings API concepts[2] | align Thing/Location/ObservedProperty/Datastream/Observation/FeatureOfInterest semantics |
| Biodiversity occurrence | Darwin Core[3] | occurrence/event/effort vocabulary and upstream mappings |
| Provenance | W3C PROV-O concepts[4] | Entity/Activity/Agent lineage, lightweight JSON projection in runtime |
| Validation | JSON Schema 2020-12[8] + generated TS types | authoritative data boundary; reject unknown versions |
| Units | UCUM | machine units and conversion registry; no string parsing of display values |
| Offline geospatial ETL | GDAL/OGR + PROJ; DuckDB spatial or PostGIS | reproducible ingest/reprojection/spatial joins; use PostGIS if multi-user service, DuckDB for build artifacts |
| Vector tiles | Tippecanoe for static artifacts or PostGIS `ST_AsMVT` for service | benchmark artifact size/update cadence before choosing |
| Statistical calibration | Python `pandas`/`numpy`/`scikit-learn`, optionally PyMC for hierarchical uncertainty | offline fit/export only; deterministic TS inference artifact |

Do not add a custom GIS kernel, home-grown projection, hand-coded point-in-polygon, bespoke occurrence vocabulary, or ad-hoc provenance strings.

---

## 6. APIs and package boundaries

```text
src/fishing-smarts-v2/
  contracts/          # generated TS types + JSON Schemas
  gates/              # access/legal/geometry/safety/evidence/domain
  behavior/           # response curves, components, uncertainty propagation
  presentations/      # lure catalog, constraints, ranking
  explanations/       # trace codes -> truthful UI text
  adapters/           # research catalog, telemetry cache, legal dataset
  selectors/          # UI-facing view models only
  fixtures/           # invented neutral test fixtures
scripts/behavior-etl/ # offline cell/occurrence/model artifact generation
```

Pure API:

```ts
evaluateBehavior(
  request: BehaviorRequestV1,
  snapshot: BehaviorSnapshotV1
): BehaviorEvaluationV1;

evaluateWindows(
  request: WindowRequestV1,
  snapshots: BehaviorSnapshotV1[]
): WindowEvaluationV1;

rankPresentations(
  context: PresentationContextV1,
  candidates: PresentationCandidate[]
): PresentationRankingV1;
```

No function reads wall clock, network, DOM, or mutable globals. `at`, snapshot times, model/data versions, and tackle constraints are explicit inputs.

---

## 7. TDD vertical slices

### Slice 0 — contract convergence

**RED:** JSON Schema rejects aggregate taxon IDs, missing provenance, unknown units, duplicate IDs, broken refs, implicit unknowns, invalid uncertainty intervals, and all-nine-habitat blanket compatibility.  
**GREEN:** exact 24-taxon crosswalk and v2 schemas; adapters remain read-only.  
**Acceptance:** existing 101 spots and 520 edges preserved; no application ranking changes.

### Slice 1 — striped bass / one inner-Bay cell (recommended first)

**Fixtures:** invented cell, exact `species:striped-bass`, fresh tide/current, known low light, unknown temperature, local medium evidence, exact open access/legal geometry, two lure candidates, explicit tackle.  
**RED tests:**

1. closed/unknown legal or access gate suppresses actionability;
2. stale current cannot silently become neutral;
3. missing optional temperature widens interval and lowers coverage;
4. missing required movement profile returns unsupported;
5. moving-water response changes hydrodynamic component monotonically within declared curve;
6. lure exceeding rod/cast constraints is rejected;
7. rocky snag risk changes presentation order but not taxon suitability;
8. same inputs produce byte-stable trace/hash;
9. removing local evidence fails only evidence gate and preserves ecological result;
10. no response string says “chance,” “guaranteed,” or an unsupported exact minute.

**GREEN:** pure evaluator + trace + shadow JSON output.  
**UI:** developer-only comparison card; current score remains untouched.

### Slice 2 — windows and telemetry uncertainty

- 15-minute bins, freshness boundaries, gaps, proxy widening, DST/timezone, tide/current phase;
- conservative class and rounded interval;
- telemetry TTL fixture must pass explicit `currentNow` to prevent current test ambiguity.

### Slice 3 — exact-taxon filters and legal mode

- exact species facets; family group is browse-only and requires selection before retain/target advice;
- pier/jetty/shore mode must reach legal resolver unchanged;
- map selection, list, export, and detail use one selector/gate output.

### Slice 4 — geospatial cell overlay

- H3 indexing vs authoritative polygon tests;
- land/water fraction, cast reach, MPA/area polygon crossing, antimeridian/order validation;
- vector-tile properties preserve class/coverage/model version; pixel color never drives gates.

### Slice 5 — occurrence history

- Darwin Core ingest, duplicate/source record identity, coordinate uncertainty, event time, effort class;
- presence-only data cannot emit encounter rate;
- zero records cannot emit absence;
- spatially blocked train/test splits.

### Slice 6 — presentation ranker

- prey/depth/substrate/turbidity/light/flow/temperature/tackle components;
- legal gear and feasibility hard rejects;
- uncertainty ties displayed co-equally;
- switch triggers from trace.

### Slice 7 — calibrated replacement

Only after offline gates pass: replace static tide graph, score ordering, daily report, region comparison, and trip-plan branch one surface at a time behind feature flags. Each replacement has rollback and parity instrumentation.

---

## 8. Migration strategy

1. **Freeze semantics, not files:** retain existing catalog generator and legal fail-closed behavior.
2. **Introduce v2 contracts alongside v1:** no required-field blast across current UI.
3. **Build exact taxon crosswalk:** 24 research taxa → exact legal profiles/rules. No misleading aggregate fallback. Missing exact legal record remains unknown.
4. **Parameterize profiles:** migrate prose into evidence-linked response curves only where sources justify them; preserve prose as notes.
5. **Generate cells/features offline:** version artifact and validate geometry/source lineage.
6. **Adapt telemetry:** numeric canonical observations, UCUM units, uncertainty and provenance; keep existing display adapter.
7. **Shadow evaluate:** log no user identifiers; compare engine output to current static surfaces without changing ranking.
8. **Backtest/calibrate:** taxon/season/environment holdouts; publish model card.
9. **Canary UI:** one taxon/spot, explicit “experimental ecological opportunity.”
10. **Remove legacy fields only after consumers are zero:** `score`, `bestWindow`, `tideSeries.bite`, `speciesMomentum`, `dailyReport`, aggregate trip-plan branches.

Migration invariants:

- accepted catalog count stays 101 unless a separately reviewed research change says otherwise;
- source catalog’s 30 exclusions never enter client;
- 520 evidence edges are retained with new raw-record/event metadata added, not invented;
- safety/legal/access never regress from fail-closed;
- generated artifacts are byte-checkable;
- no automatic job writes editorial biology from unreviewed text.

---

## 9. Calibration and offline evaluation

### 9.1 Required outcome data

A real probabilistic catch model requires trip-level effort records: exact/blurred cell, start/end, method/presentation, taxon targeted, detections/catches including zero-catch trips, angler/session effort, environmental snapshot, data source, and consent/privacy classification. Opportunistic occurrence-only records cannot calibrate “bite chance.”

### 9.2 Splits

- leave-location-cluster-out spatial CV;
- leave-season/year-out temporal CV;
- source/observer-group holdout;
- taxon and environment strata;
- no same event/source duplicates across train/test;
- final untouched prospective period.

### 9.3 Metrics

For probabilistic encounter models (only when valid outcomes exist):

- log loss and Brier score;
- calibration intercept/slope, reliability diagram, expected calibration error with bin uncertainty;
- PR-AUC for rare positives; ROC-AUC only as secondary;
- top-k recall/nDCG for ranking;
- coverage and abstention rate;
- false-actionable rate under legal/access/safety/evidence gates (target: **0**);
- subgroup calibration by taxon, environment, season, source, and confidence;
- interval coverage (e.g., empirical coverage of 80% intervals).

For bootstrap ordinal suitability:

- expert blind pairwise concordance with confidence intervals;
- rank stability under uncertainty perturbation;
- monotonicity/property tests for declared response curves;
- abstention/coverage by taxon and environment;
- retrospective event capture without interpreting non-events as absences.

### 9.4 Baselines and promotion gates

Compare against:

1. climatological taxon×month×region prior;
2. habitat-only model;
3. tide/light heuristic;
4. current arbitrary index score (expected to have no scientific utility, retained as a regression comparator only).

Promotion requires: no gate leakage; improved held-out proper score/ranking over baseline; acceptable calibration; stable spatial/temporal performance; documented data leakage audit; model card; reproducible artifact; and human review of explanations. Do not promote on AUC alone.

---

## 10. UI specification

### Map

- exact-taxon selector with scientific name;
- time slider and “now/forecast/climatology” source mode;
- toggles: ecological opportunity, uncertainty, reachable cells, habitat, occurrence history, legal/access/safety masks, telemetry footprint;
- cells hatched when coverage/uncertainty is poor; gray for unsupported;
- legend names classes, model version, and timestamp;
- tap cell → components, gates, source times, and caveats.

### Spot detail

Replace one blended “model score” with:

1. **Can I fish/target this?** independent access, legal, safety, geometry, evidence gates;
2. **Ecological opportunity:** class + interval + coverage, never percent;
3. **Why:** top positive/negative/unknown components;
4. **When:** rounded windows and data-validity horizon;
5. **What to throw:** top/co-equal presentations, tackle feasibility, switch trigger;
6. **Evidence:** historical records/date/effort/uncertainty caveat;
7. **Observations:** numeric values, provenance, age, representativeness.

### Filters and graphs

- filters: exact taxon, life stage only if known/modelled, habitat/substrate, environment, legal/access state, safety, coverage, data freshness, tackle constraints;
- graphs: taxon/cell-specific time series with median band + 10–90% interval and gaps for unsupported bins;
- region chart: remove until comparable calibrated metrics exist; never average arbitrary indices;
- occurrence graph: counts/effort and date range; label reporting bias;
- export full trace/version/provenance, not only score/window strings.

### Language guardrails

Use “ecological opportunity,” “evidence supports,” “model coverage,” and “historical observations.” Avoid “fish are here,” “best spot,” “guaranteed,” “83% bite,” and exact clock precision unsupported by source cadence.

---

## 11. Acceptance checklist

- [ ] Exact 24 taxon IDs are end-to-end identities; no aggregate enters engine/legal/lure computation.
- [ ] Taxon compatibility differs by ecological feature and is source-backed.
- [ ] Life stage, season, movement, forage, sensory response, habitat response, and vulnerability are explicit/unknown—not buried prose.
- [ ] Cells carry geometry, reachability, depth, substrate, structure, hydrology, and versioned provenance.
- [ ] Every observation has phenomenon/result time, unit, uncertainty, TTL, source, representativeness, and transformation lineage.
- [ ] Hard gates are independent and fail closed.
- [ ] Unknown is never converted to zero/neutral.
- [ ] Suitability reports class, interval, coverage, version, and trace; no pseudo-probability.
- [ ] Lure ranking uses prey, depth, substrate, turbidity, light, flow, temperature, and tackle constraints.
- [ ] Historical density distinguishes presence-only intensity from effort-standardized encounter rate.
- [ ] Spatial/temporal/source-blocked backtests and calibration metrics are published.
- [ ] Map/list/detail/export consume one tested selector.
- [ ] Static score/window/curve/report surfaces are removed only after calibrated replacements pass.
- [ ] Full test, schema, artifact freshness, lint, typecheck/build, client-boundary, and geospatial QA gates pass.

---

## 12. Recommended first slice, concretely

Implement **shadow-only striped bass evaluation** for one inner-Bay spot and one reachable H3 cell:

- exact taxon: `species:striped-bass`;
- inputs: static depth/substrate/channel distance, season/solar phase, tide/current observation or forecast, temperature if supported, local medium evidence, exact access/legal/MPA geometry, and explicit medium-rod tackle fixture;
- outputs: all gate results, habitat/movement/forage/hydrodynamics/physiology/sensory/occurrence components, coverage, conservative ordinal class, one rounded window if supported, and top/co-equal presentations;
- constraints: no current UI replacement, no 0–100 score, no catch percentage, no aggregate species, no network inside evaluator;
- promotion: deterministic tests above, artifact check, and an offline review fixture set spanning high/low flow, day/night, stale telemetry, legal unknown, no local evidence, and tackle infeasibility.

This slice validates the architecture’s hardest boundaries while remaining small enough to test scientifically and roll back completely.

## Sources

[1] https://www.rfc-editor.org/rfc/rfc7946 — RFC 7946: GeoJSON
[2] https://docs.ogc.org/is/15-078r6/15-078r6.html — OGC SensorThings API Part 1
[3] https://dwc.tdwg.org/terms — Darwin Core Terms
[4] https://www.w3.org/TR/prov-o — W3C PROV-O
[5] https://h3geo.org/docs — H3 Documentation
[6] https://turfjs.org — Turf.js
[7] https://ogcapi.ogc.org/features — OGC API Features
[8] https://json-schema.org/specification — JSON Schema Specification
