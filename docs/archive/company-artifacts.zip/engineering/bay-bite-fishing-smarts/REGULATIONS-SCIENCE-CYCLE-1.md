# Bay Bite Regulations + Species Science — Cycle 1

**Owner:** Dr. Elias Forge, CTO  
**Date:** 2026-08-13  
**Disposition:** Foundation integrated locally; fail-closed; not deployed

## Outcome

Integrated Priya Chen's verified `regulations-species-foundation.json` into the schema-v1 application boundary as 22 normalized species profiles, 66 species×area legal rules, and 3 regulatory areas. The existing accepted spot inventory remains exactly 63. The rejected `spot-catalog-100.json` was not imported, referenced, or used.

The application now displays selected-spot legality with official-source links and checked times, plain-language warnings, regional status, and aggregate-species identification caveats. Biology is explicitly labeled as science suitability rather than verified current fish presence.

## Strict-TDD behavior added

Each behavior was introduced with a targeted failing test and then made green:

- schema inventory and verified-bundle acceptance;
- HTTPS and valid source-check timestamps;
- complete biological profile fields and citations;
- official-agency source ownership for every legal record;
- warning, limits, gear, effective dates, checked time, and stale boundary fields;
- Aug. 13 critical regressions: white sturgeon closed; coast Dungeness closed; SF Bay Dungeness no-take; Chinook and rock crab special-notice/non-actionable; coast/Bay surfperch distinctions; groundfish remains restricted;
- unresolved regulatory-area and exact-MPA geometry returns `unknown`;
- all existing spot species remain unrankable until both exact geometry and accepted local-presence evidence are available;
- rockfish, surfperch, flatfish, and smoothhound aggregate labels carry identification caveats;
- stale dynamic/legal snapshots fail closed.

## Application behavior

- Removed the sample species-momentum panel that could imply current/rankable targets.
- Ranked-water/export inputs now require `rankableSpeciesForSpot`; current result is intentionally zero because no accepted exact-MPA adjudication/local evidence edges exist for these legacy records.
- Selected spots remain browseable as planning/access records and show regional legal facts, but exact legality is `unknown` where required geometry is unresolved.
- Carquinez records are `unknown` due unresolved side/inland lookup.
- Regional closed/no-take/special-notice facts remain visible even when exact spot status is forced to `unknown`.
- Science habitat/tactics are not presented as live fish presence.

## Files added or changed in this cycle

- `src/fishing-smarts/index.ts`
- `src/fishing-smarts/regulations-science-data.ts`
- `src/fishing-smarts/app-integration.ts`
- `src/fishing-smarts/schema.test.ts`
- `src/fishing-smarts/eligibility.test.ts`
- `src/data.test.ts`
- `src/presentation.test.mjs`
- `src/App.tsx`

Existing dirty live-ocean/fishing-smarts foundation changes were preserved. No production, systemd, cron, Brain, git commit, push, or deployment action was performed.

## Verification

- `npm test`: **6 files passed, 51 tests passed**.
- `npm run lint`: **0 warnings, 0 errors**.
- `npm run build`: **passed**, 2,415 modules transformed; generated JS 956.48 kB (261.73 kB gzip). Vite emitted the pre-existing/non-blocking >500 kB chunk-size advisory.
- `git diff --check`: **passed**.
- Dataset count check: **22 species, 66 rules, 3 areas**.
- Spot count: **63**, unchanged.
- Search for imported/referenced weak spot catalog or 100-spot claims: **0 matches**.

## Remaining blockers

1. Exact authoritative MPA polygon adjudication for every one of the 63 existing coordinates. Until resolved, MPA-dependent eligibility remains `unknown` and non-actionable.
2. Carquinez Bridge side/boundary resolution and current inland/Delta rule lookup for each relevant coordinate.
3. Accepted per-spot/per-species local evidence edges. Legacy labels are suitability priors, not live-presence evidence, so they cannot rank.
4. Same-day refresh/approval path for quota/notices, especially Chinook salmon and rock crab; stale snapshots must remain non-actionable.
5. Per-spot method/gear adjudication where legal openings depend on hook, appliance, size, report-card, or MPA exception details.
6. The 100-spot acceptance outcome remains blocked: the candidate catalog failed per-spot research quality due repeated tactic/safety templates and was deliberately excluded.
7. Independent Priya source reconciliation and Nora acceptance remain required before external readiness.
