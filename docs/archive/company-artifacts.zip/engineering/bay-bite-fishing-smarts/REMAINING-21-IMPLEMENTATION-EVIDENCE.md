# Bay Bite remaining-21 exact-taxon implementation evidence

**Accountable owner:** Dr. Elias Forge  
**Execution reconciliation:** Arthur Blake  
**Date:** 2026-08-13  
**Evidence status:** pending independent QA  

## Scope

Typed repository-local implementation of the 21 exact-taxon profiles reviewed in:

- `/root/company/research/bay-bite-fishing-smarts/REMAINING-21-TAXA-SCIENCE-PACKAGE.md`
- `/root/company/research/bay-bite-fishing-smarts/remaining-21-taxa-science.v1.json`
- `/root/company/engineering/bay-bite-fishing-smarts/REMAINING-21-EXPANSION-TDD-RED.md`

No runtime import or loading of the mutable research JSON was added.

## TDD evidence

Initial expansion contract:

- 4 focused files: 3 failed, 1 passed.
- 13 focused tests: 12 failed, 1 passed.
- Every failure stopped at the same prerequisite: `actualCount: 3`, with exactly the 21 canonical profiles missing and no extra IDs.
- The existing 124-test suite remained green when the intentionally RED expansion files were excluded.

Post-implementation focused command:

```text
npx vitest run src/fishing-smarts/exact-taxon-science-expansion.test.ts src/fishing-smarts/exact-taxon-evaluator-expansion.test.ts src/fishing-smarts/exact-taxon-ui-boundary-expansion.test.ts src/fishing-smarts/exact-taxon-production-boundary-expansion.test.mjs --reporter=verbose
```

Result: 4 files passed, 13/13 tests passed.

## Implemented artifacts

- `src/fishing-smarts/reviewed-exact-taxon-expansion.ts` — typed repository-local profiles and source records for the 21 taxa.
- `src/fishing-smarts/fauna-opportunity.ts` — exact-taxon contract extension, immutable profile merge, unknown propagation, conservation-first white-sturgeon gate.
- `src/fishing-smarts/scientific-sources.ts` — immutable reviewed source-registry merge.
- `src/fishing-smarts/selected-water-opportunity.ts` — canonical exact evidence taxa and labels retained.
- `scripts/generate-research-catalog.mjs` and generated catalog — deterministic reviewed compatibility projection for all 24 taxa.
- Four expansion test files plus contract helper.

Mechanical reconciliation found all 21 research profile IDs and all 38 source-registry additions in the repository-local typed artifact. The production TypeScript contains no path/reference to either research package file.

## Full deterministic gate

Command sequence:

```text
npm test -- --run
npm run catalog:check
npm run client:check
npm run lint
npm run build
git diff --check
```

Observed result:

- Vitest: 17 files, 137/137 tests passed.
- Catalog: 101 accepted, 30 excluded, 25 sensors, 520 accepted edges.
- Client boundary: 101 accepted spots; all 30 excluded IDs and names absent.
- Lint: 0 warnings, 0 errors across 41 files / 104 rules.
- Build: TypeScript and Vite passed; 2,424 modules.
- Client: 1,835.97 kB minified / 312.97 kB gzip JavaScript; non-blocking chunk-size warning remains.
- `git diff --check`: passed.

## Preserved scientific and safety limits

- Profile presence does not satisfy occurrence, mapped habitat, exact legal/access/MPA, live-condition, or shore-safety gates.
- Catalog radius evidence remains historical corroboration only.
- Five zero-edge taxa remain blocked and non-presentable.
- White sturgeon remains conservation/legal-alert-first and cannot produce a targeting presentation.
- Exact rockfish and all other exact taxa cannot inherit aggregate family rules.
- Presentation categories remain field heuristics outside scientific coverage.
- Conditions are used for control/safety; no feeding multiplier or magic threshold was added.
- No current-presence, abundance, catch-probability, static score/window, causal pressure/solunar, exact lure-frequency, or guaranteed-bite claim was added.
- Mapped habitat derivatives still do not exist for the 21 new profiles; production therefore remains fail-closed.

## Selected-water canonical exact-taxon regression (2026-08-13)

### RED

Test added first: `projects only unique canonical exact evidence taxa at Linda Mar and every selected water` in `src/fishing-smarts/selected-water-opportunity.test.ts`.

```text
npx vitest run src/fishing-smarts/selected-water-opportunity.test.ts -t "projects only unique canonical exact evidence taxa at Linda Mar and every selected water" --reporter=verbose
```

Observed before production change: exit code 1; 1 file failed; 1 test failed and 6 skipped. Expected defect was reproduced at the uniqueness assertion:

```text
ocean-beach: taxon IDs must be unique: expected 5 to be 6
RED_EXIT_CODE=1
```

This is the intended failure: aggregate `Surfperch` resolved to `species:barred-surfperch` only after pre-resolution deduplication, duplicating the canonical evidence-derived Barred surfperch card.

### GREEN

Minimal production change in `src/fishing-smarts/selected-water-opportunity.ts` now:

- starts from catalog evidence taxon IDs;
- admits only IDs owned by immutable `exactTaxonScience`;
- deduplicates after canonical resolution;
- adds only reviewed one-to-one legacy mappings (`Striped Bass`, `Halibut`) when not already represented;
- does not synthesize exact IDs from aggregate labels;
- preserves evaluator inputs, fail-closed legal/access/MPA/safety gates, and canonical science labels.

Focused regression command (same test selector): exit code 0; 1 test passed, 6 skipped; `GREEN_EXIT_CODE=0`.

Focused selected-water/expansion command:

```text
npx vitest run src/fishing-smarts/selected-water-opportunity.test.ts src/fishing-smarts/exact-taxon-science-expansion.test.ts src/fishing-smarts/exact-taxon-evaluator-expansion.test.ts src/fishing-smarts/exact-taxon-ui-boundary-expansion.test.ts src/fishing-smarts/exact-taxon-production-boundary-expansion.test.mjs --reporter=verbose
```

Observed: exit code 0; 5 files passed; 22/22 tests passed.

Full and deterministic gates:

```text
npm test -- --run
npm run catalog:check
npm run client:check
npm run lint
npm run build
git diff --check
```

Observed:

- Vitest: exit 0; 17 files passed; 140/140 tests passed.
- Catalog: exit 0; 101 accepted, 30 excluded, 25 sensors, 520 accepted edges.
- Client boundary: exit 0; 101 accepted spots; all 30 excluded IDs and names absent.
- Lint: exit 0; 0 warnings and 0 errors across 41 files / 104 rules.
- Build: exit 0; TypeScript and Vite passed; 2,424 modules; JavaScript 1,835.80 kB minified / 312.89 kB gzip. Existing non-blocking chunk-size warning remains.
- `git diff --check`: exit 0; no output.

## Disposition

Selected-water regression and deterministic engineering gates pass locally. Independent review is pending. Scientific/source fidelity, adversarial trust boundaries, browser behavior, and immutable sealing retain their prior status. No deployment, reset, clean, commit, push, systemd action, Brain write, `/srv` write, or seal was performed.
