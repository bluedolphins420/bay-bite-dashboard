# Bay Bite Fishing-Smarts Architecture

**Owner:** Dr. Elias Forge, CTO  
**Status:** Foundation implemented; research/content migration not started  
**Schema:** `fishing-smarts/v1` (`schemaVersion: 1`)  
**Decision date:** 2026-08-13

## Outcome and non-goals

This foundation lets reviewed official research be integrated without turning regional biological possibility, a stale legal snapshot, or a distant sensor into an actionable fishing recommendation. It deliberately contains **no new spots, species claims, legal facts, sensor mappings, or research records**. The existing 63-spot UI remains unchanged while records migrate.

Not in this change: current CDFW facts, spot-count expansion, production/systemd/cron/Brain changes, UI redesign, or deployment.

## Invariants

1. **Stable normalized IDs.** Every entity has a namespaced stable ID (`spot:…`, `species:…`, `habitat:…`, `area:…`, `rule:…`, `notice:…`, `mpa:…`, `sensor:…`, `evidence:…`, `source:…`). IDs never encode a mutable display label or current status.
2. **Legality is a hard gate.** Biology can affect suitability but cannot override `closed`, `no-take`, `restricted`, `catch-release`, `special-notice`, or `unknown`. Only an explicitly verified `open` status is actionable in the foundation evaluator; special notices are shown prominently but require official resolution before targeting.
3. **Unknown is non-actionable.** No matching verified rule, failed refresh, or stale matching dynamic rule returns `unknown`, never an inherited/open guess.
4. **Specific restrictions win.** Applicable statuses are reduced conservatively: `unknown > no-take > closed > restricted > catch-release > special-notice > open`. Exact spot/MPA/mode/method/gear selectors participate before reduction.
5. **Notices expire.** `expiresAt` ends applicability. Dynamic rules/notices require `maxAgeHours`; absent TTL is stale by definition.
6. **Evidence is local and owned.** A recommendation requires a spot-species evidence edge with at least medium confidence and a habitat shared by the evidence, spot, and species. Sources carry an owner class and review timestamp.
7. **Sensors are metric-local.** A sensor has per-metric representativeness, distance, TTL, and source. A station can be local for tide prediction but only regional/not-representative for waves; locality is never station-global.
8. **Snapshots validate before publication.** Schema version, arrays, global ID uniqueness, and references are checked before application use. Unknown versions fail.

## Normalized model

Implemented in `src/fishing-smarts/index.ts`:

- `SourceRecord`: provenance owner, URL, checked time.
- `SpotRecord`: habitat, regulatory area, exact MPA, and sensor references.
- `SpeciesRecord`: canonical identity and compatible habitats.
- `HabitatRecord`: reusable habitat identity.
- `RegulatoryAreaRecord`: legal geography identity.
- `RuleRecord`: species/area/spot/MPA/mode/method/gear selectors, effective interval, status, dynamic TTL, sources.
- `NoticeRecord`: rule semantics plus explicit notice expiry.
- `MpaRecord`: protected-area identity and parent legal areas.
- `SensorRecord`: environment plus metric-level bindings (`representativeness`, optional `distanceKm`, `maxAgeMinutes`, `sourceId`).
- `SpotSpeciesEvidenceRecord`: local edge, evidence habitat, confidence, sources, publication/observation and review dates.

Statuses are exactly: `open | closed | catch-release | no-take | restricted | special-notice | unknown`.

## Evaluation pipeline

`evaluateEligibility(dataset, context)` accepts the evaluation time, exact spot, species, regulatory area, fishing mode, methods, gear, and exact MPAs.

1. Filter rules/notices by effective/expiry time and every supplied selector.
2. If none match: `unknown`, non-actionable.
3. If any applicable dynamic record is stale: `unknown`, non-actionable. This is the fail-closed refresh boundary.
4. Reduce applicable statuses using conservative precedence.
5. Return status, actionability, matched IDs, and reasons.

`evaluateRecommendation(dataset, context)` separately computes:

- `legal`: result of the hard-gate evaluator;
- `biologySuitable`: medium/high local evidence plus shared spot/species habitat;
- `actionable`: `legal.actionable && biologySuitable`;
- evidence IDs used for audit/UI explanation.

Scores and environmental affinity may be added later, but only after these gates. They must never change legal actionability.

## Legacy migration

`src/fishing-smarts/legacy-adapter.ts` wraps each existing `Spot` with a stable `spot:<legacy-id>` while preserving the **same object reference** in `legacy`. The adapter is intentionally read-only. Current `src/data.ts` and `src/App.tsx` continue to serve all 63 records during research integration.

Migration sequence:

1. Validate Priya JSON independently; do not mutate `src/data.ts` from unvalidated input.
2. Reconcile IDs and references; reject aliases/coordinate duplicates and unsupported species edges.
3. Run eligibility/evidence coverage reports. Missing legality or evidence stays non-actionable.
4. Add a selector layer that prefers normalized accepted records and falls back to the untouched legacy object for presentation only—not actionable ranking.
5. Migrate UI panels incrementally, then remove generic legacy recommendation generation only after coverage/acceptance gates pass.

## Priya JSON integration contract

Deliver one UTF-8 JSON object per reviewed bundle. Required top-level shape:

```json
{
  "schemaVersion": 1,
  "generatedAt": "ISO-8601 UTC",
  "sources": [],
  "spots": [],
  "species": [],
  "habitats": [],
  "regulatoryAreas": [],
  "rules": [],
  "notices": [],
  "mpas": [],
  "sensors": [],
  "spotSpeciesEvidence": []
}
```

Contract rules:

- All IDs are globally unique, namespaced, immutable, lowercase kebab-case after the colon, and supplied explicitly.
- All references must resolve inside the bundle (or a separately version-pinned accepted base bundle when bundle composition is added).
- `source.owner` is one of `official-agency | site-owner | academic | reviewed-secondary | community`; legal rules/notices must cite official sources. Access may cite the site owner.
- Every source has canonical HTTPS URL and `checkedAt`; no search-result snippets.
- Dynamic rule/notice records require `checkedAt` and `maxAgeHours`. Notices should provide `expiresAt`. A failed updater must publish failure/staleness, not preserve actionable open beyond TTL.
- Rule selectors must be explicit. Use empty arrays only to mean the record intentionally applies across that dimension; never omit known area/mode/MPA/gear constraints to broaden a rule.
- A shore exemption is represented by `fishingModes: ["shore"]` (or the exact qualifying mode) and exact method/gear/spot/MPA selectors as applicable; it does not imply boat eligibility or adjacent-shore license treatment.
- Spot-species evidence must be local to the exact spot, identify compatible habitat IDs, cite source IDs, state confidence, and carry `reviewedAt`. Regional possibility alone is not an evidence edge.
- Sensors define each metric separately. Include environment, per-metric representativeness, distance when known, freshness TTL, and source ID. Offshore metrics must not be labeled local for protected/inland water.
- Priya may submit researched records only; no generated filler, aliases, generic copied prose, inferred current legal status, or unreviewed automation output.

Before merge, Elias runs `validateFishingSmartsDataset`, referential/uniqueness tests, legal regression fixtures using Priya's official facts, evidence coverage, >=100 accepted distinct actionable-spot checks, full tests/lint/build, and Nora acceptance.

## Validation scope and next extensions

The current runtime validator is intentionally a foundation validator, not yet the final publication validator. Before accepting research, extend under TDD to enforce field-level enums/types, ISO/HTTPS formats, ID namespace/entity matching, source-owner requirements for legal records, coordinates/access fields, duplicate-coordinate policy, and sensor binding references. Add a bundle-composition layer only if research must ship in multiple files.

Neutral tests now cover closed, exact MPA no-take, stale dynamic rules, notice expiry/freshness, shore-only mode, evidence/habitat gating, schema version/duplicates/references, and preservation of all 63 legacy UI records.
