# Remaining-21 certification remediation — TDD RED evidence

**Date:** 2026-08-13  
**Scope:** Independent-review rejection remediation only  
**Production changes in this phase:** none

## Corrected acceptance contract

Test: `src/fishing-smarts/remaining-21-cert-remediation.test.ts`

The contract is aligned to the corrected research artifact's exact 17 provenance dimensions:

- taxonomy
- authorityIdentifiers
- domain
- environment
- substrate
- structure
- salinity
- depth
- lifeStages
- season
- forage
- feedingMode
- vulnerabilities
- shoreAccessibility
- legalIdentityRuleStatus
- localHistoricalEvidence
- presentation

The test deliberately does not invent aggregate `habitat`, `legalIdentity`, or `localEvidence` provenance keys.

Rubberlip accepts either an explicit replacement-verification wrapper or the corrected in-place URL when both direct and Jina fetches return HTTP 200 and content identity matches `Rhacochilus toxotes`.

## RED execution

```bash
npx vitest run src/fishing-smarts/remaining-21-cert-remediation.test.ts --reporter=dot
```

Result:

- Test files: 1 failed
- Tests: 5 failed, 3 passed

Expected failures:

1. All 21 runtime profiles omit nine reviewed field groups (189 omissions total).
2. Runtime profiles do not expose the corrected field-level `claimProvenance` contract.
3. Source registry roles remain flattened and do not match biology/legal/advisory/conservation/taxonomy/occurrence roles.
4. Legal/advisory sources are still attached to ecological claims.
5. Both reviewed derivative registries are implemented as mutable `Map` instances.

Expected passes:

1. Corrected rubberlip replacement verification is accepted.
2. Rubberlip known/unknown source behavior satisfies the replacement rule.
3. Derivative registries remain private and adversarial occurrence/habitat forgeries remain rejected.

## Research handoff identity

- Markdown SHA-256: `c77227791bd3c16d78cee7be8fd0923094f3ffe329a9a5c1a26d8622a53da7ec`
- JSON SHA-256: `dac789c5f61b60510e8db6322354248c946478f3a84278501c5ed4bf30e2b5db`
- Profiles: 21
- Provenance claims: 357 (325 known, 32 unknown)
- Sources: 41 with distinct roles

This record established the RED boundary before implementation.

## GREEN verification — independently rerun by Arthur Blake

After the production remediation and correction of two test-specification naming errors, the exact contract passed:

```text
remaining-21-cert-remediation.test.ts: 8/8 passed
```

Full deterministic gate:

```text
npm test -- --run: 18 files, 148/148 tests passed
npm run catalog:check: 101 accepted, 30 excluded, 25 sensors, 520 edges
npm run client:check: 101 accepted; all 30 excluded IDs/names absent
npm run lint: 0 warnings, 0 errors on 42 files / 104 rules
npm run build: passed, 2,424 modules
bundle: 2,017.13 kB minified / 321.44 kB gzip (non-blocking size warning)
git diff --check: passed
```

Additional direct verification:

- 21/21 corrected profile IDs compiled into repository-local typed data.
- 41/41 corrected source IDs compiled into repository-local typed data.
- No runtime reference to `/root/company` research artifacts.
- No mutable `Map` implementation remains for either reviewed derivative registry.
- Browser selected-water regression: zero console/JavaScript errors; one Barred surfperch card; no aggregate synthetic science cards; all presentations suppressed while safety/legal/habitat evidence is unresolved.

Changed implementation surfaces:

- `src/fishing-smarts/reviewed-exact-taxon-expansion.ts`
- `src/fishing-smarts/fauna-opportunity.ts`
- `src/fishing-smarts/scientific-sources.ts`
- `src/fishing-smarts/remaining-21-cert-remediation.test.ts`

This is orchestration evidence, not a claim of independent final certification or deployment authorization.

## Pre-import poisoning rejection and remediation

A later independent review of the superseded `74bb…` seal identified a distinct module-order attack. The same attack was reproduced against the superseded `c270…` seal:

```json
{"profilesFrozen":false,"batFrozen":false,"sourcesFrozen":false,"sourceFrozen":false,"scienceHabitat":"habitat:attacker","sourceLimitation":"attacker"}
```

Valid RED was then established in an isolated Vite Node process:

```text
reviewedExpansionProfiles must be frozen immediately
false !== true
```

Production remediation:

- `reviewedExpansionProfiles` and `reviewedExpansionSources` are recursively frozen at declaration/export time.
- The freezer rejects accessor-bearing generated data and uses a cycle guard.
- The fresh-process regression attacks nested arrays, field overwrite, prototype replacement, property definition, new-key insertion, and inherited pollution before importing downstream registries.
- The fixture verifies all corrected research fields across 21 profiles and 41 sources, while allowing only deliberate runtime compatibility fields.
- A discovered `source:frontiers-sturgeon` role divergence was corrected from the mistaken runtime/test expectation `conservation-status` back to the corrected research value `biology`; CDFW white-sturgeon remains conservation-status.

Final local GREEN after this security remediation:

```text
npm test -- --run: 19 files, 149/149 tests passed
catalog: 101 accepted, 30 excluded, 25 sensors, 520 edges
client boundary: passed
lint: 0 warnings, 0 errors on 44 files / 104 rules
build: passed, 2,424 modules
bundle: 2,048.38 kB minified / 324.62 kB gzip (non-blocking warning)
git diff --check: passed
```

Neither superseded seal is acceptable. No deployment authorization is implied.

## Exact corrected source-identity retention remediation

A later independent review of the superseded `c270…` seal found that `scientificSourceRegistry` filtered three corrected identities (`source:gbif-api`, `source:inat-api`, and `source:noaa-benthic`) and substituted differently named legacy records. The same omission persisted in superseded `a830…`, so that seal was rejected.

Valid RED required all 41 corrected source IDs and corrected fields to survive into the production registry; it failed with only 38 exact matches and those three IDs absent. The stale expansion test also explicitly required the aliases to be absent, masking the fidelity defect.

Production remediation:

- The production registry now retains all 41 exact corrected records.
- Distinct legacy records remain for compatibility but do not replace canonical reviewed identities.
- The registry contains 54 total records and 54 unique IDs; no duplicate ID is present.
- The registry-level test mechanically compares corrected source fields and specifically requires the three formerly omitted identities.
- `source:frontiers-sturgeon.role` remains the corrected research value `biology`.
- The declaration-boundary pre-import poisoning defense remains green.

Final local GREEN after exact-source identity remediation:

```text
npm test -- --run: 19 files, 150/150 tests passed
corrected source registry: 41/41 exact reviewed IDs; 54/54 total unique IDs
catalog: 101 accepted, 30 excluded, 25 sensors, 520 edges
client boundary: passed
lint: 0 warnings, 0 errors on 44 files / 104 rules
build: passed, 2,424 modules
bundle: 2,048.38 kB minified / 324.62 kB gzip (non-blocking warning)
git diff --check: passed
```

No deployment authorization is implied.

## Public derivative export immutability remediation

Independent review of superseded `a830…` identified three mutable public exports. The same attack was reproduced against superseded `95de…`, so that seal was rejected:

```text
scientificIngestionContracts: 8 unfrozen paths
reviewedOccurrenceRecords: 71 unfrozen paths
occurrenceEvidenceOverlays: 15 unfrozen paths
attack: overlay legend overwritten with ATTACKER_OVERLAY
```

Strict RED asserted recursive freezing and real mutation resistance for all three direct exports. Minimal production remediation deep-freezes each export at declaration with accessor-rejecting, cycle-guarded traversal and adds accurate readonly types. Values, order, IDs, and evaluator behavior were preserved.

Independent working-tree audit after remediation:

```text
exactTaxonScience: 0 unfrozen paths
scientificSourceRegistry: 0
scientificIngestionContracts: 0
researchCatalog: 0
researchSpots: 0
sensorDefinitions: 0
reviewedOccurrenceRecords: 0
occurrenceEvidenceOverlays: 0
prior overlay overwrite now throws TypeError: Cannot assign to read only property
```

Final local GREEN:

```text
npm test -- --run: 20 files, 151/151 tests passed
catalog: 101 accepted, 30 excluded, 25 sensors, 520 edges
client boundary: passed
lint: 0 warnings, 0 errors on 45 files / 104 rules
build: passed, 2,424 modules
bundle: 2,048.67 kB minified / 324.74 kB gzip (non-blocking warning)
git diff --check: passed
```

No deployment authorization is implied.

## Comprehensive public runtime-data and legal dataset remediation

Comprehensive review rejected superseded `0f20…` after enumerating 20 public object/array exports. Nine `src/data.ts` graphs and `regulationsScienceDataset` were mutable. The exact legal exploit changed `rule:white-sturgeon-sf-coast-2026` from closed/non-actionable to open/actionable:

```json
{"datasetFrozen":false,"ruleFrozen":false,"before":{"status":"closed","actionable":false},"after":{"status":"open","actionable":true}}
```

Root cause: the repository had no single enforced rule that every exported runtime data graph is canonical and immutable; narrow prior tests listed only recently discovered exports.

Remediation:

- Added a shared accessor-rejecting, cycle-guarded runtime deep-freezer.
- Deep-froze the complete generated `regulationsScienceDataset` at declaration.
- Deep-froze all nine public `src/data.ts` exports after internal construction: `legacyDraftSpots`, `spots`, `speciesProfiles`, `tideSeries`, `speciesMomentum`, `regions`, `allSpecies`, `dailyReport`, and `researchSources`.
- Replaced the narrow public-export test with mechanical module enumeration of exactly 20 intended object/array exports across data, legal, fauna, source, catalog, expansion, and selected-water modules.
- The regression recursively checks frozen/accessor state and attacks overwrite, push, defineProperty, new keys, prototype replacement, and inherited pollution on every graph.
- Dedicated legal assertion proves white sturgeon remains closed/non-actionable after exact and generic attacks. Direct assignment now throws `TypeError`; `Reflect.set` returns false.
- Removed two dead legacy spot-literal graphs (`baseSpots` and `legacyDraftSpots`, 56.9 KB source) after the fresh seal gate proved freezing dead state forced excluded `Pacifica Pier` into the client bundle. They had no consumer; accepted 101-spot catalog projection remains authoritative. Fresh build/client check confirms all 30 excluded IDs and names absent.

Final local GREEN:

```text
public export inventory: 20/20 recursively immutable
npm test -- --run: 20 files, 153/153 tests passed
catalog: 101 accepted, 30 excluded, 25 sensors, 520 edges
client boundary: passed
lint: 0 warnings, 0 errors on 46 files / 104 rules
build: passed, 2,425 modules
bundle: 2,111.28 kB minified / 340.30 kB gzip (non-blocking warning)
git diff --check: passed
```

No deployment authorization is implied.

## Pre-import poisoning remediation — RED (2026-08-13)

Focused command:

```bash
npx vitest run src/fishing-smarts/reviewed-exact-taxon-preimport-boundary.test.mjs --reporter=dot
```

Observed result before production changes:

```text
Test Files  1 failed (1)
Tests       1 failed (1)
AssertionError: reviewedExpansionProfiles must be frozen immediately
false !== true
RED_EXIT_CODE=1
```

The regression runs the direct expansion import in an isolated child process/module cache before importing either downstream registry. The failure is the independently reproduced declaration-boundary defect, not a downstream registry assertion.

## Exact-source identity omission — RED (2026-08-13)

Focused command:

```bash
npx vitest run src/fishing-smarts/remaining-21-cert-remediation.test.ts --reporter=dot
```

Observed before the production composition fix:

```text
Test Files  1 failed (1)
Tests       1 failed | 8 passed (9)
AssertionError: exact corrected source IDs retained by runtime registry
Missing exact IDs:
- source:noaa-benthic
- source:gbif-api
- source:inat-api
RED_EXIT_CODE=1
```

The corrected artifact contains 41 unique source IDs. Runtime resolved only 38 of those exact identities because semantic legacy aliases were retained while these three corrected IDs were filtered out.

## Exact-source identity omission — GREEN (2026-08-13)

Minimal production change: compose all 41 reviewed expansion records and remove the two same-ID base records (`source:cdfw-bay-study`, `source:obis-api`) so the corrected records win by exact identity. Differently named legacy records remain.

```bash
npx vitest run src/fishing-smarts/remaining-21-cert-remediation.test.ts --reporter=dot
```

Observed:

```text
Test Files  1 passed (1)
Tests       9 passed (9)
GREEN_EXIT_CODE=0
```
