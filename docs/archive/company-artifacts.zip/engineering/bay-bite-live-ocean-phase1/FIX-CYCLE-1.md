# Bay Bite Live Ocean Phase 1 — Fix Cycle 1

**Owner:** Dr. Elias Forge  
**Date:** 2026-08-13  
**Disposition:** Second private candidate prepared for independent QA. No commit, push, production/systemd/tunnel/Shared Brain change, contact, or spend.

## Blocking defects resolved

- Replaced generic station mapping with product-specific prediction, observed-level, wind, and wave mappings for all 26 `data.ts` tide-station labels.
- Corrected official identities and reversed Bodega/Napa IDs. Prediction-only stations are never queried for `water_level`; inland/protected waters never receive ocean buoy observations. Unsupported products are explicit unavailable records.
- CO-OPS requests use metric + GMT. Observation timestamps are parsed as UTC once and rejected beyond two minutes future skew. Predictions remain forecast data and may be future.
- Freshness is per product: CO-OPS 18-minute live maximum; NDBC 2× station cadence (46026/46013 10 minutes, 46012 60 minutes), delayed through 2 hours, then stale.
- Refresh replacement is validated per product. Invalid HTTP-200 payloads, empty/nonfinite data, and bad/future timestamps retain only a matching prior valid product, preserve its timestamp, mark LKG, and recompute age/freshness.
- Schema v3 deep-validates station/product identity, timestamps, and finite numeric values before atomic rename. A temp-path regression proves malformed publication leaves the current snapshot intact.
- UI consumes metric cache field names, converts once, labels WVHT as significant wave height, separates tide forecast from observations, shows exact IDs/names/age/health/regional warning, and removes the duplicate lower live telemetry block.
- Browser cache fetch is same-origin, `no-store`, cache-busted, refreshed every 60 seconds and on focus/visibility. No browser NOAA/NDBC request exists.
- Vite preview host allowlist is restricted to localhost and `algorithms-tough-allied-approximately.trycloudflare.com`.

## Strict TDD evidence

### RED

`npx vitest run scripts/update-live-data.test.mjs src/telemetry.test.ts src/presentation.test.mjs`

Result before implementation: **11 failed, 4 passed**. Expected failures covered missing 10 labels, wrong IDs/offshore mappings, absent UTC/future parser and product cadence, absent per-product LKG/publication injection, wrong UI fields/labels, no polling, duplicate board, and unrestricted preview host.

A separate prediction-horizon regression was added and observed RED: **1 failed, 8 passed**, because future tide predictions were incorrectly rejected as future observations.

### GREEN

Targeted updater suite after implementation: **9/9 passed**. Full suite result: **23/23 passed**.

## Deterministic gate results

- `npm test` — PASS, 4 files / 23 tests.
- `npm run lint` — PASS, 0 warnings / 0 errors.
- `npm run build` — PASS, 2,412 modules; known nonblocking ~851 kB chunk advisory remains.
- `git diff --check` — PASS, empty output.
- `npm run update:live` — PASS, schema v3, 26 records; expected truthful partial/unavailable coverage.

## Actual snapshot inspection

Inspection checks every station/product record:

- no observed `readingTimestamp/observedAt` later than `generatedAt + 2 minutes`;
- no ocean buoy on inner Bay, South Bay, Carquinez, Napa, harbor, lagoon, or tidal-river mappings;
- Bodega uses tide prediction 9415625 and offshore regional buoy 46013;
- Napa uses prediction 9415623 and explicit unavailable observed level/buoy;
- 46026 official identity is `SAN FRANCISCO, 18 NM west of San Francisco`;
- 46012 is labeled `offshore USV/regional` with 60-minute cadence;
- selected-label cache coverage is 26/26.

## Residuals

- Upstream product availability legitimately yields partial/unavailable fields; no values are inferred.
- Bolinas Lagoon has explicit unsupported Phase-1 products rather than a fabricated fallback.
- The existing Vite chunk-size advisory remains nonblocking.
- Independent QA is still required; this artifact is not production authorization.
