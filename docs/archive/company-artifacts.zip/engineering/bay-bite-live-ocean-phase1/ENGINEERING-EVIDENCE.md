# Bay Bite Live Ocean Command Center — Phase 1 Engineering Evidence

**Owner:** Dr. Elias Forge, CTO / Principal Engineer  
**Date:** 2026-08-13  
**Disposition:** Working private candidate; no commit, push, deploy, publication, production restart, contact, or spend.

## Outcome

- Replaced the static-average `bestRegion` Conditions Board with a selected-spot command board.
- The browser now consumes only same-origin `/data/live-status.json`; NOAA/NDBC network access is updater-only.
- Board separates **Observed** tide/wind/gust/offshore swell/water temperature, **Forecast** next high/low, and **Model** fishing guidance.
- Added station/buoy IDs and names, source reading time/age/freshness, partial errors, and explicit offshore/non-local representativeness language.
- Corrected and exported NDBC parser: uppercase headers, first real row, `MM` missing values, UTC timestamp, and metric raw schema for WDIR/WSPD/GST/WVHT/DPD/APD/MWD/PRES/ATMP/WTMP.
- Updater deduplicates identical URLs through a shared promise cache, validates schema v2, writes a temporary file, then atomically renames it. It retains prior station values on source failures and marks last-known-good/age.
- Global health no longer calls all 16 stations live when any station is delayed/partial/stale/unavailable.
- Data refresh documentation and proposed data-only service/timer are separate from deployment; nothing was installed.

## Strict TDD evidence

### Cycle 1 — NDBC parser
RED command:
`npx vitest run scripts/update-live-data.test.mjs`

Expected RED:
- `TypeError: parseBuoy is not a function`
- 1 failed test.

Intermediate diagnostic RED after export/implementation:
- expected `2026-08-13T17:40:00.000Z`, received `2029-04-13T17:40:00.000Z` because duplicate NDBC `MM` headers collided.

GREEN command:
`npx vitest run scripts/update-live-data.test.mjs`

GREEN result:
- 1 file passed, 1 test passed.

### Cycle 2 — selected-water cached UI/provenance
RED command:
`npx vitest run src/presentation.test.mjs`

Expected RED:
- missing `Selected water live conditions` while old static board/browser CO-OPS calls remained.
- 1 failed, 1 passed.

GREEN command:
`npx vitest run src/presentation.test.mjs src/telemetry.test.ts scripts/update-live-data.test.mjs`

GREEN result:
- 3 files passed, 6 tests passed.

## Required command results

- `npm run update:live` — PASS
  - `status: partial`
  - health: `live: 9`, `delayed: 4`, `partial: 3`
  - total stations: 16
  - generated: `2026-08-13T16:34:51.524Z`
- JSON inspection — PASS
  - schemaVersion 2
  - Half Moon Bay populated: WSPD 6 m/s, GST 7 m/s, WVHT 1.6 m, DPD 9 s, PRES 1012.4 hPa, ATMP 14.3 C, WTMP 15.1 C, observed UTC timestamp.
  - APD/MWD absent in the actual latest row remain absent; no fake defaults.
  - partial stations expose real errors: Oakland Inner Harbor, Benicia, Napa River water-level requests returned HTTP 400.
- `npm test` — PASS: 4 files, 13/13 tests.
- `npm run lint` — PASS: 0 warnings, 0 errors.
- `npm run build` — PASS: 2,412 modules; assets emitted.
- `git diff --check` — PASS (empty output).
- Browser-source search — PASS: no production React source contains cross-origin CO-OPS/NDBC sensor URLs; only the negative assertion contains the NDBC literal.

## Exact Phase 1 changed/created paths

Repository:
- `/root/bay-bite-dashboard/src/App.tsx`
- `/root/bay-bite-dashboard/src/App.css`
- `/root/bay-bite-dashboard/src/telemetry.ts`
- `/root/bay-bite-dashboard/src/telemetry.test.ts` (existing test coverage retained)
- `/root/bay-bite-dashboard/src/presentation.test.mjs`
- `/root/bay-bite-dashboard/scripts/update-live-data.mjs`
- `/root/bay-bite-dashboard/scripts/update-live-data.test.mjs`
- `/root/bay-bite-dashboard/public/data/live-status.json`
- `/root/bay-bite-dashboard/docs/LIVE_DATA_REFRESH.md`

Company engineering evidence only:
- `/root/company/engineering/bay-bite-live-ocean-phase1/ENGINEERING-EVIDENCE.md`
- `/root/company/engineering/bay-bite-live-ocean-phase1/bay-bite-live-data.service.proposed`
- `/root/company/engineering/bay-bite-live-ocean-phase1/bay-bite-live-data.timer.proposed`

The repository was dirty before this task; unrelated existing changes were preserved. No Shared Brain files were edited.

## Residual limitations

- Offshore NDBC observations are regional context, not beach-local measurements; the UI says so for every mapping.
- Some NDBC latest rows omit APD/MWD/WVHT; absent fields remain unavailable.
- Three CO-OPS station/product combinations return water-level HTTP 400; their other feeds remain visible and health is partial.
- NWS, CoastWatch, HAB, current-station expansion, distance calculation, and 24-hour history remain Phase 2/backlog source slots.
- Vite still reports the known ~852 kB main-chunk advisory.
- Proposed timer/service are evidence artifacts only and were not installed or activated.
