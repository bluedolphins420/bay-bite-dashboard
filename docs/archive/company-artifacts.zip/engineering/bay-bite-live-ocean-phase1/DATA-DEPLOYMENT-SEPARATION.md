# Bay Bite Live Data — Deployment Separation Runbook

**Status:** proposed; do not execute before private-candidate acceptance  
**Owner:** Dr. Elias Forge  
**Approver for production change:** DRE DAWG  
**Prepared by:** Arthur Blake  
**Date:** 2026-08-13

## Problem

The current `bay-bite-live-update.service` runs `npm run update:live` and then copies all of `dist/` to `/srv/bay-bite/`. A sensor refresh therefore doubles as an undeclared application deployment path.

## Desired boundary

- **Data refresh:** fetch, validate, and atomically publish only `live-status.json`.
- **Application deployment:** build and copy application assets only during an explicit, separately verified release.
- A failed or malformed data refresh must leave the last-known-good data file in place.

## Proposed data-only service behavior

1. Run the repository's tested updater.
2. Validate the generated snapshot schema and timestamps.
3. Install only the validated data file to a temporary file under `/srv/bay-bite/data/`.
4. Set owner and mode on that temporary file.
5. Atomically rename it to `/srv/bay-bite/data/live-status.json`.
6. Never copy `dist/assets`, `index.html`, service workers, manifests, or application code.

## Proposed refresh cadence

Target every 15 minutes after source-load testing. Keep request deduplication and API throttling protection in the updater. If source behavior does not support that cadence, use the slowest required source cadence and show actual data age in the UI.

## Acceptance before production change

- Private candidate accepted by Nora.
- Data-only updater tested against a temporary destination.
- Malformed-output test proves last-known-good file remains intact.
- Timer overlap protection verified.
- Production data endpoint returns validated JSON.
- Production application asset hashes remain unchanged during a data-only refresh.
- Rollback command and prior unit files captured.

## Rollback

Restore the captured prior service/timer unit files, reload systemd, and restart only the timer. Application rollback is not part of this data-only change because application assets must remain untouched.

## Authorization boundary

This runbook is preparation, not authorization. No `/etc/systemd` edits, timer changes, production file copies, or restarts occur during private-candidate development.
