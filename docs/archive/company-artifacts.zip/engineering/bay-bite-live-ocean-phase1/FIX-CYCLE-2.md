# Bay Bite Live Ocean Phase 1 — Fix Cycle 2

**Owner:** Dr. Elias Forge  
**Date:** 2026-08-13  
**Disposition:** Third private candidate prepared for independent acceptance. No commit, push, production/systemd/tunnel/Shared Brain change, contact, or spend.

## Blocking fixes completed

- “Next high/low” now uses the later of snapshot `generatedAt` and current time, rejects past extrema, sorts unsorted prediction arrays, and renders unavailable when no future event exists. Local time formatting is preserved.
- `LiveTelemetry` carries independent level, wind, and buoy metadata: availability, freshness, observed timestamp, age, LKG state, exact station ID/name, and unavailable reason. Every displayed observed card renders this metadata; forecast cards do not borrow observation health.
- Aggregate observation health is conservative across all displayed observation classes. Any unavailable class makes a partly populated board `partial`; all unavailable classes make it `unavailable`; delayed/stale/LKG states propagate.
- Half Moon Bay and Alameda can no longer report `live` while displayed observation classes are unsupported. Unsupported records remain explicit and do not create source errors.
- Schema v3 validation is deeply fail-closed and accepts an injected expected mapping set for tests. It requires exact mapping coverage, top-level metadata/count consistency, station/product shape, discriminators, identities, units, finite required values, timestamp validity/future skew, freshness/age/LKG fields, prediction arrays, unsupported records, station health, and aggregate status.
- NDBC parsing omits `MM`, `-99`, `999`, and field-specific nonphysical values. A row survives when at least one useful field remains; an all-invalid row rejects.
- Refresh documentation now says schema v3. The manifest references the existing `/favicon.svg` with SVG type and `sizes: any`.
- Secure preview host allowlist and same-origin browser cache polling remain unchanged.

## Strict TDD evidence

### RED

- Telemetry/presentation regressions: 7 failures proved past/unsorted extrema, missing per-product metadata, non-conservative board state, and absent field-level UI health.
- Updater regressions: 4 failures proved sentinel acceptance, shallow schema acceptance, and unsupported products incorrectly yielding `live`.
- Cleanup regression: 1 failure proved stale schema-v2 documentation/manifest reference.

### GREEN

- Targeted telemetry/presentation: 12/12 passed.
- Targeted updater: 13/13 passed.
- Full suite: 4 files, 33/33 passed.

## Deterministic verification

- `npm test` — PASS, 33/33.
- `npm run lint` — PASS, 0 warnings/errors.
- `npm run build` — PASS, 2,412 modules; existing nonblocking ~853 kB chunk advisory.
- `git diff --check` — PASS.
- Actual `node scripts/update-live-data.mjs` — PASS, schema v3, exactly 26 stations/mappings, aggregate partial (`partial: 24`, `unavailable: 2`).
- Deep validator accepted the actual output. Inspection found zero future observations and zero `-99`/`999` sentinel numeric fields.
- Actual selected-water truth: Half Moon Bay `partial` (level/wind unavailable; buoy live at 68 min due 60-minute cadence), Alameda `partial` (level live; wind/buoy unavailable), Ocean Beach/San Francisco `partial` (level/wind live at 8 min; buoy delayed at 28 min). Each product retains exact source identity and age/timestamp.
- Actual future tide selection after `generatedAt`: Half Moon Bay next high 3:22 PM / low 8:48 PM; Alameda next high 4:52 PM / low 10:16 PM; San Francisco next high 4:25 PM / low 9:32 PM.

## Residuals

- Upstream availability remains truthful and may yield partial/unavailable products; no values are inferred.
- Existing Vite chunk-size advisory remains nonblocking.
- Independent acceptance is still required; this artifact is not production authorization.
