# Bay Bite UX cleanup — engineering evidence

- Date: 2026-08-14
- Accountable owner: Dr. Elias Forge (`coding`)
- Handoff: `/root/company/handoffs/BAY-BITE-UX-CLEANUP-2026-08-14.md`
- Candidate workspace: `/root/bay-bite-dashboard-ux-cleanup-20260814`
- Disposition: implementation complete; local gates passed; independent review passed

## Objective and acceptance disposition

Replace the long report/dashboard presentation with one selected-spot mobile workspace. The implemented presenter keeps search/map, favorites, directions, themes, filters, PWA metadata, and the existing conservative telemetry/science/legal engines while exposing three short views: `Now`, `Target`, and `Plan`. Raw evaluator reasoning and internal policy vocabulary are not rendered.

Acceptance matrix:

| Requirement | Evidence status |
|---|---|
| Strict test-first presentation change | VERIFIED — focused RED and GREEN observed below |
| No raw evaluator fields/enums in normal or expanded UI | VERIFIED by source assertion, source search, and browser DOM review |
| Banned internal vocabulary absent from rendered UI | VERIFIED by presentation test and browser DOM scan |
| Evaluator/conservative semantics unchanged | VERIFIED — no fishing-smarts/science/legal/telemetry engine files changed by this handoff |
| Fewer than two useful live values collapse to one summary; tides retained | VERIFIED by presenter branch and Linda Mar browser exercise |
| Shared target uncertainty appears once | VERIFIED in Target browser exercise |
| Concise species rows and supported presentation only | VERIFIED in Target browser exercise |
| Compact spot-level access/legal summary; links in details | VERIFIED in Plan and details browser exercises |
| Details limited to source names, age/distance, links, and short history explanation | VERIFIED in expanded browser DOM inspection |
| Mobile-first hierarchy, controls, focus, reduced motion, overflow | VERIFIED by 390×844 headless screenshot and CSS assertions; desktop DOM measured `scrollWidth=clientWidth=1265` |
| No new features or fabricated recommendations | VERIFIED by scope review |
| Named gates | VERIFIED below |
| Independent review | VERIFIED — PASS, no blocking issues remain |

## Task-specific changed files

- `/root/bay-bite-dashboard-ux-cleanup-20260814/src/App.tsx`
  - Added the selected-spot command summary and `Now` / `Target` / `Plan` workspace.
  - Collapsed insufficient live conditions while retaining upcoming tide predictions.
  - Removed rendering of evaluator status/reason/missing-input arrays, sensor binding policy text, raw legal states, and per-species caveat stacks.
  - Added plain-language access/safety/legal summaries and closed source details.
- `/root/bay-bite-dashboard-ux-cleanup-20260814/src/App.css`
  - Added desktop map/workspace hierarchy, compact tab/view styling, progressive disclosure, mobile-first ordering/sticky summary, Deck White overrides, and retained 44 px/focus/reduced-motion/no-overflow rules.
- `/root/bay-bite-dashboard-ux-cleanup-20260814/src/presentation.test.mjs`
  - Added presenter contract assertions for the workspace, no-data branch, disclosure boundaries, raw-field prohibition, and utility naming.
- `/root/bay-bite-dashboard-ux-cleanup-20260814/src/selected-telemetry.ts`
- `/root/bay-bite-dashboard-ux-cleanup-20260814/src/selected-telemetry.test.ts`
  - Added the selected-spot telemetry guard and two runtime regression tests so stale readings/cache cannot survive a spot change.
- `/root/bay-bite-dashboard-ux-cleanup-20260814/src/workspace-navigation.ts`
- `/root/bay-bite-dashboard-ux-cleanup-20260814/src/workspace-navigation.test.ts`
  - Added runtime-tested Arrow/Home/End tab navigation with wraparound.
- `/root/bay-bite-dashboard-ux-cleanup-20260814/index.html`
  - Changed the document title from `Bay Bite Command` to `Bay Bite`.
- `/root/bay-bite-dashboard-ux-cleanup-20260814/public/manifest.webmanifest`
  - Changed install metadata from dashboard/command branding to the Bay Bite shore-fishing utility name.

The candidate workspace already contained extensive uncommitted work before this handoff. No unrelated pre-existing changes were reset, staged, committed, or claimed as part of this cleanup.

## TDD evidence

### Cycle 1 — selected-spot workspace and presenter boundary

Focused RED command:

```text
npx vitest run src/presentation.test.mjs -t "uses one selected-spot workspace with concise views and no evaluator output"
```

Observed RED, exit 1:

```text
FAIL src/presentation.test.mjs > quiet fisherman-first presentation > uses one selected-spot workspace with concise views and no evaluator output
AssertionError: expected -1 to be greater than 13103
src/presentation.test.mjs:35:23
Test Files 1 failed (1)
Tests 1 failed | 5 skipped (6)
```

Expected reason: `className="card spot-workspace"` and the required workspace behavior did not exist.

Focused GREEN command: same command after minimum presenter implementation.

Observed GREEN, exit 0:

```text
Test Files 1 passed (1)
Tests 1 passed | 5 skipped (6)
```

### Cycle 2 — installed utility naming

Focused RED command:

```text
npx vitest run src/presentation.test.mjs -t "names the installed utility Bay Bite without dashboard branding"
```

Observed RED, exit 1:

```text
AssertionError: expected index.html to contain '<title>Bay Bite</title>'
Received: '<title>Bay Bite Command</title>'
Test Files 1 failed (1)
Tests 1 failed | 6 skipped (7)
```

Focused GREEN command: same command after changing `index.html` and the web manifest.

Observed GREEN, exit 0:

```text
Test Files 1 passed (1)
Tests 1 passed | 6 skipped (7)
```

### Cycle 3 — plain-language safety labels in matching results

Focused RED command:

```text
npx vitest run src/presentation.test.mjs -t "does not render raw spot safety enums in matching results"
```

Observed RED, exit 1:

```text
AssertionError: expected App.tsx not to contain '>{spot.safety}</span>'
Test Files 1 failed (1)
Tests 1 failed | 7 skipped (8)
```

Focused GREEN command: same command after routing result labels through `plainSafetyLabel`.

Observed GREEN, exit 0:

```text
Test Files 1 passed (1)
Tests 1 passed | 7 skipped (8)
```

### Cycle 4 — compact primary access summary

Focused RED command:

```text
npx vitest run src/presentation.test.mjs -t "keeps the primary access plan compact instead of dumping the source note"
```

Observed RED, exit 1:

```text
AssertionError: expected App.tsx not to contain '<p>{selected.accessNote}</p>'
Test Files 1 failed (1)
Tests 1 failed | 8 skipped (9)
```

Focused GREEN command: same command after replacing the source note dump with a bounded `plainAccessSummary` presenter.

Observed GREEN, exit 0:

```text
Test Files 1 passed (1)
Tests 1 passed | 8 skipped (9)
```

### Cycle 5 — compact sticky access/safety state

Focused RED command:

```text
npx vitest run src/presentation.test.mjs -t "keeps the sticky access and safety state compact"
```

Observed RED, exit 1:

```text
AssertionError: expected App.tsx to contain '<strong>{plainCommandStatus(selected)}</strong>'
Test Files 1 failed (1)
Tests 1 failed | 9 skipped (10)
```

Focused GREEN command: same command after adding a short access-aware command status while retaining the fuller Plan explanation.

Observed GREEN, exit 0:

```text
Test Files 1 passed (1)
Tests 1 passed | 9 skipped (10)
```

### Cycles 6–12 — independent-review remediation

Each behavior was observed RED before implementation and GREEN after the minimum change:

1. Selected telemetry stayed atomic: focused presenter test failed, then passed after state was keyed to `spotKey` and stale state was suppressed.
2. Mobile sticky behavior: focused CSS test failed because the workspace inherited clipped overflow, then passed after `.spot-workspace { overflow: visible; }`.
3. Fixed reference tide curve: focused test found `<AreaChart>`/`tideSeries`, then passed after the generic curve was removed. Valid next-high/next-low predictions remain.
4. Technical disclosure: focused test found record-count/recommendation-policy prose, then passed with one short plain display-safety explanation.
5. Accessible tabs: focused test found no tab/panel associations or keyboard handler, then passed with IDs, `aria-controls`, `aria-labelledby`, roving focus, and Arrow/Home/End handling.
6. Runtime telemetry guard: `src/selected-telemetry.test.ts` first failed to import the absent module, then 2 tests passed after implementation.
7. Runtime tab navigation: `src/workspace-navigation.test.ts` first failed to import the absent module, then 2 tests passed after implementation.
8. Persistent tab-panel association: review found that inactive tabs referenced absent panels; a focused test first failed (0 of 3 tabs referenced the persistent panel), then passed after all tabs targeted the always-present `#workspace-panel`.

## Final required gates

All commands ran independently in `/root/bay-bite-dashboard-ux-cleanup-20260814` after the final source changes.

### `npm test` — exit 0

```text
Test Files  26 passed (26)
Tests       173 passed (173)
Duration    9.15s
```

### `npm run lint` — exit 0

```text
Found 0 warnings and 0 errors.
Finished in 22ms on 56 files with 104 rules using 2 threads.
```

### `npm run build` — exit 0

```text
vite v8.2.1 building client environment for production...
1855 modules transformed.
dist/index.html                     0.56 kB │ gzip:   0.33 kB
dist/assets/index-CUhX56wG.css     32.16 kB │ gzip:  10.49 kB
dist/assets/index-asWowkxU.js   1,697.51 kB │ gzip: 224.40 kB
built in 531ms
```

Build advisory retained: the main JavaScript chunk is larger than 500 kB after minification. This is a pre-existing nonblocking bundle-size risk, not a new functional failure.

### `npm run catalog:check` — exit 0

```text
Catalog artifact verified: 101 accepted, 30 excluded, 25 sensors, 520 accepted edges.
```

### `npm run client:check` — exit 0

```text
Built client verified: 101 accepted spots; all 30 excluded IDs and names absent.
```

### `git diff --check` — exit 0

```text
(no output)
```

### Added-line security pattern scan — exit 0

No hardcoded secret assignment, shell-injection, `eval`/`exec`, or unsafe deserialization pattern was found in added lines for the task presenter files.

## Browser and responsive exercise

A local-only Vite preview was exercised on loopback. No public endpoint or production process was touched.

Desktop exercise:

- HTTP preview returned 200.
- Map/search and selected-spot workspace rendered side-by-side.
- `Now`, `Target`, and `Plan` switched in place; focusing `Now` and pressing `ArrowRight` moved selection/focus to `Target`, whose associated panel was exposed as `tabpanel "Target"`. Final DOM inspection confirmed all three tabs' `aria-controls="workspace-panel"` references resolve to an existing element.
- Linda Mar `Target` displayed seven concise history rows and one shared uncertainty explanation.
- `Plan` displayed one spot-level access/safety/license summary.
- Searching `9th Street Pier, Benicia` atomically changed the selected heading, conditions/tide summary, access/safety summary, directions, and active Plan content.
- Expanded details showed plain condition source names, update age/distance when available, official links, and one local-history explanation; no raw arrays, IDs, evaluator reasons, or policy state tokens appeared.
- Browser console: zero console messages and zero JavaScript errors during the primary exercise.
- Rendered DOM banned-vocabulary scan: zero matches.
- Desktop overflow measurement: `scrollWidth=1265`, `clientWidth=1265`.

Mobile exercise:

- Exact final-state screenshot size: 390×844 (`/tmp/bay-bite-mobile-final.png`, local QA artifact).
- Final post-build preview returned HTTP 200 on loopback.
- First viewport prioritized Bay Bite, selected Linda Mar identity, limited-data state, tide status, access/safety state, directions, and the three view tabs.
- No visible clipping, overlap, horizontal overflow, or illegible control text was observed.
- The map/search remains available immediately after the selected workspace in the mobile document flow.

## Architecture and safety decision

The smallest change was selected: keep all evaluator, scientific, legal, cache-ingestion, and telemetry semantics intact and replace only the presenter hierarchy and copy. No dependency, API, persistence, data model, recommendation engine, or deployment architecture changed. The two small pure helpers isolate selected-state and keyboard behavior for runtime verification.

## Remaining risks

1. The main bundle remains about 1.70 MB minified / 224 kB gzip and triggers Vite's >500 kB advisory.
2. Browser QA exercised deterministic/current local cache content, not live upstream provider health.
3. The 390×844 mobile check is a local headless screenshot plus existing CSS assertions, not independent device-lab certification.
4. Existing source-owned safety details remain in `Plan`; the presenter caps the primary list at two items and keeps authoritative links in details.

## Protected-boundary statement

Production was untouched. Specifically, this work did not alter `/root/bay-bite-dashboard`, `/srv/bay-bite`, systemd services, tunnels, production files/processes, git remotes, or external systems. No deployment, commit, push, publication, spending, account action, or production restart occurred.

## Independent review

Final delegated verdict: **PASS — no blocking issues remain.**

The reviewer independently confirmed that all three tabs resolve to the persistent workspace panel, the panel label tracks the active tab, and this association is regression-tested. The reviewer also confirmed that this evidence report reflects all 9 task-specific files and final gate totals.

Independently rerun by the reviewer:

- `npm test`: PASS — 26 files, 173 tests.
- `npm run lint`: PASS — 0 warnings, 0 errors.
- `npm run build`: PASS — bundle-size advisory only.
- `npm run catalog:check`: PASS.
- `npm run client:check`: PASS.
- `git diff --check`: PASS.
- Banned-language scan: PASS.
- Task diff reverse-apply integrity check: PASS.
