# Bay Bite Existing-Function Polish — TDD Evidence

Date: 2026-08-13
Owner: Dr. Elias Forge
Repository: `/root/bay-bite-dashboard`
Scope: bounded existing-function polish/debug only; no deploy, service restart, `/srv`, systemd, Brain edit during implementation, commit, or push.

## Acceptance matrix

| Gate | Status | Evidence |
|---|---|---|
| Selection reconciliation preserves explicit visible selection and auto-selects sole exact result | pending | Focused RED/GREEN required |
| Eckley canonical coordinate corrected; precision status reaches runtime/UI/navigation | pending | Focused RED/GREEN + generator check required |
| Primary UI removes specified internal/promotional terms and uses progressive disclosure | pending | Focused RED/GREEN required |
| Existing filters, favorites, map, links, live data, tide, legal/access/source/species/PWA behavior retained | pending | Full tests/build/browser smoke required |
| Species/conditions primary presentation simplified without weakening evaluators/data | pending | Presentation RED/GREEN + smoke required |
| Telemetry time-sensitive failure fixed at root cause without stale/future weakening | pending | Existing deterministic RED + focused GREEN required |
| Full test, catalog:check, lint, build, client:check, diff check | pending | Final gate transcript required |
| Desktop + exact 390×844 smoke, no console errors/overflow, coherent Eckley selection | pending | Browser evidence required |
| Independent review | pending | Reviewer verdict required |

## Baseline and root-cause evidence

### Baseline full suite — RED

Command:

```text
npm test -- --reporter=verbose
```

Observed: exit 1; 20 files, 153 tests; 152 passed, 1 failed. Exact failure: `src/telemetry.test.ts:199`, `snapshot.nextHigh` was `undefined` while the test expected `/7:00 PM/`.

Invocation clock: `2026-08-13T23:06:55-04:00`. The fixture's only high prediction is `2026-08-14T02:00:00.000Z` (10:00 PM local), already earlier than the real invocation time (03:06Z on Aug 14). Production `telemetryFromCache` correctly chooses predictions strictly later than its clock. Root cause is the test omitting the injectable `currentNow`, making a time-relative assertion expire; stale/future acceptance semantics are not implicated and must not be relaxed.

### Selection mismatch root cause

`selectedId` is independent React state. `filteredSpots` changes from search/filter controls, but `selected` is resolved from the full `spots` array (`spots.find(...)`) with no reconciliation. Therefore a nonempty filtered set can display markers for one location while live conditions/detail remain on an out-of-set prior selection.

### Coordinate truth root cause

The canonical source gives every one of 131 source records the same centroid precision string. Eckley is stored at `38.041,-122.228`; that value is copied by the generator into the runtime artifact and repeated in the physical-profile text, weather resolver, and iNaturalist radius query. Runtime `Spot` drops coordinate precision entirely, and Google Maps always uses raw coordinates, so approximate centroids are presented as exact navigation points.

### Presentation root cause

`App.tsx` renders engineering/certification diagnostics directly in the primary hierarchy, while the mobile hero remains a large marketing surface. Technical provenance exists but is not grouped under a single progressive-disclosure boundary; repeated evaluator safety/missing-input detail dominates the angler task.

## RED→GREEN cycles

### 1. Selection reconciliation

RED command:

```text
npm test -- src/selection.test.ts --reporter=verbose
```

Observed behavioral RED: exit 1; 1 of 3 tests failed. Expected `eckley-pier`, received stale `linda-mar`. (The first import run also failed because the wished-for helper module did not yet exist; a compile-only identity stub was added, then the command was rerun to capture the required behavioral RED.)

GREEN command: same command. Observed: exit 0; 1 file, 3/3 tests passed. The pure helper now preserves an explicit visible marker/card selection, selects the first member whenever a nonempty filtered set excludes the current selection, and preserves selection across an empty result set. `App` immediately derives selected detail from the reconciled ID and synchronizes state in an effect; it does not move focus.

### 2. Coordinate correction and precision truth

Coordinate RED:

```text
npm test -- src/coordinate-regression.test.ts --reporter=verbose
```

Observed: exit 1; 3/3 tests failed. Runtime Eckley was `38.041,-122.228` with no status; canonical/generated records retained the wrong coordinate; runtime had zero approximate statuses.

Coordinate GREEN:

```text
npm run generate:catalog && npm test -- src/coordinate-regression.test.ts --reporter=verbose
```

Observed: exit 0. Generator emitted 101 accepted / 30 excluded / 25 sensors / 520 edges; focused suite passed 3/3. Canonical and generated Eckley now use `38.0542059,-122.2015829`; physical text, weather resolver, and 5 km iNaturalist query match. NOAA official metadata was read for bound sensor coordinates; recalculated haversine distances are 7.0 km (9415102), 7.0 km (s06010), and 5.1 km (9415141). Source records remaining approximate: 130/131; accepted runtime spots remaining approximate: 100/101.

Navigation RED:

```text
npm test -- src/navigation.test.ts --reporter=verbose
```

Observed: exit 1; exact-coordinate behavior passed, approximate-centroid behavior failed because the URL exposed raw centroid coordinates.

Popup RED:

```text
npm test -- src/popup-content.test.ts --reporter=verbose
```

Observed: exit 1; 2/3 failed because marker copy still exposed the engineering phrase and did not label an approximate location.

Navigation/popup GREEN:

```text
npm test -- src/navigation.test.ts src/popup-content.test.ts --reporter=verbose
```

Observed: exit 0; 2 files, 5/5 tests passed. Exact Eckley navigation uses its corrected coordinate; approximate spots use a Google Maps place-name search without centroid coordinates. Popup and selected summary disclose approximation plainly.

### 3. Fisherman-first presentation

RED command:

```text
npm test -- src/presentation.test.mjs --reporter=verbose
```

Observed: exit 1; 4/6 tests failed. The specified internal/promotional phrases were present; the requested map→selected→conditions→species→access hierarchy and single disclosure were absent; species scopes were absent; mobile overflow/touch/motion requirements were absent.

GREEN command: same command after the bounded App/CSS presentation pass. Observed: exit 0; 1 file, 6/6 tests passed. The giant hero and promotional bottom sections were removed. A compact nautical field header, first-task map/search, synchronized selected summary, concise conditions, readable species history scopes, access/safety, tide chart, one collapsed technical/source area, and matching-spot cards now form the primary hierarchy. Existing map/filter/favorite/navigation/live/tide/legal/source/species/PWA wiring is asserted. CSS adds 44px controls, visible focus, overflow containment, a single restrained transition system, exact 390px-class mobile layout, reduced-motion handling, and dark/Deck White surfaces.

A subsequent build probe initially exposed accidental line-number prefixes introduced while reconstructing `App.tsx` through a paginated read. The file was repaired from its raw bytes and the build rerun successfully; no behavior claim was based on the malformed intermediate file.

### 4. Deterministic telemetry fixture

The full-suite baseline was the required RED. Root cause: the test called the injectable-clock adapter without supplying its fixture time, so the real invocation time had passed the only prediction. Production correctly rejected the now-past prediction.

GREEN command:

```text
npm test -- src/telemetry.test.ts --reporter=verbose
```

Observed: exit 0; 1 file, 15/15 tests passed. Only the test invocation now supplies `2026-08-13T18:00:00.000Z`; production prediction ordering, future checks, cache-clock skew, observed-time age recomputation, and stale suppression are unchanged.

### 5. Aggregate telemetry includes absent displayed temperature

RED command:

```text
npm test -- src/telemetry.test.ts -t "marks the summary partial when a displayed temperature binding is absent" --reporter=verbose
```

Observed: exit 1; 1 test failed, 16 skipped. Exact failure: expected status `partial`, received `live`; `observations.temperature` was unavailable. Root cause: both aggregate call sites removed absent products with `.filter(Boolean)`, even though `metadata(undefined)` already represents an absent requested product truthfully as unavailable. Explicit unavailable products were retained and already produced `partial`.

GREEN command: same command after changing `aggregate` to accept `undefined` products and removing the two pre-aggregate filters. Observed: exit 0; 1 test passed, 16 skipped. No test was weakened or removed.

Focused telemetry command:

```text
npm test -- src/telemetry.test.ts --reporter=verbose
```

Observed: exit 0; 1 file, 17/17 tests passed, including absent and explicit-unavailable temperature, delayed/stale age recomputation, invalid/future clocks, and TTL suppression.

## Final narrow-follow-up gates

- `npm test -- --reporter=verbose` — exit 0; 23 files, 156/156 tests passed.
- `npm run lint` — exit 0; 51 files, 0 warnings, 0 errors.
- `npm run build` — exit 0; TypeScript and Vite production build passed; 2,427 modules transformed. Vite retained its non-failing >500 kB chunk advisory.
- `npm run catalog:check` — exit 0; 101 accepted, 30 excluded, 25 sensors, 520 accepted edges verified.
- `npm run client:check` — exit 0; 101 accepted spots verified; all 30 excluded IDs and names absent.
- `git diff --check` — exit 0; no whitespace errors.
- Independent review — passed; no security concerns or logic errors. Non-blocking suggestion: add a table-driven aggregate-precedence test in a future authorized scope.

No preview, deployment, service, coordinate, catalog-source, UX, or Brain action was performed.

## Narrow accessibility state follow-up

Scope remained programmatic accessibility polish only. Region and species controls in the final candidate are native `<select>` elements, not buttons; their selected values remain exposed by the platform. Every existing button-based mode filter now exposes `aria-pressed`.

### RED→GREEN cycles

1. **Mode filter state**
   - RED: `npm test -- src/accessibility-state.test.mjs --reporter=verbose` — exit 1; expected the mode-button mapping to expose `aria-pressed={mode === item}`.
   - GREEN: same command after the minimal mode-button attribute — exit 0; 1/1 passed.
2. **Favorite state**
   - RED: `npm test -- src/accessibility-state.test.mjs -t "exposes whether the selected spot is a favorite" --reporter=verbose` — exit 1; expected `aria-pressed={favorites.has(selected.id)}`.
   - GREEN: same command after the minimal favorite-button attribute — exit 0; 1 passed, 1 skipped.
3. **Matching-card selection state**
   - RED: `npm test -- src/accessibility-state.test.mjs -t "exposes the selected matching-spot card" --reporter=verbose` — exit 1; expected selected cards to expose `aria-pressed={spot.id === selected.id}`.
   - GREEN: same command after the minimal matching-card attribute — exit 0; 1 passed, 2 skipped.
4. **Leaflet div-icon marker name/state**
   - RED: `npm test -- src/accessibility-state.test.mjs -t "names Leaflet marker buttons" --reporter=verbose` — exit 1; the marker lacked the expected human-readable label and selected-state wiring.
   - GREEN: same command after using supported Leaflet `title`, `alt`, and `keyboard` marker options plus `role`, `aria-label`, and `aria-pressed` element attributes synchronized on the marker `add` event — exit 0; 1 passed, 3 skipped. Spot data was not interpolated into div-icon HTML; popup binding and marker clustering were unchanged.

Final focused command:

```text
npm test -- src/accessibility-state.test.mjs --reporter=verbose
```

Observed: exit 0; 1 file, 4/4 tests passed.

### Final gates

- `npm test -- --reporter=verbose` — exit 0; 24 files, 160/160 tests passed.
- `npm run lint` — exit 0; 52 files, 0 warnings, 0 errors.
- `npm run catalog:check` — exit 0; 101 accepted, 30 excluded, 25 sensors, 520 accepted edges verified.
- `npm run build` — exit 0; TypeScript and Vite production build passed; 2,427 modules transformed. Existing non-failing >500 kB chunk advisory remains.
- `npm run client:check` — exit 0; 101 accepted spots verified; all 30 excluded IDs and names absent.
- `git diff --check` — exit 0; no whitespace errors.
- Narrow static scan of `src/App.tsx` and `src/accessibility-state.test.mjs` — no secret, injection, unsafe DOM, or dangerous execution patterns found.

### Independent review

Independent fresh-context review passed with no security concerns and no logic errors. The reviewer verified supported Leaflet 1.9.4 marker options/element APIs, markercluster re-add compatibility, unchanged popup binding, textContent-based popup construction, no spot-data interpolation into div-icon HTML, and reran focused popup/accessibility tests (7/7), lint, and diff checks. Non-blocking suggestions were a future runtime DOM marker test, an explicit marker-specific focus rule, and documenting that Leaflet `alt` applies only to image icons while the div icon is named through `aria-label`.

No preview, deployment, service, Brain, data, coordinate, telemetry, catalog, commit, or push action was performed.

