import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const app = readFileSync(new URL('./App.tsx', import.meta.url), 'utf8');
const css = readFileSync(new URL('./App.css', import.meta.url), 'utf8');
const config = readFileSync(new URL('../vite.config.ts', import.meta.url), 'utf8');
const manifest = JSON.parse(readFileSync(new URL('../public/manifest.webmanifest', import.meta.url), 'utf8'));

const primaryForbidden = [
  'API-ready',
  'Export report JSON',
  'Sample species model',
  'Relative opportunity engine',
  'Current legality · fail closed',
  'evidence:',
  'Missing dimensions',
  'Research-backed spot expansion',
  'PWA offline cache',
  'Prototype science coverage'
];

describe('quiet fisherman-first presentation', () => {
  it('removes internal, promotional, and coding language from the App source', () => {
    for (const phrase of primaryForbidden) expect(app).not.toContain(phrase);
    expect(app).not.toMatch(/raw evidence|TTL|representativeness/i);
  });

  it('uses the requested field hierarchy with one progressive-disclosure area', () => {
    expect(app).toContain('className="field-header"');
    expect(app).toContain('Bay Bite');
    expect(app).toContain('Data updated');
    const map = app.indexOf('id="fishing-map"');
    const selected = app.indexOf('id="selected-spot"');
    const conditions = app.indexOf('id="live-conditions"');
    const species = app.indexOf('Species reported here/nearby');
    const access = app.indexOf('Access & safety');
    expect(map).toBeGreaterThan(0);
    expect(selected).toBeGreaterThan(map);
    expect(conditions).toBeGreaterThan(selected);
    expect(species).toBeGreaterThan(conditions);
    expect(access).toBeGreaterThan(species);
    expect(app).toContain('<summary>Details / How we know</summary>');
    expect((app.match(/className="card how-we-know"/g) ?? [])).toHaveLength(1);
  });

  it('keeps existing field functions wired', () => {
    for (const token of [
      '<MapContainer', 'ClusteredMarkers', 'value={query}', 'setMode', 'setRegion', 'setSpecies',
      'toggleFavorite', 'googleMapsUrl(selected)', 'useLiveTelemetry(selected)', '<AreaChart',
      'currentSpotLegality(selected)', 'selected.sourceLinks', 'selected.evidenceEdges', 'selected.sensorBindings'
    ]) expect(app).toContain(token);
    expect(manifest.display).toBe('standalone');
  });

  it('shows concise evidence scope and keeps diagnostics collapsed', () => {
    expect(app).toContain('Reported at this spot');
    expect(app).toContain('Reported nearby');
    expect(app).toContain('No reviewed history yet');
    expect(app).toContain('Condition source details');
    expect(app).toContain('Regulations and source links');
    expect(app).toContain('History and model details');
    expect(app).not.toContain('Safety blocked. Opportunity and presentations are suppressed.');
  });

  it('keeps same-origin telemetry refresh and client security boundaries', () => {
    expect(app).not.toContain('api.tidesandcurrents.noaa.gov');
    expect(app).not.toContain('https://www.ndbc.noaa.gov/data/realtime2/');
    expect(app).toContain("fetch(`/data/live-status.json?ts=${Date.now()}`");
    expect(app).toContain("cache: 'no-store'");
    expect(app).toContain('formatDataDate(liveCache?.generatedAt)');
    expect(app).not.toContain('const [liveRefresh');
    expect(config).not.toContain('allowedHosts: true');
  });

  it('provides mobile field ergonomics, restrained motion, and theme contrast hooks', () => {
    expect(css).toMatch(/body\s*\{[^}]*overflow-x:\s*hidden/i);
    expect(css).toMatch(/button[^}]*min-height:\s*44px/i);
    expect(css).toMatch(/\.search-box input[^}]*min-height:\s*44px/i);
    expect(css).toMatch(/@media \(prefers-reduced-motion:\s*reduce\)/i);
    expect(css).toMatch(/@media \(max-width:\s*640px\)[\s\S]*\.map-wrap\s*\{[^}]*height:\s*3[0-9]{2}px/i);
    expect(css).toMatch(/\.deck-white \.card\s*\{[^}]*background:\s*#fff/i);
    expect(app).not.toContain('className="hero"');
  });
});
