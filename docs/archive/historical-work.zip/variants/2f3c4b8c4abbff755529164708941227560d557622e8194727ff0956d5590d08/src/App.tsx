import './research-catalog.css';
import { useEffect, useMemo, useState } from 'react';
import { Circle, MapContainer, TileLayer, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { AlertTriangle, BarChart3, Compass, Download, ExternalLink, Fish, MapPin, Search, ShieldAlert, ShipWheel, Star, Sun, Waves, WifiOff } from 'lucide-react';
import { allSpecies, isActionableSpot, regions, researchSources, safetyColor, spotCountLabel, spots, tideSeries, type Region, type Species, type Spot } from './data';
import { currentSpotLegality, rankableSpeciesForSpot } from './fishing-smarts/app-integration';
import { buildScientificStatusExport, buildSelectedWaterOpportunity, occurrenceEvidenceOverlays, overlaySourceTitle } from './fishing-smarts/selected-water-opportunity';
import { telemetryFromBindings, type LiveTelemetry, type ObservationMeta } from './telemetry';
import { buildSpotPopup } from './popup-content';

type SpotMode = 'All' | 'Favorites' | 'Surf' | 'Pier/Jetty' | 'Bay Shore' | 'Hazard Watch';
type SortMode = 'name' | 'region';

function formatDataDate(value?: string) {
  if (!value) return 'Waiting for live refresh';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'Live refresh unavailable' : date.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}

function observationMeta(observation: ObservationMeta) {
  const binding = [observation.representativeness, observation.distanceKm === undefined ? undefined : `${observation.distanceKm} km`, observation.maxAgeMinutes === undefined ? undefined : `TTL ${observation.maxAgeMinutes} min`, observation.warning].filter(Boolean).join(' · ');
  if (observation.availability === 'unavailable') return `Unavailable · ${observation.reason ?? 'No valid observation'}${binding ? ` · ${binding}` : ''}`;
  return `${observation.freshness}${observation.lastKnownGood ? ' · last known good' : ''} · ${observation.ageMinutes} min old · ${formatDataDate(observation.observedAt)} · ${observation.stationId} ${observation.stationName}${binding ? ` · ${binding}` : ''}`;
}

function makeIcon(_spot: Spot, isSelected: boolean) {
  const color = '#67e8f9';
  const size = isSelected ? 28 : 20;
  const stroke = isSelected ? '#ffffff' : 'rgba(255,255,255,0.75)';
  const shadow = isSelected ? `0 0 0 3px rgba(103,232,249,0.9), 0 0 30px ${color}` : `0 0 0 2px ${stroke}, 0 0 20px ${color}`;

  return L.divIcon({
    className: '',
    html: `<div class="marker-dot" style="width:${size}px;height:${size}px;color:${color};background:${color};border-color:${stroke};box-shadow:${shadow}"></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2]
  });
}

function MapController({ selectedSpot, visibleSpots }: { selectedSpot: Spot; visibleSpots: Spot[] }) {
  const map = useMap();

  useEffect(() => {
    const timer = setTimeout(() => map.invalidateSize(), 100);
    return () => clearTimeout(timer);
  }, [map]);

  useEffect(() => {
    if (!selectedSpot) return;
    const currentZoom = map.getZoom();
    const targetZoom = Math.max(currentZoom, 11);
    map.flyTo([selectedSpot.lat, selectedSpot.lng], targetZoom, {
      duration: 0.6,
      easeLinearity: 0.25
    });
  }, [map, selectedSpot]);

  useEffect(() => {
    if (!visibleSpots.length) return;
    if (visibleSpots.length === spots.length) return;

    const bounds = L.latLngBounds(visibleSpots.map(s => [s.lat, s.lng]));
    map.fitBounds(bounds, { padding: [40, 40], maxZoom: 13, animate: true, duration: 0.6 });
  }, [map, visibleSpots]);

  return null;
}

function ClusteredMarkers({
  visibleSpots,
  selectedId,
  onSelect
}: {
  visibleSpots: Spot[];
  selectedId: string;
  onSelect: (id: string) => void;
}) {
  const map = useMap();

  useEffect(() => {
    const clusterGroup = L.markerClusterGroup({
      showCoverageOnHover: false,
      maxClusterRadius: 35,
      spiderfyOnMaxZoom: true,
      zoomToBoundsOnClick: true,
      animate: true,
      iconCreateFunction: (cluster) => {
        const count = cluster.getChildCount();
        return L.divIcon({
          html: `<div class="custom-cluster">${count}</div>`,
          className: '',
          iconSize: [36, 36]
        });
      }
    });

    visibleSpots.forEach((spot) => {
      const isSelected = spot.id === selectedId;
      const marker = L.marker([spot.lat, spot.lng], { icon: makeIcon(spot, isSelected) });

      const popupContent = buildSpotPopup(document, spot) as unknown as HTMLElement;

      marker.bindPopup(popupContent, {
        closeButton: false,
        className: 'leaflet-popup-custom'
      });

      marker.on('click', () => {
        onSelect(spot.id);
      });

      clusterGroup.addLayer(marker);
    });

    map.addLayer(clusterGroup);

    return () => {
      map.removeLayer(clusterGroup);
    };
  }, [map, visibleSpots, selectedId, onSelect]);

  return null;
}

function useLiveTelemetry(spot: Spot): LiveTelemetry {
  const [telemetry, setTelemetry] = useState<LiveTelemetry>({
    status: 'loading',
    stationName: spot.tideStation,
    buoyId: 'Unavailable',
    waveLabel: 'Significant wave height',
    observations: { level: { availability: 'unavailable', freshness: 'unavailable' }, wind: { availability: 'unavailable', freshness: 'unavailable' }, buoy: { availability: 'unavailable', freshness: 'unavailable' }, wave: { availability: 'unavailable', freshness: 'unavailable' }, temperature: { availability: 'unavailable', freshness: 'unavailable' } },
    message: 'Loading the server-cached ocean snapshot…'
  });

  useEffect(() => {
    const controller = new AbortController();
    const refresh = () => fetch(`/data/live-status.json?ts=${Date.now()}`, { signal: controller.signal, cache: 'no-store' })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error(`live cache ${response.status}`)))
      .then((cache) => setTelemetry(telemetryFromBindings(cache, spot.sensorBindings, spot.name)))
      .catch(() => { if (!controller.signal.aborted) setTelemetry(telemetryFromBindings(undefined, spot.sensorBindings, spot.name)); });

    setTelemetry({ status: 'loading', stationName: spot.name, buoyId: 'Unavailable', waveLabel: 'Significant wave height', observations: { level: { availability: 'unavailable', freshness: 'unavailable' }, wind: { availability: 'unavailable', freshness: 'unavailable' }, buoy: { availability: 'unavailable', freshness: 'unavailable' }, wave: { availability: 'unavailable', freshness: 'unavailable' }, temperature: { availability: 'unavailable', freshness: 'unavailable' } }, message: 'Loading server-cached NOAA & NDBC telemetry…' });
    void refresh();
    const interval = setInterval(refresh, 60_000);
    const onVisible = () => { if (!document.hidden) void refresh(); };
    const onFocus = () => void refresh();
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onFocus);

    return () => { controller.abort(); clearInterval(interval); document.removeEventListener('visibilitychange', onVisible); window.removeEventListener('focus', onFocus); };
  }, [spot.id, spot.name, spot.sensorBindings]);

  return telemetry;
}

function getRegulationNotes(spot: Spot) {
  const notes: string[] = [];
  if (['Pier', 'Jetty', 'Breakwater'].includes(spot.type)) notes.push('CDFW public-pier-style access may not require a license only on qualifying public structures; all size, bag, season, and gear rules still apply.');
  else notes.push('Shore/beach fishing generally requires a valid California fishing license.');
  if (spot.accessNote.toLowerCase().includes('closed')) notes.push('Closure warning: verify current pier/park status before driving.');
  if (spot.species.includes('Sturgeon')) notes.push('Sturgeon status changes often and retention has been closed in recent SF Bay rules — check CDFW before targeting.');
  if (spot.species.includes('Dungeness Crab')) notes.push('Dungeness crab seasons/closures and health advisories change; verify current CDFW/OEHHA status.');
  if (spot.safety === 'Hazard') notes.push('Hazard spot: treat swell, rocks, cliffs, and sneaker waves as go/no-go criteria, not background details.');
  return notes;
}


function googleMapsUrl(spot: Spot) {
  return `https://www.google.com/maps/search/?api=1&query=${spot.lat},${spot.lng}`;
}

function App() {
  const [region, setRegion] = useState<Region | 'All'>('All');
  const [species, setSpecies] = useState<Species | 'All'>('All');
  const [mode, setMode] = useState<SpotMode>('All');
  const [sortMode, setSortMode] = useState<SortMode>('name');
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState('linda-mar');
  const [showAllRanked, setShowAllRanked] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(() => new Set(JSON.parse(localStorage.getItem('bay-bite-favorites') || '[]')));
  const [deckWhite, setDeckWhite] = useState(false);
  const [liveRefresh, setLiveRefresh] = useState<string>();
  const [showEvidenceOverlay, setShowEvidenceOverlay] = useState(false);

  useEffect(() => {
    fetch('/data/live-status.json', { cache: 'no-store' })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('live status unavailable')))
      .then((payload) => setLiveRefresh(payload.generatedAt))
      .catch(() => setLiveRefresh(undefined));
  }, []);

  const filteredSpots = useMemo(() => {
    const q = query.trim().toLowerCase();
    return spots.filter((spot) => {
      const regionOk = region === 'All' || spot.region === region;
      const speciesOk = species === 'All' || spot.species.includes(species);
      const modeOk =
        mode === 'All' ||
        (mode === 'Favorites' && favorites.has(spot.id)) ||
        (mode === 'Surf' && spot.type === 'Surf') ||
        (mode === 'Pier/Jetty' && ['Pier', 'Jetty', 'Breakwater'].includes(spot.type)) ||
        (mode === 'Bay Shore' && ['Bay Shore', 'Marina'].includes(spot.type)) ||
        (mode === 'Hazard Watch' && spot.safety !== 'Green');
      const searchOk = !q || [spot.name, spot.region, spot.type, spot.tideStation, ...spot.species, spot.accessNote].join(' ').toLowerCase().includes(q);
      return regionOk && speciesOk && modeOk && searchOk;
    });
  }, [region, species, mode, query, favorites]);

  const sortedSpots = useMemo(() => {
    return [...filteredSpots].sort((a, b) => {
      if (sortMode === 'name') return a.name.localeCompare(b.name);
      if (sortMode === 'region') return a.region.localeCompare(b.region) || a.name.localeCompare(b.name);
      return a.name.localeCompare(b.name);
    });
  }, [filteredSpots, sortMode]);

  const selected = spots.find((spot) => spot.id === selectedId) ?? spots[0];
  const actionableSpots = sortedSpots.filter((spot) => isActionableSpot(spot) && rankableSpeciesForSpot(spot).length > 0);
  const rankedSpots = actionableSpots.slice(0, showAllRanked ? 40 : 12);

  const telemetry = useLiveTelemetry(selected);
  const legalItems = currentSpotLegality(selected);
  const scientificOpportunity = buildSelectedWaterOpportunity(selected, telemetry);
  const selectedOverlays = occurrenceEvidenceOverlays.filter((overlay) => overlay.spotId === selected.stableId);
  const regulationNotes = getRegulationNotes(selected);



  function toggleFavorite(id: string) {
    const next = new Set(favorites);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setFavorites(next);
    localStorage.setItem('bay-bite-favorites', JSON.stringify([...next]));
  }

  function downloadReport() {
    const payload = buildScientificStatusExport(selected, telemetry);
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bay-bite-daily-report.json';
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className={`app-shell ${deckWhite ? 'deck-white' : ''}`}>
      <section className="hero">
        <div className="hero-overlay">
          <nav className="nav">
            <div className="brand">
              <div className="logo"><ShipWheel size={24} /></div>
              <div>
                <div>Bay Bite Command</div>
                <div className="muted small">Greater Bay Area shore intel</div>
              </div>
            </div>
            <div className="nav-pills">
              <span className="pill date-pill">Live data: {formatDataDate(liveRefresh)}</span>
              <span className="pill">{spotCountLabel(spots)}</span>
              <span className="pill">NOAA & NDBC telemetry status</span>
              <span className="pill">Sample species model</span>
              <span className="pill">Captain Salty Pete</span>
              <button className="pill pill-button" onClick={() => setDeckWhite(!deckWhite)}><Sun size={14} /> {deckWhite ? 'Dark deck' : 'Deck White'}</button>
            </div>
          </nav>
          <div className="kicker">Sample fishing outlook · not a live forecast</div>
          <h1>Know the tide. Find the bite. Fish the Bay smarter.</h1>
          <p className="hero-sub">A shore-fishing command center that keeps historical occurrence, ecology, live conditions, and legal targetability separate.</p>
          <div className="hero-actions">
            <button className="ghost" onClick={downloadReport}><Download size={18} /> Export report JSON</button>
          </div>
          <nav className="mobile-quick-nav" aria-label="Field quick navigation">
            <a href="#fishing-map"><MapPin size={15} /> Map & search</a>
            <a href="#live-conditions"><Waves size={15} /> Live conditions</a>
            <a href="#selected-water"><Compass size={15} /> Selected spot</a>
          </nav>
        </div>
      </section>

      <section className="dashboard">
        <div className="card map-card" id="fishing-map">
          <div className="card-header stacked-header">
            <div>
              <h2 className="card-title"><MapPin size={20} /> Interactive fishing map</h2>
              <span className="muted small">{filteredSpots.length}/{spots.length} spots · researched + API-ready</span>
            </div>
            <div className="search-box">
              <Search size={16} />
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search spots, species, regions…" />
            </div>
          </div>

          <div className="mode-row">
            {(['All', 'Favorites', 'Surf', 'Pier/Jetty', 'Bay Shore', 'Hazard Watch'] as SpotMode[]).map((m) => (
              <button key={m} className={`mode-chip ${mode === m ? 'active' : ''}`} onClick={() => setMode(m)}>{m}</button>
            ))}
            <select className="sort-select" value={sortMode} onChange={(event) => setSortMode(event.target.value as SortMode)} aria-label="Sort spots">
              <option value="region">Sort by region</option>
              <option value="name">Sort by name</option>
            </select>
          </div>

          <div className="filters compact-filters">
            {(['All', ...regions] as const).map((r) => (
              <button key={r} className={`filter ${region === r ? 'active' : ''}`} onClick={() => setRegion(r)}>{r === 'All' ? 'All regions' : r}</button>
            ))}
          </div>
          <div className="filters compact-filters species-filter-row">
            {(['All', ...allSpecies] as const).map((s) => (
              <button key={s} className={`filter ${species === s ? 'active' : ''}`} onClick={() => setSpecies(s)}>{s === 'All' ? 'All species' : s}</button>
            ))}
          </div>
          <div className="map-wrap">
            <MapContainer center={[37.73, -122.36]} zoom={9} scrollWheelZoom style={{ height: '100%', width: '100%' }}>
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <ClusteredMarkers visibleSpots={filteredSpots} selectedId={selected.id} onSelect={setSelectedId} />
              {showEvidenceOverlay && selectedOverlays.map((overlay) => <Circle key={overlay.id} center={overlay.geometry.center} radius={overlay.geometry.radiusMeters} pathOptions={{ color: overlay.confidence === 'medium' ? '#67e8f9' : '#facc15', fillOpacity: 0.1, weight: 2 }} />)}
              <MapController selectedSpot={selected} visibleSpots={filteredSpots} />
            </MapContainer>
          </div>
          <div className="overlay-control">
            <button className={`mode-chip ${showEvidenceOverlay ? 'active' : ''}`} aria-pressed={showEvidenceOverlay} onClick={() => setShowEvidenceOverlay(!showEvidenceOverlay)}>Show occurrence evidence overlays</button>
            <span className="muted small">Historical occurrence areas — not habitat polygons or live fish locations.</span>
          </div>
          {showEvidenceOverlay && selectedOverlays.length > 0 && <div className="overlay-legend" role="note">{selectedOverlays.map((overlay) => <div key={overlay.id}><strong>{overlay.taxonId.replace('species:','').replaceAll('-',' ')}</strong> · {overlay.evidenceAgeLabel} · {overlay.method} · {overlay.confidence} confidence · {overlay.geometry.publicResolution}<br/><span>{overlay.legend} Source: {overlaySourceTitle(overlay.sourceId)}</span></div>)}</div>}
        </div>

        <aside className="side-stack">

          <div className="card" id="live-conditions">
            <div className="card-header">
              <h2 className="card-title"><Compass size={20} /> Selected water live conditions</h2>
            </div>
            <div className="conditions-command" aria-live="polite">
              <div className="source-health"><span className={`health-dot ${telemetry.status}`} /> {selected.name} · {telemetry.status}</div>
              <div className="grid-2">
                <div className="metric"><div className="metric-label">Observed · Water level</div><div className="metric-value">{telemetry.waterLevelFt || 'Unavailable'}</div><div className="observation-meta">{observationMeta(telemetry.observations.level)}</div></div>
                <div className="metric"><div className="metric-label">Observed · Wind / gust</div><div className="metric-value">{[telemetry.windDir, telemetry.windSpeedKt].filter(Boolean).join(' ') || 'Unavailable'}{telemetry.gustKt ? ` · ${telemetry.gustKt}` : ''}</div><div className="observation-meta">{observationMeta(telemetry.observations.wind)}</div></div>
                <div className="metric"><div className="metric-label">Observed · Significant wave height</div><div className="metric-value">{telemetry.waveHeightFt || 'Unavailable'}{telemetry.wavePeriodSec ? ` @ ${telemetry.wavePeriodSec}` : ''}</div><div className="observation-meta">{observationMeta(telemetry.observations.wave)}</div></div>
                <div className="metric"><div className="metric-label">Observed · Water temp</div><div className="metric-value">{telemetry.waterTempF || 'Unavailable'}</div><div className="observation-meta">{observationMeta(telemetry.observations.temperature)}</div></div>
                <div className="metric"><div className="metric-label">Forecast · Tide prediction · Next high</div><div className="metric-value">{telemetry.nextHigh || 'Unavailable'}</div></div>
                <div className="metric"><div className="metric-label">Forecast · Tide prediction · Next low</div><div className="metric-value">{telemetry.nextLow || 'Unavailable'}</div></div>
              </div>
              <div className="source-meta"><strong>NOAA {telemetry.stationId || 'station unavailable'}</strong> · {telemetry.stationName}<br/><strong>NDBC {telemetry.buoyId}</strong>{telemetry.buoyName ? ` · ${telemetry.buoyName}` : ''}<br/>{telemetry.observedAt ? `Observation ${formatDataDate(telemetry.observedAt)} · ${telemetry.observationAge}. ` : ''}{telemetry.representativeness}<br/>{telemetry.message}</div>
              <div className="model-band"><strong>Relative opportunity engine:</strong> conditions feed exact-taxon evaluations below only when fresh and complete. Unknown inputs never become favorable defaults.</div>
            </div>
          </div>

          <div className="card chart-card">
            <div className="card-title"><Fish size={20} /> Current legality · fail closed</div>
            <p className="muted small"><strong>Official rules control.</strong> Science suitability only — not verified live fish presence. Exact MPA geometry is unresolved, so no target is actionable.</p>
            {legalItems.map((item) => (
              <article className="reg-note legal-item" key={item.label}>
                <AlertTriangle size={15} />
                <div><strong>{item.label} · {item.status}</strong> <span className="muted small">(regional rule: {item.regionalStatus})</span><br/>
                  {item.identificationCaveat && <><span>{item.identificationCaveat}</span><br/></>}
                  <span>{item.warning}</span><br/>
                  <span className="muted small">Source checked {formatDataDate(item.checkedAt)}{item.sourceUrl && <> · <a href={item.sourceUrl} target="_blank" rel="noreferrer">official source <ExternalLink size={12} /></a></>}</span>
                </div>
              </article>
            ))}
          </div>
        </aside>

        <section className="card detail-panel" id="selected-water">
          <div className="detail-body">
            <div className="detail-topline">
              <div>
                <div className="kicker">Selected water</div>
                <h2>{selected.name}</h2>
              </div>
              <button className={`favorite-button ${favorites.has(selected.id) ? 'active' : ''}`} onClick={() => toggleFavorite(selected.id)} aria-label="Toggle favorite spot">
                <Star size={18} fill={favorites.has(selected.id) ? 'currentColor' : 'none'} />
              </button>
            </div>
            <p className="muted">{selected.region} · {selected.type} · Tide station: {selected.tideStation}</p>
            <div className="intel-section opportunity-panel" aria-live="polite">
              <div className="card-title"><Fish size={18} /> Relative opportunity · exact taxa</div>
              <p className="muted small">Not a live-presence claim. Historical occurrence, habitat fit, condition fit, legal targetability, and lure fishability remain separate.</p>
              {scientificOpportunity.map(({ displayLabel, taxonId, ecology, result }) => <article className="species-play opportunity-result" key={`${displayLabel}-${taxonId}`}>
                <strong>{displayLabel} · {result.status}{result.opportunityBand ? ` · ${result.opportunityBand}` : ''}</strong>
                {ecology && <p><em>{ecology.scientificName}</em> · {ecology.feedingMode} · Habitat ecology: {ecology.habitat.nuances.join(' ')} · Forage: {ecology.forageGuilds.join(', ')}</p>}
                <p>Confidence: {result.confidence} · Historical occurrence prior: {result.factors.historicalOccurrencePrior} · Ecology / catalog habitat context: {result.factors.habitatFit} · Conditions: {result.factors.conditionFit} · Legal: {result.factors.legalGate} · Lure fishability: {result.factors.lureFishability}</p>
                {result.reasons.map((reason) => <small key={reason}>{reason}</small>)}
                {result.missingInputs.length > 0 && <p className="muted small"><strong>Missing inputs:</strong> {result.missingInputs.join(', ')}. No opportunity band or presentation is produced while required inputs are unknown.</p>}
                {result.presentations.map((presentation) => <div className="presentation-plan" key={presentation.lureFamily}><strong>{presentation.lureFamily} · {presentation.profileSize}</strong><br/>{presentation.colorContrast} · {presentation.depthZone}<br/>{presentation.retrieve}<br/>{presentation.rigWeight}<br/><small>{presentation.why} {presentation.shorePracticality}</small></div>)}
                <details><summary>Factors, confidence coverage, and caveats</summary>{result.contributions.map((factor) => <div key={factor.factor}><strong>{factor.factor}: {factor.effect}</strong> — {factor.reason}</div>)}{result.confidenceReasons.map((reason) => <div key={reason}>Confidence: {reason}</div>)}{result.caveats.map((caveat) => <div key={caveat}>{caveat}</div>)}</details>
              </article>)}
            </div>
            <div className="info-callout">
              <strong>Access:</strong> {selected.accessNote}
            </div>
            {selected.accessStatus && selected.accessStatus.state !== 'open' && (
              <div className="info-callout access-alert" role="alert">
                <strong>{selected.accessStatus.state === 'closed' ? 'CLOSED — not a recommended fishing stop.' : 'PARTIAL ACCESS RESTRICTION.'}</strong>{' '}
                {selected.accessStatus.affectedArea} · Checked {selected.accessStatus.checkedAt}.{' '}
                <a href={selected.accessStatus.sourceUrl} target="_blank" rel="noreferrer">Verify with the site owner <ExternalLink size={13} /></a>
              </div>
            )}
            <div className="info-callout source-note">
              <strong>Research note:</strong> {selected.sourceNote}
            </div>
            <div className="intel-section field-proof">
              <div className="card-title"><ShieldAlert size={18} /> Access & license boundary</div>
              <p><strong>{selected.ownerJurisdiction}</strong><br/>{selected.licenseBoundary}</p>
              <div className="source-grid compact-source-grid">
                {selected.sourceLinks?.map((source) => <a className="source-pill" href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.label} <ExternalLink size={13}/></a>)}
              </div>
            </div>
            <div className="intel-section field-proof">
              <div className="card-title"><Fish size={18} /> Local corroboration — not current presence</div>
              <p className="muted small">Reviewed occurrence or catch-pattern evidence supports a local historical pattern. It does not prove fish are present now, at this casting point, or legal to target.</p>
              <div className="evidence-list">{selected.evidenceEdges?.map((edge) => <div className="tactic" key={edge.id}><Fish size={14}/><span><strong>{edge.speciesId.replace('species:', '').replaceAll('-', ' ')}</strong> · {edge.confidence} · {edge.evidenceType.replaceAll('-', ' ')}<br/><small>{edge.locality.warning}</small></span></div>)}</div>
            </div>
            <div className="intel-section field-proof">
              <div className="card-title"><Waves size={18} /> Metric-local sensor net</div>
              <div className="sensor-grid">{selected.sensorBindings?.map((binding) => <div className="metric" key={binding.metric}>
                <div className="metric-label">{binding.metric.replaceAll('_', ' ')}</div>
                <strong>{binding.availability === 'unavailable' ? 'Unavailable' : `${binding.representativeness} · ${binding.distanceKm} km`}</strong>
                <small>{binding.availability === 'unavailable' && binding.metric === 'wave' ? 'Ocean wave unavailable for this inland environment. ' : ''}{binding.warning}{binding.maxAgeMinutes ? ` · TTL ${binding.maxAgeMinutes} min` : ''}</small>
              </div>)}</div>
            </div>
            <div className="info-callout source-note">
              <strong>MPA point screen:</strong> {selected.mpaScreen?.status} · {selected.mpaScreen?.warning}
            </div>

            <div className="tags species-tags">
              {selected.species.map((s) => <span className="tag species-tag" key={s}>{s}</span>)}
            </div>

            <a className="maps-link" href={googleMapsUrl(selected)} target="_blank" rel="noreferrer"><ExternalLink size={16} /> Open spot in Google Maps</a>
          </div>
          <div className="detail-body">
            <div className="card-title"><BarChart3 size={20} /> Sample tide-height context · not an opportunity forecast</div>
            <div style={{ width: '100%', height: 310, marginTop: 16 }}>
              <ResponsiveContainer>
                <AreaChart data={tideSeries}>
                  <defs>
                    <linearGradient id="tide" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#22d3ee" stopOpacity={0}/>
                    </linearGradient>

                  </defs>
                  <CartesianGrid stroke="rgba(255,255,255,.08)" />
                  <XAxis dataKey="time" stroke="#8a8f98" />
                  <YAxis stroke="#8a8f98" />
                  <Tooltip contentStyle={{ background: '#0b1218', border: '1px solid rgba(255,255,255,.1)', borderRadius: 12, color: '#fff' }} />
                  <Area type="monotone" dataKey="height" stroke="#22d3ee" fill="url(#tide)" name="Tide ft" />

                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="safety-strip">
              <AlertTriangle size={16} /> Always verify live CDFW regulations, closures, swell, and local signage before fishing.
            </div>
          </div>
        </section>

        <section className="card detail-panel utility-panel">
          <div className="detail-body">
            <div className="card-title"><ShieldAlert size={20} /> Regulation & safety layer</div>
            <div className="reg-list">
              {regulationNotes.map((note) => <div className="reg-note" key={note}><AlertTriangle size={15} /> {note}</div>)}
            </div>
          </div>

        </section>

        <section className="card">
          <div className="card-header">
            <h2 className="card-title"><Waves size={20} /> Ranked water</h2>
            <span className="muted small">Tap a spot to update map + chart context</span>
          </div>
          <div className="spot-list">
            {rankedSpots.length === 0 && filteredSpots.length > 0 && (
              <div className="reg-note" role="status"><AlertTriangle size={15} /> Matching locations are not currently rankable because legal status and exact MPA geometry remain unresolved. Review a map marker for research, access, and safety details.</div>
            )}
            {rankedSpots.map((spot) => (
              <button key={spot.id} className={`spot-card ${spot.id === selected.id ? 'selected' : ''}`} onClick={() => setSelectedId(spot.id)}>
                <div className="spot-top">
                  <div>
                    <strong>{spot.name}</strong>
                    <div className="muted small">{spot.region} · scientific rank unavailable until gates resolve</div>
                  </div>

                </div>
                <div className="tags">
                  <span className="tag" style={{ color: safetyColor(spot.safety) }}><ShieldAlert size={11} /> {spot.safety}</span>
                  {favorites.has(spot.id) && <span className="tag favorite-tag">★ Favorite</span>}
                  {spot.species.slice(0, 4).map((s) => <span className="tag" key={s}>{s}</span>)}
                </div>
              </button>
            ))}
            {actionableSpots.length > 12 && (
              <button className="show-more" onClick={() => setShowAllRanked(!showAllRanked)}>{showAllRanked ? 'Collapse ranked list' : `Show more spots (${actionableSpots.length - 12} more)`}</button>
            )}
          </div>
        </section>


        <section className="card research-card">
          <div className="card-header">
            <h2 className="card-title"><Compass size={20} /> Research-backed spot expansion</h2>
            <span className="muted small">{spots.length} spots · {allSpecies.length} species groups</span>
          </div>
          <div className="research-body">
            <p>The map now blends official public-pier/access lists, SF Bay species/regulation references, CDFW striped bass shore guidance, and local pier-species notes into one fishable dashboard.</p>
            <div className="source-grid">
              {researchSources.map((source) => <a className="source-pill" href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.label} <ExternalLink size={13} /></a>)}
            </div>
          </div>
        </section>

        <section className="card research-card offline-card">
          <div className="card-header">
            <h2 className="card-title"><WifiOff size={20} /> PWA offline cache</h2>
            <span className="muted small">Installable shell · latest report cached</span>
          </div>
          <div className="research-body">
            <p>The app now registers a service worker, caches the app shell, keeps favorites in local storage, and is ready to cache live tide/report JSON for beach dead zones.</p>
          </div>
        </section>
      </section>
      <p className="footer-note">Prototype science coverage is limited and fail-closed. Always check live CDFW rules, pier closures, swell, and local signage before fishing.</p>
    </main>
  );
}

export default App;
