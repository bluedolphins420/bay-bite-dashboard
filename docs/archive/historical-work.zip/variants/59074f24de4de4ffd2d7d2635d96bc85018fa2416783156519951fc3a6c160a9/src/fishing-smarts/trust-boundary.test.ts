import { describe, expect, it } from 'vitest';
import * as faunaApi from './fauna-opportunity';
import * as legalApi from './legal-provenance';
import * as safetyApi from './safety-provenance';
import type { LiveTelemetry } from '../telemetry';

describe('production trust-boundary API', () => {
  it('does not export mutable reviewed manifests or generic trust mints', () => {
    expect(faunaApi).not.toHaveProperty('reviewedOccurrenceDerivativeRegistry');
    expect(faunaApi).not.toHaveProperty('reviewedHabitatDerivativeRegistry');
    expect(legalApi).not.toHaveProperty('trustedCurrentSpotLegalDecision');
    expect(safetyApi).not.toHaveProperty('trustedConditionSnapshot');
    expect(safetyApi).not.toHaveProperty('trustedFootingInspection');
  });

  it('exposes only producer validation paths, not caller-data signers', () => {
    expect(legalApi).toHaveProperty('produceCurrentSpotLegalDecision');
    expect(safetyApi).toHaveProperty('produceConditionSnapshot');
    expect(safetyApi).not.toHaveProperty('produceFootingInspection');
  });

  it('keeps caller-fabricated condition products unknown', () => {
    const fabricated: LiveTelemetry = {
      status: 'live', stationName: 'caller', stationId: 'fake-station', buoyId: 'fake-buoy',
      observedAt: '2026-08-13T17:30:00Z', windSpeedKt: '1 kt', waveHeightFt: '1 ft', waveLabel: 'caller', message: 'caller',
      observations: {
        level: { availability: 'available', freshness: 'live', stationId: 'fake-station', ageMinutes: 1 },
        wind: { availability: 'available', freshness: 'live', stationId: 'fake-station', ageMinutes: 1 },
        buoy: { availability: 'available', freshness: 'live', stationId: 'fake-buoy', ageMinutes: 1 },
        wave: { availability: 'available', freshness: 'live', stationId: 'fake-buoy', ageMinutes: 1 },
        temperature: { availability: 'unavailable', freshness: 'unavailable' },
      },
    };
    const snapshot = safetyApi.produceConditionSnapshot(fabricated, 'spot:ocean-beach')!;
    expect(snapshot).toMatchObject({ current: { state: 'unknown' }, wave: { state: 'unknown' }, wind: { state: 'unknown' }, clarity: 'unknown', light: 'unknown' });
  });
});
