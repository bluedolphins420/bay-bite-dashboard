import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const app = readFileSync(new URL('./App.tsx', import.meta.url), 'utf8');
const css = readFileSync(new URL('./App.css', import.meta.url), 'utf8');
const config = readFileSync(new URL('../vite.config.ts', import.meta.url), 'utf8');
const manifest = readFileSync(new URL('../public/manifest.webmanifest', import.meta.url), 'utf8');
const refreshDocs = readFileSync(new URL('../docs/LIVE_DATA_REFRESH.md', import.meta.url), 'utf8');

describe('presentation truth, refresh, and security', () => {
  it('renders access provenance, local corroboration, MPA warning, and metric-local sensor bindings', () => {
    expect(app).toContain('Access & license boundary');
    expect(app).toContain('Local corroboration — not current presence');
    expect(app).toContain('MPA point screen');
    expect(app).toContain('Metric-local sensor net');
    expect(app).toContain('Ocean wave unavailable for this inland environment');
    expect(app).toContain('selected.sourceLinks');
    expect(app).toContain('selected.evidenceEdges');
    expect(app).toContain('selected.sensorBindings');
  });
  it('shows fail-closed legal status, source time, legal warning, and separates suitability from presence', () => {
    expect(app).toContain('Current legality · fail closed');
    expect(app).toContain('Source checked');
    expect(app).toContain('Official rules control');
    expect(app).toContain('Science suitability only — not verified live fish presence');
    expect(app).toContain('currentSpotLegality(selected)');
    expect(app).toContain('rankableSpeciesForSpot(spot).length > 0');
    expect(app).not.toContain('Sample species momentum');
    expect(app).not.toContain('speciesMomentum.map');
  });
  it('keeps field controls discoverable in the first mobile viewport', () => {
    expect(app).toContain('className="mobile-quick-nav"');
    expect(app).toContain('href="#fishing-map"');
    expect(app).toContain('href="#live-conditions"');
    expect(app).toContain('href="#selected-water"');
    expect(app).toContain('id="fishing-map"');
    expect(app).toContain('id="live-conditions"');
    expect(app).toContain('id="selected-water"');
    expect(css).toMatch(/@media \(max-width: 640px\)[\s\S]*\.hero h1\s*\{[^}]*font-size:\s*clamp\(34px/i);
  });

  it('keeps the desktop map compact and explains fail-closed empty rankings truthfully', () => {
    expect(css).toMatch(/\.map-card\s*\{[^}]*align-self:\s*start/i);
    expect(app).toContain('Matching locations are not currently rankable');
    expect(app).toContain('legal status and exact MPA geometry remain unresolved');
    expect(app).not.toContain('Matching locations are access alerts');
  });

  it('has one authoritative selected-water live board with truthful labels', () => {
    expect(app).toContain('Selected water live conditions');
    expect(app).toContain('Significant wave height');
    expect(app).toContain('Forecast · Tide prediction');
    expect(app).toContain('Relative opportunity');
    expect(app).not.toContain('bestRegion');
    expect(app).not.toContain('Observed · Offshore swell');
    expect(app).not.toContain('NOAA Sensor Telemetry');
    expect(app).not.toContain('NDBC Buoy Marine Conditions');
    expect((app.match(/Selected water live conditions/g) ?? []).length).toBe(1);
    expect(app).toContain('observationMeta(telemetry.observations.level)');
    expect(app).toContain('observationMeta(telemetry.observations.wind)');
    expect(app).toContain('observationMeta(telemetry.observations.wave)');
    expect(app).toContain('observationMeta(telemetry.observations.temperature)');
  });

  it('renders exact-taxon opportunity and public-resolution evidence overlays without selected-water legacy claims', () => {
    expect(app).toContain('buildSelectedWaterOpportunity');
    expect(app).toContain('Show occurrence evidence overlays');
    expect(app).toContain('Historical occurrence areas');
    expect(app).not.toContain('habitatEvidenceOverlays');
    expect(app).toContain('Historical occurrence prior');
    expect(app).toContain('Not a live-presence claim');
    expect(app).not.toContain('<p>{selected.biteReason}</p>');
    expect(app).not.toContain('model score {selected.score}');
    expect(app).not.toContain('{spot.region} · {spot.bestWindow}');
    expect(app).not.toContain('Sample tide curve vs model bite score');
    expect(app).not.toContain('<Area type="monotone" dataKey="bite"');
    expect(app).not.toContain('Sort by bite score');
    expect(app).not.toContain('aria-label={`Model score');
    expect(app).not.toContain('Model region-score comparison');
    expect(app).not.toContain('model score {peak.bite}');
    expect(app).not.toContain('dailyReport.');
    expect(app).not.toContain('Jump to best visible bite');
    expect(app).not.toContain('Standard rig & bait plan');
    expect(app).not.toContain('Species playbook');
    expect(app).not.toContain('selected.tactics.map');
    expect(app).not.toContain('where the fish are likely moving');
    expect(app).not.toContain('mock-scored');
    expect(app).not.toContain('selectedSpot: selected');
    expect(app).not.toContain('where the fish are likely moving');
  });

  it('revalidates same-origin cache without browser NOAA/NDBC requests', () => {
    expect(app).not.toContain('api.tidesandcurrents.noaa.gov');
    expect(app).not.toContain('https://www.ndbc.noaa.gov/data/realtime2/');
    expect(app).toContain("fetch(`/data/live-status.json?ts=${Date.now()}`");
    expect(app).toContain("cache: 'no-store'");
    expect(app).toContain("document.addEventListener('visibilitychange'");
    expect(app).toContain("window.addEventListener('focus'");
    expect(app).toMatch(/setInterval\([^,]+,\s*60_000\)/s);
  });

  it('restricts preview hosts', () => {
    expect(config).not.toContain('allowedHosts: true');
    expect(config).toContain('algorithms-tough-allied-approximately.trycloudflare.com');
  });

  it('documents schema v4 and references an existing valid manifest SVG icon', () => {
    expect(refreshDocs).toContain('schema v4');
    expect(refreshDocs).not.toContain('schema v3');
    expect(JSON.parse(manifest).icons).toContainEqual(expect.objectContaining({ src: '/favicon.svg', type: 'image/svg+xml', sizes: 'any' }));
  });

  it('gives Deck White explicit opaque, high-contrast surfaces and text', () => {
    expect(css).toMatch(/\.deck-white \.hero\s*\{[^}]*background:\s*#fff/i);
    expect(css).toMatch(/\.deck-white \.hero-overlay\s*\{[^}]*background:\s*#fff/i);
    expect(css).toMatch(/\.deck-white \.hero h1[^}]*color:\s*#0f172a/i);
    expect(css).toMatch(/\.deck-white \.metric-label[^}]*color:\s*#334155/i);
  });

  it('keeps the Deck White sort control and native options explicitly readable', () => {
    expect(css).toMatch(/\.deck-white \.sort-select\s*\{[^}]*color:\s*#0f172a[^}]*background:\s*#fff[^}]*border-color:\s*#64748b/i);
    expect(css).toMatch(/\.deck-white \.sort-select option\s*\{[^}]*color:\s*#0f172a[^}]*background:\s*#fff/i);
  });

  it('gives the Deck White favorite control explicit dark foregrounds in every state', () => {
    expect(css).toMatch(/\.deck-white \.favorite-button\s*\{[^}]*color:\s*#334155/i);
    expect(css).toMatch(/\.deck-white \.favorite-button:hover[^}]*color:\s*#0f172a/i);
    expect(css).toMatch(/\.deck-white \.favorite-button:focus-visible[^}]*color:\s*#0f172a/i);
    expect(css).toMatch(/\.deck-white \.favorite-button\.active\s*\{[^}]*color:\s*#713f12/i);
  });

  it('gives Deck White Leaflet attribution links an explicit dark foreground', () => {
    expect(css).toMatch(/\.deck-white \.leaflet-control-attribution a\s*\{[^}]*color:\s*#075985/i);
    expect(css).toMatch(/\.deck-white \.leaflet-control-attribution a:hover[^}]*color:\s*#0c4a6e/i);
    expect(css).toMatch(/\.deck-white \.leaflet-control-attribution a:focus-visible[^}]*color:\s*#0c4a6e/i);
  });
});
