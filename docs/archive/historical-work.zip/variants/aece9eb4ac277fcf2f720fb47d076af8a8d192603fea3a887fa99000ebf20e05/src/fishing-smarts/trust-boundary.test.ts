import { describe, expect, it } from 'vitest';
import * as faunaApi from './fauna-opportunity';
import * as legalApi from './legal-provenance';
import * as safetyApi from './safety-provenance';
import { ingestLiveStatusCache, telemetryFromBindings, type LiveTelemetry } from '../telemetry';

describe('production trust-boundary API', () => {
  it('does not export mutable reviewed manifests or generic trust mints', () => {
    expect(faunaApi).not.toHaveProperty('reviewedOccurrenceDerivativeRegistry');
    expect(faunaApi).not.toHaveProperty('reviewedHabitatDerivativeRegistry');
    expect(legalApi).not.toHaveProperty('trustedCurrentSpotLegalDecision');
    expect(safetyApi).not.toHaveProperty('trustedConditionSnapshot');
    expect(safetyApi).not.toHaveProperty('trustedFootingInspection');
    expect(safetyApi).not.toHaveProperty('issueReviewedScenarioSafety');
    expect(legalApi).not.toHaveProperty('issueReviewedScenarioLegalDecision');
  });

  it('exposes only reviewed cache validation paths, not caller-data signers', () => {
    expect(legalApi).toHaveProperty('produceCurrentSpotLegalDecision');
    expect(safetyApi).toHaveProperty('produceConditionSnapshotFromCache');
    expect(safetyApi).not.toHaveProperty('produceFootingInspection');
  });

  it('rejects forged bound station IDs even with favorable freshness', () => {
    const fabricated: LiveTelemetry = {
      status: 'live', stationName: 'caller', stationId: '9414275', buoyId: '46237',
      observedAt: '2026-08-13T17:30:00Z', windSpeedKt: '1 kt', waveHeightFt: '1 ft', waveLabel: 'caller', message: 'caller',
      observations: {
        level: { availability: 'unavailable', freshness: 'unavailable' },
        wind: { availability: 'available', freshness: 'live', stationId: '46026', ageMinutes: 1 },
        buoy: { availability: 'available', freshness: 'live', stationId: '46237', ageMinutes: 1 },
        wave: { availability: 'available', freshness: 'live', stationId: '46237', ageMinutes: 1 },
        temperature: { availability: 'unavailable', freshness: 'unavailable' },
      },
    };
    expect(safetyApi.conditionsAreTrusted(fabricated as never, 'spot:ocean-beach')).toBe(false);
  });

  it('never lets the generic bindings normalizer mint trusted conditions', () => {
    const observed = (stationId: string, fields: Record<string, unknown>) => ({ kind: 'observed' as const, stationId, stationName: stationId, observedAt: '2026-08-13T17:30:00Z', ageMinutes: 30, freshness: 'live' as const, lastKnownGood: false, ...fields });
    const telemetry = telemetryFromBindings({ generatedAt: '2026-08-13T18:00:00Z', sensors: {
      'sensor:46237': { products: { buoy: observed('46237', { waveHeightM: 0.3 }) } },
      'sensor:46026': { products: { wind: observed('46026', { speedMps: 0.5 }) } },
    } }, [
      { metric: 'wave', sensorId: 'sensor:46237', warning: 'Regional only', maxAgeMinutes: 120 },
      { metric: 'wind', sensorId: 'sensor:46026', warning: 'Regional only', maxAgeMinutes: 120 },
    ], 'Ocean Beach', new Date('2026-08-13T18:00:00Z'));
    expect(safetyApi.conditionsAreTrusted(telemetry as never, 'spot:ocean-beach')).toBe(false);
    expect(safetyApi.conditionsAreTrusted(structuredClone(telemetry) as never, 'spot:ocean-beach')).toBe(false);
  });

  it('rejects a directly constructed cache and a copied issued cache', () => {
    const direct = validRawCache();
    expect(safetyApi.produceConditionSnapshotFromCache(direct as never, 'spot:ocean-beach', new Date('2026-08-13T18:00:00Z'))).toBeUndefined();
    const issued = ingestLiveStatusCache(validRawCache());
    expect(issued).toBeDefined();
    expect(safetyApi.produceConditionSnapshotFromCache(structuredClone(issued) as never, 'spot:ocean-beach', new Date('2026-08-13T18:00:00Z'))).toBeUndefined();
  });

  it('accepts only the exact cache issued from unknown schema-valid JSON and rejects copied telemetry', () => {
    const raw: unknown = validRawCache();
    const issued = ingestLiveStatusCache(raw)!;
    const snapshot = safetyApi.produceConditionSnapshotFromCache(issued, 'spot:ocean-beach', new Date('2026-08-13T18:00:00Z'));
    expect(snapshot).toMatchObject({ wave: { state: 'manageable' }, wind: { state: 'light' } });
    expect(safetyApi.conditionsAreTrusted(snapshot, 'spot:ocean-beach')).toBe(true);
    expect(safetyApi.conditionsAreTrusted(structuredClone(snapshot) as never, 'spot:ocean-beach')).toBe(false);
  });

  it('rejects schema-valid station-ID forgery before issuing a cache', () => {
    const forged = validRawCache();
    forged.sensors['sensor:46237'].products.buoy.stationId = '46026';
    expect(() => ingestLiveStatusCache(forged)).toThrow(/station.*identity|stationId/i);
  });
});

function validRawCache() {
  const observed = (stationId: string, fields: Record<string, unknown>) => ({ kind: 'observed', stationId, stationName: stationId, observedAt: '2026-08-13T17:30:00Z', ageMinutes: 30, freshness: 'delayed', lastKnownGood: false, ...fields });
  return {
    schemaVersion: 4, generatedAt: '2026-08-13T18:00:00Z', status: 'partial', healthCounts: { partial: 2 }, totalStations: 2, sources: ['NOAA'], stations: {},
    sensors: {
      'sensor:46237': { key: 'sensor:46237', health: 'delayed', products: { buoy: observed('46237', { waveHeightM: 0.3 }) }, errors: [] },
      'sensor:46026': { key: 'sensor:46026', health: 'delayed', products: { wind: observed('46026', { speedMps: 0.5 }) }, errors: [] },
    },
  };
}
