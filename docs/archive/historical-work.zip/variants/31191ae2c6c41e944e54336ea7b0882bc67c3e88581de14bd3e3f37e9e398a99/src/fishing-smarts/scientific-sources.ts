import type { StableId } from './index';

export interface ScientificSourceRegistryRecord {
  id: StableId;
  title: string;
  url: string;
  authority: 'official-agency'|'academic-repository'|'supplemental-biodiversity-network';
  role: 'occurrence-seasonality'|'biology'|'habitat-geography'|'supplemental-occurrence'|'conditions';
  checkedAt: string;
  reachability: 'verified-http'|'not-verified-environment';
  claimStatus: 'authoritative-foundation'|'supplemental-only';
  limitations: string;
}

const checkedAt = '2026-08-13';
export const scientificSourceRegistry: ScientificSourceRegistryRecord[] = [
  { id:'source:edi-deltafish-1075-1',title:'Integrated dataset for fish assemblages in the San Francisco Estuary, EDI package edi.1075.1',url:'https://doi.org/10.6073/pasta/0cdf7e5e954be1798ab9bf4f23816e83',authority:'academic-repository',role:'occurrence-seasonality',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Large integrated derivative; later ingestion must retain component program, station, effort, method, dates, and taxon resolution. Package edi.1075.1.' },
  { id:'source:cdfw-bay-study',title:'CDFW San Francisco Bay Study',url:'https://wildlife.ca.gov/Conservation/Delta/Bay-Study',authority:'official-agency',role:'occurrence-seasonality',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Use published station/method/time metadata and public catch matrices; survey occurrence is not current presence.' },
  { id:'source:cdfw-california-halibut-esr',title:'CDFW California Halibut Enhanced Status Report',url:'https://wildlife.ca.gov/Conservation/Marine/CA-Halibut-ESR',authority:'official-agency',role:'biology',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Regional biology and fishery status do not establish local occurrence or current presence.' },
  { id:'source:noaa-sf-bay-benthic-2011',title:'NOAA Marine Cadastre San Francisco Bay Benthic Habitats 2011',url:'https://www.marinecadastre.gov/',authority:'official-agency',role:'habitat-geography',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Derived habitat polygons require source-resolution preservation; do not imply exact bottom at a casting point.' },
  { id:'source:opc-seafloor-mapping',title:'California Ocean Protection Council Seafloor and Coastal Mapping',url:'https://opc.ca.gov/seafloor-and-coastal-mapping/',authority:'official-agency',role:'habitat-geography',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Bathymetry and substrate products have survey-specific scale, date, and uncertainty.' },
  { id:'source:obis-api',title:'Ocean Biodiversity Information System API',url:'https://api.obis.org/',authority:'supplemental-biodiversity-network',role:'supplemental-occurrence',checkedAt,reachability:'verified-http',claimStatus:'supplemental-only',limitations:'Record quality, sampling bias, coordinate uncertainty, and taxonomic resolution must be retained.' },
  { id:'source:gbif-occurrence-api',title:'GBIF Occurrence API',url:'https://techdocs.gbif.org/en/openapi/',authority:'supplemental-biodiversity-network',role:'supplemental-occurrence',checkedAt,reachability:'verified-http',claimStatus:'supplemental-only',limitations:'Supplemental only; preserve basis of record, issue flags, coordinate uncertainty, date, and license.' },
  { id:'source:noaa-coops-api',title:'NOAA CO-OPS Data API',url:'https://api.tidesandcurrents.noaa.gov/api/prod/',authority:'official-agency',role:'conditions',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Station representativeness and product-specific freshness must be explicit.' },
  { id:'source:noaa-ndbc',title:'NOAA National Data Buoy Center',url:'https://www.ndbc.noaa.gov/',authority:'official-agency',role:'conditions',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Offshore observations can be regional proxies and do not resolve shorebreak.' },
  { id:'source:noaa-erddap',title:'NOAA ERDDAP services',url:'https://www.ncei.noaa.gov/erddap/',authority:'official-agency',role:'conditions',checkedAt,reachability:'verified-http',claimStatus:'authoritative-foundation',limitations:'Each dataset requires explicit identity, units, temporal resolution, quality flags, and locality.' },
];

export const scientificIngestionContracts = {
  occurrence: {
    version: 1,
    requiredFields: ['sourceId','taxonId','geometry','timeCoverage','method','effort','lifeStage','spatialResolution','limitations'],
    missingSemantics: 'Unavailable method or effort remains explicitly unknown; zero and absence are never inferred.',
  },
  habitat: {
    version: 1,
    requiredFields: ['sourceId','geometry','classification','publicResolution','limitations'],
    missingSemantics: 'No habitat polygon or class means unknown habitat support, never compatible by default.',
  },
  conditions: {
    version: 1,
    requiredFields: ['sourceId','stationId','metric','observedAt','retrievedAt','value','unit','quality','representativeness','maxAgeMinutes'],
    browserRuntimeFetch: false,
    delivery: 'Reviewed server-side generated derivative or same-origin cache only.',
    missingSemantics: 'Missing, stale, invalid-clock, or non-representative observations are unavailable and cannot improve opportunity.',
  },
} as const;
