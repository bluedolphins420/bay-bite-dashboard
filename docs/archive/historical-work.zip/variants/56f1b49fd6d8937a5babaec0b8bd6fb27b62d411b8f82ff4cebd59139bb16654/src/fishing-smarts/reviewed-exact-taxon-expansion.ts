import type { ExactTaxonScienceRecord } from './fauna-opportunity';
import type { ScientificSourceRegistryRecord } from './scientific-sources';

// Typed, repository-local translation of the reviewed 2026-08-13 analyst package.
// Mutable external JSON is never loaded at runtime. Presentation categories remain
// field heuristics and are deliberately excluded from scientific coverage.
export const reviewedExpansionProfiles = {
  "species:bat-ray": {
    "id": "species:bat-ray",
    "commonName": "Bat ray",
    "scientificName": "Myliobatis californica",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine–estuarine"
        ],
        "substrateStructureDepth": [
          "Shallow sand/mud flats, bays, sloughs and estuary channels; recorded from surface to about 46 m."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:bay-shore",
        "habitat:tidal-slough",
        "habitat:estuary",
        "habitat:estuary-mouth",
        "habitat:surf"
      ],
      "incompatible": [
        "habitat:rocky-shore"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Summer mating and approximately annual gestation are regional life-history context only; no local bite season."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "mollusks",
      "benthic crustaceans"
    ],
    "feedingMode": "Benthic suction/digging predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-bat-ray",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "mollusks",
          "benthic crustaceans"
        ],
        "habitats": [
          "habitat:bay-shore",
          "habitat:tidal-slough",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:surf"
        ],
        "lureFamily": "bottom natural bait over mapped soft bottom",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "mollusks",
          "benthic crustaceans"
        ],
        "habitats": [
          "habitat:bay-shore",
          "habitat:tidal-slough",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:surf"
        ],
        "lureFamily": "scent-led benthic presentation",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Shallow sand/mud flats, bays, sloughs and estuary channels; recorded from surface to about 46 m."
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Shallow sand/mud flats, bays, sloughs and estuary channels; recorded from surface to about 46 m."
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Shallow sand/mud flats, bays, sloughs and estuary channels; recorded from surface to about 46 m."
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "mollusks",
          "benthic crustaceans"
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Summer mating and approximately annual gestation are regional life-history context only; no local bite season."
        ],
        "sourceIds": [
          "source:cdfw-bat-ray"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:black-rockfish": {
    "id": "species:black-rockfish",
    "commonName": "Black rockfish",
    "scientificName": "Sebastes melanops",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine"
        ],
        "substrateStructureDepth": [
          "Schools over high-relief rock, kelp, boulders and artificial reef; typically shallower than 73 m though records are deeper."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:rocky-shore",
        "habitat:jetty",
        "habitat:breakwater"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Parturition timing is regional context; resident/transient behavior varies and no shore window is inferred."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "small fishes",
      "crustaceans",
      "cephalopods"
    ],
    "feedingMode": "Water-column/structure-associated predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-black-rockfish",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-groundfish-2026",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "small fishes",
          "crustaceans",
          "cephalopods"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "small-fish profile near mapped rock",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "small fishes",
          "crustaceans",
          "cephalopods"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "controlled crustacean profile near structure",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Schools over high-relief rock, kelp, boulders and artificial reef; typically shallower than 73 m though records are deeper."
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Schools over high-relief rock, kelp, boulders and artificial reef; typically shallower than 73 m though records are deeper."
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Schools over high-relief rock, kelp, boulders and artificial reef; typically shallower than 73 m though records are deeper."
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "small fishes",
          "crustaceans",
          "cephalopods"
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Parturition timing is regional context; resident/transient behavior varies and no shore window is inferred."
        ],
        "sourceIds": [
          "source:cdfw-black-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:blue-rockfish": {
    "id": "species:blue-rockfish",
    "commonName": "Blue rockfish",
    "scientificName": "Sebastes mystinus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine"
        ],
        "substrateStructureDepth": [
          "Schools above shallow rock and kelp; surface to about 156 m in agency profile."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:rocky-shore",
        "habitat:jetty",
        "habitat:breakwater"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Regional spawning mainly November–March; not a catch window."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "small fish",
      "crustaceans",
      "gelatinous zooplankton"
    ],
    "feedingMode": "Schooling water-column predator/zooplanktivore.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-blue-rockfish",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-groundfish-2026",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "small fish",
          "crustaceans",
          "gelatinous zooplankton"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "small suspended fish/crustacean profile near mapped kelp-rock",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Schools above shallow rock and kelp; surface to about 156 m in agency profile."
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Schools above shallow rock and kelp; surface to about 156 m in agency profile."
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Schools above shallow rock and kelp; surface to about 156 m in agency profile."
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "small fish",
          "crustaceans",
          "gelatinous zooplankton"
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Regional spawning mainly November–March; not a catch window."
        ],
        "sourceIds": [
          "source:cdfw-blue-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:brown-rockfish": {
    "id": "species:brown-rockfish",
    "commonName": "Brown rockfish",
    "scientificName": "Sebastes auriculatus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine, including structured bay margins"
        ],
        "substrateStructureDepth": [
          "Nearshore rock, kelp and artificial structure; generally shallower than 53 m despite deeper records."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:rocky-shore",
        "habitat:jetty",
        "habitat:breakwater",
        "habitat:pier"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Regional spawning December–June; no local movement/catch curve."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "crabs",
      "small fish",
      "small crustaceans"
    ],
    "feedingMode": "Structure-associated ambush predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-brown-rockfish",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-groundfish-2026",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "crabs",
          "small fish",
          "small crustaceans"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater",
          "habitat:pier"
        ],
        "lureFamily": "crab/crustacean profile close to mapped structure",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "crabs",
          "small fish",
          "small crustaceans"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater",
          "habitat:pier"
        ],
        "lureFamily": "small-fish profile near rock",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine, including structured bay margins"
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine, including structured bay margins"
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Nearshore rock, kelp and artificial structure; generally shallower than 53 m despite deeper records."
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Nearshore rock, kelp and artificial structure; generally shallower than 53 m despite deeper records."
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine, including structured bay margins"
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Nearshore rock, kelp and artificial structure; generally shallower than 53 m despite deeper records."
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "crabs",
          "small fish",
          "small crustaceans"
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Regional spawning December–June; no local movement/catch curve."
        ],
        "sourceIds": [
          "source:cdfw-brown-rockfish",
          "source:cdfw-groundfish-2026"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:cabezon": {
    "id": "species:cabezon",
    "commonName": "Cabezon",
    "scientificName": "Scorpaenichthys marmoratus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine"
        ],
        "substrateStructureDepth": [
          "Crevices, reefs, kelp, tidepools and jetties from intertidal into deeper water."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:rocky-shore",
        "habitat:jetty",
        "habitat:breakwater"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Regional spawning October–March; males guard egg masses. No catch window."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "crabs",
      "mollusks",
      "cephalopods",
      "small fish"
    ],
    "feedingMode": "Sedentary benthic predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-cabezon",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-groundfish-2026",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "crabs",
          "mollusks",
          "cephalopods",
          "small fish"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "slow benthic crab/mollusk profile near crevices",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "crabs",
          "mollusks",
          "cephalopods",
          "small fish"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "bottom natural bait near mapped rock",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Crevices, reefs, kelp, tidepools and jetties from intertidal into deeper water."
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Crevices, reefs, kelp, tidepools and jetties from intertidal into deeper water."
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Crevices, reefs, kelp, tidepools and jetties from intertidal into deeper water."
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "crabs",
          "mollusks",
          "cephalopods",
          "small fish"
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Regional spawning October–March; males guard egg masses. No catch window."
        ],
        "sourceIds": [
          "source:cdfw-cabezon",
          "source:cdfw-groundfish-2026"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:channel-catfish": {
    "id": "species:channel-catfish",
    "commonName": "Channel catfish",
    "scientificName": "Ictalurus punctatus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "freshwater–low-salinity upper estuary"
        ],
        "substrateStructureDepth": [
          "Deep pools, runs, backwaters and cover over sand/gravel/rock; salinity tolerance is not preference."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:jetty",
        "habitat:breakwater",
        "habitat:rocky-shore",
        "habitat:estuary-mouth"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Tributary spawning movement and nocturnal tendency are broad biology only."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "insect larvae",
      "crustaceans",
      "mollusks",
      "fish"
    ],
    "feedingMode": "Bottom-oriented opportunistic omnivore.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:smithsonian-channel-catfish",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "B",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-catfish-monitoring",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "insect larvae",
          "crustaceans",
          "mollusks",
          "fish"
        ],
        "habitats": [
          "habitat:tidal-slough",
          "habitat:estuary"
        ],
        "lureFamily": "bottom natural bait near freshwater/low-salinity cover",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "insect larvae",
          "crustaceans",
          "mollusks",
          "fish"
        ],
        "habitats": [
          "habitat:tidal-slough",
          "habitat:estuary"
        ],
        "lureFamily": "scent-led benthic presentation",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "freshwater–low-salinity upper estuary"
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "freshwater–low-salinity upper estuary"
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Deep pools, runs, backwaters and cover over sand/gravel/rock; salinity tolerance is not preference."
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Deep pools, runs, backwaters and cover over sand/gravel/rock; salinity tolerance is not preference."
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "freshwater–low-salinity upper estuary"
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Deep pools, runs, backwaters and cover over sand/gravel/rock; salinity tolerance is not preference."
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "insect larvae",
          "crustaceans",
          "mollusks",
          "fish"
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Tributary spawning movement and nocturnal tendency are broad biology only."
        ],
        "sourceIds": [
          "source:smithsonian-channel-catfish",
          "source:cdfw-catfish-monitoring"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:jacksmelt": {
    "id": "species:jacksmelt",
    "commonName": "Jacksmelt",
    "scientificName": "Atherinopsis californiensis",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine–estuarine"
        ],
        "substrateStructureDepth": [
          "Shallow schools in bays, estuaries, sandy beaches and kelp canopy; usually about 1.5–15 m."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:pier",
        "habitat:bay-shore",
        "habitat:estuary",
        "habitat:estuary-mouth",
        "habitat:surf"
      ],
      "incompatible": [
        "habitat:tidal-slough"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Year-round spawning with a broad fall–spring peak is agency life history, not a school-presence forecast."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "amphipods",
      "detritus",
      "small fish"
    ],
    "feedingMode": "Schooling opportunistic omnivore.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-jacksmelt",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "amphipods",
          "detritus",
          "small fish"
        ],
        "habitats": [
          "habitat:pier",
          "habitat:bay-shore",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:surf"
        ],
        "lureFamily": "small suspended bait/invertebrate profile",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "amphipods",
          "detritus",
          "small fish"
        ],
        "habitats": [
          "habitat:pier",
          "habitat:bay-shore",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:surf"
        ],
        "lureFamily": "light midwater presentation",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Shallow schools in bays, estuaries, sandy beaches and kelp canopy; usually about 1.5–15 m."
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Shallow schools in bays, estuaries, sandy beaches and kelp canopy; usually about 1.5–15 m."
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Shallow schools in bays, estuaries, sandy beaches and kelp canopy; usually about 1.5–15 m."
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "amphipods",
          "detritus",
          "small fish"
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Year-round spawning with a broad fall–spring peak is agency life history, not a school-presence forecast."
        ],
        "sourceIds": [
          "source:cdfw-jacksmelt"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:kelp-greenling": {
    "id": "species:kelp-greenling",
    "commonName": "Kelp greenling",
    "scientificName": "Hexagrammos decagrammus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine"
        ],
        "substrateStructureDepth": [
          "Rocky coasts, kelp and jetties; intertidal to 149 m, more common shallower than 100 m."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:rocky-shore",
        "habitat:jetty",
        "habitat:breakwater"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Attached demersal eggs and regional autumn spawning records; migration unknown."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "crabs",
      "shrimp",
      "mollusks",
      "fish",
      "algae"
    ],
    "feedingMode": "Benthic omnivore/predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-kelp-greenling",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:noaa-kelp-greenling",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-groundfish-2026",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "crabs",
          "shrimp",
          "mollusks",
          "fish",
          "algae"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "slow small-crustacean/mollusk profile near rock-kelp",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Rocky coasts, kelp and jetties; intertidal to 149 m, more common shallower than 100 m."
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Rocky coasts, kelp and jetties; intertidal to 149 m, more common shallower than 100 m."
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Rocky coasts, kelp and jetties; intertidal to 149 m, more common shallower than 100 m."
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "crabs",
          "shrimp",
          "mollusks",
          "fish",
          "algae"
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Attached demersal eggs and regional autumn spawning records; migration unknown."
        ],
        "sourceIds": [
          "source:cdfw-kelp-greenling",
          "source:noaa-kelp-greenling",
          "source:cdfw-groundfish-2026"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:leopard-shark": {
    "id": "species:leopard-shark",
    "commonName": "Leopard shark",
    "scientificName": "Triakis semifasciata",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine–estuarine"
        ],
        "substrateStructureDepth": [
          "Shallow bay/estuary sand and nearshore sandy/kelp environments, usually near bottom."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:bay-shore",
        "habitat:estuary",
        "habitat:estuary-mouth",
        "habitat:surf"
      ],
      "incompatible": [
        "habitat:tidal-slough",
        "habitat:rocky-shore"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Regional fall aggregations in SF/Monterey Bays do not prove presence at a shore."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "fish",
      "squid",
      "crabs"
    ],
    "feedingMode": "Bottom-oriented mobile predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-leopard-shark",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sf-bay-regs",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "fish",
          "squid",
          "crabs"
        ],
        "habitats": [
          "habitat:bay-shore",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:surf"
        ],
        "lureFamily": "bottom natural bait over mapped sand",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "fish",
          "squid",
          "crabs"
        ],
        "habitats": [
          "habitat:bay-shore",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:surf"
        ],
        "lureFamily": "fish/squid profile near soft-bottom edge",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Shallow bay/estuary sand and nearshore sandy/kelp environments, usually near bottom."
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Shallow bay/estuary sand and nearshore sandy/kelp environments, usually near bottom."
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine–estuarine"
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Shallow bay/estuary sand and nearshore sandy/kelp environments, usually near bottom."
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "fish",
          "squid",
          "crabs"
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Regional fall aggregations in SF/Monterey Bays do not prove presence at a shore."
        ],
        "sourceIds": [
          "source:cdfw-leopard-shark",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:lingcod": {
    "id": "species:lingcod",
    "commonName": "Lingcod",
    "scientificName": "Ophiodon elongatus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine"
        ],
        "substrateStructureDepth": [
          "Adults use rocky bottom and kelp; juveniles can use sand near eelgrass/kelp. Adult compatibility is structure-specific."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:rocky-shore",
        "habitat:jetty",
        "habitat:breakwater"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:bay-shore",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Females migrate seasonally to spawn and males guard winter–spring egg masses; no shore window inferred."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "bottom fish",
      "squid",
      "octopus",
      "crab"
    ],
    "feedingMode": "Large structure-associated predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:noaa-lingcod",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-lingcod",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-groundfish-2026",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "bottom fish",
          "squid",
          "octopus",
          "crab"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "large fish profile near mapped rock",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      },
      {
        "forageGuilds": [
          "bottom fish",
          "squid",
          "octopus",
          "crab"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "squid/crab natural bait near structure",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Adults use rocky bottom and kelp; juveniles can use sand near eelgrass/kelp. Adult compatibility is structure-specific."
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Adults use rocky bottom and kelp; juveniles can use sand near eelgrass/kelp. Adult compatibility is structure-specific."
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine"
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Adults use rocky bottom and kelp; juveniles can use sand near eelgrass/kelp. Adult compatibility is structure-specific."
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "bottom fish",
          "squid",
          "octopus",
          "crab"
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Females migrate seasonally to spawn and males guard winter–spring egg masses; no shore window inferred."
        ],
        "sourceIds": [
          "source:noaa-lingcod",
          "source:cdfw-lingcod",
          "source:cdfw-groundfish-2026"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:monkeyface-prickleback": {
    "id": "species:monkeyface-prickleback",
    "commonName": "Monkeyface prickleback",
    "scientificName": "Cebidichthys violaceus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine intertidal–shallow subtidal"
        ],
        "substrateStructureDepth": [
          "Rocky crevices, boulders, algae, jetties and breakwaters; highly local residential use."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:rocky-shore",
        "habitat:jetty",
        "habitat:breakwater"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:bay-shore",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Small home range is defensible; flooding-tide activity is biology, not a bite guarantee."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "algae (adults)",
      "small crustaceans (juveniles)"
    ],
    "feedingMode": "Adult algal grazer; juveniles consume small invertebrates.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-monkeyface",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "algae (adults)",
          "small crustaceans (juveniles)"
        ],
        "habitats": [
          "habitat:rocky-shore",
          "habitat:jetty",
          "habitat:breakwater"
        ],
        "lureFamily": "crevice-level bait presentation (agency-described poke-poling category)",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine intertidal–shallow subtidal"
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine intertidal–shallow subtidal"
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Rocky crevices, boulders, algae, jetties and breakwaters; highly local residential use."
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Rocky crevices, boulders, algae, jetties and breakwaters; highly local residential use."
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine intertidal–shallow subtidal"
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Rocky crevices, boulders, algae, jetties and breakwaters; highly local residential use."
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "algae (adults)",
          "small crustaceans (juveniles)"
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Small home range is defensible; flooding-tide activity is biology, not a bite guarantee."
        ],
        "sourceIds": [
          "source:cdfw-monkeyface"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:pacific-staghorn-sculpin": {
    "id": "species:pacific-staghorn-sculpin",
    "commonName": "Pacific staghorn sculpin",
    "scientificName": "Leptocottus armatus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine–brackish with freshwater tolerance"
        ],
        "substrateStructureDepth": [
          "Soft sandy/muddy estuaries, bays and tidal water; bottom-associated."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:bay-shore",
        "habitat:tidal-slough",
        "habitat:estuary",
        "habitat:estuary-mouth",
        "habitat:pier"
      ],
      "incompatible": [
        "habitat:rocky-shore"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Juvenile dispersal and regional January–February spawning are context only; marine fish may follow tides."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "amphipods",
      "insect larvae",
      "crabs",
      "shrimp",
      "small fish"
    ],
    "feedingMode": "Benthic opportunistic predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:ca-waterboards-staghorn",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "B",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-general-ocean",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "amphipods",
          "insect larvae",
          "crabs",
          "shrimp",
          "small fish"
        ],
        "habitats": [
          "habitat:bay-shore",
          "habitat:tidal-slough",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:pier"
        ],
        "lureFamily": "small bottom invertebrate/fish profile over soft estuary substrate",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine–brackish with freshwater tolerance"
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine–brackish with freshwater tolerance"
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Soft sandy/muddy estuaries, bays and tidal water; bottom-associated."
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Soft sandy/muddy estuaries, bays and tidal water; bottom-associated."
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine–brackish with freshwater tolerance"
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Soft sandy/muddy estuaries, bays and tidal water; bottom-associated."
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "amphipods",
          "insect larvae",
          "crabs",
          "shrimp",
          "small fish"
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Juvenile dispersal and regional January–February spawning are context only; marine fish may follow tides."
        ],
        "sourceIds": [
          "source:ca-waterboards-staghorn",
          "source:cdfw-general-ocean"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:pile-perch": {
    "id": "species:pile-perch",
    "commonName": "Pile perch",
    "scientificName": "Rhacochilus vacca",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine–estuarine juvenile use"
        ],
        "substrateStructureDepth": [
          "Adults around rocky shores, kelp, pilings and artificial reef; juveniles can use eelgrass/bays."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:pier",
        "habitat:jetty",
        "habitat:breakwater",
        "habitat:bay-shore",
        "habitat:rocky-shore"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Seasonal movement unknown."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "mollusks",
      "crabs",
      "barnacles",
      "benthic invertebrates"
    ],
    "feedingMode": "Structure-associated benthic forager.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-pile",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-surfperch-account",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sf-bay-regs",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "mollusks",
          "crabs",
          "barnacles",
          "benthic invertebrates"
        ],
        "habitats": [
          "habitat:pier",
          "habitat:jetty",
          "habitat:breakwater",
          "habitat:bay-shore",
          "habitat:rocky-shore"
        ],
        "lureFamily": "small invertebrate bottom presentation beside mapped pilings/rock",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine–estuarine juvenile use"
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine–estuarine juvenile use"
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Adults around rocky shores, kelp, pilings and artificial reef; juveniles can use eelgrass/bays."
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Adults around rocky shores, kelp, pilings and artificial reef; juveniles can use eelgrass/bays."
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine–estuarine juvenile use"
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Adults around rocky shores, kelp, pilings and artificial reef; juveniles can use eelgrass/bays."
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "mollusks",
          "crabs",
          "barnacles",
          "benthic invertebrates"
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Seasonal movement unknown."
        ],
        "sourceIds": [
          "source:cdfw-pile",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:redtail-surfperch": {
    "id": "species:redtail-surfperch",
    "commonName": "Redtail surfperch",
    "scientificName": "Amphistichus rhodoterus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine surf zone"
        ],
        "substrateStructureDepth": [
          "High-energy open-coast sandy beaches, sandy pocket beaches and swash/trough habitat."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:surf"
      ],
      "incompatible": [
        "habitat:bay-shore",
        "habitat:tidal-slough",
        "habitat:estuary",
        "habitat:rocky-shore"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Summer parturition/nearshore aggregation is broad biology, not a bite window."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "isopods",
      "amphipods",
      "polychaetes",
      "small crabs"
    ],
    "feedingMode": "Surf-zone benthic forager.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-redtail",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sf-bay-regs",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "isopods",
          "amphipods",
          "polychaetes",
          "small crabs"
        ],
        "habitats": [
          "habitat:surf"
        ],
        "lureFamily": "small invertebrate bottom presentation through mapped sandy swash",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine surf zone"
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine surf zone"
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "High-energy open-coast sandy beaches, sandy pocket beaches and swash/trough habitat."
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "High-energy open-coast sandy beaches, sandy pocket beaches and swash/trough habitat."
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine surf zone"
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "High-energy open-coast sandy beaches, sandy pocket beaches and swash/trough habitat."
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "isopods",
          "amphipods",
          "polychaetes",
          "small crabs"
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Summer parturition/nearshore aggregation is broad biology, not a bite window."
        ],
        "sourceIds": [
          "source:cdfw-redtail",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:rubberlip-seaperch": {
    "id": "species:rubberlip-seaperch",
    "commonName": "Rubberlip seaperch",
    "scientificName": "Rhacochilus toxotes",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine nearshore"
        ],
        "substrateStructureDepth": [
          "Rocky reef/kelp, wharves, pilings and jetties; exact depth unresolved in fetched primary material."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:pier",
        "habitat:jetty",
        "habitat:breakwater",
        "habitat:rocky-shore"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Movement/season unknown."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "benthic invertebrates"
    ],
    "feedingMode": "Structure-associated benthic forager.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:usfws-rubberlip",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "B",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-surfperch-account",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sf-bay-regs",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "benthic invertebrates"
        ],
        "habitats": [
          "habitat:pier",
          "habitat:jetty",
          "habitat:breakwater",
          "habitat:rocky-shore"
        ],
        "lureFamily": "small invertebrate presentation beside pilings/rock-kelp",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine nearshore"
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine nearshore"
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Rocky reef/kelp, wharves, pilings and jetties; exact depth unresolved in fetched primary material."
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Rocky reef/kelp, wharves, pilings and jetties; exact depth unresolved in fetched primary material."
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine nearshore"
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Rocky reef/kelp, wharves, pilings and jetties; exact depth unresolved in fetched primary material."
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "benthic invertebrates"
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Movement/season unknown."
        ],
        "sourceIds": [
          "source:usfws-rubberlip",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:starry-flounder": {
    "id": "species:starry-flounder",
    "commonName": "Starry flounder",
    "scientificName": "Platichthys stellatus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine–brackish–freshwater tolerant"
        ],
        "substrateStructureDepth": [
          "Demersal over gravel, sand and mud in ocean, bays, estuaries, river mouths and sloughs."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:surf",
        "habitat:pier",
        "habitat:bay-shore",
        "habitat:tidal-slough",
        "habitat:estuary",
        "habitat:estuary-mouth"
      ],
      "incompatible": [
        "habitat:rocky-shore"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Regional spawning near river mouths/sloughs November–February; no catch window."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "worms",
      "crustaceans",
      "small fish"
    ],
    "feedingMode": "Soft-bottom benthic predator.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-starry",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-general-ocean",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "worms",
          "crustaceans",
          "small fish"
        ],
        "habitats": [
          "habitat:surf",
          "habitat:pier",
          "habitat:bay-shore",
          "habitat:tidal-slough",
          "habitat:estuary",
          "habitat:estuary-mouth"
        ],
        "lureFamily": "bottom-contact presentation over mapped sand/mud/gravel",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine–brackish–freshwater tolerant"
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine–brackish–freshwater tolerant"
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Demersal over gravel, sand and mud in ocean, bays, estuaries, river mouths and sloughs."
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Demersal over gravel, sand and mud in ocean, bays, estuaries, river mouths and sloughs."
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine–brackish–freshwater tolerant"
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Demersal over gravel, sand and mud in ocean, bays, estuaries, river mouths and sloughs."
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "worms",
          "crustaceans",
          "small fish"
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Regional spawning near river mouths/sloughs November–February; no catch window."
        ],
        "sourceIds": [
          "source:cdfw-starry",
          "source:cdfw-general-ocean"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:striped-seaperch": {
    "id": "species:striped-seaperch",
    "commonName": "Striped seaperch",
    "scientificName": "Embiotoca lateralis",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine, including bays/estuaries"
        ],
        "substrateStructureDepth": [
          "Shallow rocky reef, kelp and nearshore artificial structure; surface/intertidal to deeper water."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:pier",
        "habitat:jetty",
        "habitat:breakwater",
        "habitat:bay-shore",
        "habitat:rocky-shore"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:tidal-slough"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Seasonal movement unknown."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "brittle stars",
      "fish eggs",
      "bivalves",
      "gastropods",
      "urchins"
    ],
    "feedingMode": "Structure-associated benthic forager.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-striped-seaperch",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sf-bay-regs",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "brittle stars",
          "fish eggs",
          "bivalves",
          "gastropods",
          "urchins"
        ],
        "habitats": [
          "habitat:pier",
          "habitat:jetty",
          "habitat:breakwater",
          "habitat:bay-shore",
          "habitat:rocky-shore"
        ],
        "lureFamily": "small benthic-invertebrate profile near rock/kelp/pilings",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine, including bays/estuaries"
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine, including bays/estuaries"
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Shallow rocky reef, kelp and nearshore artificial structure; surface/intertidal to deeper water."
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Shallow rocky reef, kelp and nearshore artificial structure; surface/intertidal to deeper water."
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine, including bays/estuaries"
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Shallow rocky reef, kelp and nearshore artificial structure; surface/intertidal to deeper water."
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "brittle stars",
          "fish eggs",
          "bivalves",
          "gastropods",
          "urchins"
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Seasonal movement unknown."
        ],
        "sourceIds": [
          "source:cdfw-striped-seaperch",
          "source:cdfw-sf-bay-regs"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:topsmelt": {
    "id": "species:topsmelt",
    "commonName": "Topsmelt",
    "scientificName": "Atherinops affinis",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine–estuarine, hypersaline tolerant"
        ],
        "substrateStructureDepth": [
          "Upper-water-column schools along estuaries, shorelines, beaches, kelp and pilings; most often surface to about 9 m."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:pier",
        "habitat:bay-shore",
        "habitat:estuary",
        "habitat:estuary-mouth",
        "habitat:surf"
      ],
      "incompatible": [
        "habitat:tidal-slough"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Broad spring/summer estuary use and fall/winter coast/bay pattern is not current presence."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "algae",
      "diatoms",
      "small crustaceans",
      "benthic invertebrates"
    ],
    "feedingMode": "Schooling omnivore/planktivore.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-topsmelt",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-general-ocean",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:oehha-sf-bay",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "B",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "algae",
          "diatoms",
          "small crustaceans",
          "benthic invertebrates"
        ],
        "habitats": [
          "habitat:pier",
          "habitat:bay-shore",
          "habitat:estuary",
          "habitat:estuary-mouth",
          "habitat:surf"
        ],
        "lureFamily": "small suspended presentation around observed upper-water schools",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine–estuarine, hypersaline tolerant"
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine–estuarine, hypersaline tolerant"
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Upper-water-column schools along estuaries, shorelines, beaches, kelp and pilings; most often surface to about 9 m."
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Upper-water-column schools along estuaries, shorelines, beaches, kelp and pilings; most often surface to about 9 m."
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine–estuarine, hypersaline tolerant"
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Upper-water-column schools along estuaries, shorelines, beaches, kelp and pilings; most often surface to about 9 m."
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "algae",
          "diatoms",
          "small crustaceans",
          "benthic invertebrates"
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Broad spring/summer estuary use and fall/winter coast/bay pattern is not current presence."
        ],
        "sourceIds": [
          "source:cdfw-topsmelt",
          "source:cdfw-general-ocean",
          "source:oehha-sf-bay"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:walleye-surfperch": {
    "id": "species:walleye-surfperch",
    "commonName": "Walleye surfperch",
    "scientificName": "Hyperprosopon argenteum",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine nearshore/embayment"
        ],
        "substrateStructureDepth": [
          "Sandy beach, bays and shallow water near rocks/pier structure; schooling."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:surf",
        "habitat:pier",
        "habitat:jetty",
        "habitat:breakwater",
        "habitat:bay-shore"
      ],
      "incompatible": [
        "habitat:tidal-slough"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Regional mating and embayment patterns do not establish a Bay Bite season."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "small crustaceans"
    ],
    "feedingMode": "Schooling small-crustacean forager.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-walleye",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-surfperch-account",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sf-bay-regs",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:oehha-sf-bay",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "B",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "small crustaceans"
        ],
        "habitats": [
          "habitat:surf",
          "habitat:pier",
          "habitat:jetty",
          "habitat:breakwater",
          "habitat:bay-shore"
        ],
        "lureFamily": "small suspended or bottom-near invertebrate profile at sand/structure edge",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine nearshore/embayment"
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine nearshore/embayment"
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Sandy beach, bays and shallow water near rocks/pier structure; schooling."
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Sandy beach, bays and shallow water near rocks/pier structure; schooling."
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine nearshore/embayment"
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Sandy beach, bays and shallow water near rocks/pier structure; schooling."
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "small crustaceans"
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Regional mating and embayment patterns do not establish a Bay Bite season."
        ],
        "sourceIds": [
          "source:cdfw-walleye",
          "source:cdfw-surfperch-account",
          "source:cdfw-sf-bay-regs",
          "source:oehha-sf-bay"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:white-croaker": {
    "id": "species:white-croaker",
    "commonName": "White croaker",
    "scientificName": "Genyonemus lineatus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "marine nearshore/bays"
        ],
        "substrateStructureDepth": [
          "Demersal soft sand–mud habitat, sometimes sand-bottom kelp; surf zone to deeper water."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:surf",
        "habitat:pier",
        "habitat:bay-shore",
        "habitat:estuary",
        "habitat:estuary-mouth"
      ],
      "incompatible": [
        "habitat:rocky-shore",
        "habitat:tidal-slough"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Study-specific spawning/diel findings do not support a Bay Bite catch window."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "crustaceans",
      "polychaetes",
      "clams",
      "small fish"
    ],
    "feedingMode": "Primarily benthic/epibenthic feeder.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-white-croaker",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:oehha-white-croaker",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "B",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [
      {
        "forageGuilds": [
          "crustaceans",
          "polychaetes",
          "clams",
          "small fish"
        ],
        "habitats": [
          "habitat:surf",
          "habitat:pier",
          "habitat:bay-shore",
          "habitat:estuary",
          "habitat:estuary-mouth"
        ],
        "lureFamily": "bottom presentation over mapped soft bottom",
        "profileSize": "qualitative only",
        "depthZone": "mapped shore-reachable habitat only",
        "retrieve": "controlled for substrate/current and safety",
        "rigWeight": "minimum needed for safe control; no universal number",
        "vibration": "qualitative only; no frequency claim",
        "claimProvenance": {
          "lureFamily": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "forageMatch": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "profileSize": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "depthZone": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "retrieve": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "vibration": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          },
          "rigWeight": {
            "kind": "field-heuristic",
            "sourceIds": [],
            "limitations": [
              "Habitat/diet translation only; no comparative local catch/effort validation."
            ],
            "includedInScientificCoverage": false
          }
        }
      }
    ],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "marine nearshore/bays"
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "marine nearshore/bays"
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Demersal soft sand–mud habitat, sometimes sand-bottom kelp; surf zone to deeper water."
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Demersal soft sand–mud habitat, sometimes sand-bottom kelp; surf zone to deeper water."
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "marine nearshore/bays"
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Demersal soft sand–mud habitat, sometimes sand-bottom kelp; surf zone to deeper water."
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "crustaceans",
          "polychaetes",
          "clams",
          "small fish"
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Study-specific spawning/diel findings do not support a Bay Bite catch window."
        ],
        "sourceIds": [
          "source:cdfw-white-croaker",
          "source:oehha-white-croaker"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    }
  },
  "species:white-sturgeon": {
    "id": "species:white-sturgeon",
    "commonName": "White sturgeon",
    "scientificName": "Acipenser transmontanus",
    "lifeStages": [
      {
        "stage": "unknown/mixed",
        "waterAndSalinity": [
          "freshwater–brackish–estuarine with occasional coastal movement"
        ],
        "substrateStructureDepth": [
          "Large rivers, Delta and estuary channels; spawning eggs adhere to hard river substrate; feeding/residence is demersal."
        ]
      }
    ],
    "habitat": {
      "compatible": [
        "habitat:bay-shore",
        "habitat:tidal-slough",
        "habitat:estuary"
      ],
      "incompatible": [
        "habitat:surf",
        "habitat:jetty",
        "habitat:breakwater",
        "habitat:rocky-shore"
      ],
      "nuances": [
        "Compatibility is conditional on mapped substrate/structure/salinity/depth and shore reachability; catalog label alone is insufficient."
      ]
    },
    "seasonalPhenology": [
      "Adults move riverward seasonally and spawn broadly February–June; individual salinity histories vary. Not a target window."
    ],
    "dielLight": [
      "Unknown for actionable scoring; light may be used only as a visibility/control input."
    ],
    "forageGuilds": [
      "benthic prey (exact local composition unresolved)"
    ],
    "feedingMode": "Demersal benthic feeder.",
    "conditionResponses": [
      {
        "input": "current",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wave",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "wind",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "clarity",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      },
      {
        "input": "light",
        "rule": "Assess presentation control and safety only; no feeding multiplier is asserted.",
        "uncertainty": "Requires fresh, representative local observation and mapped geometry."
      }
    ],
    "evidence": [
      {
        "sourceId": "source:cdfw-white-sturgeon",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sturgeon-card",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:cdfw-sturgeon-opener",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "A",
        "limitations": "Does not establish current local presence or lure effectiveness."
      },
      {
        "sourceId": "source:frontiers-sturgeon",
        "supports": "Taxonomy, habitat, life history, feeding, vulnerability, or legal statement as bounded in profile.",
        "grade": "B",
        "limitations": "Does not establish current local presence or lure effectiveness."
      }
    ],
    "uncertainty": [
      "No current local presence claim.",
      "No calibrated abundance, catch probability, bite window, environmental threshold, or causal lure claim.",
      "Numeric physiology/response curves remain unknown unless separately sourced and validated."
    ],
    "shorePresentations": [],
    "claims": {
      "domain": {
        "state": "known",
        "value": [
          "freshwater–brackish–estuarine with occasional coastal movement"
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "environment": {
        "state": "known",
        "value": [
          "freshwater–brackish–estuarine with occasional coastal movement"
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "substrate": {
        "state": "known",
        "value": [
          "Large rivers, Delta and estuary channels; spawning eggs adhere to hard river substrate; feeding/residence is demersal."
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "structure": {
        "state": "known",
        "value": [
          "Large rivers, Delta and estuary channels; spawning eggs adhere to hard river substrate; feeding/residence is demersal."
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "salinity": {
        "state": "known",
        "value": [
          "freshwater–brackish–estuarine with occasional coastal movement"
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "depth": {
        "state": "known",
        "value": [
          "Large rivers, Delta and estuary channels; spawning eggs adhere to hard river substrate; feeding/residence is demersal."
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "forage": {
        "state": "known",
        "value": [
          "benthic prey (exact local composition unresolved)"
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "season": {
        "state": "known",
        "value": [
          "Adults move riverward seasonally and spawn broadly February–June; individual salinity histories vary. Not a target window."
        ],
        "sourceIds": [
          "source:cdfw-white-sturgeon",
          "source:cdfw-sturgeon-card",
          "source:cdfw-sturgeon-opener",
          "source:frontiers-sturgeon"
        ]
      },
      "presentation": {
        "state": "unknown",
        "reason": "Practical presentation categories are field heuristics excluded from scientific coverage; no comparative local catch/effort evidence."
      }
    },
    "targetingPolicy": "conservation-legal-alert-first"
  }
} as const satisfies Readonly<Record<string, ExactTaxonScienceRecord>>;

export const reviewedExpansionSources = [
  {
    "id": "source:cdfw-bat-ray",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/bat-ray/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-black-rockfish",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/black-rockfish/false",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-blue-rockfish",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/blue-rockfish/false/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-brown-rockfish",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/brown-rockfish/false/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-cabezon",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/cabezon/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-groundfish-2026",
    "title": "CDFW current regulation summary",
    "url": "https://wildlife.ca.gov/Fishing/Ocean/Regulations/Groundfish-Summary",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-catfish-monitoring",
    "title": "CDFW peer-reviewed monitoring",
    "url": "https://journal.wildlife.ca.gov/2024/12/27/experimental-gillnet-study-to-inform-future-large-fish-monitoring-in-the-san-francisco-estuary/",
    "sourceType": "peer-reviewed-paper",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:smithsonian-channel-catfish",
    "title": "Smithsonian institutional synthesis",
    "url": "https://invasions.si.edu/nemesis/species_summary/163998",
    "sourceType": "authoritative-agency-publication",
    "publisher": "Smithsonian Institution",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-jacksmelt",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/jacksmelt/true/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-kelp-greenling",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/kelp-greenling/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:noaa-kelp-greenling",
    "title": "NOAA agency life-history database",
    "url": "https://apps-afsc.fisheries.noaa.gov/ichthyo/LHDataLH.php?GSID=Hexagrammos%21decagrammus",
    "sourceType": "authoritative-agency-publication",
    "publisher": "NOAA",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-leopard-shark",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/leopard-shark/false/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-sf-bay-regs",
    "title": "CDFW current SF Bay regulation map",
    "url": "https://wildlife.ca.gov/Fishing/Ocean/Regulations/Fishing-Map/sf-bay",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:noaa-lingcod",
    "title": "NOAA agency species profile",
    "url": "https://www.fisheries.noaa.gov/species/lingcod",
    "sourceType": "authoritative-agency-publication",
    "publisher": "NOAA",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-lingcod",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/lingcod/false/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-monkeyface",
    "title": "CDFW agency species account PDF",
    "url": "https://nrm.dfg.ca.gov/FileHandler.ashx?DocumentID=34299",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:ca-waterboards-staghorn",
    "title": "California State Water Resources Control Board-hosted agency technical species account",
    "url": "https://www.waterboards.ca.gov/centralcoast/water_issues/programs/duke_energy/docs/sampling/staghornsculpin.pdf",
    "sourceType": "authoritative-agency-publication",
    "publisher": "Reviewed source publisher",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-general-ocean",
    "title": "CDFW current general ocean regulations",
    "url": "https://wildlife.ca.gov/Fishing/Ocean/Regulations/Sport-Fishing/General-Ocean-Fishing-Regs",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-pile",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/pile-perch/false/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-surfperch-account",
    "title": "CDFW agency fisheries account PDF",
    "url": "https://nrm.dfg.ca.gov/FileHandler.ashx?DocumentID=34362",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-redtail",
    "title": "CDFW enhanced status report",
    "url": "https://marinespecies.wildlife.ca.gov/barred-surfperch-and-redtail-surfperch/the-species/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:usfws-rubberlip",
    "title": "USFWS species profile mirror",
    "url": "https://apps.dtic.mil/sti/html/tr/ADA212125/index.html",
    "sourceType": "authoritative-agency-publication",
    "publisher": "USFWS",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-starry",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/starry-flounder/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-striped-seaperch",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/striped-seaperch/false/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-topsmelt",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/topsmelt/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-walleye",
    "title": "CDFW agency species profile",
    "url": "https://marinespecies.wildlife.ca.gov/walleye-surfperch/false/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-white-croaker",
    "title": "CDFW enhanced status report",
    "url": "https://marinespecies.wildlife.ca.gov/white-croaker/true/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:oehha-white-croaker",
    "title": "California OEHHA consumption advisory",
    "url": "https://oehha.ca.gov/fish/species/white-croaker",
    "sourceType": "authoritative-agency-publication",
    "publisher": "California OEHHA",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:oehha-sf-bay",
    "title": "California OEHHA consumption advisory",
    "url": "https://oehha.ca.gov/fish/advisories/san-francisco-bay",
    "sourceType": "authoritative-agency-publication",
    "publisher": "California OEHHA",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-white-sturgeon",
    "title": "CDFW conservation/legal status page",
    "url": "https://wildlife.ca.gov/Conservation/Fishes/Sturgeon/White-Sturgeon",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-sturgeon-card",
    "title": "CDFW regulation/report-card page",
    "url": "https://wildlife.ca.gov/Conservation/Fishes/Sturgeon/report-card",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-sturgeon-opener",
    "title": "CDFW 2025–26 season notice",
    "url": "https://wildlife.ca.gov/News/Archive/white-sturgeon-opener-kicks-off-with-a-no-fee-report-card-for-this-season",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:frontiers-sturgeon",
    "title": "Peer-reviewed telemetry/geochemistry study",
    "url": "https://www.frontiersin.org/journals/marine-science/articles/10.3389/fmars.2022.859038/full",
    "sourceType": "peer-reviewed-paper",
    "publisher": "Frontiers in Marine Science",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:cdfw-bay-study",
    "title": "CDFW primary standardized survey",
    "url": "https://wildlife.ca.gov/Conservation/Delta/Bay-Study",
    "sourceType": "authoritative-agency-publication",
    "publisher": "CDFW",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:noaa-benthic",
    "title": "NOAA agency mapped habitat service",
    "url": "https://coast.noaa.gov/arcgis/rest/services/Hosted/san_francisco_bay_2011/FeatureServer",
    "sourceType": "official-agency-geospatial-product",
    "publisher": "NOAA",
    "role": "habitat-geography",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:obis-api",
    "title": "OBIS historical occurrence aggregator",
    "url": "https://api.obis.org/v3/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "OBIS",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:gbif-api",
    "title": "GBIF historical occurrence aggregator",
    "url": "https://techdocs.gbif.org/en/openapi/v1/occurrence",
    "sourceType": "authoritative-agency-publication",
    "publisher": "GBIF",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  },
  {
    "id": "source:inat-api",
    "title": "iNaturalist community occurrence API",
    "url": "https://api.inaturalist.org/v1/docs/",
    "sourceType": "authoritative-agency-publication",
    "publisher": "iNaturalist",
    "role": "biology",
    "checkedAt": "2026-08-13",
    "reachability": "verified-http",
    "claimStatus": "foundation",
    "limitations": "Reviewed exact-taxon package source; does not establish current local presence, abundance, catch probability, or presentation efficacy."
  }
] as const satisfies readonly ScientificSourceRegistryRecord[];
