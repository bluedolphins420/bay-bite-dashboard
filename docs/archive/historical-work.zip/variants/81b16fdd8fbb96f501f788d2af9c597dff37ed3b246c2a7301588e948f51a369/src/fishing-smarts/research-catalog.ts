import rawCatalog from './generated/research-catalog.v2.json';

export type ResearchSource = { id: string; title: string; url: string; owner: string; checkedAt: string; notes?: string };
export type ResearchSensorBinding = { metric: string; sensorId?: string; availability?: 'unavailable'; distanceKm?: number; representativeness?: 'exact-site'|'local'|'regional'|'proxy'|'not-representative'; warning: string; maxAgeMinutes?: number };
export type ResearchSpot = {
  id: string; legacyId: string; displayName: string; coordinates: { lat: number; lon: number; precision: string }; region: string;
  habitatIds: string[]; environmentClass: string; ownerJurisdiction: string;
  access: { state: string; checkedAt: string; sourceIds: string[]; verificationScope: string; conditions: string; originalV1State: string };
  licenseBoundary: string; physicalProfile: { summary: string; substrate: string; salinity: string; exposure: string; grounding: string };
  tactics: string[]; safety: { hazardsAndRetreat: string[]; closureConstraints: string };
  mpaAdjudication: { status: string; checkedAt: string; sourceIds: string[]; intersections: string[]; warning: string };
  advisories: { consumptionSourceId?: string; weatherResolver: string; sameDayChecks: string[] };
  sensorBindings: ResearchSensorBinding[]; sourceIds: string[];
  researchAcceptance: { acceptedActionable: true; reasons: string[]; speciesEvidenceCount: number };
};
export type ResearchSpeciesEdge = { id: string; spotId: string; speciesId: string; evidenceType: string; sourceIds: string[]; confidence: 'low'|'medium'|'high'; locality: { radiusKm?: number; observationCount?: number; warning: string }; habitatIds: string[]; reviewedAt: string };
export type ResearchSensor = { id: string; officialId: string; name: string; environment: string; sourceId: string };
export type ResearchCatalog = {
  schemaVersion: number; generatedAt: string; bundleId: string; scope: string; metrics: Record<string, number>;
  sources: ResearchSource[]; spots: ResearchSpot[]; species: Array<{ id: string; commonName: string; scientificName?: string; compatibleHabitats: string[] }>;
  habitats: Array<{ id: string; displayName: string }>; regulatoryAreas: Array<{ id: string; displayName: string }>;
  mpas: Array<{ id: string; displayName: string; sourceIds: string[] }>; sensors: ResearchSensor[]; spotSpeciesEvidence: ResearchSpeciesEdge[];
};

export const researchCatalog = rawCatalog as ResearchCatalog;
export const researchSpots = researchCatalog.spots;

export const sensorDefinitions = researchCatalog.sensors;
export const researchSourceById = new Map(researchCatalog.sources.map((source) => [source.id, source]));
export const evidenceBySpotId = new Map(researchSpots.map((spot) => [spot.id, researchCatalog.spotSpeciesEvidence.filter((edge) => edge.spotId === spot.id)]));
export const evidenceDisclosure = 'Local corroboration from reviewed occurrence/catch-pattern evidence; not current presence, exact casting-point proof, or legal target-now status.';
