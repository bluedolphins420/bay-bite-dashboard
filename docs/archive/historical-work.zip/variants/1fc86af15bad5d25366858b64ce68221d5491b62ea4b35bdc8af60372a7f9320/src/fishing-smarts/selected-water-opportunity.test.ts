import { describe, expect, it } from 'vitest';
import { spots } from '../data';
import { buildScientificStatusExport, buildSelectedWaterOpportunity, occurrenceEvidenceOverlays, reviewedOccurrenceRecords } from './selected-water-opportunity';

const conditions = {
  status: 'live' as const, observedAt: '2026-08-13T17:30:00Z', windSpeedKt: '7 kt', waveHeightFt: '2.0 ft',
  observations: {
    level: { availability: 'available' as const, freshness: 'live' as const }, wind: { availability: 'available' as const, freshness: 'live' as const }, buoy: { availability: 'available' as const, freshness: 'live' as const }, wave: { availability: 'available' as const, freshness: 'live' as const }, temperature: { availability: 'unavailable' as const, freshness: 'unavailable' as const },
  },
  stationName: 'fixture', buoyId: 'fixture', waveLabel: 'Significant wave height', message: 'fixture',
};

describe('selected-water strict scientific integration', () => {
  it('keeps catalog radius evidence corroboration-only and not a favorable prior', () => {
    const oceanBeach = spots.find((spot) => spot.id === 'ocean-beach')!;
    const barred = buildSelectedWaterOpportunity(oceanBeach, conditions, '2026-08-13T18:00:00Z').find((item) => item.taxonId === 'species:barred-surfperch')!;
    expect(barred.displayLabel).toBe('Barred surfperch');
    expect(barred.result.factors.historicalOccurrencePrior).toBe('unknown');
    expect(barred.result.corroborationOnly.length).toBeGreaterThan(0);
    expect(barred.result.corroborationOnly[0].displayStatus).toBe('reviewed local corroboration only');
  });

  it('preserves source and query geometry separately and never fabricates source fish-location centers', () => {
    expect(reviewedOccurrenceRecords.length).toBeGreaterThan(0);
    for (const record of reviewedOccurrenceRecords) {
      expect(record.queryGeometry).toMatchObject({ kind: 'radius', radiusKm: 5 });
      expect(record.sourceGeometry).not.toHaveProperty('center');
      expect(record).not.toHaveProperty('spotId');
      expect(record.evidenceRole).toBe('community-corroboration');
      expect(record.spatialApplicability.reviewStatus).toBe('not-reviewed');
    }
    for (const overlay of occurrenceEvidenceOverlays) {
      expect(overlay.geometry).toMatchObject({ kind: 'query-radius' });
      expect(overlay.geometry).not.toHaveProperty('center');
      expect(overlay.legend).toMatch(/query area.*not source fish-location geometry/i);
      expect(overlay.displayStatus).toBe('reviewed local corroboration only');
    }
  });

  it('preserves eligibility actionable and matched rule IDs end-to-end', () => {
    const crissy = spots.find((spot) => spot.id === 'crissy-field')!;
    const results = buildSelectedWaterOpportunity(crissy, conditions, '2026-08-13T18:00:00Z');
    for (const item of results) {
      expect(item.result.legalEligibility.actionable).toBe(false);
      expect(item.result.legalEligibility.matchedRuleIds).toEqual(expect.any(Array));
      expect(item.result.presentations).toEqual([]);
    }
  });

  it('does not reuse family legality to authorize an exact barred-surfperch taxon', () => {
    const oceanBeach = spots.find((spot) => spot.id === 'ocean-beach')!;
    const barred = buildSelectedWaterOpportunity(oceanBeach, conditions, '2026-08-13T18:00:00Z').find((item) => item.taxonId === 'species:barred-surfperch')!;
    expect(barred.result.legalEligibility).toMatchObject({ actionable: false, matchedRuleIds: [] });
    expect(barred.result.factors.legalGate).not.toBe('open');
  });

  it('keeps the live UI low or unknown with safety and missing dimensions explicit', () => {
    const crissy = spots.find((spot) => spot.id === 'crissy-field')!;
    for (const item of buildSelectedWaterOpportunity(crissy, conditions, '2026-08-13T18:00:00Z')) {
      expect(item.result.evidenceCoverage).not.toBe('high');
      expect(item.result.presentations).toEqual([]);
      expect(item.result.missingInputs).toEqual(expect.arrayContaining(['mapped habitat geometry', 'exact MPA geometry']));
      expect(['safe', 'unsafe', 'unknown']).toContain(item.result.safetyStatus);
    }
  });

  it('exports corroboration, evidence coverage, safety, missing dimensions, legal identity, and claim provenance without legacy claims', () => {
    const crissy = spots.find((spot) => spot.id === 'crissy-field')!;
    const exported = buildScientificStatusExport(crissy, conditions, '2026-08-13T18:00:00Z');
    const serialized = JSON.stringify(exported);
    expect(serialized).toMatch(/corroborationOnly|evidenceCoverage|safetyStatus|missingInputs|matchedRuleIds|claimProvenance/);
    expect(serialized).not.toMatch(/bestWindow|biteReason|modelScore|solunar|barometr|40.?80\s*Hz|61\s*°?F/i);
  });
});
