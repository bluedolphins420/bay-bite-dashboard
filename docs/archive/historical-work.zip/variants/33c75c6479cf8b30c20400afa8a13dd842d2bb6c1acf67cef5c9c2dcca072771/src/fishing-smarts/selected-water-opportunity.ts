import type { Species, Spot } from '../data';
import type { LiveTelemetry } from '../telemetry';
import { currentSpotLegality } from './app-integration';
import { evaluateSpeciesOpportunity, exactTaxonScience, type ExactTaxonId, type ExactTaxonScienceRecord, type HistoricalOccurrenceEvidence, type OpportunityConditions, type OpportunityResult } from './fauna-opportunity';
import { evidenceBySpotId, researchSourceById, researchSpots } from './research-catalog';
import type { StableId } from './index';

const labelToTaxon: Partial<Record<Species, ExactTaxonId>> = {
  'Striped Bass': 'species:striped-bass',
  Halibut: 'species:california-halibut',
};

function reviewedOccurrenceFor(spotId: StableId, taxonId: ExactTaxonId): HistoricalOccurrenceEvidence[] {
  return (evidenceBySpotId.get(spotId) ?? [])
    .filter((edge) => edge.speciesId === taxonId)
    .map((edge) => ({
      id: edge.id as StableId,
      taxonId,
      spotId,
      sourceId: edge.sourceIds[0] as StableId,
      geometry: { kind: 'area' as const, publicResolution: edge.locality.radiusKm ? `${edge.locality.radiusKm} km public-source query radius` : 'public source area' },
      timeCoverage: { reviewedAt: edge.reviewedAt },
      method: edge.evidenceType.replaceAll('-', ' '),
      effort: edge.locality.observationCount === undefined ? 'not supplied by reviewed derivative' : `${edge.locality.observationCount} source records in reviewed query result`,
      lifeStage: 'not supplied',
      spatialResolution: edge.locality.radiusKm ? `${edge.locality.radiusKm} km radius` : 'source area',
      evidenceGrade: edge.confidence === 'high' ? 'B' as const : 'C' as const,
      limitations: [edge.locality.warning, 'Historical occurrence evidence is not current presence, abundance, or exact casting-point proof.'],
    }));
}

export const reviewedOccurrenceRecords: HistoricalOccurrenceEvidence[] = (['spot:linda-mar','spot:crissy-field'] as StableId[]).flatMap((spotId) =>
  (['species:striped-bass','species:california-halibut','species:barred-surfperch'] as ExactTaxonId[]).flatMap((taxonId) => reviewedOccurrenceFor(spotId, taxonId))
);

export interface OccurrenceEvidenceOverlay {
  id: StableId;
  spotId: StableId;
  taxonId: ExactTaxonId;
  geometry: { kind:'area'|'cell'; center:[number,number]; radiusMeters:number; publicResolution:string };
  sourceId: StableId;
  method:string;
  reviewedAt:string;
  evidenceAgeLabel:string;
  confidence:'low'|'medium'|'high';
  legend:string;
}

export const occurrenceEvidenceOverlays: OccurrenceEvidenceOverlay[] = reviewedOccurrenceRecords.map((record) => {
  const spot = researchSpots.find((item) => item.id === record.spotId)!;
  const radiusKm = Number.parseFloat(record.spatialResolution) || 5;
  return {
    id: `overlay:${record.id.replace('evidence:','')}` as StableId,
    spotId:record.spotId, taxonId:record.taxonId,
    geometry:{kind:'area',center:[spot.coordinates.lat,spot.coordinates.lon],radiusMeters:radiusKm*1000,publicResolution:record.geometry.publicResolution},
    sourceId:record.sourceId,method:record.method ?? 'method not supplied',reviewedAt:record.timeCoverage.reviewedAt,evidenceAgeLabel:`Reviewed ${record.timeCoverage.reviewedAt.slice(0,10)}`,
    confidence:record.evidenceGrade==='A'?'high':record.evidenceGrade==='B'?'medium':'low',
    legend:'Historical occurrence area — not live presence; circle reflects public source query resolution, not a fish-location boundary.',
  };
});

function conditionState(telemetry:LiveTelemetry):OpportunityConditions | undefined {
  if (!telemetry.observedAt) return undefined;
  const freshnessUnknown = (value:string) => value === 'unavailable' || value === 'stale';
  const windNumber = Number.parseFloat(telemetry.windSpeedKt ?? '');
  const waveNumber = Number.parseFloat(telemetry.waveHeightFt ?? '');
  return {
    observedAt:telemetry.observedAt,
    current:{state:'unknown',sourceId:'source:noaa-coops-api'},
    wave:{state:freshnessUnknown(telemetry.observations.wave.freshness)?'unknown':Number.isFinite(waveNumber)&&waveNumber>=6?'rough':'manageable',sourceId:'source:noaa-ndbc'},
    wind:{state:freshnessUnknown(telemetry.observations.wind.freshness)?'unknown':Number.isFinite(windNumber)&&windNumber>=20?'strong':Number.isFinite(windNumber)&&windNumber<=8?'light':'manageable',sourceId:'source:noaa-coops-api'},
    clarity:'unknown',light:'unknown',
  };
}

export interface SelectedWaterOpportunity { displayLabel:string; taxonId:StableId; ecology?:{scientificName:string;lifeStages:ExactTaxonScienceRecord['lifeStages'];habitat:ExactTaxonScienceRecord['habitat'];forageGuilds:string[];feedingMode:string}; result:OpportunityResult }

export function buildSelectedWaterOpportunity(spot:Spot, telemetry:LiveTelemetry, evaluatedAt=new Date().toISOString()):SelectedWaterOpportunity[] {
  const record=researchSpots.find((item)=>item.id===spot.stableId);
  const legalByLabel=new Map(currentSpotLegality(spot,evaluatedAt).map((item)=>[item.label,item]));
  return spot.species.map((displayLabel) => {
    const spotId=(spot.stableId ?? `spot:${spot.id}`) as StableId;
    const exactBarredEvidence=displayLabel==='Surfperch'&&reviewedOccurrenceFor(spotId,'species:barred-surfperch').length>0;
    const taxonId=exactBarredEvidence?'species:barred-surfperch':labelToTaxon[displayLabel] ?? (`species:${displayLabel.toLowerCase().replaceAll(/[^a-z0-9]+/g,'-')}` as StableId);
    const scientificDisplayLabel=exactBarredEvidence?'Barred surfperch':displayLabel;
    const legalItem=legalByLabel.get(displayLabel);
    const exactLegalItem=taxonId==='species:barred-surfperch'?undefined:legalItem;
    const legal=exactLegalItem?{status:exactLegalItem.status,actionable:exactLegalItem.actionable,matchedRuleIds:[],reasons:[exactLegalItem.warning]}:{status:'unknown' as const,actionable:false,matchedRuleIds:[],reasons:['No exact-taxon legal record is mapped. Family-level rules are not reused.']};
    const result=evaluateSpeciesOpportunity({
      taxonId,spotId,habitatIds:(record?.habitatIds ?? []) as StableId[],environmentClass:record?.environmentClass ?? 'unknown',evaluatedAt,
      occurrence:taxonId in exactTaxonScience?reviewedOccurrenceFor(spotId,taxonId as ExactTaxonId):[],conditions:conditionState(telemetry),legal,
      access:{state:record?.access.state==='open'?'open':record?.access.state==='closed'?'closed':'unknown'},
      mpa:{resolved:false,intersectsNoTake:false},
    });
    const science=taxonId in exactTaxonScience?exactTaxonScience[taxonId as ExactTaxonId]:undefined;
    const ecology=science?{scientificName:science.scientificName,lifeStages:science.lifeStages,habitat:science.habitat,forageGuilds:science.forageGuilds,feedingMode:science.feedingMode}:undefined;
    return {displayLabel:scientificDisplayLabel,taxonId,ecology,result};
  });
}

export function buildScientificStatusExport(spot:Spot,telemetry:LiveTelemetry,evaluatedAt=new Date().toISOString()) {
  return {
    reportType:'bay-bite-scientific-status',generatedAt:evaluatedAt,
    selectedWater:{id:spot.id,stableId:spot.stableId,name:spot.name,region:spot.region,type:spot.type},
    opportunities:buildSelectedWaterOpportunity(spot,telemetry,evaluatedAt),
  };
}

export function overlaySourceTitle(sourceId:StableId):string {
  return researchSourceById.get(sourceId)?.title ?? sourceId;
}
