import './research-catalog.css';
import { useEffect, useMemo, useState } from 'react';
import { MapContainer, TileLayer, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { AlertTriangle, ExternalLink, Fish, MapPin, Search, ShieldAlert, Star, Sun, Waves } from 'lucide-react';
import { allSpecies, regions, safetyColor, spots, tideSeries, type Region, type Species, type Spot } from './data';
import { currentSpotLegality } from './fishing-smarts/app-integration';
import { buildSelectedWaterOpportunity } from './fishing-smarts/selected-water-opportunity';
import { ingestLiveStatusCache, reviewedTelemetryFromCache, type LiveStatusCache, type LiveTelemetry } from './telemetry';
import { buildSpotPopup } from './popup-content';
import { reconcileSelectedId } from './selection';
import { googleMapsUrl } from './navigation';

type SpotMode = 'All' | 'Favorites' | 'Surf' | 'Pier/Jetty' | 'Bay Shore' | 'Hazard Watch';
type SortMode = 'name' | 'region';

function formatDataDate(value?: string) {
  if (!value) return 'Waiting for live refresh';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'Live refresh unavailable' : date.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}


function makeIcon(_spot: Spot, isSelected: boolean) {
  const color = '#67e8f9';
  const size = isSelected ? 28 : 20;
  const stroke = isSelected ? '#ffffff' : 'rgba(255,255,255,0.75)';
  const shadow = isSelected ? `0 0 0 3px rgba(103,232,249,0.9), 0 0 30px ${color}` : `0 0 0 2px ${stroke}, 0 0 20px ${color}`;

  return L.divIcon({
    className: '',
    html: `<div class="marker-dot" style="width:${size}px;height:${size}px;color:${color};background:${color};border-color:${stroke};box-shadow:${shadow}"></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2]
  });
}

function MapController({ selectedSpot, visibleSpots }: { selectedSpot: Spot; visibleSpots: Spot[] }) {
  const map = useMap();

  useEffect(() => {
    const timer = setTimeout(() => map.invalidateSize(), 100);
    return () => clearTimeout(timer);
  }, [map]);

  useEffect(() => {
    if (!selectedSpot) return;
    const currentZoom = map.getZoom();
    const targetZoom = Math.max(currentZoom, 11);
    map.flyTo([selectedSpot.lat, selectedSpot.lng], targetZoom, {
      duration: 0.6,
      easeLinearity: 0.25
    });
  }, [map, selectedSpot]);

  useEffect(() => {
    if (!visibleSpots.length) return;
    if (visibleSpots.length === spots.length) return;

    const bounds = L.latLngBounds(visibleSpots.map(s => [s.lat, s.lng]));
    map.fitBounds(bounds, { padding: [40, 40], maxZoom: 13, animate: true, duration: 0.6 });
  }, [map, visibleSpots]);

  return null;
}

function ClusteredMarkers({
  visibleSpots,
  selectedId,
  onSelect
}: {
  visibleSpots: Spot[];
  selectedId: string;
  onSelect: (id: string) => void;
}) {
  const map = useMap();

  useEffect(() => {
    const clusterGroup = L.markerClusterGroup({
      showCoverageOnHover: false,
      maxClusterRadius: 35,
      spiderfyOnMaxZoom: true,
      zoomToBoundsOnClick: true,
      animate: true,
      iconCreateFunction: (cluster) => {
        const count = cluster.getChildCount();
        return L.divIcon({
          html: `<div class="custom-cluster">${count}</div>`,
          className: '',
          iconSize: [36, 36]
        });
      }
    });

    visibleSpots.forEach((spot) => {
      const isSelected = spot.id === selectedId;
      const markerLabel = `${spot.name}, ${isSelected ? 'selected' : 'not selected'}`;
      const marker = L.marker([spot.lat, spot.lng], {
        icon: makeIcon(spot, isSelected),
        title: markerLabel,
        alt: markerLabel,
        keyboard: true
      });
      const syncMarkerAccessibility = () => {
        const markerElement = marker.getElement();
        if (!markerElement) return;
        markerElement.setAttribute('role', 'button');
        markerElement.setAttribute('aria-label', markerLabel);
        markerElement.setAttribute('aria-pressed', String(isSelected));
      };
      marker.on('add', syncMarkerAccessibility);

      const popupContent = buildSpotPopup(document, spot) as unknown as HTMLElement;

      marker.bindPopup(popupContent, {
        closeButton: false,
        className: 'leaflet-popup-custom'
      });

      marker.on('click', () => {
        onSelect(spot.id);
      });

      clusterGroup.addLayer(marker);
    });

    map.addLayer(clusterGroup);

    return () => {
      map.removeLayer(clusterGroup);
    };
  }, [map, visibleSpots, selectedId, onSelect]);

  return null;
}

function useLiveTelemetry(spot: Spot): { telemetry: LiveTelemetry; cache?: LiveStatusCache } {
  const [telemetry, setTelemetry] = useState<LiveTelemetry>({
    status: 'loading',
    stationName: spot.tideStation,
    buoyId: 'Unavailable',
    waveLabel: 'Significant wave height',
    observations: { level: { availability: 'unavailable', freshness: 'unavailable' }, wind: { availability: 'unavailable', freshness: 'unavailable' }, buoy: { availability: 'unavailable', freshness: 'unavailable' }, wave: { availability: 'unavailable', freshness: 'unavailable' }, temperature: { availability: 'unavailable', freshness: 'unavailable' } },
    message: 'Loading the server-cached ocean snapshot…'
  });
  const [cache, setCache] = useState<LiveStatusCache>();

  useEffect(() => {
    const controller = new AbortController();
    const refresh = () => fetch(`/data/live-status.json?ts=${Date.now()}`, { signal: controller.signal, cache: 'no-store' })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error(`live cache ${response.status}`)))
      .then((raw: unknown) => {
        const issued = ingestLiveStatusCache(raw);
        const next = reviewedTelemetryFromCache(issued, spot.stableId ?? `spot:${spot.id}`);
        if (!next) throw new Error('Selected spot has no reviewed telemetry binding.');
        setCache(issued);
        setTelemetry(next);
      })
      .catch(() => { if (!controller.signal.aborted) { setCache(undefined); setTelemetry({ status:'unavailable', stationName:spot.name, buoyId:'Unavailable', waveLabel:'Significant wave height', observations:{level:{availability:'unavailable',freshness:'unavailable'},wind:{availability:'unavailable',freshness:'unavailable'},buoy:{availability:'unavailable',freshness:'unavailable'},wave:{availability:'unavailable',freshness:'unavailable'},temperature:{availability:'unavailable',freshness:'unavailable'}}, message:'Same-origin live cache is unavailable or invalid.' }); } });

    setTelemetry({ status: 'loading', stationName: spot.name, buoyId: 'Unavailable', waveLabel: 'Significant wave height', observations: { level: { availability: 'unavailable', freshness: 'unavailable' }, wind: { availability: 'unavailable', freshness: 'unavailable' }, buoy: { availability: 'unavailable', freshness: 'unavailable' }, wave: { availability: 'unavailable', freshness: 'unavailable' }, temperature: { availability: 'unavailable', freshness: 'unavailable' } }, message: 'Loading server-cached NOAA & NDBC telemetry…' });
    void refresh();
    const interval = setInterval(refresh, 60_000);
    const onVisible = () => { if (!document.hidden) void refresh(); };
    const onFocus = () => void refresh();
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onFocus);

    return () => { controller.abort(); clearInterval(interval); document.removeEventListener('visibilitychange', onVisible); window.removeEventListener('focus', onFocus); };
  }, [spot.id, spot.name, spot.sensorBindings, spot.stableId]);

  return { telemetry, cache };
}

function getRegulationNotes(spot: Spot) {
  const notes: string[] = [];
  if (['Pier', 'Jetty', 'Breakwater'].includes(spot.type)) notes.push('CDFW public-pier-style access may not require a license only on qualifying public structures; all size, bag, season, and gear rules still apply.');
  else notes.push('Shore/beach fishing generally requires a valid California fishing license.');
  if (spot.accessNote.toLowerCase().includes('closed')) notes.push('Closure warning: verify current pier/park status before driving.');
  if (spot.species.includes('Sturgeon')) notes.push('Sturgeon status changes often and retention has been closed in recent SF Bay rules — check CDFW before targeting.');
  if (spot.species.includes('Dungeness Crab')) notes.push('Dungeness crab seasons/closures and health advisories change; verify current CDFW/OEHHA status.');
  if (spot.safety === 'Hazard') notes.push('Hazard spot: treat swell, rocks, cliffs, and sneaker waves as go/no-go criteria, not background details.');
  return notes;
}


function evidenceScope(spot: Spot, taxonId: string) {
  const edge = spot.evidenceEdges?.find((item) => item.speciesId === taxonId);
  if (!edge) return 'No reviewed history yet';
  return edge.evidenceType.includes('exact-spot') ? 'Reported at this spot' : 'Reported nearby';
}

function shortUnavailableReason(reason?: string) {
  if (!reason) return 'No recent reading';
  if (/wave|environment-compatible|representative/i.test(reason)) return 'No nearby matching sensor';
  if (/clock|expired|age/i.test(reason)) return 'No recent reading';
  return 'Reading unavailable';
}

function App() {
  const [region, setRegion] = useState<Region | 'All'>('All');
  const [species, setSpecies] = useState<Species | 'All'>('All');
  const [mode, setMode] = useState<SpotMode>('All');
  const [sortMode, setSortMode] = useState<SortMode>('name');
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState('linda-mar');
  const [showAllRanked, setShowAllRanked] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(() => new Set(JSON.parse(localStorage.getItem('bay-bite-favorites') || '[]')));
  const [deckWhite, setDeckWhite] = useState(false);


  const filteredSpots = useMemo(() => {
    const q = query.trim().toLowerCase();
    return spots.filter((spot) => {
      const regionOk = region === 'All' || spot.region === region;
      const speciesOk = species === 'All' || spot.species.includes(species);
      const modeOk =
        mode === 'All' ||
        (mode === 'Favorites' && favorites.has(spot.id)) ||
        (mode === 'Surf' && spot.type === 'Surf') ||
        (mode === 'Pier/Jetty' && ['Pier', 'Jetty', 'Breakwater'].includes(spot.type)) ||
        (mode === 'Bay Shore' && ['Bay Shore', 'Marina'].includes(spot.type)) ||
        (mode === 'Hazard Watch' && spot.safety !== 'Green');
      const searchOk = !q || [spot.name, spot.region, spot.type, spot.tideStation, ...spot.species, spot.accessNote].join(' ').toLowerCase().includes(q);
      return regionOk && speciesOk && modeOk && searchOk;
    });
  }, [region, species, mode, query, favorites]);

  const sortedSpots = useMemo(() => [...filteredSpots].sort((a, b) => {
    if (sortMode === 'region') return a.region.localeCompare(b.region) || a.name.localeCompare(b.name);
    return a.name.localeCompare(b.name);
  }), [filteredSpots, sortMode]);

  const reconciledSelectedId = reconcileSelectedId(selectedId, filteredSpots);
  useEffect(() => {
    if (reconciledSelectedId !== selectedId) setSelectedId(reconciledSelectedId);
  }, [reconciledSelectedId, selectedId]);

  const selected = spots.find((spot) => spot.id === reconciledSelectedId) ?? spots[0];
  const visibleList = sortedSpots.slice(0, showAllRanked ? 40 : 8);
  const { telemetry, cache: liveCache } = useLiveTelemetry(selected);
  const legalItems = currentSpotLegality(selected);
  const scientificOpportunity = buildSelectedWaterOpportunity(selected, telemetry, new Date().toISOString(), liveCache);
  const regulationNotes = getRegulationNotes(selected);

  function toggleFavorite(id: string) {
    const next = new Set(favorites);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setFavorites(next);
    localStorage.setItem('bay-bite-favorites', JSON.stringify([...next]));
  }

  return (
    <main className={`app-shell ${deckWhite ? 'deck-white' : ''}`}>
      <header className="field-header">
        <div className="brand-lockup">
          <span className="brand-mark" aria-hidden="true"><Waves size={21} /></span>
          <div><strong>Bay Bite</strong><span>Shore fishing field tool</span></div>
        </div>
        <div className="header-tools">
          <span className="freshness">Data updated {formatDataDate(liveCache?.generatedAt)}</span>
          <button className="theme-button" onClick={() => setDeckWhite(!deckWhite)} aria-label={deckWhite ? 'Use dark theme' : 'Use Deck White theme'}>
            <Sun size={17} /> {deckWhite ? 'Dark' : 'Deck White'}
          </button>
        </div>
      </header>

      <div className="field-layout">
        <section className="card map-card" id="fishing-map" aria-labelledby="map-title">
          <div className="map-toolbar">
            <div><h1 id="map-title"><MapPin size={20} /> Find a fishing spot</h1><span>{filteredSpots.length} of {spots.length} places</span></div>
            <label className="search-box"><Search size={18} /><span className="sr-only">Search fishing spots</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search a pier, beach, species…" /></label>
          </div>
          <div className="mode-row" aria-label="Quick spot filters">
            {(['All', 'Favorites', 'Surf', 'Pier/Jetty', 'Bay Shore', 'Hazard Watch'] as SpotMode[]).map((item) => <button key={item} className={`mode-chip ${mode === item ? 'active' : ''}`} aria-pressed={mode === item} onClick={() => setMode(item)}>{item}</button>)}
          </div>
          <details className="filter-drawer">
            <summary>More filters</summary>
            <div className="filter-fields">
              <label>Region<select value={region} onChange={(event) => setRegion(event.target.value as Region | 'All')}><option value="All">All regions</option>{regions.map((item) => <option key={item}>{item}</option>)}</select></label>
              <label>Species<select value={species} onChange={(event) => setSpecies(event.target.value as Species | 'All')}><option value="All">All species</option>{allSpecies.map((item) => <option key={item}>{item}</option>)}</select></label>
              <label>Sort<select value={sortMode} onChange={(event) => setSortMode(event.target.value as SortMode)}><option value="name">Name</option><option value="region">Region</option></select></label>
            </div>
          </details>
          <div className="map-wrap">
            <MapContainer center={[37.73, -122.36]} zoom={9} scrollWheelZoom style={{ height: '100%', width: '100%' }}>
              <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              <ClusteredMarkers visibleSpots={filteredSpots} selectedId={selected.id} onSelect={setSelectedId} />
              <MapController selectedSpot={selected} visibleSpots={filteredSpots} />
            </MapContainer>
          </div>
          {filteredSpots.length === 0 && <p className="empty-state">No places match. Clear a filter or try another name.</p>}
        </section>

        <section className="card selected-card" id="selected-spot" aria-labelledby="selected-title">
          <div className="selected-heading">
            <div><span className="eyebrow">Selected spot</span><h2 id="selected-title">{selected.name}</h2><p>{selected.region} · {selected.type}</p></div>
            <button className={`favorite-button ${favorites.has(selected.id) ? 'active' : ''}`} aria-pressed={favorites.has(selected.id)} onClick={() => toggleFavorite(selected.id)} aria-label={favorites.has(selected.id) ? 'Remove favorite' : 'Add favorite'}><Star size={20} fill={favorites.has(selected.id) ? 'currentColor' : 'none'} /></button>
          </div>
          <p className={`location-precision ${selected.coordinateStatus}`}>{selected.coordinateStatus === 'exact-named-feature' ? 'Exact named map feature' : 'Approximate map location — verify the legal access and casting point on site'}</p>
          <div className="selected-actions">
            <a className="primary-action" href={googleMapsUrl(selected)} target="_blank" rel="noreferrer"><ExternalLink size={17} /> {selected.coordinateStatus === 'exact-named-feature' ? 'Directions to marker' : 'Find this area'}</a>
            <span className={`safety-badge ${selected.safety.toLowerCase()}`}><ShieldAlert size={15} /> {selected.safety === 'Green' ? 'Normal shore caution' : selected.safety}</span>
          </div>
        </section>

        <section className="card conditions-card" id="live-conditions" aria-labelledby="conditions-title">
          <div className="section-heading"><div><span className="eyebrow">Right now</span><h2 id="conditions-title">Conditions</h2></div><span className={`status-dot ${telemetry.status}`}>{telemetry.status === 'loading' ? 'Updating' : telemetry.status}</span></div>
          <div className="condition-grid" aria-live="polite">
            <div className="condition"><span>Water level</span><strong>{telemetry.waterLevelFt ?? 'Unavailable'}</strong>{!telemetry.waterLevelFt && <small>{shortUnavailableReason(telemetry.observations.level.reason)}</small>}</div>
            <div className="condition"><span>Wind</span><strong>{[telemetry.windDir, telemetry.windSpeedKt].filter(Boolean).join(' ') || 'Unavailable'}{telemetry.gustKt ? ` · gust ${telemetry.gustKt}` : ''}</strong>{!telemetry.windSpeedKt && <small>{shortUnavailableReason(telemetry.observations.wind.reason)}</small>}</div>
            <div className="condition"><span>Waves</span><strong>{telemetry.waveHeightFt ? `${telemetry.waveHeightFt}${telemetry.wavePeriodSec ? ` @ ${telemetry.wavePeriodSec}` : ''}` : 'Unavailable'}</strong>{!telemetry.waveHeightFt && <small>{shortUnavailableReason(telemetry.observations.wave.reason)}</small>}</div>
            <div className="condition"><span>Water temp</span><strong>{telemetry.waterTempF ?? 'Unavailable'}</strong>{!telemetry.waterTempF && <small>{shortUnavailableReason(telemetry.observations.temperature.reason)}</small>}</div>
            <div className="condition"><span>Next high</span><strong>{telemetry.nextHigh ?? 'Unavailable'}</strong>{!telemetry.nextHigh && <small>No upcoming prediction</small>}</div>
            <div className="condition"><span>Next low</span><strong>{telemetry.nextLow ?? 'Unavailable'}</strong>{!telemetry.nextLow && <small>No upcoming prediction</small>}</div>
          </div>
        </section>

        <section className="card species-card" aria-labelledby="species-title">
          <div className="section-heading"><div><span className="eyebrow">History, not a promise</span><h2 id="species-title">Species reported here/nearby</h2></div><Fish size={21} /></div>
          <div className="species-list">
            {scientificOpportunity.length > 0 ? scientificOpportunity.map(({ displayLabel, taxonId, result }) => {
              const scope = evidenceScope(selected, taxonId);
              const presentation = result.presentations[0];
              return <article className="species-summary" key={taxonId}><div><strong>{displayLabel}</strong><span>{scope}</span></div><p>{presentation ? `${presentation.lureFamily}: ${presentation.retrieve}` : 'History only — check current rules and conditions before choosing a target.'}</p></article>;
            }) : selected.species.map((label) => <article className="species-summary" key={label}><div><strong>{label}</strong><span>No reviewed history yet</span></div><p>Check local history and current rules before targeting.</p></article>)}
          </div>
        </section>

        <section className="card access-card" aria-labelledby="access-title">
          <div className="section-heading"><div><span className="eyebrow">Before you go</span><h2 id="access-title">Access & safety</h2></div><ShieldAlert size={21} /></div>
          <p><strong>{selected.ownerJurisdiction}</strong></p>
          <p>{selected.accessNote}</p>
          <ul>{selected.safetyDetails?.slice(0, 2).map((item) => <li key={item}>{item}</li>)}</ul>
          {selected.accessStatus && selected.accessStatus.state !== 'open' && <p className="access-warning" role="alert"><strong>{selected.accessStatus.state === 'closed' ? 'Closed' : 'Restricted access'}.</strong> {selected.accessStatus.affectedArea} <a href={selected.accessStatus.sourceUrl} target="_blank" rel="noreferrer">Check owner notice <ExternalLink size={13} /></a></p>}
          <p className="safety-reminder"><AlertTriangle size={16} /> Check posted closures, weather, swell, and regulations before fishing.</p>
        </section>

        <section className="card tide-card" aria-labelledby="tide-title">
          <div className="section-heading"><div><span className="eyebrow">Reference curve</span><h2 id="tide-title">Tide chart</h2></div><Waves size={21} /></div>
          <div className="chart-wrap"><ResponsiveContainer><AreaChart data={tideSeries}><defs><linearGradient id="tide" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#4dd7d0" stopOpacity={0.7}/><stop offset="95%" stopColor="#4dd7d0" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="rgba(148,163,184,.14)" vertical={false}/><XAxis dataKey="time" stroke="#8393a1"/><YAxis stroke="#8393a1"/><Tooltip contentStyle={{ background:'#0b151b', border:'1px solid #24404c', borderRadius:10, color:'#fff' }}/><Area type="monotone" dataKey="height" stroke="#4dd7d0" fill="url(#tide)" name="Tide ft"/></AreaChart></ResponsiveContainer></div>
        </section>

        <details className="card how-we-know">
          <summary>Details / How we know</summary>
          <div className="details-grid">
            <section><h3>Condition source details</h3><p>{telemetry.message}</p>{(['level','wind','wave','temperature'] as const).map((key) => { const item = telemetry.observations[key]; return <p key={key}><strong>{key}</strong>: {item.stationName ?? 'No station'}{item.distanceKm !== undefined ? ` · ${item.distanceKm} km away` : ''}{item.maxAgeMinutes !== undefined ? ` · maximum age ${item.maxAgeMinutes} minutes` : ''}{item.warning ? ` · ${item.warning}` : ''}</p>; })}<div className="sensor-detail">{selected.sensorBindings?.map((binding) => <p key={binding.metric}><strong>{binding.metric.replaceAll('_',' ')}</strong>: {binding.availability === 'unavailable' ? 'Unavailable' : `${binding.distanceKm} km away`} · {binding.warning}</p>)}</div></section>
            <section><h3>Regulations and source links</h3>{legalItems.map((item) => <p key={item.label}><strong>{item.label}: {item.status}</strong><br/>{item.warning} {item.sourceUrl && <a href={item.sourceUrl} target="_blank" rel="noreferrer">Official source <ExternalLink size={12}/></a>}</p>)}{regulationNotes.map((note) => <p key={note}>{note}</p>)}<p><strong>MPA screen:</strong> {selected.mpaScreen?.status} · {selected.mpaScreen?.warning}</p><div className="source-grid">{selected.sourceLinks?.map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.label} <ExternalLink size={12}/></a>)}</div></section>
            <section><h3>History and model details</h3><p>{selected.evidenceEdges?.length ?? 0} reviewed local history records inform this spot. Nearby records do not prove fish are present at the marker today.</p>{scientificOpportunity.map(({ displayLabel, result }) => <div className="technical-species" key={displayLabel}><strong>{displayLabel}: {result.status}</strong>{result.reasons.map((reason) => <p key={reason}>{reason}</p>)}{result.missingInputs.length > 0 && <p><strong>What we still don't know:</strong> {result.missingInputs.join(', ')}</p>}</div>)}</section>
          </div>
        </details>

        <section className="card spot-list-card" aria-labelledby="matching-title">
          <div className="section-heading"><div><span className="eyebrow">Map results</span><h2 id="matching-title">Matching spots</h2></div><span>{sortedSpots.length}</span></div>
          <div className="spot-list">{visibleList.map((spot) => <button key={spot.id} className={`spot-card ${spot.id === selected.id ? 'selected' : ''}`} aria-pressed={spot.id === selected.id} onClick={() => setSelectedId(spot.id)}><span><strong>{spot.name}</strong><small>{spot.region} · {spot.type}</small></span><span className="spot-safety" style={{ color:safetyColor(spot.safety) }}>{spot.safety}</span></button>)}</div>
          {sortedSpots.length > 8 && <button className="show-more" onClick={() => setShowAllRanked(!showAllRanked)}>{showAllRanked ? 'Show fewer' : `Show ${Math.min(32, sortedSpots.length - 8)} more`}</button>}
        </section>
      </div>
    </main>
  );
}

export default App;
