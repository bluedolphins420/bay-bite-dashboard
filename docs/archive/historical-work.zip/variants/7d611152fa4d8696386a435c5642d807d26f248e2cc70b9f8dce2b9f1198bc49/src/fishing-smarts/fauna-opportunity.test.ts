import { describe, expect, it } from 'vitest';
import { evaluateSpeciesOpportunity, exactTaxonScience, type OpportunityInput } from './fauna-opportunity';
import { scientificIngestionContracts, scientificSourceRegistry } from './scientific-sources';

const occurrence = {
  id: 'evidence:test-striped' as const,
  taxonId: 'species:striped-bass' as const,
  spotId: 'spot:crissy-field' as const,
  sourceId: 'source:edi-deltafish-1075-1' as const,
  geometry: { kind: 'area' as const, publicResolution: 'survey area' },
  timeCoverage: { start: '1980-01-01', end: '2024-12-31', reviewedAt: '2026-08-13T00:00:00Z' },
  method: 'reviewed survey derivative', effort: 'preserved in source package', lifeStage: 'mixed/unspecified', spatialResolution: 'survey area', evidenceGrade: 'B' as const,
  limitations: ['Historical occurrence only; not current presence.'],
};
const baseInput = (): OpportunityInput => ({
  taxonId: 'species:striped-bass', spotId: 'spot:crissy-field', habitatIds: ['habitat:bay-shore'], environmentClass: 'inner_bay', evaluatedAt: '2026-08-13T18:00:00Z',
  occurrence: [occurrence],
  conditions: { observedAt: '2026-08-13T17:30:00Z', current: { state: 'manageable', sourceId: 'source:noaa-coops-api' }, wave: { state: 'calm', sourceId: 'source:noaa-ndbc' }, wind: { state: 'light', sourceId: 'source:noaa-coops-api' }, clarity: 'moderate', light: 'low' },
  legal: { status: 'open', actionable: true, matchedRuleIds: ['rule:test-open'], reasons: [] }, access: { state: 'open' }, mpa: { resolved: true, intersectsNoTake: false },
});

describe('canonical exact-taxon science', () => {
  it('uses taxon-specific habitat compatibility instead of assigning every habitat to every taxon', () => {
    expect(exactTaxonScience['species:california-halibut'].habitat.compatible).not.toContain('habitat:tidal-slough');
    expect(exactTaxonScience['species:california-halibut'].habitat.compatible).not.toContain('habitat:rocky-shore');
    expect(exactTaxonScience['species:barred-surfperch'].habitat.compatible).not.toContain('habitat:tidal-slough');
    expect(exactTaxonScience['species:barred-surfperch'].habitat.compatible).not.toContain('habitat:bay-shore');
    expect(exactTaxonScience['species:striped-bass'].habitat.compatible).toContain('habitat:bay-shore');
    expect(exactTaxonScience['species:striped-bass'].habitat.compatible).toContain('habitat:surf');
    expect(new Set(Object.values(exactTaxonScience).map((record) => record.scientificName))).toEqual(new Set(['Morone saxatilis','Paralichthys californicus','Amphistichus argenteus']));
  });
});

describe('evaluateSpeciesOpportunity', () => {
  it('keeps historical occurrence distinct from live presence and returns deterministic relative output', () => {
    const first = evaluateSpeciesOpportunity(baseInput());
    const second = evaluateSpeciesOpportunity(structuredClone(baseInput()));
    expect(first).toEqual(second);
    expect(first).toMatchObject({ status: 'scored', confidence: 'low', livePresenceClaim: false, factors: { historicalOccurrencePrior: 'favorable', habitatFit: 'favorable', legalGate: 'open' } });
    expect(first.confidenceCoverage).toMatchObject({ occurrenceEvidence: 'partial', habitatEvidence: 'missing', conditionEvidence: 'complete', legalAccessMpa: 'complete' });
    expect(first.confidenceReasons.join(' ')).toMatch(/habitat evidence geometry.*not integrated/i);
    expect(first.caveats.join(' ')).toMatch(/not live presence/i);
  });

  it('treats missing or stale required conditions as insufficient rather than favorable', () => {
    const missing = baseInput();
    missing.conditions = undefined;
    expect(evaluateSpeciesOpportunity(missing)).toMatchObject({ status: 'insufficient-data', factors: { conditionFit: 'unknown', lureFishability: 'unknown' } });
    expect(evaluateSpeciesOpportunity(missing).missingInputs).toEqual(expect.arrayContaining(['current', 'wave', 'wind', 'clarity', 'light']));
    const stale = baseInput();
    stale.conditions!.observedAt = '2026-08-12T00:00:00Z';
    expect(evaluateSpeciesOpportunity(stale)).toMatchObject({ status: 'insufficient-data', factors: { conditionFit: 'unknown' } });
  });

  it('reports omitted optional clarity and light as missing condition inputs', () => {
    const input = baseInput();
    delete input.conditions!.clarity;
    delete input.conditions!.light;
    const result = evaluateSpeciesOpportunity(input);
    expect(result).toMatchObject({ status: 'insufficient-data', confidence: 'low', confidenceCoverage: { conditionEvidence: 'partial' }, presentations: [] });
    expect(result.missingInputs).toEqual(expect.arrayContaining(['clarity', 'light']));
  });

  it('separates habitat mismatch from legal and MPA not-targetable gates', () => {
    const mismatch = baseInput();
    mismatch.taxonId = 'species:california-halibut';
    mismatch.habitatIds = ['habitat:tidal-slough'];
    mismatch.occurrence = [];
    expect(evaluateSpeciesOpportunity(mismatch)).toMatchObject({ status: 'insufficient-data', factors: { habitatFit: 'adverse', legalGate: 'open' } });
    const closed = baseInput();
    closed.legal = { status: 'closed', actionable: false, matchedRuleIds: ['rule:closed'], reasons: [] };
    expect(evaluateSpeciesOpportunity(closed)).toMatchObject({ status: 'not-targetable', factors: { legalGate: 'blocked' } });
    const mpaUnknown = baseInput();
    mpaUnknown.mpa.resolved = false;
    const unresolved = evaluateSpeciesOpportunity(mpaUnknown);
    expect(unresolved).toMatchObject({ status: 'not-targetable', factors: { historicalOccurrencePrior: 'favorable', habitatFit: 'favorable', conditionFit: 'mixed' }, presentations: [] });
    expect(unresolved.contributions).toHaveLength(4);
    expect(unresolved.confidenceCoverage.legalAccessMpa).toBe('missing');
  });

  it('keeps confidence low when grade-A occurrence lacks habitat geometry and conditions or MPA certainty', () => {
    const input = baseInput();
    input.occurrence![0].evidenceGrade = 'A';
    input.conditions!.current!.state = 'unknown';
    input.conditions!.clarity = 'unknown';
    input.conditions!.light = 'unknown';
    input.mpa.resolved = false;
    const result = evaluateSpeciesOpportunity(input);
    expect(result).toMatchObject({ status: 'not-targetable', confidence: 'low', opportunityBand: undefined, presentations: [] });
    expect(result.missingInputs).toEqual(expect.arrayContaining(['current', 'clarity', 'light', 'habitat evidence geometry', 'MPA geometry']));
    expect(result.confidenceReasons.join(' ')).toMatch(/condition.*incomplete|MPA.*unresolved/i);
  });

  it('returns honest unsupported-taxon output without a legacy score fallback', () => {
    const input = baseInput();
    input.taxonId = 'species:surfperch';
    const result = evaluateSpeciesOpportunity(input);
    expect(result).toMatchObject({ status: 'insufficient-data', opportunityBand: undefined, presentations: [] });
    expect(result.reasons.join(' ')).toMatch(/not yet modeled/i);
    expect(result.caveats.join(' ')).toMatch(/no legacy species score/i);
  });

  it('changes rig guidance when current fishability changes and blocks unsafe wind or waves', () => {
    const manageable = evaluateSpeciesOpportunity(baseInput());
    const strongCurrent = baseInput();
    strongCurrent.conditions!.current!.state = 'strong';
    const adjusted = evaluateSpeciesOpportunity(strongCurrent);
    expect(adjusted.presentations[0].rigWeight).not.toBe(manageable.presentations[0].rigWeight);
    expect(adjusted.presentations[0].rigWeight).toMatch(/heavier|increase/i);
    const unsafe = baseInput();
    unsafe.conditions!.wave!.state = 'rough';
    expect(evaluateSpeciesOpportunity(unsafe)).toMatchObject({ status: 'scored', opportunityBand: 'lower', factors: { lureFishability: 'adverse' }, presentations: [] });
  });

  it('does not expose solunar, barometer, pressure, lure-frequency, or temperature-optimum multipliers', () => {
    const serialized = JSON.stringify({ science: exactTaxonScience, result: evaluateSpeciesOpportunity(baseInput()) });
    expect(serialized).not.toMatch(/solunar|barometr|pressure multiplier|frequency claim|temperature optimum/i);
  });

  it('pins authoritative source provenance and ingestion contracts without runtime browser calls', () => {
    expect(scientificSourceRegistry.map((source) => source.id)).toEqual(expect.arrayContaining([
      'source:edi-deltafish-1075-1','source:cdfw-bay-study','source:cdfw-california-halibut-esr','source:noaa-sf-bay-benthic-2011','source:opc-seafloor-mapping','source:obis-api','source:gbif-occurrence-api','source:noaa-coops-api','source:noaa-ndbc','source:noaa-erddap',
    ]));
    expect(scientificSourceRegistry.every((source) => source.url.startsWith('https://') && source.claimStatus && source.checkedAt)).toBe(true);
    expect(scientificIngestionContracts.occurrence.requiredFields).toEqual(expect.arrayContaining(['sourceId','taxonId','geometry','timeCoverage','method','effort','lifeStage','spatialResolution','limitations']));
    expect(scientificIngestionContracts.habitat.requiredFields).toEqual(expect.arrayContaining(['sourceId','geometry','classification','publicResolution','limitations']));
    expect(scientificIngestionContracts.conditions.browserRuntimeFetch).toBe(false);
  });
});
