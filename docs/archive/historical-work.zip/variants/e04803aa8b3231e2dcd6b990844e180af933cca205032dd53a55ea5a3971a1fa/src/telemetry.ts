export type Freshness = 'live' | 'delayed' | 'stale' | 'partial' | 'unavailable';

type UnavailableProduct = { kind: 'unavailable'; supported: boolean; freshness: 'unavailable'; reason: string };
type PredictionProduct = { kind: 'prediction'; stationId: string; stationName: string; freshness: 'forecast'; values: Array<{ observedAt: string; value: number; type?: string; unit: 'm' }> };
type ObservedProduct = { kind: 'observed'; stationId: string; stationName: string; observedAt: string; ageMinutes: number; freshness: 'live'|'delayed'|'stale'; lastKnownGood: boolean; [key: string]: unknown };
type Product = UnavailableProduct | PredictionProduct | ObservedProduct;
export type CacheStation = { key: string; health: Freshness; products: { prediction?: Product; observedLevel?: Product; wind?: Product; buoy?: Product }; errors?: string[] };
export type ObservationMeta = {
  availability: 'available' | 'unavailable'; freshness: 'live'|'delayed'|'stale'|'unavailable'; observedAt?: string;
  ageMinutes?: number; lastKnownGood?: boolean; stationId?: string; stationName?: string; reason?: string;
  representativeness?: string; distanceKm?: number; maxAgeMinutes?: number; warning?: string;
};
export type LiveTelemetry = {
  status: 'loading' | Freshness; stationName: string; stationId?: string; buoyId: string; buoyName?: string;
  waterLevelFt?: string; nextHigh?: string; nextLow?: string; waterTempF?: string; windSpeedKt?: string; gustKt?: string; windDir?: string;
  waveHeightFt?: string; waveLabel: string; wavePeriodSec?: string; observedAt?: string; ageMinutes?: number; observationAge?: string;
  observations: { level: ObservationMeta; wind: ObservationMeta; buoy: ObservationMeta; wave: ObservationMeta; temperature: ObservationMeta };
  representativeness?: string; sourceErrors?: string[]; message: string;
};
const finite = (value: unknown) => typeof value === 'number' && Number.isFinite(value) ? value : undefined;
const observed = (p?: Product): ObservedProduct | undefined => p?.kind === 'observed' ? p : undefined;
const prediction = (p?: Product): PredictionProduct | undefined => p?.kind === 'prediction' ? p : undefined;
function localTime(value?: string) { if (!value) return undefined; const date = new Date(value); return Number.isNaN(date.getTime()) ? undefined : date.toLocaleTimeString([], { hour:'numeric', minute:'2-digit' }); }
function unsupportedReasons(station: CacheStation) { return Object.values(station.products).filter((p): p is UnavailableProduct => p?.kind === 'unavailable').map((p)=>p.reason); }
function metadata(product?: Product): ObservationMeta {
  if (product?.kind === 'observed') return { availability:'available', freshness:product.freshness, observedAt:product.observedAt, ageMinutes:product.ageMinutes, lastKnownGood:product.lastKnownGood, stationId:product.stationId, stationName:product.stationName };
  return { availability:'unavailable', freshness:'unavailable', reason:product?.kind === 'unavailable' ? product.reason : 'Observation product is unavailable.' };
}
function aggregate(products: Product[]): Freshness {
  const states=products.map((product)=>metadata(product).freshness);
  if (states.every((state)=>state==='unavailable')) return 'unavailable';
  if (states.some((state)=>state==='unavailable')) return 'partial';
  if (states.some((state)=>state==='stale')) return 'stale';
  if (states.some((state)=>state==='delayed')) return 'partial';
  return 'live';
}
function nextPrediction(tides: PredictionProduct | undefined, type: 'H'|'L', clock: number) {
  return tides?.values
    .filter((item)=>item.type===type && Number.isFinite(new Date(item.observedAt).getTime()) && new Date(item.observedAt).getTime()>clock)
    .sort((a,b)=>new Date(a.observedAt).getTime()-new Date(b.observedAt).getTime())[0];
}
const emptyObservations = () => ({ level:metadata(), wind:metadata(), buoy:metadata(), wave:metadata(), temperature:metadata() });
export function telemetryFromCache(station: CacheStation | undefined, fallbackName: string, generatedAt?: string, currentNow = new Date()): LiveTelemetry {
  if (!station) return { status:'unavailable', stationName:fallbackName, buoyId:'Unavailable', waveLabel:'Significant wave height', observations:emptyObservations(), message:'No cached source mapping is available for this selected water. Unknown labels never fall back to another station.' };
  const levelProduct=station.products.observedLevel, windProduct=station.products.wind, buoyProduct=station.products.buoy;
  const level=observed(levelProduct), wind=observed(windProduct), buoy=observed(buoyProduct), tides=prediction(station.products.prediction);
  const generatedMs=generatedAt ? new Date(generatedAt).getTime() : Number.NaN; const nowMs=currentNow.getTime(); const clock=Number.isFinite(generatedMs) ? Math.max(generatedMs,nowMs) : nowMs;
  const high=nextPrediction(tides,'H',clock), low=nextPrediction(tides,'L',clock); const waterM=finite(level?.value), speed=finite(wind?.speedMps), gust=finite(wind?.gustMps), wave=finite(buoy?.waveHeightM), temp=finite(buoy?.waterTempC);
  const ages=[level,wind,buoy].filter(Boolean) as ObservedProduct[]; const youngest=[...ages].sort((a,b)=>a.ageMinutes-b.ageMinutes)[0]; const reasons=[...(station.errors??[]),...unsupportedReasons(station)];
  const observations={ level:metadata(levelProduct), wind:metadata(windProduct), buoy:metadata(buoyProduct), wave:metadata(buoyProduct), temperature:metadata(buoyProduct) };
  return {
    status:aggregate([levelProduct,windProduct,buoyProduct].filter(Boolean) as Product[]), stationName:level?.stationName ?? tides?.stationName ?? fallbackName, stationId:level?.stationId ?? tides?.stationId,
    buoyId:buoy?.stationId ?? 'Unavailable', buoyName:buoy?.stationName, observedAt:youngest?.observedAt, ageMinutes:youngest?.ageMinutes, observations,
    observationAge:youngest ? `${youngest.ageMinutes} min (${youngest.freshness}${youngest.lastKnownGood?' · last known good':''})` : undefined,
    waterLevelFt:waterM===undefined?undefined:`${(waterM*3.28084).toFixed(1)} ft MLLW`, nextHigh:localTime(high?.observedAt), nextLow:localTime(low?.observedAt),
    windSpeedKt:speed===undefined?undefined:`${Math.round(speed*1.94384)} kt`, gustKt:gust===undefined?undefined:`${Math.round(gust*1.94384)} kt`,
    windDir:typeof wind?.directionCardinal==='string'?wind.directionCardinal:finite(wind?.directionDeg)!==undefined?`${Math.round(finite(wind?.directionDeg)!)}°`:undefined,
    waveHeightFt:wave===undefined?undefined:`${(wave*3.28084).toFixed(1)} ft`, waveLabel:'Significant wave height', wavePeriodSec:finite(buoy?.dominantPeriodSec)===undefined?undefined:`${finite(buoy?.dominantPeriodSec)}s`,
    waterTempF:temp===undefined?undefined:`${Math.round(temp*9/5+32)}°F`, representativeness:typeof buoy?.warning==='string'?buoy.warning:reasons.find((x)=>/buoy|offshore|representative/i.test(x)), sourceErrors:station.errors??[],
    message:reasons.length?`Source coverage: ${reasons.join('; ')}`:'Server-cached NOAA observations and predictions. No browser sensor requests.'
  };
}

type Binding = { metric:string; sensorId?:string; availability?:'unavailable'; distanceKm?:number; representativeness?:string; warning:string; maxAgeMinutes?:number };
type SensorCache = { generatedAt?:string; sensors?:Record<string,{products:CacheStation['products']}> };
const boundProduct = (product:Product|undefined, binding:Binding|undefined, clockMs:number, clockError?:string):Product|undefined => {
  if (product?.kind==='observed') {
    if (clockError) return { kind:'unavailable', supported:true, freshness:'unavailable', reason:clockError };
    const observedMs=new Date(product.observedAt).getTime();
    if (!Number.isFinite(observedMs) || observedMs>clockMs) return { kind:'unavailable', supported:true, freshness:'unavailable', reason:'Binding TTL cannot be verified from observedAt; observation unavailable.' };
    const effectiveAgeMinutes=Math.max(0,Math.round((clockMs-observedMs)/60_000));
    if (binding?.maxAgeMinutes!==undefined && effectiveAgeMinutes>binding.maxAgeMinutes) return { kind:'unavailable', supported:true, freshness:'unavailable', reason:`Binding TTL ${binding.maxAgeMinutes} min expired from observedAt; observation is ${effectiveAgeMinutes} min old.` };
    const freshness:ObservedProduct['freshness']=effectiveAgeMinutes<=20?'live':effectiveAgeMinutes<=120?'delayed':'stale';
    return { ...product, ageMinutes:effectiveAgeMinutes, freshness };
  }
  return product;
};
const boundMeta = (meta:ObservationMeta, binding?:Binding):ObservationMeta => binding ? ({ ...meta, representativeness:binding.representativeness, distanceKm:binding.distanceKm, maxAgeMinutes:binding.maxAgeMinutes, warning:binding.warning }) : meta;
export function telemetryFromBindings(cache: SensorCache | undefined, bindings: Binding[] = [], fallbackName: string, currentNow = new Date()): LiveTelemetry {
  const generatedMs=cache?.generatedAt ? new Date(cache.generatedAt).getTime() : Number.NaN;
  const nowMs=currentNow.getTime();
  const clockError=!Number.isFinite(nowMs)?'Invalid invocation clock; bound observation unavailable.':!Number.isFinite(generatedMs)?'Invalid cache clock; bound observation unavailable.':generatedMs>nowMs+120_000?'Future cache clock exceeds allowed skew; bound observation unavailable.':undefined;
  const clockMs=clockError?Number.NaN:Math.max(generatedMs,nowMs);
  const binding = (metric:string) => bindings.find((item)=>item.metric===metric);
  const product = (item:Binding|undefined, kind:keyof CacheStation['products']):Product|undefined => boundProduct(item?.sensorId ? cache?.sensors?.[item.sensorId]?.products?.[kind] : item?.availability==='unavailable' ? {kind:'unavailable',supported:false,freshness:'unavailable',reason:item.warning} : undefined, item, clockMs, clockError);
  const tide=binding('tide'), levelBinding=binding('tide_level'), windBinding=binding('wind'), waveBinding=binding('wave'), tempBinding=binding('temperature');
  const waveProduct=product(waveBinding,'buoy'), temperatureProduct=product(tempBinding,'buoy');
  const products={ prediction:product(tide,'prediction'), observedLevel:product(levelBinding,'observedLevel'), wind:product(windBinding,'wind'), buoy:waveProduct };
  const result=telemetryFromCache({key:fallbackName,health:'partial',products},fallbackName,cache?.generatedAt,currentNow);
  result.observations.level=boundMeta(metadata(products.observedLevel),levelBinding ?? tide);
  result.observations.wind=boundMeta(metadata(products.wind),windBinding);
  result.observations.wave=boundMeta(metadata(waveProduct),waveBinding);
  result.observations.temperature=boundMeta(metadata(temperatureProduct),tempBinding);
  result.observations.buoy=result.observations.wave;
  if (result.observations.wave.availability==='unavailable') { result.waveHeightFt=undefined; result.wavePeriodSec=undefined; }
  const temperature=observed(temperatureProduct), temperatureC=finite(temperature?.waterTempC);
  result.waterTempF=temperatureC===undefined?undefined:`${Math.round(temperatureC*9/5+32)}°F`;
  return result;
}
