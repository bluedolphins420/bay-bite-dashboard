import { describe, expect, it } from 'vitest';
import { scientificIngestionContracts } from './scientific-sources';
import { occurrenceEvidenceOverlays, reviewedOccurrenceRecords } from './selected-water-opportunity';

function immutableGraphViolations(value: unknown, path: string, seen = new WeakSet<object>()): string[] {
  if (value === null || typeof value !== 'object' || seen.has(value)) return [];
  seen.add(value);
  const violations: string[] = [];
  if (!Object.isFrozen(value)) violations.push(`${path} is not frozen`);
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
    const childPath = `${path}.${String(key)}`;
    if (!('value' in descriptor)) violations.push(`${childPath} is an accessor`);
    else violations.push(...immutableGraphViolations(descriptor.value, childPath, seen));
  }
  return violations;
}

function snapshot(value: unknown): string {
  return JSON.stringify(value);
}

describe('mutable public-export production boundary', () => {
  it('recursively freezes direct scientific contracts and selected-water evidence against public attacks', () => {
    const exportsUnderAudit = {
      scientificIngestionContracts,
      reviewedOccurrenceRecords,
      occurrenceEvidenceOverlays,
    } as const;
    const canonical = Object.fromEntries(Object.entries(exportsUnderAudit).map(([name, value]) => [name, snapshot(value)]));
    const appVisibleOverlayLegend = occurrenceEvidenceOverlays[0].legend;
    const violations = Object.entries(exportsUnderAudit).flatMap(([name, value]) => immutableGraphViolations(value, name));

    const attempt = (attack: () => unknown) => { try { attack(); } catch { /* rejection is the expected frozen-boundary behavior */ } };
    attempt(() => Reflect.set(scientificIngestionContracts.occurrence.requiredFields as unknown as string[], '0', 'attackerField'));
    attempt(() => Reflect.set(reviewedOccurrenceRecords[0].spatialApplicability.limitations as unknown as string[], '0', 'attacker limitation'));
    attempt(() => Reflect.set(occurrenceEvidenceOverlays[0] as unknown as Record<string, unknown>, 'legend', 'ATTACKER OVERLAY LEGEND'));
    attempt(() => Reflect.apply(Array.prototype.push, reviewedOccurrenceRecords[0].limitations as unknown as unknown[], ['attacker push']));
    attempt(() => Reflect.apply(Array.prototype.push, occurrenceEvidenceOverlays as unknown as unknown[], [{ id: 'overlay:attacker' }]));
    attempt(() => Reflect.defineProperty(scientificIngestionContracts.occurrence, 'attackerKey', { value: true, enumerable: true }));
    attempt(() => Reflect.defineProperty(reviewedOccurrenceRecords[0], 'attackerKey', { value: true, enumerable: true }));
    attempt(() => Reflect.defineProperty(occurrenceEvidenceOverlays[0], 'attackerKey', { value: true, enumerable: true }));
    attempt(() => Reflect.setPrototypeOf(scientificIngestionContracts.conditions, { attacker: true }));
    attempt(() => Reflect.setPrototypeOf(reviewedOccurrenceRecords[0].queryGeometry, { attacker: true }));
    attempt(() => Reflect.setPrototypeOf(occurrenceEvidenceOverlays[0].geometry, { attacker: true }));

    const pollutionKey = '__bayBiteInheritedPollution__';
    Object.defineProperty(Object.prototype, pollutionKey, { value: 'attacker', configurable: true });
    try {
      for (const value of Object.values(exportsUnderAudit)) {
        expect(Object.prototype.hasOwnProperty.call(value, pollutionKey)).toBe(false);
      }
      expect(occurrenceEvidenceOverlays.filter((overlay) => overlay.spotId === occurrenceEvidenceOverlays[0].spotId)[0].legend).toBe(appVisibleOverlayLegend);
      for (const [name, value] of Object.entries(exportsUnderAudit)) expect(snapshot(value), `${name} changed after attack`).toBe(canonical[name]);
      expect(violations, violations.join('\n')).toEqual([]);
    } finally {
      Reflect.deleteProperty(Object.prototype, pollutionKey);
    }
  });
});
