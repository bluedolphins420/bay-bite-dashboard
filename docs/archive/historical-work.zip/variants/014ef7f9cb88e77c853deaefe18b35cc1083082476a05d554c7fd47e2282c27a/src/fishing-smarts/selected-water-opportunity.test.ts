import { describe, expect, it } from 'vitest';
import { spots } from '../data';
import { buildScientificStatusExport, buildSelectedWaterOpportunity, occurrenceEvidenceOverlays, reviewedOccurrenceRecords } from './selected-water-opportunity';

const conditions = {
  status: 'live' as const,
  observedAt: '2026-08-13T17:30:00Z',
  windSpeedKt: '7 kt', waveHeightFt: '2.0 ft',
  observations: {
    level: { availability: 'available' as const, freshness: 'live' as const }, wind: { availability: 'available' as const, freshness: 'live' as const }, buoy: { availability: 'available' as const, freshness: 'live' as const }, wave: { availability: 'available' as const, freshness: 'live' as const }, temperature: { availability: 'unavailable' as const, freshness: 'unavailable' as const },
  },
  stationName: 'fixture', buoyId: 'fixture', waveLabel: 'Significant wave height', message: 'fixture',
};

describe('selected-water scientific opportunity integration', () => {
  it('connects exact taxa at accepted coast and SF Bay spots without using static legacy scores', () => {
    const lindaMar = spots.find((spot) => spot.id === 'linda-mar')!;
    const crissy = spots.find((spot) => spot.id === 'crissy-field')!;
    const coast = buildSelectedWaterOpportunity(lindaMar, conditions, '2026-08-13T18:00:00Z');
    const bay = buildSelectedWaterOpportunity(crissy, conditions, '2026-08-13T18:00:00Z');
    expect(coast.map((item) => item.taxonId)).toEqual(expect.arrayContaining(['species:barred-surfperch','species:striped-bass']));
    expect(bay.map((item) => item.taxonId)).toEqual(expect.arrayContaining(['species:california-halibut','species:striped-bass']));
    expect(JSON.stringify({ coast, bay })).not.toContain(`"score":${lindaMar.score}`);
    expect(JSON.stringify({ coast, bay })).not.toMatch(/bestWindow|biteReason/);
  });

  it('never turns aggregate Surfperch into barred surfperch and labels exact evidence exactly', () => {
    const lindaMar = spots.find((spot) => spot.id === 'linda-mar')!;
    const aggregateOnly = { ...lindaMar, id: 'aggregate-only-fixture', stableId: 'spot:aggregate-only-fixture' as const, species: ['Surfperch' as const] };
    const aggregate = buildSelectedWaterOpportunity(aggregateOnly, conditions, '2026-08-13T18:00:00Z')[0];
    expect(aggregate).toMatchObject({ taxonId: 'species:surfperch', result: { status: 'insufficient-data' } });
    const oceanBeach = spots.find((spot) => spot.id === 'ocean-beach')!;
    const exact = buildSelectedWaterOpportunity(oceanBeach, conditions, '2026-08-13T18:00:00Z').find((item) => item.taxonId === 'species:barred-surfperch')!;
    expect(exact.displayLabel).toBe('Barred surfperch');
    expect(exact.result.factors.historicalOccurrencePrior).toBe('favorable');
  });

  it('leaves unsupported legacy labels explicitly insufficient instead of synthesizing science', () => {
    const spot = spots.find((item) => item.species.some((species) => species === 'Rockfish'))!;
    const results = buildSelectedWaterOpportunity(spot, conditions, '2026-08-13T18:00:00Z');
    const unsupported = results.find((item) => item.displayLabel === 'Rockfish')!;
    expect(unsupported.result).toMatchObject({ status: 'insufficient-data', opportunityBand: undefined });
    expect(unsupported.result.reasons.join(' ')).toMatch(/not yet modeled/i);
  });

  it('preserves upstream non-actionable legality and treats conditional access as unresolved', () => {
    const lindaMar = spots.find((spot) => spot.id === 'linda-mar')!;
    const results = buildSelectedWaterOpportunity(lindaMar, conditions, '2026-08-13T18:00:00Z');
    for (const item of results.filter((item) => ['species:striped-bass','species:california-halibut','species:barred-surfperch'].includes(item.taxonId))) expect(item.result).toMatchObject({ status: 'not-targetable' });
    expect(results.flatMap((item) => item.result.reasons).join(' ')).toMatch(/unresolved|fails closed/i);
  });

  it('does not reuse family-level surfperch legality as an exact barred-surfperch rule', () => {
    const lindaMar = spots.find((spot) => spot.id === 'linda-mar')!;
    const barred = buildSelectedWaterOpportunity(lindaMar, conditions, '2026-08-13T18:00:00Z').find((item) => item.taxonId === 'species:barred-surfperch')!;
    expect(barred.result).toMatchObject({ status: 'not-targetable', factors: { legalGate: 'unknown' } });
    expect(barred.result.reasons.join(' ')).toMatch(/unresolved|fails closed/i);
  });

  it('provides versioned historical evidence and public-resolution map overlay records without sensitive coordinates', () => {
    expect(reviewedOccurrenceRecords.some((record) => record.spotId === 'spot:linda-mar')).toBe(true);
    expect(reviewedOccurrenceRecords.some((record) => record.spotId === 'spot:crissy-field')).toBe(true);
    for (const record of reviewedOccurrenceRecords) {
      expect(record.geometry.publicResolution).toBeTruthy();
      expect(record).not.toHaveProperty('coordinates');
      expect(record.timeCoverage.reviewedAt).toMatch(/^\d{4}-\d{2}-\d{2}/);
      expect(record.limitations.join(' ')).toMatch(/historical|not current|does not/i);
    }
    expect(occurrenceEvidenceOverlays.length).toBeGreaterThanOrEqual(2);
    expect(occurrenceEvidenceOverlays.every((overlay) => overlay.legend.startsWith('Historical occurrence area'))).toBe(true);
    expect(occurrenceEvidenceOverlays.every((overlay) => ['area','cell'].includes(overlay.geometry.kind))).toBe(true);
  });

  it('exports scientific status without legacy score, window, reason, or tactics fields', () => {
    const lindaMar = spots.find((spot) => spot.id === 'linda-mar')!;
    const exported = buildScientificStatusExport(lindaMar, conditions, '2026-08-13T18:00:00Z');
    expect(exported.selectedWater).toEqual({ id: 'linda-mar', stableId: 'spot:linda-mar', name: 'Linda Mar / Pacifica State Beach', region: 'Peninsula', type: 'Surf' });
    const keys:string[]=[];
    const collect=(value:unknown):void=>{ if (!value||typeof value!=='object') return; for (const [key,child] of Object.entries(value)) { keys.push(key); collect(child); } };
    collect(exported);
    expect(keys).not.toEqual(expect.arrayContaining(['score','bestWindow','biteReason','tactics']));
  });
});
