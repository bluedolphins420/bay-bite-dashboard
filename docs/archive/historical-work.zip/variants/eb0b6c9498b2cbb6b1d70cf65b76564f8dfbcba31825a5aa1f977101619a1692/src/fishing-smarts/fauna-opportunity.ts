import type { EligibilityResult, StableId } from './index';

export type ExactTaxonId = 'species:striped-bass' | 'species:california-halibut' | 'species:barred-surfperch';
export type EvidenceGrade = 'A' | 'B' | 'C';
export type FactorFit = 'favorable' | 'mixed' | 'adverse' | 'unknown';

export interface EvidenceCitation {
  sourceId: StableId;
  supports: string;
  grade: EvidenceGrade;
  limitations: string;
}

export interface ExactTaxonScienceRecord {
  id: ExactTaxonId;
  commonName: string;
  scientificName: string;
  lifeStages: Array<{ stage: string; waterAndSalinity: string[]; substrateStructureDepth: string[] }>;
  habitat: { compatible: StableId[]; incompatible: StableId[]; nuances: string[] };
  seasonalPhenology: string[];
  dielLight: string[];
  forageGuilds: string[];
  feedingMode: string;
  conditionResponses: Array<{ input: 'current'|'wave'|'wind'|'clarity'|'light'; rule: string; uncertainty: string }>;
  shorePresentations: Array<{ forageGuilds: string[]; habitats: StableId[]; lureFamily: string; profileSize: string; depthZone: string; retrieve: string; rigWeight: string }>;
  evidence: EvidenceCitation[];
  uncertainty: string[];
}

const CDFW_HALIBUT = 'source:cdfw-california-halibut-esr' as StableId;
const CDFW_STRIPER = 'source:wildlife-ca-gov-fishing-inland-striped-bass' as StableId;
const CDFW_SURFPERCH = 'source:marinespecies-wildlife-ca-gov-barred-surfperch-and-redtail-surfperch-true' as StableId;

export const exactTaxonScience: Record<ExactTaxonId, ExactTaxonScienceRecord> = {
  'species:striped-bass': {
    id: 'species:striped-bass', commonName: 'Striped bass', scientificName: 'Morone saxatilis',
    lifeStages: [
      { stage: 'juvenile', waterAndSalinity: ['fresh to estuarine'], substrateStructureDepth: ['shoals, channel margins, marsh-edge water'] },
      { stage: 'adult', waterAndSalinity: ['fresh to marine'], substrateStructureDepth: ['channels, current seams, beaches, rip edges'] },
    ],
    habitat: { compatible: ['habitat:surf','habitat:pier','habitat:jetty','habitat:breakwater','habitat:bay-shore','habitat:tidal-slough','habitat:estuary','habitat:estuary-mouth'], incompatible: [], nuances: ['Coast opportunity requires a fishable beach/current feature and local historical evidence; Bay and estuary use does not imply every slough is equally suitable.'] },
    seasonalPhenology: ['Anadromous movements and Bay/coast use vary among resident and migratory contingents; season is supporting context, not a presence claim.'],
    dielLight: ['Lower light can change presentation contrast, but light alone does not establish feeding activity.'],
    forageGuilds: ['small pelagic fish','estuarine forage fish','surf crustaceans'], feedingMode: 'mobile visual and vibration-oriented predator',
    conditionResponses: [
      { input:'current', rule:'Prefer a fishable seam or moving-water edge over featureless or unsafe current.', uncertainty:'Direction and speed without local geometry may be insufficient.' },
      { input:'clarity', rule:'Use stronger silhouette or vibration in reduced clarity; natural translucence in clearer water.', uncertainty:'Clarity may be a qualitative proxy.' },
      { input:'light', rule:'Use contrast appropriate to ambient light; do not infer presence from dawn or dusk.', uncertainty:'Artificial light and cloud can alter the proxy.' },
      { input:'wave', rule:'Open-coast wave conditions affect shore fishability and access to troughs.', uncertainty:'Offshore buoy readings may be only regional.' },
      { input:'wind', rule:'Wind affects casting control and line management, not biological presence by itself.', uncertainty:'Exposure depends on shoreline orientation.' },
    ],
    shorePresentations: [{ forageGuilds:['small pelagic fish','estuarine forage fish'], habitats:['habitat:surf','habitat:bay-shore','habitat:estuary-mouth','habitat:pier'], lureFamily:'minnow plug, spoon, or paddle-tail', profileSize:'small-to-medium forage profile', depthZone:'surface-to-midwater or along a visible seam', retrieve:'steady or sweep-and-pause while maintaining control', rigWeight:'unweighted plug or jig head selected only to hold depth and casting control' }],
    evidence:[{ sourceId:CDFW_STRIPER, supports:'Exact-taxon life history, movement, and shore fishery context.', grade:'A', limitations:'Regional biology does not prove local or current presence.' }],
    uncertainty:['Historical occurrence is a prior only.','Only explicit habitat, occurrence, legal, condition, and fishability factors are evaluated.'],
  },
  'species:california-halibut': {
    id:'species:california-halibut', commonName:'California halibut', scientificName:'Paralichthys californicus',
    lifeStages:[{stage:'juvenile',waterAndSalinity:['estuarine to marine'],substrateStructureDepth:['shallow soft-bottom nursery, eelgrass edge']},{stage:'adult',waterAndSalinity:['marine and bay'],substrateStructureDepth:['sand or mud flats, channels, sand beside structure']}],
    habitat:{compatible:['habitat:surf','habitat:pier','habitat:bay-shore','habitat:estuary-mouth'],incompatible:['habitat:tidal-slough','habitat:rocky-shore'],nuances:['Pier compatibility means fishable soft bottom near the structure, not pilings or rock alone.','Broad Bay shoreline labels require soft-bottom or eelgrass/channel-edge evidence.']},
    seasonalPhenology:['Inshore and Bay use can vary seasonally and by life stage; season is contextual rather than a fixed numeric threshold.'],
    dielLight:['Light and clarity alter ambush-presentation visibility but are not bite multipliers.'],
    forageGuilds:['small pelagic fish','gobies and demersal fish','small squid'],feedingMode:'soft-bottom ambush predator',
    conditionResponses:[{input:'current',rule:'Keep a controlled presentation near bottom; excessive current can make shore contact ineffective.',uncertainty:'Local depth and bottom relief are required to interpret current.'},{input:'clarity',rule:'Natural profiles suit clearer water; stronger silhouette may remain visible in reduced clarity.',uncertainty:'Clarity proxy is qualitative.'},{input:'light',rule:'Adjust contrast without inferring feeding activity.',uncertainty:'Cloud and depth alter available light.'},{input:'wave',rule:'Shorebreak and surge can block safe bottom contact.',uncertainty:'Regional wave data may not resolve the beach.'},{input:'wind',rule:'Wind matters through casting and bottom-contact control.',uncertainty:'Shore orientation is required.'}],
    shorePresentations:[{forageGuilds:['small pelagic fish','gobies and demersal fish'],habitats:['habitat:surf','habitat:bay-shore','habitat:estuary-mouth','habitat:pier'],lureFamily:'paddle-tail or fluke-style soft plastic',profileSize:'small-to-medium forage-fish profile',depthZone:'near bottom over soft substrate',retrieve:'slow swim, short lift, or controlled drag that preserves bottom proximity',rigWeight:'jig head or drop-shot weight selected to maintain bottom contact without excessive weight'}],
    evidence:[{sourceId:CDFW_HALIBUT,supports:'Exact-taxon biology, fishery, and estuarine/soft-bottom habitat context.',grade:'A',limitations:'Regional habitat use does not establish presence at a spot.'}],
    uncertainty:['Exact substrate and depth are often unresolved at public shore-point scale.','Presentation guidance remains qualitative and avoids unsupported precision.'],
  },
  'species:barred-surfperch': {
    id:'species:barred-surfperch',commonName:'Barred surfperch',scientificName:'Amphistichus argenteus',
    lifeStages:[{stage:'juvenile and adult',waterAndSalinity:['marine surf zone'],substrateStructureDepth:['open sandy beach, inner trough, shallow subtidal sand']}],
    habitat:{compatible:['habitat:surf'],incompatible:['habitat:tidal-slough','habitat:bay-shore','habitat:estuary','habitat:rocky-shore'],nuances:['Nearby Bay or estuary observations do not substitute for open sandy surf habitat.']},
    seasonalPhenology:['Surf-zone residency and reproduction vary seasonally; season alone does not establish local presence.'],
    dielLight:['Available light can guide contrast choice but is not a generic feeding multiplier.'],
    forageGuilds:['surf-zone crustaceans','marine worms','small benthic invertebrates'],feedingMode:'benthic forager in mobile sandy surf',
    conditionResponses:[{input:'current',rule:'A manageable trough or wash allows a small presentation to stay in the feeding zone.',uncertainty:'Current is inferred from local surf structure when not measured.'},{input:'wave',rule:'Unsafe or uncontrollable shorebreak blocks a practical presentation.',uncertainty:'Buoy wave height does not resolve shorebreak.'},{input:'wind',rule:'Crosswind can make light rigs uncontrollable.',uncertainty:'Beach orientation matters.'},{input:'clarity',rule:'Natural colors suit clearer wash; contrast can help in turbid foam.',uncertainty:'Qualitative proxy only.'},{input:'light',rule:'Adjust contrast to visibility; do not infer presence from time alone.',uncertainty:'Cloud and foam change light.'}],
    shorePresentations:[{forageGuilds:['surf-zone crustaceans','marine worms'],habitats:['habitat:surf'],lureFamily:'small crustacean- or worm-profile soft plastic',profileSize:'small benthic-invertebrate profile',depthZone:'inner trough and lower wash near sand',retrieve:'slow drift or short controlled pulls with bottom proximity',rigWeight:'light sliding-sinker or single-hook rig weighted only enough to hold the selected trough'}],
    evidence:[{sourceId:CDFW_SURFPERCH,supports:'Exact barred-surfperch identification and surf fishery context.',grade:'A',limitations:'Species page does not establish occurrence at a selected beach today.'}],
    uncertainty:['Family-level surfperch labels must not be treated as exact barred surfperch.','Only directly supported ecological and fishability factors are evaluated.'],
  },
};

export interface HistoricalOccurrenceEvidence {
  id: StableId; taxonId: ExactTaxonId; spotId: StableId; sourceId: StableId;
  geometry: { kind:'area'|'station'|'cell'; publicResolution:string; geometryRef?:string; stationId?:string };
  timeCoverage: { start?:string; end?:string; reviewedAt:string };
  method?:string; effort?:string; lifeStage?:string; spatialResolution:string; evidenceGrade:EvidenceGrade; limitations:string[];
}

export interface OpportunityConditions {
  observedAt:string;
  current?: { state:'slack'|'manageable'|'strong'|'unknown'; sourceId:StableId };
  wave?: { state:'calm'|'manageable'|'rough'|'unknown'; sourceId:StableId };
  wind?: { state:'light'|'manageable'|'strong'|'unknown'; sourceId:StableId };
  clarity?: 'clear'|'moderate'|'turbid'|'unknown';
  light?: 'bright'|'low'|'dark'|'unknown';
}

export interface OpportunityInput {
  taxonId: StableId; spotId: StableId; habitatIds:StableId[]; environmentClass:string; evaluatedAt:string;
  occurrence?:HistoricalOccurrenceEvidence[]; conditions?:OpportunityConditions;
  legal:EligibilityResult; access:{state:'open'|'closed'|'unknown'}; mpa:{resolved:boolean; intersectsNoTake:boolean};
}

export interface PresentationRecommendation { lureFamily:string; profileSize:string; colorContrast:string; depthZone:string; retrieve:string; rigWeight:string; why:string; shorePracticality:string; safetyBlockers:string[] }
export interface OpportunityResult {
  taxonId:StableId; status:'scored'|'insufficient-data'|'not-targetable'; opportunityBand?:'lower'|'conditional'|'higher'; confidence:'low'|'medium'|'high';
  factors:{historicalOccurrencePrior:FactorFit;habitatFit:FactorFit;conditionFit:FactorFit;legalGate:'open'|'blocked'|'unknown';lureFishability:FactorFit};
  confidenceCoverage:{occurrenceEvidence:'missing'|'partial'|'complete';habitatEvidence:'missing'|'partial'|'complete';conditionEvidence:'missing'|'partial'|'complete';legalAccessMpa:'missing'|'partial'|'complete'};
  confidenceReasons:string[]; missingInputs:string[];
  contributions:Array<{factor:string;effect:FactorFit;reason:string}>; reasons:string[]; caveats:string[]; presentations:PresentationRecommendation[]; livePresenceClaim:false;
}

const supported = (id:StableId): id is ExactTaxonId => id in exactTaxonScience;
const unknownConditions = (c:OpportunityConditions) => [c.current?.state,c.wave?.state,c.wind?.state,c.clarity,c.light].some((value)=>!value||value==='unknown');

export function evaluateSpeciesOpportunity(input:OpportunityInput):OpportunityResult {
  const legalGate: OpportunityResult['factors']['legalGate']=input.legal.status==='open'&&input.legal.actionable?'open':input.legal.status==='unknown'?'unknown':'blocked';
  const gateBlocked=input.access.state==='closed'||input.mpa.intersectsNoTake||legalGate==='blocked';
  const gateUnknown=input.access.state==='unknown'||!input.mpa.resolved||legalGate==='unknown';
  const conditionNames = ['current','wave','wind','clarity','light'] as const;
  const missingConditions = conditionNames.filter((name) => {
    if (!input.conditions) return true;
    const value = name === 'clarity' || name === 'light' ? input.conditions[name] : input.conditions[name]?.state;
    return !value || value === 'unknown';
  });
  const age=input.conditions?new Date(input.evaluatedAt).getTime()-new Date(input.conditions.observedAt).getTime():Number.POSITIVE_INFINITY;
  const stale=!Number.isFinite(age)||age<0||age>3*60*60*1000;
  const missingInputs=[...missingConditions, ...(stale&&input.conditions?['fresh condition observations']:[]), 'habitat evidence geometry', ...(input.access.state==='unknown'?['access status']:[]), ...(!input.mpa.resolved?['MPA geometry']:[]), ...(legalGate==='unknown'?['exact legal status']:[])];
  const confidenceCoverage:OpportunityResult['confidenceCoverage']={occurrenceEvidence:'missing',habitatEvidence:'missing',conditionEvidence:!input.conditions||stale?'missing':missingConditions.length?'partial':'complete',legalAccessMpa:gateBlocked||gateUnknown?'missing':'complete'};
  const confidenceReasons=['Habitat evidence geometry is not integrated; catalog habitat labels are ecological context only.',...(confidenceCoverage.conditionEvidence!=='complete'?['Condition evidence is incomplete, unknown, or stale.']:[]),...(confidenceCoverage.legalAccessMpa!=='complete'?['Legal, access, or MPA certainty is blocked or unresolved.']:[])];
  const base = { taxonId:input.taxonId, opportunityBand:undefined, confidence:'low' as const, confidenceCoverage, confidenceReasons, missingInputs, livePresenceClaim:false as const };
  if (!supported(input.taxonId)) return { ...base,status:'insufficient-data',factors:{historicalOccurrencePrior:'unknown',habitatFit:'unknown',conditionFit:'unknown',legalGate,lureFishability:'unknown'},contributions:[],reasons:['This exact taxon is not yet modeled.'],caveats:['No legacy species score is substituted.'],presentations:[] };
  const science=exactTaxonScience[input.taxonId];
  const occurrence=(input.occurrence??[]).filter((item)=>item.taxonId===input.taxonId&&item.spotId===input.spotId);
  confidenceCoverage.occurrenceEvidence=occurrence.some((item)=>item.evidenceGrade==='A')?'complete':occurrence.length?'partial':'missing';
  const prior:FactorFit=occurrence.length?'favorable':'unknown';
  const habitatFit:FactorFit=input.habitatIds.some((id)=>science.habitat.incompatible.includes(id))?'adverse':input.habitatIds.some((id)=>science.habitat.compatible.includes(id))?'favorable':'unknown';
  const missing=!input.conditions||stale||unknownConditions(input.conditions);
  const safetyBlocked=Boolean(input.conditions&&(input.conditions.wave?.state==='rough'||input.conditions.wind?.state==='strong'));
  const conditionFit:FactorFit=missing?'unknown':safetyBlocked?'adverse':'mixed';
  const lureFishability:FactorFit=missing?'unknown':safetyBlocked?'adverse':'favorable';
  const factors={historicalOccurrencePrior:prior,habitatFit,conditionFit,legalGate,lureFishability};
  const contributions=[
    {factor:'historical occurrence prior',effect:prior,reason:occurrence.length?'Reviewed historical evidence supports occurrence in the source area; it does not show live presence.':'No reviewed exact-taxon occurrence record is available for this spot.'},
    {factor:'habitat fit',effect:habitatFit,reason:habitatFit==='favorable'?'Selected habitat is compatible with the modeled life-stage ecology.':habitatFit==='adverse'?'Selected habitat conflicts with the exact-taxon habitat record.':'Habitat support is unresolved.'},
    {factor:'condition suitability',effect:conditionFit,reason:stale?'Condition observations are stale or time-invalid.':missing?'Required condition inputs are missing or unknown.':safetyBlocked?'Wind or waves block safe, controllable shore fishing.':'Conditions permit a controllable presentation; this does not imply fish are present or feeding.'},
    {factor:'lure fishability',effect:lureFishability,reason:lureFishability==='favorable'?'A shore presentation can be controlled in the stated habitat and conditions.':lureFishability==='adverse'?'A safe, controlled shore presentation is blocked.':'Presentation control cannot be assessed.'},
  ];
  const caveats=['Historical evidence is not live presence, abundance, or a catch forecast.',...science.uncertainty];
  if (gateBlocked||gateUnknown) return { ...base,status:'not-targetable',factors,contributions,reasons:[gateBlocked?'A legal, access, or no-take gate blocks targeting.':'Legal, access, or exact MPA status is unresolved; targeting fails closed.'],caveats,presentations:[] };
  if (habitatFit!=='favorable'||prior==='unknown'||missing) return { ...base,status:'insufficient-data',factors,contributions,reasons:['Support is insufficient to assign a relative opportunity band.'],caveats,presentations:[] };
  const opportunityBand:OpportunityResult['opportunityBand']=conditionFit==='adverse'?'lower':conditionFit==='mixed'?'conditional':'higher';
  const presentation=science.shorePresentations.find((item)=>item.habitats.some((id)=>input.habitatIds.includes(id)));
  const colorContrast=input.conditions!.clarity==='turbid'||input.conditions!.light==='dark'?'high-contrast silhouette with a visible or vibration-producing profile':input.conditions!.clarity==='clear'&&input.conditions!.light==='bright'?'natural/translucent forage tones':'moderate natural contrast';
  const rigWeight=input.conditions!.current?.state==='strong'?`Increase to a heavier controllable option from this baseline: ${presentation?.rigWeight ?? 'select only enough weight to maintain control'}`:presentation?.rigWeight;
  const presentations=presentation&&!safetyBlocked?[{lureFamily:presentation.lureFamily,profileSize:presentation.profileSize,colorContrast,depthZone:presentation.depthZone,retrieve:presentation.retrieve,rigWeight:rigWeight!,why:`Matches ${science.feedingMode} and likely ${science.forageGuilds.join(', ')} in the supported habitat.`,shorePracticality:'Use only enough weight to maintain control; stop if footing, casting, or line control becomes unsafe.',safetyBlockers:[]}]:[];
  return { ...base,status:'scored',opportunityBand,factors,contributions,reasons:['Relative opportunity reflects reviewed occurrence, habitat compatibility, current condition suitability, and shore fishability.'],caveats,presentations };
}
